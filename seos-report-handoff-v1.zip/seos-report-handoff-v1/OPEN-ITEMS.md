# Open items

What is still open after version 1, 2026-10-12. Every line reference is to `reference/` (byte-identical copies of our
working code, so the line numbers hold). Each item says how it is known:

- **seen**: the words are in the Green Haven documents in `fixtures/green-haven-48/expected/` (counted in the files);
- **shown**: a run on an altered copy of the fixture or model produced it;
- **read**: read from the code and not run.

"Found by" names the builder reports in `parts/` that raised it (A runner and fixture, B data contract, C1 outline and
wording, C2 rules), or the independent check of the assembled package; several found the same thing on their own. Nothing below has been fixed: the reference code is
unchanged, and our rule is that working code changes only with the owner's word.

## 0. Decisions for James

1. **Who fixes the reference code, and when.** Recommended: we fix sections 2, 4 and 5 (and section 6, the 8 defects
   that show in today's Green Haven documents) in our reference code, rebuild Green Haven, and re-issue this package as
   version 2, before SEOS builds this report for any other business. Reason: the contract files, the fixture's expected
   outputs and the conformance test are all generated from the reference, so fixing it there keeps one source of truth.
   Section 6 changes Green Haven's two live documents slightly (the preview site would be republished). Dan can start on
   section 1 and on wiring the runner in the meantime; nothing there waits on these fixes.
2. **The Compare switch in the Action Plan** (N1). It opens "on" today; the code's own comment says "off" in the
   Service view. Which is meant? Changing it changes behaviour on open, not the file's text.
3. **Businesses outside cannabis.** If SEOS will run this report for other trades, section 3 is needed (one "vertical
   profile" per trade). If not yet, only V1 is needed now (it misfires for any vertical the code does not know).

## 1. SEOS side (for Dan)

- **S1. Another account's readings in a business's answer.** `GET /businesses/48/full-audit-result` carries 4 Google
  Analytics and Search Console readings of 2 other accounts' websites, plus 24 readings bought for other reports (Oct 5
  and Oct 6, 2026), all 24 about businesses hundreds of miles away. The report uses none of them and flags them to the
  team (check `answer-scope`, task `answer-isolation`, both team-only and left out of the Action Plan). Fix in SEOS: a
  business's answers hold only that business's readings. In the fixture those 4 rows keep their kind, place, website and
  time, with the request and result emptied (`input/SCRUBBED.md`). Found by A, C2; seen in `expected/report-data.json`.
- **S2. Another market's directory sources.** Green Haven's directory list holds 10 sources that name Michigan places,
  left over from another store's list; all 10 came back "could not be read". The report leaves them out of every count
  (136 checked, not 146) and flags them (check `directory-sources`). Fix in SEOS: give each source a market in the source
  registry and build each store's list from its own market. Then the `other_market_sources` setting is not needed.
  Found by B; seen in `expected/report-data.json`.
- **S3. Map checks searched from far away.** 31 of the 298 business rows in Green Haven's 3 map checks sit 1,078 to
  1,310 miles away, near where the scan engine searches from (Council Bluffs, Iowa). For "weed near me" they are in a first
  20 at 120 of 121 points, and one reached a top 3 at 66 points. The report reads each list again without them and quotes
  only counts that do not change (check `scan-market`). Fix in SEOS: search from the store's market, or return the vantage
  with each sweep so the report can name it from the data (see G2). Seen in `expected/report-data.json`.
- **S4. Sweeps of the expected searches.** SEOS holds no "weed near me" sweep of Green Haven; the fixture folds in the
  owner's Eagle Eyes scan 320 (`--extra-sweep`). For SEOS to build this report alone, it must sweep each expected search
  (same grid as its other sweeps, in opening hours), for example from `scan_schedules.keywords`. Without one, the report
  shows that search as "not measured" with a team task, and the client copy never mentions it (VARIANTS.md,
  no-weed-scan). Shown.
- **S5. Where the settings live.** Each settings key, and the column SEOS could hold it in, is in `contract/SETTINGS.md`
  ("Where SEOS could store it"). Two notes: `businesses.vertical` is null for Green Haven (fill it), and whether
  `locations.citation_vendor_tag` is the same tag as `agency` was not verified.
- **S6. Whole lists from the table answers.** `engine_sweeps-all.json` and `locations-all.json` must hold every row. The
  extractor counts rows, not the answer's `total` (M12), and paging past 1,000 rows was not tried.

## 2. Green Haven facts written into the code

Each is right for Green Haven, or happens to be, and would print the same words for any other business.

- **G1.** `extract-v2.mjs:926`, task `content-gap`: "for Elizabeth and the towns around it". Fix: `loc.city`. Seen
  (Action Plan). Found by A, B, C1, C2.
- **G2.** `extract-v2.mjs:779`, check `scan-market`: "(its Council Bluffs vantage)". True only while the scan engine
  searches from Council Bluffs; not read from the data. Fix: drop it, or read the vantage from the sweep record (S3). Seen
  (Action Plan). Found by B, C1, C2.
- **G3.** `extract-v2.mjs:915`, task `map-gap`: step 4 says "Check both searches again" while 3 searches are on file
  (wrong already for Green Haven), and step 2 says "the only one that survives its control is the distance from the grid
  centre" (true for Green Haven, 1 of 13 factors, but not computed). Fix: count from the searches; name the factors with
  `survives` true, or say none does. Seen (Action Plan). Found by B, C1, C2.
- **G4.** `extract-v2.mjs:916`, task `expected-search`: "(11 by 11, 2 miles)". Fix: the grid, radius and unit of the
  store's sweeps. Step 3 also tells the team to "Add it to the market file (sweeps-market --extra)", an option of our
  working tree; it should say: run it as a SEOS sweep, or fold an Eagle Eyes export in with `run-report.mjs
  --extra-sweep`. Prints only when an expected search is missing (shown in variant no-weed-scan). Found by A, B, C1, C2,
  and the independent check.
- **G5.** `extract-v2.mjs:925`, task `store-page-check`: "Fix the duplicate meta tags the software found", printed whether
  or not that finding is open. Fix: only when the page checks hold it. Seen (Action Plan). Found by C1, C2.
- **G6.** `extract-v2.mjs:932`, task `junk-links`: "(Search Console is not connected to the software yet.)". Fix: from
  `search.search_console_connected`. Seen (Action Plan). Found by C1, C2.
- **G7.** `extract-v2.mjs:946` and `:1032`: "the first 100 pages" in a task title and "crawl past 100 pages" in a hold,
  while the limit is read as `website.crawl.max`. Fix: use it. Seen (Action Plan). Found by C1, C2.
- **G8.** `extract-v2.mjs:1027`: "rows came back in two of the four parts". Fix: count the parts. Seen (Action Plan).
  Found by C2.
- **G9.** `extract-v2.mjs:869-870`, `build-report.mjs:388, 515, 527`: "the three rivals", "the three stores this report
  follows", "two of the three". True while SEOS names 3 rivals. Fix: `rivals.length`. Seen (both documents). Found by B,
  C1, C2.
- **G10.** `sweeps-market.mjs:284`: `velocity.built_from` says "SEOS has one day of sweeps for this store." for every
  business. Fix: count the sweeps' days. In `market.json` and the model, not printed. Found by A, B.
- **G11.** `sweeps-market.mjs:328`: a note about sweep 352 ("7 minutes before its stated finish") is written into every
  market file. Fix: compute it per sweep, or drop it. In `market.json` and the model, not printed. Found by A, B.
- **G12.** `build-report.mjs:219`: the find-box words for "Full link on the listing" include "charlotte", a town from
  another report. Fix: drop it. Seen (Action Plan's find data). Found by C1, C2.
- **G13.** `extract-v2.mjs:1267-1340` (the `--facts` comparison) and `fixtures/green-haven-48/oracle/gh-facts.mjs:34-40`:
  Green Haven only (slug "green-haven", "weed near me", file names). Production runs do not need `--facts`; it is this
  fixture's independent check. Read. Found by A, B, C1.
- **G14.** `extract-v2.mjs:65-69, 84`: without `--settings` the extractor falls back to a built-in table that knows
  businesses 26 and 48; any other business silently gets no settings. `run-report.mjs` always passes `--settings`. Fix:
  make it required and delete the table. Read. Found by A, B, C1.
- **G15.** `extract-v2.mjs:85-87`: the state-to-zone table holds 22 states; 29 (DC included) are missing, so a business
  there stops with a message unless `settings.timezone` is set: that part fails closed. It also fails open: FL, TX, OR, MI
  and NV span two zones and are mapped whole (the Florida panhandle, El Paso, Malheur County, four western Upper
  Peninsula counties and West Wendover keep the other zone), so a store there gets local times an hour off with no
  message, which moves every map check's opening-hours test. Fix: require `timezone`, or derive it from the location's
  coordinates. Read. Found by A and the independent check.
- **G16.** `extract-v2.mjs:691`; `run-report.mjs:55`, `extract-v2.mjs:49` and `merge-sweep.mjs:20` take
  `tables.locations[0]` (and `sweeps-market.mjs:52` takes the row whose place id `run-report.mjs` gives it, from that same
  row): one store per report; the first location row is the store. Fix: name the store's place id in the settings, or
  have SEOS order the rows. Read. Found by A, B.
- **G17.** `extract-v2.mjs:916`, task `expected-search`, step 1: "Find the "<kw>" scan the owner remembers: it is not in
  the software's records." That is Green Haven's history, printed for any missing expected search; the settings only say
  the search is expected. Fix: "No "<kw>" sweep of this store is in SEOS. Find out whether one was run elsewhere; if not,
  run one." Shown (variant no-weed-scan). Found by the independent check.
- **G18.** `extract-v2.mjs:918` with `:992`, task `client-questions`: "Send the client one email with three questions",
  always the same three, for every business with reviews, links and listings readings, whether or not reviews go
  unanswered or links were bought; "the last two months" is Green Haven's link wave. (V9 covers only the directory names
  in the third question.) Fix: ask about replies only when the reply rate is low, about bought links only when fresh
  seller links exist (and say over how many days), about logins for the listings that matter. Seen (Action Plan). Found
  by the independent check.
- **G19.** `extract-v2.mjs:822`, check `rival-searches`: always "fail", "Counts only", "The record holds how many searches
  each rival's website shows up for, and not which ones." Nothing is read: it would print the same with the rivals'
  searches on file. Fix: derive it from the rivals' `ranked_keywords` readings. Seen (Action Plan). Found by the
  independent check.
- **G20.** `extract-v2.mjs:1148` and `build-report.mjs:427, 432`: "Switched off in this run's settings", "Which searches
  they are", "Not part of this report" are fixed. True for Green Haven (`search.ranked_read` is false); a run that read
  the ranked searches would still tell the client they are not part of the report. Fix: print them only when
  `search.ranked_read` is false, and "switched off" only when the setting says so. Seen (both documents). Found by the
  independent check.
- **G21.** `build-report.mjs:387`, the map checks note, second sentence: "The store's place at each point, its place in
  each point's list and the software's share agree for every check." Printed whatever the data say; when check
  `scan-depth` fails, the note contradicts the check beside it. (W2 is the note's first sentence.) Fix: print it only when
  `scan-depth` passes, else name the checks that disagree. Seen (Action Plan). Found by the independent check.

## 3. Cannabis words and lists

Measured with `vertical` set to "Dental" (VARIANTS.md, other-vertical): the documents still print cannabis, dispensary,
weed or marijuana 130 times (Competitor Analysis) and 158 times (Action Plan). Most are business names, searches and web
addresses from the data; 2 and 7 sentences carry the word in the code's own wording. VARIANTS.md lists all 23 code lines.
Proposed for all of these: one vertical profile (directories, site pattern, name stop words, category ids, review
subjects, wording) named by the settings and read by the three scripts.

- **V1.** `extract-v2.mjs:789-791`: `CATEGORY` knows only Cannabis. For any other vertical the category check is "Not
  measured", yet it still opens task `fix-category`, and "Set the right main category" reaches the client's plan (plan
  item 6 of 11 with "Vape shop"; also with "Dental"). Fix now, whatever is decided on verticals: open the task only when
  `CATEGORY` has the vertical; later, the category ids go in the profile. Shown. Found by A, B, C1, C2.
- **V2.** `extract-v2.mjs:108` (`shortName`) and `sweeps-market.mjs:207`: Weed, Cannabis, Dispensary, Marijuana,
  Recreational (and Provisioning) are cut from business names. Read.
- **V3.** `extract-v2.mjs:283`: the plain town search is "<city> dispensary". Read.
- **V4.** `extract-v2.mjs:335-340`: low-star review subjects include "budtender", "bad weed", "moldy". Read.
- **V5.** `extract-v2.mjs:455`: the age-gate heading test (18, 19, 21). Read.
- **V6.** `extract-v2.mjs:492` and `build-report.mjs:515`: the cannabis site pattern and its chip "Cannabis directory".
  Seen (both documents).
- **V7.** `extract-v2.mjs:594-595`: "The listings that matter" include Weedmaps, Leafly and Dutchie. Read.
- **V8.** `extract-v2.mjs:865`: "is a cannabis article / are cannabis articles". Seen (Action Plan).
- **V9.** `extract-v2.mjs:918`, task `client-questions`: "(Google, Weedmaps, Leafly, Yelp, Apple Maps)". Seen (Action
  Plan).
- **V10.** `extract-v2.mjs:928, 930`: "starting with the core and cannabis ones", "Start with the cannabis sites". Seen
  (Action Plan).
- **V11.** Retail words throughout: "the store", "Ways to shop" (`build-report.mjs:214`), "where to shop" (`:452`), "store
  page". A business that is not a shop would read wrong. Read.

## 4. Missing or odd data: crashes and wrong lines

- **M1.** `check-sweeps-market.mjs:177-180`: with no Google reviews reading for the store, it prints three "MISMATCH
  velocity of the store ..." lines and stops the run, without saying the reading is missing. Fix: test for the reading
  first; say "not measured" and decide whether that stops the run. Shown (variant no-store-reviews). Found by A.
- **M2.** `extract-v2.mjs:1086-1087`: the same case crashes the extractor ("Cannot read properties of null (reading
  'collected_at')"). Fix: guard on the store's pull, mark it "could not be read". Shown. Found by A.
- **M3.** `build-report.mjs:191`: with no `bl_exhaustive` reading for the store the model holds `links: null` and both
  builds crash. Fix: stop in the extractor with a message, or show "not read". Shown. Found by B.
- **M4.** `extract-v2.mjs:254`: a sweep with points but no `engine_sweep_businesses` rows crashes. Fix: stop with "sweep
  <id> has points and no business rows". Shown. Found by B.
- **M5.** `extract-v2.mjs:892` with `build-report.mjs:546, 651`: check `stored-findings` with findings but no tasks names
  no task, the find box points at "tk-null", and the build stops. Fix: always name `store-findings`. Shown on a model copy.
  Found by C2.
- **M6.** `extract-v2.mjs:796`: check `listing-link` can name task `town-page`, which is not defined; the build would stop.
  Not reachable while one store is built. Fix: define it or drop the branch. Read. Found by C2.
- **M7.** `extract-v2.mjs:555, 870`: with no `bl_link_gap` reading, the link-list check passes with 0 instead of "not
  read" (rule 5). Fix: status `na`, "not read". Shown. Found by B.
- **M8.** `extract-v2.mjs:1109`: with no rival front page read, a note ends with an empty list ("front page the night
  before: (the store's page ...)"). Fix: leave the sentence out. Shown (variant no-rival-pages). Found by A.
- **M9.** `extract-v2.mjs:1032`: with no rival crawls, a hold's number reads "score 95.05; " with a trailing separator. Fix:
  add the rivals' part only when there is one. Shown. Found by A.
- **M10.** `extract-v2.mjs:905`: with no other-account readings, the `answer-scope` detail opens "24 more readings ...",
  with nothing before "more". Shown. Found by A.
- **M11.** `extract-v2.mjs:159` (used at 215-216, 226, 773-774): a weekday with no posted hours counts as unknown, not
  closed, so a map check on a closed day is neither flagged nor held. Fix: closed when the timetable exists and the day has
  no hours. Read. Found by C2.
- **M12.** `extract-v2.mjs:767-770`: the list of all sweeps is counted by its rows, not its `total`, so a paged list would
  print a wrong count. Read. Found by B.
- **M13.** `ee-scan-to-seos.mjs:70` (into `sweeps-market.mjs:193`): an Eagle Eyes sweep's `read_at` is the export file's
  modification time. The same export with another file time (git does not keep file times; nor do many copy tools)
  changes `market.json` at 3 paths and the model at 5; the documents do not change. `conformance.mjs` pins the recorded time
  until this is fixed. Fix: take it from the export's content or a `--read-at` argument. Shown. Found by A, B.
- **M14.** `extract-v2.mjs:916` (with 769-770 and 985-988): with two or more expected searches missing, each gets its own
  check and hold, but they all point at one task `expected-search`, whose title, steps and done line name only the first.
  Fix: list them all. Read. Found by the independent check.

## 5. Settings that should be refused

All in `extract-v2.mjs` `settingsFrom` (lines 72-83) unless named. Shown by runs on altered copies of the settings file
(`contract/SETTINGS.md` has each result). Found by B unless named.

- **K1.** `:78`: an empty `brand_terms` list is accepted; lines 568 and 610 then match every string (outside sites with
  the phone and the name went from 9 to 22). Fix: require at least one term.
- **K2.** `:79-80`: `other_market_sources` is not type-checked; `""` or `{}` drops nearly every directory (136 verdicts to
  none). Fix: require a string with a non-blank character.
- **K3.** `:768`: `expected_searches` are compared case-sensitively with the stored keywords, so "Weed Near Me" stops the
  build with a misleading message. Fix: trim and lower-case them.
- **K4.** `:75`, `:76`: a file holding `null` crashes; a quoted id prints "for business 48, not 48". Fix: refuse a
  non-object first; print the type.
- **K5.** `:1248`, `:1254`: patterns are built from the agency name and the expected phrases without escaping. Fix: escape
  with `reEsc` (line 1018). Read. Found by C2.
- **K6.** `sweeps-market.mjs:23`: `--tz` is not checked (a bad zone crashed it) and defaults to America/New_York.
  `run-report.mjs` checks the zone and passes the same one to both scripts. Fix: check it as `extract-v2.mjs:81` does.
  Shown. Found by A, B.

## 6. Defects in today's Green Haven documents

Fixing these changes both live documents (or the Action Plan), so `expected/` is rewritten and the preview republished:
decision 1.

- **W1.** `build-report.mjs:565`: the pattern `/, d+:d+ [AP]M$/` lacks its backslashes, so the "What was read, and when"
  row prints every map check's full time ("Sun, Oct 11, 7:21 PM, Sun, Oct 11, 7:26 PM, Mon, Oct 12, 10:31 AM") instead
  of the days. Fix: `/, \d+:\d+ [AP]M$/`, as on line 229. Seen (both). Found by A, C1, C2.
- **W2.** `build-report.mjs:387` with `extract-v2.mjs:23-24`: the Action Plan says "A far-away business in a point's top 3
  would put that check on hold"; the code holds a check only when the far businesses change the store's own count. "weed
  near me" has one in a top 3 at 66 points and is rightly not held. Fix: the note and the comment, not the rule. Seen
  (Action Plan). Found by C2.
- **W3.** "Check both searches again": see G3. Seen (Action Plan).
- **W4.** `build-report.mjs:313, 315-316`: "it is in the top 3 at none at 0 of 121 points"; factor names lower-cased whole
  ("gbp points at homepage"). Fix: a comma as on line 390; lower-case only the first letter. Seen (Action Plan). Found by
  C1.
- **W5.** `build-report.mjs:538`: the Service table of directory verdicts prints codes ("not-listed", "nap-incomplete").
  Fix: words, as `extract-v2.mjs:644` does. Seen (Action Plan). Found by C1.
- **W6.** `build-report.mjs:213, 399`: "5 stars" on the listing row and Reviews card, "5.0 stars" everywhere else. Fix:
  one decimal. Seen (both). Found by C1.
- **W7.** `extract-v2.mjs:532` (printed at `build-report.mjs:523` in the Action Plan, and through check `link-wave`,
  `extract-v2.mjs:869`, in both documents): shared-title waves print stored dates ("first seen 2026-09-11 to
  2026-10-12"); every other date reads "Oct 11, 2026". Seen (both). Found by C1.
- **W8.** `build-report.mjs:36`: the Action Plan leaves the other-account task out but keeps every task's number, so the
  numbers skip (31, then 33). Fix: renumber after the cut, or say the numbers follow the full report. Seen. Found by C1.

## 7. Rule edges and latent defects (no effect on Green Haven today)

- **E1.** `extract-v2.mjs:1210`: the placed loss line drops "at least" when number 1's count is a floor. Read. C1.
- **E2.** `extract-v2.mjs:431, 435`: the phone speed band reads the raw score but the page prints it rounded (a raw 0.895
  prints "90 of 100" with "Needs a look"). Read. C2.
- **E3.** `extract-v2.mjs:739, 910, 1205`: losses are sorted three times with different tie-breaks; on a tie the headline
  could name another search than the first map and the map-gap task. Fix: one comparator. Read. C2.
- **E4.** `extract-v2.mjs:1030-1031`: the chain-rival hold names a link strength its leak patterns do not cover (not
  printed today). Read. C2.
- **E5.** `build-report.mjs:38-39`: two tests of the Action Plan's orphan gate read fields the model never has, so they
  never fire. Read and confirmed on the model. C2.
- **E6.** `build-report.mjs:29-37` (gate at 676-686): the Action Plan's other-accounts cut matches a text pattern, so
  wording decides what is left out. Measured: with the other-account readings dropped whole, `answer-scope` and
  `answer-isolation` stop matching and stay in (761,380 to 764,637 bytes). Fix: the extractor marks such items with a
  field and the builder cuts by it, keeping the text gate as a second check. Shown. A.
- **E7.** `extract-v2.mjs:820`: check `connected` says "Neither is connected" when one of the two is. Read. C2.
- **E8.** `extract-v2.mjs:799`: `review-count` passes against the smallest store beside it (Green Haven's has 6 ratings).
  Read. C2.
- **E9.** `extract-v2.mjs:837`: check `title` opens no task on watch. Read. C2.
- **E10.** `build-report.mjs:115`: the map subtitle says "every one taken in opening hours" whenever no check is known to
  be outside them, including checks whose hours are unknown. Read. C2.
- **E11.** `mapview.js:110, 122, 125`: "Number 1" in the map's trend tooltip and its every-search table is the first
  business in the field, far-away ones included, while the board, the picker and the extractor never make a far business
  number 1 (`mapview.js:33, 81, 133`; `extract-v2.mjs:269-271`). Where a far business has the most top-3 points, the
  table would disagree with the headline. Not Green Haven's case (Joyleaf has 117; the far business reached 66). Fix: the
  first business in the field that is not far. Read. Found by the independent check.
- **E12.** `extract-v2.mjs:917`, task `rescan-open-hours`: gives Monday's hours as the window for every day (Green Haven
  posts 10 AM to 10 PM on Monday, 9 PM closing on Saturday, 11 AM opening on Sunday). The task opens only when a map check
  ran outside opening hours; Green Haven's three did not, so today's documents do not carry it. Fix: the week's hours.
  Read. Found by C2.
- **E13.** `run-report.mjs:87-91`: a stage that fails after the builds (the class check, the browser check, or the
  Action Plan build after the Competitor Analysis) stops the run but leaves the documents already written in `<out>`.
  SPEC section 12 says to publish only on exit 0 with `<out>/SHA256SUMS` present (written last). Fix, if wanted: write the
  documents under a temporary name and rename them after the last stage. Shown. Found by the independent check.

## 8. Comments and notes that disagree with the code (no effect on output)

- **N1.** `build-report.mjs:12-13` says Compare starts off in the Service view; `client.js:50-53` starts it on in both
  (decision 2).
- **N2.** `extract-v2.mjs:1051-1053`: a "nearby" comparison set no row uses; `:890-891`: a pass wording for `rival-rows`
  that is never emitted.
- **N3.** `extract-v2.mjs:23-24`: the rule 1 comment (see W2). Our working notes (`DATA-NOTES.md`, not in this package)
  still describe the old order "lead with what they built"; the code is loss-first.
- **N4.** `merge-sweep.mjs:33-35`: the merged answer keeps the old `counts` header (nothing reads it).
- **N5.** `report-data.json` `ledger` is built and never printed (`build-report.mjs:45`).
- **N6.** `build-report.mjs` keeps branches for an older High Society file (no `meta.v2`): inert for this report.
- **N7.** `extract-v2.mjs:825, 1151, 1353` and `build-report.mjs:264, 452`: the AI answers tab says SEOS has no
  answer-engine surface yet and nothing was collected; `ai` is a constant `{ collected: false }`. True today; revisit when
  SEOS collects AI answers. Seen (Action Plan; the tab is not in the Competitor Analysis).
- **N8.** `reference/static-password-gate/gate.mjs:42` asks phones for digits (`inputmode="numeric"`). A published gated
  file can be attacked offline: as an estimate, not measured, an 8-digit number falls to one current GPU in about an hour
  at 250,000 PBKDF2-SHA256 rounds, and each extra digit multiplies that by ten. Use a long random passphrase, or serve
  the Action Plan behind SEOS's own login.

## 9. Not verified

- The browser checks (`check-documents.mjs`, conformance without `--no-browser`) ran only on Windows 11 with Chrome at its
  Windows path. The macOS and Linux paths, and running as root (`--no-sandbox`), were not tried.
- Pinning the export's file time needs a file system that keeps milliseconds (NTFS here). On one that does not,
  `conformance.mjs` is written to stop with a message; that was read from the code, not run.
- `run-report.mjs` with more than one `--extra-sweep`: written, not run (one export exists).
- Other businesses, other trades and multi-location brands were not run, beyond the six scripted variants on Green
  Haven's own data. The model schema was inferred from one model and passed on 21 altered ones from the same answers.
- 35 wording entries are branches the Green Haven data does not reach: read from the code, and checked absent from both
  documents, not rendered.
- Paging of `GET /api/data/v1/tables/*` past 1,000 rows; whether `locations.citation_vendor_tag` is the agency tag; any
  Eagle Eyes export other than scan 320.
- Several rules were read from the code and never met by a model that holds them (`RULES.md` section 8 and
  `parts/C2-rules.json` list them).
- About 15 tie-breaks use `localeCompare` without a locale, so they follow the host's default collation. POSIX and Danish
  collation were simulated and gave the same bytes on this fixture; other data could tie differently.
- The rebuild from the raw, unscrubbed SEOS answers (SPEC section 10) was run by the fixture's builder, not by the
  independent check, which could read the raw answers only through the privacy scanner.
