// inputs-census.mjs: what the report chain reads from SEOS, field by field, and how much of it one business's answers hold.
// The list of what is read (tables, reading kinds, columns, JSON paths, which script reads each, which report key it
// feeds, and what happens when it is missing) was written from the code of extract-v2.mjs, sweeps-market.mjs,
// check-sweeps-market.mjs, check-compare-v2.mjs and ee-scan-to-seos.mjs. The counts are computed from the files given.
// It prints counts and names only: never a value from any reading, never a token. Readings about other accounts
// (analytics_watch, gsc_sitemaps) are counted and nothing else; their target is not even read.
// usage: node inputs-census.mjs <business-N.json> <full-audit-N.json> <website-audit-N.json>
//          [--all-sweeps=<engine_sweeps-all.json>] [--locations=<locations-all.json>] [--tables=<tables.json>]
//          [--openapi=<openapi.json>] [--ee=<eagle eyes scan export>] [--json=<out.json>] [--md=<out INPUTS.md>]
//   --md writes INPUTS.md (the prose and the tables, with the counts of these files). Edit this script, not INPUTS.md.
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const [bizPath, fullPath, webPath] = argv.filter(a => !a.startsWith('--'));
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
const die = m => { console.error('CENSUS FAILED: ' + m); process.exit(1); };
if (!bizPath || !fullPath || !webPath) { console.error('usage: node inputs-census.mjs <business-N.json> <full-audit-N.json> <website-audit-N.json> [--all-sweeps=] [--locations=] [--tables=] [--openapi=] [--ee=] [--json=] [--md=]'); process.exit(2); }
const load = p => { let raw; try { raw = fs.readFileSync(p); } catch (e) { die(`cannot read ${p}: ${e.code || e.message}`); } try { return { json: JSON.parse(raw.toString('utf8')), bytes: raw.length, file: path.basename(p) }; } catch (e) { die(`${path.basename(p)} is not JSON: ${e.message}`); } };

// ---------- paths: "a.b" key, "a[]" every item of an array, "*" every key, "~re" every key matching re ----------
const vals = (o, p) => {
  let cur = [o];
  for (const seg of p.split('.')) {
    const next = [];
    for (const x of cur) {
      if (x === null || x === undefined || typeof x !== 'object') continue;
      if (seg === '*') next.push(...Object.values(x));
      else if (seg.startsWith('~')) { const re = new RegExp(seg.slice(1)); for (const [k, v] of Object.entries(x)) if (re.test(k)) next.push(v); }
      else if (seg.endsWith('[]')) { const a = x[seg.slice(0, -2)]; if (Array.isArray(a)) next.push(...a); }
      else next.push(x[seg]);
    }
    cur = next;
  }
  return cur;
};
const present = (o, p) => vals(o, p).some(v => v !== null && v !== undefined);

// ---------- the scripts ----------
const BY = { E: 'extract-v2.mjs', S: 'sweeps-market.mjs', CS: 'check-sweeps-market.mjs', CC: 'check-compare-v2.mjs', M: 'merge-sweep.mjs', EE: 'ee-scan-to-seos.mjs' };

// ---------- GET /api/data/v1/businesses/{id}: the tables the chain reads ----------
// rows: which rows are read. cols: [column or JSON path in a row, read by, what it feeds]. missing: what happens without rows.
const TABLES = [
  { table: 'businesses', rows: 'the first row', missing: 'extract-v2 stops: "no business row".',
    cols: [['id', 'E', 'business.id, stores[0].id. Both audit answers and the settings file must carry the same id, else the build stops'],
      ['name', 'E S CS', 'business.register_name; the short name when settings give none (shortName); the store\'s short name in the market file'],
      ['vertical', 'E', 'business.vertical (settings.vertical fills it when empty); the category check'],
      ['brand_slug', 'S', 'market.directories.rows[store].slug']] },
  { table: 'locations', rows: 'the first row (sweeps-market: the row whose place_id is the store place id it is given)', missing: 'extract-v2 stops: "no location row". sweeps-market stops: "the business data is about another store: no location row for <id>".',
    cols: [['place_id', 'E S CS CC M', 'the store. It must be the run\'s subject, else "the run is about another place than the location row"'],
      ['state', 'E', 'the time zone from the state table when settings.timezone is not given, else "no time zone known for state <XX>: give settings.timezone"'],
      ['city', 'E S', 'business.city, stores[0].label, the town-search match, the headline when no search is usable; town words cut from short names'],
      ['street', 'E', 'business.street; the store\'s street-number pattern for listings when the reading has no street_regex'],
      ['zip', 'E', 'business.zip'],
      ['phone', 'E', 'business.phone when the Google listing has none; the phone pattern when phone_e164 is empty'],
      ['phone_e164', 'E', 'the store\'s phone pattern for the listings around the web'],
      ['website', 'E', 'business.website; business.domain when the Google listing has no domain'],
      ['named_rivals[].place_id', 'E', 'matches a rival to its named website'],
      ['named_rivals[].website', 'E', 'a rival\'s domain when its Google listing has none'],
      ['lat', 'S CS', 'the store\'s point: every distance and the 150-mile line (sweeps-market stops without it: "the store\'s own location has no coordinates")'],
      ['lng', 'S CS', 'as lat'],
      ['name', 'S', 'the store\'s name when its Google listing has no title']] },
  { table: 'audit_runs', rows: 'every row; the one with the most steps is the run the report is built on', missing: 'extract-v2 stops: "no audit run in the record", or "run names no subject" when its businesses list has no subject.',
    cols: [['id', 'E', 'meta.run_id. The full-audit answer\'s audit_runs[0].id must be the same, else "the full-audit answer is about run <x>, the record\'s main run is <y>"'],
      ['started_at', 'E', 'meta.report_date, meta.run_started; the 30-day window for new linking sites; the 3-day line for old readings'],
      ['finished_at', 'E', 'meta.run_finished'],
      ['scan_id', 'E', 'maps.scan_id; the sweep the run used (maps.board, compare.listings)'],
      ['keyword', 'E', 'maps.phrase; the main search: the search of this phrase is the one the map-listed check and its hold use, and map.main is the market file\'s row of it (else the search checked most often)'],
      ['request.parts', 'E', 'meta.parts; search.ranked_setting, search.organic_ranks_setting'],
      ['businesses[].place_id', 'E', 'you, rivals (one per business that is not the subject)'],
      ['businesses[].is_subject', 'E', 'which business is the store'],
      ['businesses[].slug', 'E', 'you.id, rivals[].id (the ids every comparison entry uses)'],
      ['businesses[].name', 'E', 'a rival\'s name when its Google listing has none'],
      ['businesses[].solv', 'E', 'you.map_share, rivals[].map_share'],
      ['steps[].part', 'E', 'the rival-rows check (parts reviews, site_audits, page_speed, exhaustive, cit_pages); meta.steps'],
      ['steps[].place_id', 'E', 'whose step it is'],
      ['steps[].state', 'E', 'the rival-rows check: every rival step must be done'],
      ['steps[].note', 'E', 'reviews_collect notes: "<n> reviews collected" and "capped" give each rival\'s review count and the collection limit (rule 4)']] },
  { table: 'engine_sweeps', rows: 'extract-v2: every row in the answer; sweeps-market: the rows whose subject is the store', missing: 'extract-v2: no map check from the record (maps.sweeps empty, maps.* null); the market file\'s searches still count. sweeps-market stops: "no sweep of this store in the input".',
    cols: [['scan_id', 'E S CS', 'maps.sweeps[].id, the search keys (scan-<id>, seos-<id>)'],
      ['subject', 'S CS', 'a sweep about another store is skipped'],
      ['keyword', 'E S CS', 'maps.sweeps[].kw, maps.searches[].kw (lower case); a phrase under 3 letters is skipped by sweeps-market'],
      ['grid_size', 'E S CS', 'maps.sweeps[].grid, grid_points, excluded; the grid layout'],
      ['radius', 'E S', 'maps.sweeps[].radius; market.geoms[].radius'],
      ['unit', 'E S', 'maps.sweeps[].unit'],
      ['total_points', 'E S CS', 'a hold reason when it differs from the points held; sweeps-market stops: "SEOS says <n> points, the record holds <m>"'],
      ['found_points', 'S CS', 'must equal the store\'s listed points, else sweeps-market stops'],
      ['solv', 'S CS', 'the store\'s share in the header must equal its top-3 points, else sweeps-market stops'],
      ['arp', 'S', 'market.scans[].seos.stated; a note when it differs'],
      ['atrp', 'S', 'market.scans[].seos.stated'],
      ['exclusion_note', 'E S', 'maps.sweeps[].exclusion_note; sweeps-market reads "<n> of the <m> grid points were excluded" and stops when it does not match the missing points'],
      ['started_how', 'E S', 'maps.sweeps[].started_how, maps.mode'],
      ['finished_at', 'E S CS', 'when each check ran (store time); the opening-hours test; the distance-fit cut'],
      ['read_at', 'S', 'market.scans[].seos.read_at']] },
  { table: 'engine_sweep_cells', rows: 'one row per sweep', missing: 'extract-v2: a sweep with no cells has 0 points and leaves the searches. sweeps-market skips it: "its points are not in the record".',
    cols: [['scan_id', 'E S CS CC', 'the sweep the points belong to'],
      ['cells[].top', 'E S CS CC', 'each point\'s list of businesses, best first. The first 20 are read: top-3 and listed counts, places, the field, the far-business test'],
      ['cells[].rank', 'E S CS', 'the store\'s rank field: a second reading of its place (a hold when it disagrees); not-found points'],
      ['cells[].row', 'S CS', 'the grid layout (sweeps-market stops on a point outside the grid or two points in one place)'],
      ['cells[].col', 'S CS', 'as row'],
      ['cells[].lat', 'S CS', 'the grid layout (stops when rows are not evenly spaced)'],
      ['cells[].lng', 'S CS', 'as lat'],
      ['centre_lat', 'S', 'market.scans[].seos.centre_stated and centre_stated_off_m'],
      ['centre_lng', 'S', 'as centre_lat']] },
  { table: 'engine_sweep_businesses', rows: 'every row of every sweep', missing: 'extract-v2 crashes when a sweep with points has no business rows: "TypeError: Cannot read properties of null (reading \'short\')" (line 254 reads the number 1 of an empty field; tried on a copy without the rows of sweep 352). sweeps-market stops when a point lists a business the rows do not: "a point lists <id>, which the sweep\'s own list of businesses does not".',
    cols: [['scan_id', 'E S CS', 'which sweep'],
      ['place_id', 'E S CS', 'which business'],
      ['is_subject', 'E', 'the store\'s own row is not used for names'],
      ['name', 'E S CS', 'names of the field (when no Google listing was read)'],
      ['solv', 'E S CS', 'a third reading of each business\'s share: a hold when it disagrees with the points (extract-v2); sweeps-market stops'],
      ['distance_km', 'E', 'businesses more than 150 miles away (rule 1); maps.sweeps[].far; the distance fit (maps.factors[].refit)'],
      ['lat', 'S CS', 'market.biz[].lat and km from the store; out of market'],
      ['lng', 'S CS', 'as lat'],
      ['rating', 'E S CS', 'maps.sweeps[].top[].rating; market.scans[].field'],
      ['reviews', 'E S CS', 'maps.sweeps[].top[].reviews; market.scans[].field'],
      ['address', 'E S', 'the far towns named in the scan-market check; telling two businesses with one name apart'],
      ['category', 'S', 'market.biz[].cat_name when no listing was read (a street address in it is noted and ignored)'],
      ['top3_appearances', 'S', 'must equal the business\'s top-3 points, else sweeps-market stops'],
      ['appearances', 'S', 'a note when it counts past the first 20'],
      ['best_rank', 'S', 'a note when it differs'],
      ['arp', 'S', 'a note when it differs']] },
  { table: 'engine_actors', rows: 'rows with kind "scan"; ref is the scan id', missing: '"the software holds no record of who started it or when" (scan-setup check); maps.sweeps[].started is null and the start is not tested against opening hours.',
    cols: [['kind', 'E S', 'only "scan" rows are read'],
      ['ref', 'E S', 'the scan id'],
      ['at', 'E S', 'when the sweep started: maps.sweeps[].started, open_at_start'],
      ['role', 'E S', 'maps.sweeps[].starter_role ("started by an admin")'],
      ['username', 'S', 'market.scans[].seos.by_person (true or false only)']] },
  { table: 'citation_verdicts', rows: 'extract-v2: the store\'s rows; sweeps-market and check-sweeps-market: every business in the field', missing: 'listings.verdicts is null and the directory-verdicts check is not made; market.directories is null. sweeps-market stops when rows exist and none is about the store.',
    cols: [['place_id', 'E S CS', 'whose verdict'],
      ['source_id', 'E', 'other-market sources (settings.other_market_sources); listings.verdicts.other_market[].source'],
      ['domain', 'E', 'listings.verdicts.rows[].domain; the verdict behind listings.matter'],
      ['tier', 'E', 'listings.verdicts.rows[].tier, by_tier'],
      ['verdict', 'E S CS', 'listed / not-listed / undetermined counts ("undetermined" = could not be read, rule 5)'],
      ['nap_status', 'E S', 'listings.verdicts.rows[].nap; market.directories nap counts'],
      ['contested', 'E S', 'listings.verdicts.contested'],
      ['listing_url', 'E', 'listings.verdicts.rows[].url and ours (our tag)'],
      ['computed_at', 'E S', 'listings.verdicts.computed; market.directories.read']] },
  { table: 'review_velocity_snapshots', rows: 'the store\'s rows', missing: 'no second reading of the store\'s reviews: the review-velocity check is "not measured" and on hold, the velocity comparison is on hold, the velocity gap line is left out.',
    cols: [['place_id', 'E S CS', 'the store'],
      ['window_days', 'E S CS', 'reviews.snapshots[].days; matched with the 30, 90 and 365-day windows'],
      ['reviews_in_window', 'E S CS', 'must equal the reviews counted in the window (meta.second_readings)'],
      ['per_month', 'E', 'must equal the pace within 0.011'],
      ['replied_in_window', 'E', 'must equal the replies counted in the window'],
      ['reviews_total', 'E', 'reviews.snapshots[].total']] },
  { table: 'analytics_bindings', rows: 'any row', missing: 'search.analytics_connected and search_console_connected are false: the connected check says "Not connected" and the client task connect-google is made.',
    cols: [['ga_property_id', 'E', 'search.analytics_connected'], ['sc_property', 'E', 'search.search_console_connected']] },
  { table: 'apex_runs', rows: 'the newest row by created_at', missing: 'maps.apex and maps.model are null, maps.factors is empty, the page-checks check is not made.',
    cols: [['id', 'E', 'maps.apex.id; picks the factors and the findings of the latest model run'], ['created_at', 'E', 'which run is newest; the sweeps the distance fit can use'], ['model_ver', 'E', 'maps.model'], ['grid', 'E', 'maps.apex.grid'], ['solv', 'E', 'maps.apex.solv'], ['arp', 'E', 'maps.apex.arp'], ['residual', 'E', 'maps.apex.residual']] },
  { table: 'run_factors', rows: 'the rows of the newest apex run', missing: 'maps.factors is empty; the Service view says nothing about the software\'s fit.',
    cols: [['run_id', 'E', 'which run'], ['factor', 'E', 'maps.factors[].factor'], ['rho', 'E', 'maps.factors[].rho'], ['partial_rho', 'E', 'maps.factors[].partial'], ['q', 'E', 'maps.factors[].q'], ['n', 'E', 'maps.factors[].n'], ['survives_control', 'E', 'maps.factors[].survives'], ['note', 'E', 'maps.factors[].note']] },
  { table: 'model_versions', rows: 'the row of the newest apex run\'s model_ver', missing: 'maps.model is null.',
    cols: [['ver', 'E', 'maps.model.ver'], ['fitted_at', 'E', 'maps.model.fitted'], ['population_n', 'E', 'maps.model.population'], ['notes', 'E', 'maps.model.notes']] },
  { table: 'findings', rows: 'every row', missing: 'with no findings (or no tasks) the stored-findings check fails and the software task store-findings is made.',
    cols: [['id', 'E', 'the finding ids in each SEOS task card'], ['run_id', 'E', 'the latest run\'s open page checks; older duplicates'], ['code', 'E', 'one task card per code (tasks[].seos_code); PAGE_CHECK_* codes feed the page-checks check'], ['evidence_url', 'E', 'the evidence line of a SEOS task (left out when it carries our tag)']] },
  { table: 'tasks', rows: 'every row (SEOS\'s own task table, not the report\'s tasks)', missing: 'as findings.',
    cols: [['id', 'E', 'listed in each SEOS task card; task_groups[].dupes'], ['finding_id', 'E', 'ties a task to its finding'], ['run_id', 'E', 'older duplicates of the latest run\'s tasks'], ['state', 'E', 'open page-check tasks; duplicates still open'], ['statement', 'E', 'tasks[].title of the SEOS task card (the newest one)'], ['generated_at', 'E', 'which task is newest']] },
  { table: 'task_briefs', rows: 'one per code', missing: 'the SEOS task card has no brief line and its steps are the generic two.',
    cols: [['code', 'E', 'which card'], ['what', 'E', 'tasks[].why'], ['why', 'E', 'tasks[].why'], ['fix', 'E', 'tasks[].steps']] },
  { table: 'pm_tasks', rows: 'one per code', missing: 'no "Already sent to the task board" line.',
    cols: [['code', 'E', 'which card'], ['public_key', 'E', 'tasks[].why'], ['pm_status_label', 'E', 'tasks[].why']] },
];
// notes on tables in the business answer that no script of the chain reads (the list itself is computed)
const TABLES_NOT_READ = { engine_sweep_fields: 'merge-sweep.mjs appends its rows and ee-scan-to-seos.mjs writes one; nothing reads it', portal_tokens: 'its token column is withheld by the API; nothing here reads the table' };

// ---------- the readings: both audit answers, picked by kind AND place id, newest fetched_at first ----------
// who: which places are read. Roles: store (the location's place id), rival (the run's other businesses), field (a
// business in one of the store's sweeps), site (a "site:<domain>" key of the website audit), other.
const R0 = 'result.business_info.items.0.';
const KINDS = [
  { kind: 'business_info', answer: 'full', who: 'the store (required), the rivals and the field', by: 'E S CS CC',
    missing: 'Store: extract-v2 stops: "no Google listing reading for the store", or "the store\'s Google listing reading is empty". A rival without one is named from the audit run\'s businesses list and its domain comes from locations.named_rivals; a field business without one is named from its sweep row. Either is left out of the listing table (compare.listings) and the listing comparisons.',
    paths: [[R0 + 'title', 'E S CS', 'business.name, rivals[].name, compare.listings, market.biz[].name'], [R0 + 'url', 'E S CC', 'business.listing_link, listing_is_homepage, the chain test for rivals (rule 7), compare.listings[].lands'], [R0 + 'domain', 'E S', 'business.domain, rivals[].domain'],
      [R0 + 'phone', 'E', 'business.phone; a rival\'s phone pattern'], [R0 + 'category', 'E S', 'business.category; compare.listings[].category'], [R0 + 'category_ids', 'E S', 'the category check (cannabis_store)'], [R0 + 'additional_categories', 'E S', 'business.extra_categories; compare.listings[].extra'],
      [R0 + 'is_claimed', 'E S CS', 'business.claimed (claimed check); compare.listings[].claimed'], [R0 + 'rating.value', 'E S CS CC', 'business.rating (rating check); the stars comparison'], [R0 + 'rating.votes_count', 'E S CS CC', 'business.ratings; the ratings comparison and gap line'],
      [R0 + 'rating_distribution', 'E', 'business.rating_dist'], [R0 + 'total_photos', 'E S CS CC', 'business.photos; the photos comparison'], [R0 + 'work_time.work_hours.timetable', 'E S', 'business.hours; every opening-hours test of a map check'],
      [R0 + 'attributes.available_attributes', 'E S CS', 'business.service_options, business.attributes; ways to shop and details counts'], [R0 + 'place_topics', 'E', 'business.topics'], [R0 + 'people_also_search', 'E', 'business.also_viewed, compare.nearby; the review-count check needs 3 or more'],
      [R0 + 'address_info.address', 'E', 'a rival\'s street pattern for listings'], [R0 + 'latitude', 'S', 'market.biz[].lat when no sweep row has one'], [R0 + 'longitude', 'S', 'as latitude'], ['fetched_at', 'E S', 'business.profile_read_at; the dates under the listing comparisons']] },
  { kind: 'reviews', answer: 'full', who: 'the store and the rivals', by: 'E S CS CC',
    missing: 'Store: reviews is null; the review checks (review-count, review-pace, replies, low-open, recent-rating) and the client-questions task are not made; the store has no velocity row. A rival without one reads "Not read" in the velocity and reply comparisons.',
    paths: [['result.reviews.items[].timestamp', 'E S CS', 'every review window (30, 90, 365 days), reviews.monthly, the velocity rows'], ['result.reviews.items[].rating', 'E', 'reviews.reply_by_stars, low-star counts, monthly averages'], ['result.reviews.items[].owner_reply', 'E', 'replies (reply_rate, windows[].replied)'],
      ['result.reviews.items[].text', 'E', 'reviews.low_subjects, low_open_list (team only)'], ['result.reviews.collected_at', 'E S', 'the end of every window; reviews.collected_at'], ['result.reviews.capped', 'E S CS CC', 'a pull that stopped at its limit: its count is never printed (rule 4)'],
      ['result.pull.depth', 'S CS CC', 'a pull that reached the depth it asked for counts as limited'], ['request.reviews.depth', 'CC', 'as result.pull.depth'], ['result.reviews.count', 'CC', 'the capped test of check-compare-v2']] },
  { kind: 'ranking_signals', answer: 'full and website', who: 'the store (its reading lists every website)', by: 'E CC',
    missing: 'In neither answer: you and rivals have no visits, keywords or link strength: the searches, visits and strength comparisons and gap lines are not made.',
    paths: [['result.traffic.items[].target', 'E CC', 'which website'], ['result.traffic.items[].metrics.organic.etv', 'E CC', 'you.visits, rivals[].visits'], ['result.traffic.items[].metrics.organic.count', 'E CC', 'you.keywords, rivals[].keywords'], ['result.ranks.items[].target', 'E CC', 'which website'], ['result.ranks.items[].rank', 'E CC', 'the link strength comparison and gap line']] },
  { kind: 'competitor_domains', answer: 'full', who: 'the store', by: 'E',
    missing: 'search.keywords_total and the buckets are null: the footprint check is not made and compare.search_sites is empty.',
    paths: [['result.competitors.items[].domain', 'E', 'the store\'s own row and compare.search_sites[].domain'], ['result.competitors.items[].intersections', 'E', 'compare.search_sites[].shared, search.others'], ['result.competitors.items[].full_domain_metrics.organic.count', 'E', 'search.keywords_total'],
      ['result.competitors.items[].full_domain_metrics.organic.etv', 'E', 'search.visits'], ['result.competitors.items[].full_domain_metrics.organic.pos_1', 'E', 'search.buckets, top3, top10 (with pos_2_3 ... pos_91_100)'], ['result.competitors.items[].full_domain_metrics.organic.is_new', 'E', 'search.moved (with is_up, is_down, is_lost)'], ['fetched_at', 'E', 'search.read_at']] },
  { kind: 'ranked_keywords', answer: 'full', who: 'the store', by: 'E',
    missing: 'search.ranked_read is false: the ranked-keywords check fails and the software task ranked-keywords is made.',
    paths: [['result.ranked.items[].keyword', 'E', 'search.stored, stored_brand, stored_plain (settings.brand_terms)'], ['result.ranked.items[].search_volume', 'E', 'read, not in the model'], ['result.ranked.items[].rank_group', 'E', 'read, not in the model'], ['result.ranked.items[].etv', 'E', 'search.stored_visits'], ['result.ranked.items[].url', 'E', 'read, not in the model']] },
  { kind: 'site_audit', answer: 'full and website', who: 'the store and the rivals (by place id). The website audit\'s site:<domain> readings are not read', by: 'E',
    missing: 'Store, in neither answer: the website page fields are null and the page-words, main-heading, title, basics and store-details checks are not made. A rival without one has no page row on the Website comparisons.',
    paths: [['result.page.items.0.url', 'E', 'website.url, compare.website[].url'], ['result.page.items.0.status_code', 'E', 'website.status (basics check)'], ['result.page.items.0.onpage_score', 'E', 'website.onpage (rule 9: null when the rendered read disagrees)'], ['result.page_rendered.items.0.onpage_score', 'E', 'the second on-page reading'],
      ['result.page.items.0.meta.title', 'E', 'website.title'], ['result.page.items.0.meta.title_length', 'E', 'website.title_chars (title check)'], ['result.page.items.0.meta.description', 'E', 'website.description'], ['result.page.items.0.meta.description_length', 'E', 'website.description_chars'],
      ['result.page.items.0.meta.htags', 'E', 'website.headings, main_heading, gate_heading'], ['result.page.items.0.meta.content.plain_text_word_count', 'E', 'website.words'], ['result.page.items.0.meta.content.plain_text_size', 'E', 'website.chars'],
      ['result.page.items.0.checks.no_h1_tag', 'E', 'website.main_heading_flag_missing'], ['result.page.items.0.checks.frame', 'E', 'website.has_frame'], ['result.page.items.0.checks.is_https', 'E', 'website.https'], ['result.page.items.0.checks.has_micromarkup', 'E', 'website.structured_data_found (store-details check)'],
      ['result.probe.status', 'E', 'website.status'], ['result.probe.hops', 'E', 'website.hops'], ['result.probe.canonical_offhost', 'E', 'website.canonical_self'], ['result.probe.head_hosts', 'E', 'website.head_mentions_schema'], ['result.probe.tags.schema', 'E', 'website.business_schema, schema_types'],
      ['result.render.crawler_words', 'E', 'website.crawler_words (page-words comparison)'], ['result.render.browser_words', 'E', 'website.browser_words'], ['result.render.thin_to_crawler', 'E', 'website.thin_to_crawler'], ['result.age_gate.gated', 'E', 'website.age_gate'],
      ['result.discovery.urls_total', 'E', 'website.sitemap_pages'], ['result.~^page_\\d+$', 'E', 'website.pages_read'], ['result.site_files.llms', 'E', 'website.llms'], ['result.site_files.og_image', 'E', 'website.og_image'], ['fetched_at', 'E', 'website.read_at']] },
  { kind: 'page_speed', answer: 'full and website', who: 'the store and the rivals; the website audit\'s site:<domain> readings are the second reading of each rival\'s front page', by: 'E CC',
    missing: 'Store, in neither answer: website.phone is null, the speed-phone check reads "Not measured", the speed comparisons and the speed gap line are not made (tried on copies of both answers without the store\'s page_speed). Removed from the full audit alone, the website audit\'s copy of the same reading is used. Without the site:<domain> readings the two readings of the rivals cannot agree, so no speed order is quoted (compare.speed_order_holds is false).',
    paths: [['result.phone.score', 'E CC', 'website.phone.score (speed-phone check, comparison, gap line)'], ['result.desktop.score', 'E CC', 'website.desktop.score'], ['result.phone.error', 'E CC', 'a failed test is no score (absent when the test ran)'], ['result.phone.metrics', 'E', 'website.phone.metrics (lcp, tbt, ...)'], ['result.phone.fixes', 'E', 'website.phone.fixes (savings_ms > 0)'], ['target', 'E', 'the URL of the second reading']] },
  { kind: 'landing_flags', answer: 'full', who: 'the store and the rivals', by: 'E', missing: 'website.flags is null and the landing-flags check is not made.',
    paths: [['result.flags', 'E', 'website.flags, website.rivals[].page.flags'], ['result.notes', 'E', 'website.rivals[].page.flag_notes']] },
  { kind: 'site_crawl', answer: 'full and website', who: 'the store (place id), each rival (site:<domain>, website audit)', by: 'E',
    missing: 'Store, in neither answer: website.crawl is null: the whole-site check gives pages read only, the crawl-score row and the crawl hold are not made.',
    paths: [['result.summary.pages_crawled', 'E', 'website.crawl.pages'], ['result.summary.max_pages', 'E', 'website.crawl.max, at_limit (rule 4)'], ['result.summary.onpage_score', 'E', 'website.crawl.score (team only, on hold)'], ['result.summary.broken_links', 'E', 'website.crawl.broken_links'], ['result.summary.duplicate_title', 'E', 'website.crawl.duplicate_title'], ['result.summary.duplicate_description', 'E', 'website.crawl.duplicate_description'], ['result.summary.progress', 'E', 'website.crawl.progress'], ['fetched_at', 'E', 'the crawl date']] },
  { kind: 'bl_exhaustive', answer: 'full', who: 'the store and the rivals', by: 'E',
    missing: 'Store: links is null: no link check, comparison or link hold, no client-questions task, and then build-report.mjs crashes on the null block ("TypeError: Cannot read properties of null (reading \'not_sellers\')", line 191; tried on a copy of report-data.json with links set to null), so both documents need this reading. A rival without it is not counted.',
    paths: [['result.~^rd_\\d+$.items[].domain', 'E', 'links.sites (linking sites)'], ['result.~^rd_\\d+$.items[].rank', 'E', 'with_weight, top_sites'], ['result.~^rd_\\d+$.items[].first_seen', 'E', 'links.fresh, daily'], ['result.~^rd_\\d+$.total_count', 'E', 'sites_complete (rule 4)'],
      ['result.~^bl_\\d+$.items[].domain_from', 'E', 'which host a link is on'], ['result.~^bl_\\d+$.items[].page_from_title', 'E', 'the seller test (rule 8)'], ['result.~^bl_\\d+$.items[].url_to', 'E', 'our tag on links (agency)'], ['result.~^bl_\\d+$.items[].vendor_tagged', 'E', 'links.tagged_*'], ['result.~^bl_\\d+$.items[].backlink_spam_score', 'E', 'links.quality.strict'], ['result.~^bl_\\d+$.total_count', 'E', 'links_complete (rule 4)'], ['fetched_at', 'E', 'links.read_at']] },
  { kind: 'bl_ledger', answer: 'full', who: 'the store and the rivals', by: 'E', missing: 'no host is flagged by the ledger; links.wave is null.',
    paths: [['result.hosts[].host', 'E', 'ledger-flagged sellers'], ['result.hosts[].scheme_like', 'E', 'links.by_ledger'], ['result.shared_title_waves[].hosts', 'E', 'links.wave'], ['result.tagged_rows', 'E', 'read, not in the model']] },
  { kind: 'bl_link_gap', answer: 'full', who: 'the store', by: 'E', missing: 'the gap list is empty and the link-list check passes with 0 sites (not marked as not read).',
    paths: [['request.~^gap_\\d+$.targets', 'E', 'which rivals each part covers'], ['result.~^gap_\\d+$.items[].domain_intersection', 'E', 'links.gap_worth, gap_left'], ['result.~^gap_\\d+$.total_count', 'E', 'links.gap_floor (rule 4)']] },
  { kind: 'bl_location', answer: 'full', who: 'the store', by: 'E', missing: 'links.store_links is null.', paths: [['result.loc.total_count', 'E', 'links.store_links']] },
  { kind: 'bl_landing', answer: 'full', who: 'the store and the rivals', by: 'E', missing: 'nothing changes: it is read and not used.', paths: [['result.land', 'E', 'read, not in the model']] },
  { kind: 'cit_sweep', answer: 'full', who: 'the store and the rivals', by: 'E', missing: 'Store: when cit_pages is missing too, listings is null: no listing check; no client-questions task.',
    paths: [['result.*.items[].url', 'E', 'listings.results_seen, named_site_list, table'], ['result.*.items[].title', 'E', 'the name match (settings.brand_terms)'], ['result.*.items[].description', 'E', 'the phone, street and name match'], ['request.target.brand_regex', 'E', 'the name pattern when settings.brand_terms is not given (and for rivals)'], ['request.target.street_regex', 'E', 'the street pattern'], ['fetched_at', 'E', 'listings.read_at']] },
  { kind: 'cit_pages', answer: 'full', who: 'the store and the rivals', by: 'E', missing: 'listings.pages_* and table are 0 or empty.',
    paths: [['request.candidates[].url', 'E', 'listings.pages_opened, table'], ['result.~^page-\\d+$.items', 'E', 'readable pages (pages_readable)'], ['result.~^page-\\d+$.crawl_status', 'E', 'an empty read is not a missing listing (rule 5)']] },
  { kind: 'cit_probe', answer: 'full', who: 'the store and the rivals', by: 'E', missing: 'listings.directories_* are null or 0 and the directory-coverage check is not made; listings.matter is empty.',
    paths: [['request.sources', 'E', 'listings.directories_listed (minus settings.other_market_sources), listings.matter'], ['request.~^ctl:', 'E', 'directories_tested'], ['request.~^biz:', 'E', 'directories_searched'], ['result.~^(ctl|biz):.items', 'E', 'directories_test_passed, answered, showed']] },
  { kind: 'analytics_watch', answer: 'full', who: 'none of the store\'s; any other place counts', by: 'E', other: true,
    missing: 'no answer-scope check. When present for another place: the answer-scope check fails and the software task answer-isolation is made (both team only, left out of the Action Plan). The content is never read.',
    paths: [] },
  { kind: 'gsc_sitemaps', answer: 'full', who: 'as analytics_watch', by: 'E', other: true, missing: 'as analytics_watch.', paths: [] },
];
// notes on reading kinds the chain does not read (the list itself is computed)
const KINDS_NOT_READ = { bl_variants: 'landing_flags carries what the chain needs of it', site_files: 'the website audit lists the kind with 0 rows; the files are read from site_audit result.site_files' };

// ---------- read the files ----------
const B = load(bizPath), F = load(fullPath), W = load(webPath);
const T = B.json.tables || die('the business answer has no tables');
const store = T.locations?.[0]?.place_id || die('the business answer has no location row');
const runs = [...(T.audit_runs || [])].sort((a, b) => (b.steps?.length || 0) - (a.steps?.length || 0));
const run = runs[0] || die('the business answer has no audit run');
const rivals = new Set((run.businesses || []).filter(b => !b.is_subject).map(b => b.place_id));
const field = new Set((T.engine_sweep_businesses || []).map(r => r.place_id));
const role = pid => pid === store ? 'store' : rivals.has(pid) ? 'rival' : String(pid).startsWith('site:') ? 'site' : field.has(pid) ? 'field' : 'other';
const catalog = opt('tables') ? load(opt('tables')).json : null;
const api = opt('openapi') ? load(opt('openapi')).json : null;
const ids = { business: B.json.business_id, full: F.json.business_id, web: W.json.business_id, full_audit: F.json.audit, web_audit: W.json.audit, full_run: F.json.tables?.audit_runs?.[0]?.id ?? null, main_run: run.id, main_run_steps: run.steps?.length ?? 0 };

const census = { files: { business: { file: B.file, bytes: B.bytes }, full: { file: F.file, bytes: F.bytes }, web: { file: W.file, bytes: W.bytes } }, ids, tables: [], kinds: [], not_read: {}, side: {} };
// the business answer's tables
for (const t of TABLES) {
  const rows = T[t.table] || [];
  const cat = catalog ? (catalog.tables || []).find(x => x.name === t.table) : null;
  census.tables.push({ table: t.table, rows: rows.length, in_answer: Object.prototype.hasOwnProperty.call(T, t.table), header_count: B.json.counts?.[t.table] ?? null,
    catalog_rows: cat ? cat.rows : null, cols: t.cols.map(([c, by]) => ({ col: c, by, present: rows.filter(r => present(r, c)).length, of: rows.length, in_catalog: cat ? cat.columns.some(x => x.name === c.split(/[.[]/)[0]) : null })) });
}
census.not_read.tables = Object.keys(T).filter(k => !TABLES.some(t => t.table === k)).map(k => ({ table: k, rows: (T[k] || []).length }));
// the readings of both audit answers
const READS = [...(F.json.tables?.vendor_readings || []).map(r => ({ r, answer: 'full' })), ...(W.json.tables?.vendor_readings || []).map(r => ({ r, answer: 'website' }))];
for (const k of KINDS) {
  const list = READS.filter(x => x.r.kind === k.kind);
  const roles = {}; for (const x of list) { const ro = role(x.r.place_id); roles[ro] = (roles[ro] || 0) + 1; }
  const byAnswer = { full: list.filter(x => x.answer === 'full').length, website: list.filter(x => x.answer === 'website').length };
  // readings about other accounts: counted only. Nothing else of them is read here.
  const paths = k.other ? [] : k.paths.map(([p, by]) => ({ path: p, by, present: list.filter(x => present(x.r, p)).length, of: list.length, store: list.some(x => role(x.r.place_id) === 'store' && present(x.r, p)) }));
  census.kinds.push({ kind: k.kind, readings: list.length, by_answer: byAnswer, roles, store_reading: list.some(x => role(x.r.place_id) === 'store'), paths });
}
census.not_read.kinds = [...new Set(READS.map(x => x.r.kind))].filter(k => !KINDS.some(x => x.kind === k)).map(k => ({ kind: k, readings: READS.filter(x => x.r.kind === k).length }));
census.listed_kinds_without_rows = (W.json.kinds || []).concat(F.json.kinds || []).filter(k => !READS.some(x => x.r.kind === k));
// the side files: SEOS's list of every sweep and every location
if (opt('all-sweeps')) { const j = load(opt('all-sweeps')); const rows = Array.isArray(j.json) ? j.json : j.json.rows || []; census.side.all_sweeps = { file: j.file, rows: rows.length, total: j.json.total ?? null, complete: j.json.total === undefined || Number(j.json.total) === rows.length, of_this_store: rows.filter(r => r.subject === store).length, cols: ['scan_id', 'subject', 'keyword', 'finished_at'].map(c => ({ col: c, present: rows.filter(r => present(r, c)).length })) }; }
if (opt('locations')) { const j = load(opt('locations')); const rows = Array.isArray(j.json) ? j.json : j.json.rows || []; census.side.locations = { file: j.file, rows: rows.length, total: j.json.total ?? null, other_businesses_in_the_sweeps: rows.filter(r => r.business_id !== ids.business && field.has(r.place_id)).length, cols: ['place_id', 'business_id', 'name', 'city', 'state'].map(c => ({ col: c, present: rows.filter(r => present(r, c)).length })) }; }
if (api) census.side.openapi = { paths: Object.keys(api.paths || {}) };
// the Eagle Eyes export (ee-scan-to-seos.mjs): the fields it reads, counted; vantage address and the rest are never read
const EE_FIELDS = { top: ['id', 'status', 'error', 'created_at', 'finished_at', 'request', 'results', 'metrics'],
  request: ['place_id', 'business_name', 'keyword', 'grid_size', 'radius', 'unit', 'center_lat', 'center_lng', 'excluded_points', 'feed_depth', 'zoom', 'vantage.label'],
  result: ['index', 'row', 'col', 'lat', 'lng', 'rank', 'error', 'listings'], listing: ['position', 'place_id', 'name', 'address', 'category', 'rating', 'reviews', 'lat', 'lng'],
  metrics: ['found_points', 'top3_points', 'solv', 'atrp', 'arp', 'total_points', 'listings_seen'] };
if (opt('ee')) {
  const j = load(opt('ee')).json, res = Array.isArray(j.results) ? j.results : [], lis = res.flatMap(p => Array.isArray(p.listings) ? p.listings : []);
  census.side.eagle_eyes = { file: path.basename(opt('ee')), top: EE_FIELDS.top.map(c => ({ col: c, present: present(j, c) ? 1 : 0 })), request: EE_FIELDS.request.map(c => ({ col: c, present: present(j.request || {}, c) ? 1 : 0 })),
    points: res.length, errored_points: res.filter(p => p.error).length, result: EE_FIELDS.result.map(c => ({ col: c, present: res.filter(p => Object.prototype.hasOwnProperty.call(p, c)).length })), listings: lis.length, listing: EE_FIELDS.listing.map(c => ({ col: c, present: lis.filter(l => present(l, c)).length })),
    metrics: EE_FIELDS.metrics.map(c => ({ col: c, present: present(j.metrics || {}, c) ? 1 : 0 })), store_matches: (j.request || {}).place_id === store };
}

// ---------- print ----------
const out = [];
const P = s => out.push(s);
P(`business answer ${B.file} (${B.bytes.toLocaleString('en-US')} bytes): business ${ids.business}; main run ${ids.main_run} (${ids.main_run_steps} steps)`);
P(`full-audit answer ${F.file}: business ${ids.full}, audit "${ids.full_audit}", run ${ids.full_run}${ids.full_run === ids.main_run ? ' (the main run)' : ' (NOT the main run)'}`);
P(`website-audit answer ${W.file}: business ${ids.web}, audit "${ids.web_audit}"`);
P('');
P('tables read (rows in the answer; columns read: present in rows)');
for (const t of census.tables) P(`  ${t.table}: ${t.rows} rows${t.header_count !== null && t.header_count !== t.rows ? ` (the answer's counts header says ${t.header_count})` : ''}${t.in_answer ? '' : ' (NOT IN THE ANSWER)'} | ${t.cols.map(c => `${c.col} ${c.present}/${c.of}${c.in_catalog === false ? ' (not in the catalog)' : ''}`).join(', ')}`);
P(`tables in the answer the chain does not read: ${census.not_read.tables.map(t => `${t.table} ${t.rows}`).join(', ')}`);
P('');
P('reading kinds read (readings: by answer; by place)');
for (const k of census.kinds) P(`  ${k.kind}: ${k.readings} (full ${k.by_answer.full}, website ${k.by_answer.website}; ${Object.entries(k.roles).map(([r, n]) => `${r} ${n}`).join(', ') || 'none'})${k.paths.length ? ' | ' + k.paths.map(p => `${p.path} ${p.present}/${p.of}`).join(', ') : ''}`);
P(`reading kinds in the answers the chain does not read: ${census.not_read.kinds.map(k => `${k.kind} ${k.readings}`).join(', ') || 'none'}`);
P(`kinds an answer lists with no rows: ${census.listed_kinds_without_rows.join(', ') || 'none'}`);
if (census.side.all_sweeps) { const s = census.side.all_sweeps; P(`\nevery sweep (${s.file}): ${s.rows} rows, total ${s.total}${s.complete ? '' : ' (INCOMPLETE: paged)'}, ${s.of_this_store} of this store | ${s.cols.map(c => `${c.col} ${c.present}/${s.rows}`).join(', ')}`); }
if (census.side.locations) { const s = census.side.locations; P(`every location (${s.file}): ${s.rows} rows, total ${s.total}; ${s.other_businesses_in_the_sweeps} belong to other businesses and sit in this store's sweeps | ${s.cols.map(c => `${c.col} ${c.present}/${s.rows}`).join(', ')}`); }
if (census.side.openapi) P(`openapi paths: ${census.side.openapi.paths.join(', ')}`);
if (census.side.eagle_eyes) { const e = census.side.eagle_eyes; P(`\nEagle Eyes export (${e.file}): about the store: ${e.store_matches}; ${e.points} points (${e.errored_points} errored), ${e.listings} listings | top ${e.top.map(c => `${c.col} ${c.present}`).join(', ')} | request ${e.request.map(c => `${c.col} ${c.present}`).join(', ')} | point fields ${e.result.map(c => `${c.col} ${c.present}/${e.points}`).join(', ')} | listing fields ${e.listing.map(c => `${c.col} ${c.present}/${e.listings}`).join(', ')} | metrics ${e.metrics.map(c => `${c.col} ${c.present}`).join(', ')}`); }
console.log(out.join('\n'));
console.log(`\ncounted: ${census.tables.length} tables, ${census.kinds.length} reading kinds, ${census.tables.reduce((s, t) => s + t.cols.length, 0)} columns and ${census.kinds.reduce((s, k) => s + k.paths.length, 0)} reading paths`);
if (opt('json')) fs.writeFileSync(opt('json'), JSON.stringify(census, null, 1));

// ---------- INPUTS.md ----------
if (opt('md')) {
  const md = [];
  const L = s => md.push(s);
  const esc = s => String(s).replace(/\|/g, '\\|');
  const yn = (k, n) => n === 0 ? 'no rows' : k === n ? `yes (${k}/${n})` : k === 0 ? `no (0/${n})` : `partly (${k}/${n})`;
  const byText = s => s.split(' ').map(x => BY[x]).join(', ');
  L('# What the report chain reads from SEOS');
  L('');
  L(`Generated by \`inputs-census.mjs\` from the Green Haven answers (${census.files.business.file}, ${census.files.full.file}, ${census.files.web.file}). Edit the script, not this file. Every field below was taken from the code of the scripts named in each row. Every count was computed from the files.`);
  L('');
  L('The scripts, by the short names the tables use:');
  L('');
  for (const [k, v] of Object.entries(BY)) L(`- ${k} = \`${v}\``);
  L('');
  L('Scope: the v2 chain (`report-data.json` with `meta.v2 = true`). The High Society branches of `build-report.mjs` read an older file shape. They are inert when `meta.v2` is true, so they are not covered here.');
  L('');
  L('## The answers SEOS must supply');
  L('');
  L('| Answer | API path | Saved as | Read by | Green Haven file |');
  L('|---|---|---|---|---|');
  const apiHas = p => !api || (census.side.openapi?.paths || []).includes(p);
  L(`| The business and its tables | \`GET /api/data/v1/businesses/{id}\`${apiHas('/api/data/v1/businesses/{business_id}') ? '' : ' (not in openapi.json)'} | \`business-<id>.json\` | ${byText('E S CS CC M')} | ${census.files.business.file}, ${census.files.business.bytes.toLocaleString('en-US')} bytes |`);
  L(`| What the Full audit fetched | \`GET /api/data/v1/businesses/{id}/full-audit-result\` | \`full-audit-<id>.json\` | ${byText('E S CS CC')} | ${census.files.full.file}, ${census.files.full.bytes.toLocaleString('en-US')} bytes |`);
  L(`| What the Website audit fetched | \`GET /api/data/v1/businesses/{id}/website-audit-result\` | \`website-audit-<id>.json\` | ${byText('E CC')} | ${census.files.web.file}, ${census.files.web.bytes.toLocaleString('en-US')} bytes |`);
  if (census.side.all_sweeps) L(`| Every sweep in SEOS | \`GET /api/data/v1/tables/engine_sweeps\` | \`engine_sweeps-all.json\` | ${byText('E S')} (optional, \`--all-sweeps\`) | ${census.side.all_sweeps.file}, ${census.side.all_sweeps.rows} rows |`);
  if (census.side.locations) L(`| Every location in SEOS | \`GET /api/data/v1/tables/locations\` | \`locations-all.json\` | ${byText('E')} (optional, \`--locations\`) | ${census.side.locations.file}, ${census.side.locations.rows} rows |`);
  L('');
  L('The answers are read as saved, with no network call. The business answer holds every table linked to the business except the readings. The readings are in the two audit answers.');
  L('');
  L('Checks across the answers (extract-v2 stops when one fails):');
  L('');
  L(`- Each audit answer's \`business_id\` must equal \`businesses[0].id\`: "<file> is about business <x>, not <y>". Green Haven: ${ids.business}, ${ids.full}, ${ids.web}.`);
  L(`- Each audit answer's \`audit\` must be its own kind: "<file> is not the full-audit answer" (or website-audit). Green Haven: "${ids.full_audit}", "${ids.web_audit}".`);
  L(`- The full-audit answer's \`tables.audit_runs[0].id\` must be the record's main run (the run with the most steps). Green Haven: ${ids.full_run} = ${ids.main_run} (${ids.main_run_steps} steps).`);
  L('- `locations[0].place_id` must be the subject of that run.');
  L('');
  L('How a reading is picked: by `kind` and by `place_id` together, from both audit answers, the newest `fetched_at` first. The store\'s readings use its place id. A rival\'s use its place id. The website audit keys each rival\'s front page as `site:<domain>`.');
  L('');
  L('What must be there, or the documents are not built (from the code; the two crashes were tried on altered copies):');
  L('');
  L('- the first `businesses` row and the first `locations` row;');
  L('- a time zone: `locations.state` in the state table of extract-v2.mjs, or `timezone` in the settings file;');
  L('- an `audit_runs` row whose `businesses` list names a subject, and that subject\'s place id on the location row;');
  L('- both audit answers, about the same business, the full audit about the same run;');
  L('- the store\'s `business_info` reading, with its item;');
  L('- for every sweep with points, its `engine_sweep_businesses` rows (without them extract-v2 crashes);');
  L('- the store\'s `bl_exhaustive` reading (without it extract-v2 writes `links: null` and build-report.mjs crashes);');
  L('- for the map file (sweeps-market.mjs): at least one sweep of the store, the store\'s `lat` and `lng`, and sweep headers that agree with their points.');
  L('');
  L('Everything else can be missing. The report then says "not measured", "could not be read" or "not in the record", or leaves the line out, as each section below says.');
  L('');
  L(`## GET /api/data/v1/businesses/{id}: the tables`);
  L('');
  L('"Present" counts the rows of the Green Haven answer in which the column holds a value (not null). "Catalog" says whether SEOS\'s table catalog (`GET /api/data/v1/tables`, saved as tables.json) lists the column. "Partly" is not a defect by itself: a value can be missing for a real reason. For example `cells[].rank` is empty in the row of scan 320 because the store is in no list at any of its points.');
  for (const t of TABLES) {
    const c = census.tables.find(x => x.table === t.table);
    L('');
    L(`### ${t.table}`);
    L('');
    L(`Rows read: ${t.rows}. Green Haven: ${c.rows} ${c.rows === 1 ? 'row' : 'rows'}${c.header_count !== null && c.header_count !== c.rows ? ` (the answer's counts header says ${c.header_count}; merge-sweep.mjs appends rows and leaves the header as it was)` : ''}.`);
    L('');
    L(`When there are no rows: ${t.missing}`);
    L('');
    L('| Column | Read by | Feeds | Present | Catalog |');
    L('|---|---|---|---|---|');
    for (const [col, by, feeds] of t.cols) { const x = c.cols.find(y => y.col === col); L(`| \`${esc(col)}\` | ${by} | ${esc(feeds)} | ${yn(x.present, x.of)} | ${x.in_catalog === null ? 'not checked' : x.in_catalog ? 'yes' : 'NO'} |`); }
  }
  L('');
  L(`Tables in the answer that the chain does not read, with their Green Haven rows: ${census.not_read.tables.map(t => `${t.table} (${t.rows}${TABLES_NOT_READ[t.table] ? `; ${TABLES_NOT_READ[t.table]}` : ''})`).join(', ')}.`);
  L('');
  L('## The readings: GET /api/data/v1/businesses/{id}/full-audit-result and /website-audit-result');
  L('');
  L('Each audit answer is `{business_id, audit, keys, kinds, counts, tables: {vendor_readings, audit_runs}, not_included}`. The chain reads `business_id`, `audit`, `tables.audit_runs[0]` (the full audit: its id; the website audit: id, started_at, finished_at and steps, for `meta.website_run`) and `tables.vendor_readings`. Of each reading it reads `kind`, `place_id`, `fetched_at`, and per kind the paths below (`target`, `request`, `result`).');
  L('');
  L('"Readings" counts by place: store, rival (the run\'s other businesses), field (a business in one of the store\'s sweeps), site (a website audit `site:<domain>` key) and other. "Present" counts the readings of that kind in which the path holds a value. A path with `~` means every key matching the pattern, and `*` means every key.');
  for (const k of KINDS) {
    const c = census.kinds.find(x => x.kind === k.kind);
    L('');
    L(`### ${k.kind}`);
    L('');
    L(`Answer: ${k.answer}. Read for: ${k.who}. Read by: ${byText(k.by)}. Green Haven: ${c.readings} ${c.readings === 1 ? 'reading' : 'readings'} (${Object.entries(c.roles).map(([r, n]) => `${r} ${n}`).join(', ') || 'none'}); the store's: ${c.store_reading ? 'yes' : 'no'}.`);
    L('');
    L(`When missing or empty: ${k.missing}`);
    if (k.other) { L(''); L('Only `kind`, `place_id`, `target` (its host) and `fetched_at` are read. Nothing else of these readings is read, printed or copied here.'); continue; }
    L('');
    L('| Path | Read by | Feeds | Present |');
    L('|---|---|---|---|');
    for (const [p, by, feeds] of k.paths) { const x = c.paths.find(y => y.path === p); L(`| \`${esc(p)}\` | ${by} | ${esc(feeds)} | ${c.readings ? yn(x.present, x.of) : 'no readings'} |`); }
  }
  L('');
  L(`Reading kinds in the Green Haven answers that the chain does not read, with their readings: ${census.not_read.kinds.map(k => `${k.kind} (${k.readings}${KINDS_NOT_READ[k.kind] ? `; ${KINDS_NOT_READ[k.kind]}` : ''})`).join(', ') || 'none'}.${census.listed_kinds_without_rows.length ? ` Listed by an answer with no rows: ${census.listed_kinds_without_rows.map(k => `${k}${KINDS_NOT_READ[k] ? ` (${KINDS_NOT_READ[k]})` : ''}`).join(', ')}.` : ''}`);
  L('');
  L('Two more rules read every reading:');
  L('');
  L('- A reading fetched more than 3 days before the run started that is not about the store or a rival counts in the team-only answer-scope check.');
  L('- The rival-rows check needs every rival step of the parts reviews, site_audits, page_speed, exhaustive and cit_pages to be done, and at least one reading for every rival.');
  L('');
  L('## The two optional lists');
  L('');
  if (census.side.all_sweeps) { const s = census.side.all_sweeps; L(`\`--all-sweeps\` (GET /api/data/v1/tables/engine_sweeps): \`{table, columns, total, limit, offset, rows}\`. sweeps-market reads \`rows[].scan_id\`, \`subject\`, \`keyword\` and \`finished_at\`, and \`total\`. It lists the store's sweeps it did not read (market.source.all_sweeps), and calls an absence "not proof" when \`total\` exceeds the rows held. extract-v2 reads only the number of rows, for the sentence "None of the <n> sweeps in the software is a <phrase> check of this store". Green Haven: ${s.rows} rows, total ${s.total}, ${s.of_this_store} of this store. Without it the sentence is left out, and sweeps-market's market.source.all_sweeps is null. The API pages at \`limit\`. Save every page.`); L(''); }
  if (census.side.locations) { const s = census.side.locations; L(`\`--locations\` (GET /api/data/v1/tables/locations): extract-v2 reads \`rows[].place_id\`, \`business_id\`, \`name\`, \`city\` and \`state\`. A location of another business whose place id is in the store's sweeps is one of our own accounts on this map. It feeds the own-accounts check and a hold (team only), both of which build-report.mjs leaves out of the Action Plan. They are never in the Competitor Analysis. Green Haven: ${s.rows} rows; ${s.other_businesses_in_the_sweeps} belong to other businesses and sit in this store's sweeps. Without it there is no own-accounts check or hold.`); L(''); }
  L('## A sweep from Eagle Eyes (ee-scan-to-seos.mjs)');
  L('');
  L('When SEOS holds no sweep of a search the owner expects, an Eagle Eyes scan export can stand in. `node ee-scan-to-seos.mjs <export.json> <store place id> <out.json>` turns it into SEOS\'s own sweep rows (`engine_sweeps`, `engine_sweep_cells`, `engine_sweep_businesses`, `engine_sweep_fields`, `engine_actors`). `merge-sweep.mjs` then appends them to a copy of the business answer. It refuses a sweep id already held and a sweep about another store.');
  L('');
  L('The export shape it reads:');
  L('');
  L(`- Top level: ${EE_FIELDS.top.map(x => '`' + x + '`').join(', ')}.`);
  L(`- \`request\`: ${EE_FIELDS.request.map(x => '`' + x + '`').join(', ')}.`);
  L(`- \`results[]\`, one per point: ${EE_FIELDS.result.map(x => '`' + x + '`').join(', ')}.`);
  L(`- \`results[].listings[]\`, best first: ${EE_FIELDS.listing.map(x => '`' + x + '`').join(', ')}.`);
  L(`- \`metrics\`: ${EE_FIELDS.metrics.map(x => '`' + x + '`').join(', ')}.`);
  L('');
  L('It stops (`EE CONVERT FAILED`) when:');
  L('');
  L('- there is no `request` or no `results`;');
  L('- `request.place_id` is not the store;');
  L('- any point has an `error`;');
  L('- `status` is "failed" for any reason other than "no point named this business" (a scan where the store is found nowhere is kept as a real result);');
  L('- a listing\'s `position` is not its place in the list;');
  L('- a point\'s `rank` is not the store\'s place in that point\'s list;');
  L('- a `metrics` value disagrees with what the points give.');
  L('');
  L('`excluded_points` are left out and named in `exclusion_note`. `feed_depth` "centre_whole" becomes `started_how` "whole_feed". `read_at` is the export file\'s modification time.');
  if (census.side.eagle_eyes) { const e = census.side.eagle_eyes; L(''); L(`Green Haven (scan 320, ${e.file}): about the store: ${e.store_matches ? 'yes' : 'no'}; ${e.points} points, ${e.errored_points} errored, ${e.listings} listings. Fields present: top level ${e.top.filter(c => c.present).length} of ${e.top.length}, request ${e.request.filter(c => c.present).length} of ${e.request.length}, point fields ${e.result.filter(c => c.present === e.points).length} of ${e.result.length} on every point, listing fields ${e.listing.filter(c => c.present === e.listings).length} of ${e.listing.length} on every listing (${e.listing.filter(c => c.present !== e.listings).map(c => `${c.col} ${c.present}/${e.listings}`).join(', ') || 'none missing'}), metrics ${e.metrics.filter(c => c.present).length} of ${e.metrics.length}.`); }
  L('');
  L('## How to run');
  L('');
  L('```sh');
  L('D=_data/green-haven-2026-10-12-with-ee320');
  L('node <this folder>/inputs-census.mjs $D/business-48.json $D/full-audit-48.json $D/website-audit-48.json \\');
  L('  --all-sweeps=$D/engine_sweeps-all.json --locations=$D/locations-all.json --tables=$D/tables.json --openapi=$D/openapi.json \\');
  L('  --ee=_data/green-haven-2026-10-12/extra-ee/eagleeyes-scan-320-weed-near-me.json --md=<this folder>/INPUTS.md');
  L('```');
  L('');
  L('The census prints counts and names only. It never prints a value from a reading, and never anything from the readings about other accounts beyond how many there are.');
  fs.writeFileSync(opt('md'), md.join('\n') + '\n');
  console.log(`wrote ${path.basename(opt('md'))}`);
}
