// validate-model.mjs: checks a JSON file against one of this folder's schemas (report-data.schema.json,
// business-settings.schema.json). Zero dependencies. It knows only the part of JSON Schema 2020-12 those schemas use:
// type, const, enum, properties, required, additionalProperties, items, pattern, dependentRequired, and the
// annotations ($schema, $id, title, description, examples, $comment). A schema that uses anything else is refused
// (fail closed), so a keyword can never be ignored without anyone knowing.
// usage: node validate-model.mjs <schema.json> <data.json> [--plant]
//   --plant  (report-data.json only) also checks three planted mistakes, each made in memory on a copy of the data: a
//            missing required key (business.name deleted), a wrong enum value (checks[0].status = "great") and a wrong
//            type (business.ratings as text). Exit code 0 only when the data passes and each planted copy fails.
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const [schemaPath, dataPath] = argv.filter(a => !a.startsWith('--'));
if (!schemaPath || !dataPath) { console.error('usage: node validate-model.mjs <schema.json> <data.json> [--plant]'); process.exit(2); }
const die = m => { console.error('VALIDATE FAILED: ' + m); process.exit(2); };
const read = p => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { die(`${path.basename(p)}: ${e.message}`); } };
const SCHEMA = read(schemaPath), DATA = read(dataPath);

const KNOWN = new Set(['$schema', '$id', 'title', 'description', 'examples', '$comment', 'type', 'const', 'enum', 'properties', 'required', 'additionalProperties', 'items', 'pattern', 'dependentRequired']);
// refuse a schema that uses a keyword this validator does not apply, anywhere in it
const audit = (s, at) => {
  if (s === true || s === false) return;
  if (s === null || typeof s !== 'object' || Array.isArray(s)) die(`${at}: a schema must be an object or a boolean`);
  for (const k of Object.keys(s)) if (!KNOWN.has(k)) die(`${at}: the schema uses "${k}", which this validator does not support`);
  if (s.properties) for (const [k, x] of Object.entries(s.properties)) audit(x, `${at}.properties.${k}`);
  if (s.additionalProperties !== undefined && typeof s.additionalProperties === 'object') audit(s.additionalProperties, `${at}.additionalProperties`);
  if (s.items !== undefined) audit(s.items, `${at}.items`);
};
audit(SCHEMA, '#');

const isObj = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const TYPES = { object: isObj, array: Array.isArray, string: v => typeof v === 'string', number: v => typeof v === 'number' && Number.isFinite(v), integer: v => Number.isInteger(v), boolean: v => typeof v === 'boolean', null: v => v === null };
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const show = v => { const s = JSON.stringify(v); return s === undefined ? 'nothing' : s.length > 60 ? s.slice(0, 57) + '...' : s; };

const check = (s, v, at, errs, tally) => {
  tally.n++;
  if (s === true) return; if (s === false) { errs.push(`${at}: not allowed here`); return; }
  if (Object.prototype.hasOwnProperty.call(s, 'const') && !same(v, s.const)) errs.push(`${at}: must be ${show(s.const)}, is ${show(v)}`);
  if (s.enum && !s.enum.some(e => same(e, v))) errs.push(`${at}: ${show(v)} is not one of ${s.enum.map(show).join(', ')}`);
  if (s.type !== undefined) {
    const ts = [].concat(s.type);
    for (const t of ts) if (!TYPES[t]) die(`${at}: unknown type "${t}" in the schema`);
    if (!ts.some(t => TYPES[t](v))) { errs.push(`${at}: must be ${ts.join(' or ')}, is ${v === null ? 'null' : Array.isArray(v) ? 'an array' : typeof v} ${show(v)}`); return; }
  }
  if (isObj(v)) {
    for (const k of s.required || []) if (!Object.prototype.hasOwnProperty.call(v, k)) errs.push(`${at}: missing required key "${k}"`);
    for (const [k, list] of Object.entries(s.dependentRequired || {})) if (Object.prototype.hasOwnProperty.call(v, k)) for (const r of list) if (!Object.prototype.hasOwnProperty.call(v, r)) errs.push(`${at}: "${k}" needs "${r}"`);
    for (const [k, x] of Object.entries(v)) {
      const sub = s.properties && Object.prototype.hasOwnProperty.call(s.properties, k) ? s.properties[k] : s.additionalProperties;
      if (sub === undefined) continue; // no rule for this key
      if (sub === false) { errs.push(`${at}: key "${k}" is not in the schema`); continue; }
      check(sub, x, `${at}.${k}`, errs, tally);
    }
  }
  if (Array.isArray(v) && s.items !== undefined) v.forEach((x, i) => check(s.items, x, `${at}[${i}]`, errs, tally));
  if (typeof v === 'string' && s.pattern !== undefined && !new RegExp(s.pattern, 'u').test(v)) errs.push(`${at}: ${show(v)} does not match the pattern ${s.pattern}`);
};
const validate = data => { const errs = [], tally = { n: 0 }; check(SCHEMA, data, '$', errs, tally); return { errs, n: tally.n }; };
const report = (label, r) => `${label}: ${r.errs.length ? `FAIL, ${r.errs.length} ${r.errs.length === 1 ? 'error' : 'errors'}` : 'PASS'} (${r.n.toLocaleString('en-US')} values checked)${r.errs.length ? '\n    ' + r.errs.slice(0, 30).join('\n    ') + (r.errs.length > 30 ? `\n    ... and ${r.errs.length - 30} more` : '') : ''}`;

const base = validate(DATA);
console.log(report(`${path.basename(dataPath)} against ${path.basename(schemaPath)}`, base));
let ok = base.errs.length === 0;
if (argv.includes('--plant')) {
  if (!isObj(DATA.business) || !Array.isArray(DATA.checks) || !DATA.checks.length) die('--plant needs a report-data.json (business and checks)');
  const copy = () => JSON.parse(JSON.stringify(DATA));
  const plants = [
    ['a missing required key (business.name deleted)', d => { delete d.business.name; }, e => /\$\.business: missing required key "name"/.test(e)],
    ['a wrong enum value (checks[0].status = "great")', d => { d.checks[0].status = 'great'; }, e => /\$\.checks\[0\]\.status: "great" is not one of/.test(e)],
    ['a wrong type (business.ratings as text)', d => { d.business.ratings = String(d.business.ratings); }, e => /\$\.business\.ratings: must be number/.test(e)],
  ];
  for (const [label, plant, expected] of plants) {
    const d = copy(); plant(d); const r = validate(d);
    const caught = r.errs.some(expected);
    console.log(report(`planted ${label}`, r) + (caught ? '' : '\n    NOT CAUGHT where expected'));
    if (!r.errs.length || !caught) ok = false;
  }
  console.log(ok ? 'PLANTED CHECK: PASS (the data passes, and each planted copy fails where it was planted)' : 'PLANTED CHECK: FAIL');
}
process.exit(ok ? 0 : 1);
