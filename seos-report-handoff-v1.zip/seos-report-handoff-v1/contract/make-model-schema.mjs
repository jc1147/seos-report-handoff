// make-model-schema.mjs: the report model (report-data.json, written by extract-v2.mjs) as a JSON Schema (2020-12), and
// MODEL.md, its readable version. Three sources, each kept apart:
//   1. structure: inferred from the model itself. Types (every number is "number"), required keys (present in every
//      instance), array item shapes, null where null occurs. Five objects whose keys are data (store names, rival ids,
//      speed metrics, star levels) are maps. Then the overlay below, each line checked against extract-v2.mjs: the type of
//      a key that is null or an empty list in this model, values the code fixes (const), small closed sets (enum), keys
//      the code can add that this model lacks, and nulls the code can write that this model does not show.
//   2. meaning: the DESC table below (what a key means, which inputs and rule make it), written from the code.
//   3. where it shows: measured, not written. For every key that holds a value, the model is copied with that one key
//      changed (text gets a marker and its last digit moves, a number moves, a true/false flips) and build-report.mjs
//      builds both documents from the copy. A document that comes out different shows the key; the first changed place
//      in each tab is named. A build that stops depends on the key. "No change seen" means changing it changed neither
//      file; it can still be read by a test whose answer did not flip. About 1,100 probes, 2 builds each: under 2 minutes
//      with 8 jobs. No clock is read and no network is used; the output is the same run to run and job count to job count.
// usage: node make-model-schema.mjs <report-data.json> <build-report.mjs> <out report-data.schema.json>
//          [--md=<out MODEL.md>] [--ca=<competitor-analysis.html>] [--ap=<action-plan.html>] [--jobs=8] [--work=<dir>]
//          [--reach-json=<out reach.json>] [--reach-from=<saved reach.json>] [--desc-report=<out .tsv>]
//   --ca/--ap      the live documents: the baseline builds must equal them byte for byte, or nothing is written
//   --work         where the probe copies and builds go (default: a new folder in the system temp folder, removed at the end)
//   --reach-json   save the probe's results; --reach-from reuses them (only while editing descriptions: it says so when used)
//   --desc-report  which DESC entry described each key, to review the shared ("**.") entries
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';

const argv = process.argv.slice(2);
const [modelPath, buildPath, outPath] = argv.filter(a => !a.startsWith('--'));
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
const die = m => { console.error('MODEL SCHEMA FAILED: ' + m); process.exit(1); };
if (!modelPath || !buildPath || !outPath) { console.error('usage: node make-model-schema.mjs <report-data.json> <build-report.mjs> <out report-data.schema.json> [--md=] [--ca=] [--ap=] [--jobs=] [--work=] [--reach-json=]'); process.exit(2); }
const MODEL_RAW = fs.readFileSync(modelPath, 'utf8');
const MODEL = JSON.parse(MODEL_RAW);
if (Object.keys(MODEL).length !== 25) die(`the model has ${Object.keys(MODEL).length} top-level keys, the contract has 25`);
if (MODEL.meta?.v2 !== true) die('not a v2 model (meta.v2 is not true)');

// ---------- paths ----------
// "a.b" a key, "a[]" the items of an array, "a.*" the values of a map. Patterns in the tables below may start with "**."
// (any prefix) and use "*" for one key.
const segsOf = p => p.split('.').flatMap(t => { const m = /^([^[]*)((?:\[\])*)$/.exec(t); const out = []; if (m[1]) out.push(m[1]); for (let i = 0; i < m[2].length / 2; i++) out.push('[]'); return out; });
const join = (p, k) => (p ? p + '.' + k : k);
const segMatch = (a, b) => a.length === b.length && a.every((s, i) => s === b[i] || (s === '*' && b[i] !== '[]'));
const matches = (pat, p) => {
  if (pat === p) return true;
  const ps = segsOf(p), ss = segsOf(pat);
  if (ss[0] !== '**') return segMatch(ss, ps);
  const tail = ss.slice(1); // "**." matches any prefix
  for (let i = 0; i <= ps.length - tail.length; i++) if (segMatch(tail, ps.slice(i))) return true;
  return false;
};

// ---------- 1. structure ----------
const MAPS = ['business.rating_dist', 'maps.scans[].places', 'links.quality.strict', 'search.sister_town_by_kind', '**.metrics'];
const isMap = p => MAPS.some(m => matches(m, p));
const typeOf = v => v === null ? 'null' : Array.isArray(v) ? 'array' : typeof v === 'number' ? 'number' : typeof v;
const node = () => ({ types: new Set(), count: 0, props: new Map(), objects: 0, items: null, arrays: 0, empty: 0, map: false, mapVal: null, values: [], seen: new Set() });
const NODES = new Map();
const absorb = (n, v, p) => {
  NODES.set(p, n);
  n.count++;
  const t = typeOf(v); n.types.add(t);
  if (t !== 'object' && t !== 'array') n.values.push(v);
  if (Object.prototype.hasOwnProperty.call(CONST, p)) n.seen.add(JSON.stringify(v));
  if (t === 'object') {
    n.objects++;
    if (isMap(p)) { n.map = true; n.mapVal ||= node(); for (const x of Object.values(v)) absorb(n.mapVal, x, join(p, '*')); }
    else for (const [k, x] of Object.entries(v)) { let c = n.props.get(k); if (!c) { c = node(); c.present = 0; n.props.set(k, c); } c.present++; absorb(c, x, join(p, k)); }
  }
  if (t === 'array') { n.arrays++; if (!v.length) n.empty++; n.items ||= node(); for (const x of v) absorb(n.items, x, p + '[]'); if (!v.length) NODES.set(p + '[]', n.items); }
};

// ---------- the overlay, from extract-v2.mjs (line numbers of extract-v2.mjs as of 2026-10-12) ----------
// CONST: values the code fixes for every business (the v1 fields kept for the 25-key contract, and flags)
const CONST = {
  'meta.v2': true, 'meta.order': 'loss-first', 'meta.extractor': 'extract-v2.mjs', 'verdict.order': 'loss-first', 'ai.collected': false, // 1349, 1217, 1353
  'business.listing_fixed_link': null, // 174
  'you.is_you': true, 'you.reviews': null, 'you.reviews_capped': false, 'rivals[].is_you': false, // 389-390: the store's own review count is never set here
  'stores[].has_run': true, 'stores[].current': true, // 691
  'search.brand_visit_share': null, 'search.plain_visit_share': null, 'search.top_search': null, 'search.store_slug': null, 'search.store_searches': null, 'search.store_visits': null, 'search.store_name_visits': null, 'search.store_name_searches': null, 'search.name_town': null, // 417
  'search.top_brand': [], 'search.top_plain': [], 'search.page1_complete': false, 'search.town_page1': null, 'search.sister_town_page1': [], 'search.sister_town_page1_n': 0, 'search.sister_town_by_kind': {}, // 418
  'search.other_store_page': null, 'search.other_store_page_title': null, 'search.other_store_page_links': null, 'search.tracked': null, 'search.tracked_usable': null, // 419-420
  'website.whole_site_read': false, // 474
  'links.field': [], 'links.field_size': 0, 'links.field_dropped_far': 0, 'links.tagged_top_page': null, 'links.tagged_top_two': 0, 'links.fresh_days': 30, // 578, 583, 587
  'listings.sister_pages': 0, // 661
  'maps.list_runs_by_score': true, // 737
  'compare.missing.website': [], 'compare.missing.links[].task': null, // 1149-1150
  'map.reach': null, 'map.velocity.you.dated': null, // 296, 300
  // the market file as sweeps-market.mjs writes it (sweeps-market.mjs 188-189, 276, 286, 333-335)
  'market.subject': 0, 'market.scans[].full': true, 'market.scans[].own': null, 'market.velocity.window_days': 90, 'market.velocity.stale_days': 0,
  'market.velocity.rows[].from': null, 'market.velocity.rows[].drops': null, 'market.velocity.rows[].days': 90, 'market.source.built_by': 'sweeps-market.mjs', 'market.source.top': 20,
  'map.velocity.stale_days': 0, 'map.velocity.you.from': null, 'map.velocity.leader.from': null, 'map.velocity.top[].from': null,
};
// ENUM: small closed sets, each from the code
const DOORS = ['maps', 'search', 'ai', 'website', 'links', 'overview'];
const ENUM = {
  'checks[].status': ['pass', 'watch', 'fail', 'na'], // 743, every check() call
  'checks[].weight': ['outcome', 'rank', 'practice', 'protect', 'data'], // 743
  'checks[].door': DOORS, // the first argument of every check() call
  'tasks[].door': DOORS, // a check's door, a SEOS task's door (955) or 'overview' (987)
  'tasks[].owner': ['us', 'client', 'account', 'software'], // TASKS 913-951 use us, client, software; 'account' has a label and a filter in build-report.mjs and no task yet
  'tasks[].status': ['watch', 'fail', 'na'], // 987-988: the first check's status (never 'pass', 991) or 'watch'; 'fail' when any of its checks fails
  'tasks[].group': ['first', 'ours', 'map', 'rank', 'reviews', 'page', 'content', 'links', 'speed', 'account', 'seos', 'data'], // GROUPS 969-982
  'task_groups[].key': ['first', 'ours', 'map', 'rank', 'reviews', 'page', 'content', 'links', 'speed', 'account', 'seos', 'data'],
  'compare.rows[].door': ['maps', 'search', 'website', 'links'], // every cmpRow() call
  'compare.rows[].set': ['map', 'rivals'],
  'compare.rows[].scope': ['Map check', 'This store', 'Whole website', 'Store page'],
  'gaps[].door': ['maps', 'search', 'website', 'links'], // every gap() call
  'gaps[].scope': ['whole', null], // 1192-1195 set 'whole'; the rest null (1171)
  'maps.searches[].source': ['record', 'market'], // 256, 276
  'map.searches[].source': ['record', 'market'], 'map.main.source': ['record', 'market'],
  'website.phone.band': ['pass', 'watch', 'fail'], 'website.desktop.band': ['pass', 'watch', 'fail'], // band() 431
  '**.metrics.*.band': ['pass', 'watch', 'fail'], '**.page.phone.band': ['pass', 'watch', 'fail'], '**.page.desktop.band': ['pass', 'watch', 'fail'],
  'links.quality.rows[].kind': ['names the store', 'copied article', 'article'], // 571
  'listings.table[].source': ['the page and Google', 'the page', "Google's result", 'nothing: the page came back empty'], // 635
  'business.hours.days[].day': ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'], // 151
  'compare.listings[].lands': ['home', 'inner', null], 'market.biz[].lands': ['home', 'inner', null], 'market.listings.rows[].lands': ['home', 'inner', null], 'map.leader_listing.lands': ['home', 'inner', null],
  'reviews.low_subjects[].label': ['a discount or a deal', 'staff or service', 'the product', 'hours, waiting or being closed'], // 335-340
};
// TYPE: the type of a key that is null (or an empty list) in this model, from the code; replaces the inferred type
const TYPE = {
  'business.listing_tag': ['string', 'null'], 'business.listing_tag_store': ['string', 'null'], 'business.listing_tag_matches': ['boolean', 'null'], // 144-145, 174
  'search.ranked_setting': null, 'search.organic_ranks_setting': null, // 421: the run's own part setting as stored (any JSON), null when absent
  'compare.search_sites[].rival': ['string', 'null'], // 1145
  'map.word': ['string', 'null'], 'map.middle': ['number', 'null'], 'map.town': ['object', 'null'], 'map.best': ['object', 'null'], // 282-287
  'market.velocity.left_out[].read': ['string'],
};
// SHAPE: a key with the same shape as another key (its schema is copied), for keys this model leaves null or empty
const SHAPE = { 'map.town': 'map.searches[]', 'map.best': 'map.series[]', 'map.won[]': 'map.searches[]' };
// ITEMS: the item schema of lists that are empty in this model, from the code
const S = (type, more = {}) => ({ type, ...more });
const ITEMS = {
  'meta.missing_searches[]': S('string'), // 768
  'maps.hold_reasons[]': S('string'), 'maps.sweeps[].hold_reasons[]': S('string'), 'maps.sweeps[].far.towns[]': S('string'), // 225-231, 242, 724
  'map.main.hold_reasons[]': S('string'), 'map.searches[].hold_reasons[]': S('string'), // 276, 314, 316
  'website.flags[]': S('string'), // 445: landing_flags result.flags
  'reviews.low_open_list[]': S('object', { properties: { date: S('string'), rating: S('number'), recent: S('boolean'), text: S('string') }, required: ['date', 'rating', 'recent', 'text'], additionalProperties: false }), // 369
  'compare.missing.maps[]': S('object', { properties: { what: S('string'), state: S('string'), task: S(['string', 'null']) }, required: ['what', 'state', 'task'], additionalProperties: false }), // 1147
  'map.velocity.resets[]': S('object', { properties: { name: S('string'), before: S('number'), before_on: S('string'), after: S('number'), after_on: S('string') }, required: ['name', 'before', 'before_on', 'after', 'after_on'], additionalProperties: false }), // 295
  'market.source.skipped[]': S('array', { items: S('string') }), // sweeps-market 66, 98-99: [what, why]
  'market.source.all_sweeps.not_read[]': S('object', { properties: { scan_id: S('string'), kw: S(['string', 'null']), finished: S(['string', 'null']) }, required: ['scan_id', 'kw', 'finished'], additionalProperties: false }), // sweeps-market 322
  'market.source.missing[]': S('object', { properties: { kw: S('string'), why: S('string') }, required: ['kw', 'why'], additionalProperties: false }), // sweeps-market 326
  'market.scans[].seos.rank_field_disagrees[]': S('object', { properties: { i: S('number'), row: S('number'), col: S('number'), rank_field: S('number'), in_list: S('number') }, required: ['i', 'row', 'col', 'rank_field', 'in_list'], additionalProperties: false }), // sweeps-market 131
  'market.scans[].seos.disagree.appearances.rows[]': S('object', { properties: { pid: S('string'), name: S(['string', 'null']), seos: S('number'), first_20: S('number'), whole_list: S('number'), explained: S('boolean') }, required: ['pid', 'name', 'seos', 'first_20', 'whole_list', 'explained'], additionalProperties: false }), // sweeps-market 146
  'market.scans[].seos.disagree.best_rank[]': S('object', { properties: { pid: S('string'), seos: S('number'), first_20: S(['number', 'null']) }, required: ['pid', 'seos', 'first_20'], additionalProperties: false }), // sweeps-market 148
  'market.scans[].seos.disagree.arp[]': S('object', { properties: { pid: S('string'), seos: S('number'), first_20: S('number'), from: S('string', { const: 'header' }) }, required: ['pid', 'seos', 'first_20'], additionalProperties: false }), // sweeps-market 150, 158
};
// EXTRA: keys the code can add to an object that no instance in this model has
const EXTRA = {
  'checks[]': { hold: S('boolean'), internal: S('boolean'), expected: S('string') }, // 759, 769, 797, 812, 871
};
// REQUIRED_NOT: keys present in every instance here that the code can leave out
const REQUIRED_NOT = {
  'market.velocity.left_out[]': ['b', 'read'], 'maps.factors[]': ['refit'], // sweeps-market 265-267; extract-v2 717
  // a rival with no citation readings, or no link reading, keeps only its id and name (extract-v2 686, 1160)
  'listings.rivals[]': ['phone_named_outside', 'street_named_sites', 'directories_searched', 'directories_answered', 'directories_showed', 'pages_opened', 'pages_readable', 'searches', 'searches_answered', 'read_at'],
  'compare.links[]': ['sites', 'sites_total', 'links_read', 'links_total', 'links_complete', 'sellers', 'not_sellers', 'clean_with_weight', 'fresh', 'fresh_sellers', 'wave', 'strength'],
};
// NULLABLE: keys the code can write as null that are never null here
const NULLABLE = [
  'reviews', 'links', 'listings', 'map', 'market', // 341-342, 540, 674, 262-263 (no --market)
  'meta.facts_check', 'meta.website_run', 'meta.agency', 'meta.record.sha256', // 1336 (no --facts), 1348, 1345
  'business.vertical', 'business.rating', 'business.ratings', 'business.photos', 'business.hours', 'business.rating_dist', 'business.listing_link', 'business.listing_full_link', 'business.listing_path', 'business.listing_is_homepage', 'business.profile_read_at', // 157, 163, 167-176
  'you.domain', 'you.map_share', 'you.visits', 'you.keywords', 'you.linking_sites', 'rivals[].domain', 'rivals[].map_share', 'rivals[].visits', 'rivals[].keywords', 'rivals[].linking_sites', 'rivals[].reviews', // 385-391
  'maps.scan_id', 'maps.phrase', 'maps.scanned', 'maps.scanned_clock', 'maps.started', 'maps.mode', 'maps.in_hours', 'maps.close', 'maps.seen', 'maps.far', 'maps.model', 'maps.apex', // 723-735
  'maps.sweeps[].place', 'maps.sweeps[].leader', 'maps.sweeps[].best_rival', 'maps.sweeps[].open', 'maps.sweeps[].started', 'maps.sweeps[].store_day_hours', 'maps.sweeps[].started_how', 'maps.sweeps[].excluded', 'maps.sweeps[].far.miles', // 233-245, 729-734
  'maps.searches[].place', 'maps.searches[].second', 'maps.searches[].second_points', 'maps.searches[].open', 'maps.scans[].open', // 253-256, 736
  'reviews.windows', 'reviews.since_avg', 'reviews.opening_avg', 'reviews.reply_by_stars[].total', // 364, 372
  'search.keywords_total', 'search.buckets', 'search.top10', 'search.top3', 'search.visits', 'search.moved', 'search.read_at', // 414-424
  'website.url', 'website.title', 'website.title_chars', 'website.description', 'website.description_chars', 'website.words', 'website.chars', 'website.main_heading', 'website.main_heading_flag_missing', 'website.status', 'website.hops', 'website.canonical_self', 'website.business_schema', 'website.age_gate', 'website.crawler_words', 'website.browser_words', 'website.thin_to_crawler', 'website.onpage', 'website.flags', 'website.phone', 'website.desktop', 'website.sitemap_pages', 'website.crawl', 'website.llms', 'website.og_image', 'website.read_at', // 461-477
  'website.rivals[].domain', 'website.rivals[].crawl', 'website.rivals[].page.url', 'website.rivals[].page.status', 'website.rivals[].page.words', 'website.rivals[].page.crawler_words', 'website.rivals[].page.browser_words', 'website.rivals[].page.onpage', 'website.rivals[].page.flags', 'website.rivals[].page.phone', 'website.rivals[].page.desktop', 'website.rivals[].page.gated', 'website.rivals[].page.business_schema', 'website.rivals[].page.read_at', // 438-445
  'links.seller_title', 'links.wave', 'links.store_links', 'links.links_total', 'links.clean_with_weight', 'links.quality.copied_title', // 523-588
  'listings.searches', 'listings.searches_refused', 'listings.searches_answered', 'listings.directories_listed', 'listings.directories_listed_all', 'listings.verdicts', 'listings.matter[].verdict', 'listings.read_at', // 652-683
  'compare.velocity_window', 'compare.listings_kw', 'compare.listings_n', 'compare.rows[].place', 'compare.rows[].entries[].v', 'compare.rows[].entries[].show', // 1060-1066, 1157-1158
  'gaps[].note', // 1171
  // found by validating models built with an input or a setting left out, and the same "?? null" patterns beside them
  'compare.website[].url', 'compare.website[].status', 'compare.website[].words', 'compare.website[].browser_words', 'compare.website[].onpage', 'compare.website[].phone', 'compare.website[].desktop', 'compare.website[].lcp', 'compare.website[].flags', 'compare.website[].gated', 'compare.website[].schema', 'compare.website[].crawl', // 1159
  'compare.links[].sites', 'compare.links[].sites_total', 'compare.links[].links_total', 'compare.links[].strength', 'compare.links[].wave', // 1160
  'compare.listings[].pts', 'compare.listings[].miles', 'compare.velocity[].d30', 'compare.velocity[].d90', 'compare.velocity[].d365', 'compare.velocity[].points', // 699-700, 1155-1157
  'compare.search_sites[].searches', 'compare.search_sites[].visits', 'compare.nearby[].rating', 'business.also_viewed[].rating', 'business.also_viewed[].ratings', // 175, 1070, 1145
  'changes.numbers[].now', 'maps.sweeps[].top[].miles', 'reviews.windows.d30', 'reviews.windows.d90', 'reviews.windows.d365', 'website.gate_heading', // 331, 732, 1229-1234
  'website.rivals[].page.chars', 'website.rivals[].page.thin_to_crawler', 'website.rivals[].page.blocked', 'website.rivals[].page.title_chars', 'website.rivals[].page.microdata_flag', // 438-444
  'listings.verdicts.other_market_label', // 682
  'map.velocity', 'map.velocity.leader', 'map.directories', 'map.listings_read', 'map.leader_listing', // 294-302
  'map.main.place', 'map.main.leader_rating', 'map.main.leader_ratings', 'map.main.second', 'map.main.second_pid', 'map.main.second_points', 'map.searches[].leader_rating', 'map.searches[].second', 'map.searches[].second_pid', 'map.searches[].second_points', // 273-275
  // the market file (sweeps-market.mjs): num() and the optional blocks give null
  'market.velocity', 'market.directories', 'market.listings', 'market.far.cluster', 'market.far.farthest_inside_km', 'market.far.nearest_outside_km', 'market.far.scans[].best', 'market.source.all_sweeps', 'market.directories.rivals', 'market.directories.rows[].slug', // 245-250, 284-313, 317-323
  'market.biz[].lat', 'market.biz[].lng', 'market.biz[].km', 'market.biz[].far', 'market.velocity.rows[].to', 'market.velocity.rows[].windows[].n', 'market.velocity.rows[].windows[].per_month', // 215-224, 240, 271-276
  'market.scans[].seos.read_at', 'market.scans[].seos.hours_that_day', 'market.scans[].seos.open_at_finish', 'market.scans[].seos.in_hours', 'market.scans[].seos.stated.solv', 'market.scans[].seos.stated.found_points', 'market.scans[].seos.stated.atrp', 'market.scans[].seos.disagree.appearances.why', // 192-199
  'market.listings.rows[].rating', 'market.listings.rows[].reviews', 'market.listings.rows[].photos', 'market.listings.rows[].claimed', // 296
];

const ROOT = node();
absorb(ROOT, MODEL, '');

// ---------- 2. meaning: what each key is, and which inputs and rule make it (written from extract-v2.mjs and sweeps-market.mjs) ----------
// The input names are the ones INPUTS.md uses: a table of the business answer (engine_sweeps, citation_verdicts, ...), or a
// reading kind of the audit answers (business_info, reviews, ...). "Store time" is the store's time zone (meta.timezone).
const DESC = Object.entries({
  // ----- meta -----
  'meta': 'About this build: the run, the answers read and the settings that shaped it.',
  'meta.built_at': 'When extract-v2.mjs wrote the file (ISO time, UTC). The one clock read of the chain (new Date(), extract-v2.mjs line 1344). No document prints it.',
  'meta.report_date': 'The report\'s date: the day the main audit run started, store time. From audit_runs.started_at.',
  'meta.run_id': 'The main audit run: the record\'s audit_runs row with the most steps. The full-audit answer must be about the same run. The Competitor Analysis build stops if it prints this id.',
  'meta.run_started': 'When the main run started, store time. From audit_runs.started_at.',
  'meta.run_finished': 'When the main run finished, store time. From audit_runs.finished_at.',
  'meta.parts': 'How many parts the main run\'s request names (audit_runs.request.parts).',
  'meta.steps': 'How many steps the main run took (audit_runs.steps).',
  'meta.agency': 'settings.agency, null without it: the brand mark in the header and the "Prepared by" line.',
  'meta.timezone': 'The time zone of every local time in the model: settings.timezone, else the state table of extract-v2.mjs (locations.state).',
  'meta.record': 'The business answer as read: file name, size, sha256.',
  'meta.record.file': 'File name of the business answer.',
  'meta.record.bytes': 'Its size in bytes.',
  'meta.record.sha256': 'Its sha256.',
  'meta.sources': 'The three answers as read, in order: business, full audit, website audit.',
  'meta.sources[]': 'One answer as read.',
  'meta.sources[].file': 'File name.',
  'meta.sources[].bytes': 'Size in bytes.',
  'meta.sources[].sha256': 'sha256 of the file.',
  'meta.sources[].answer': 'Which answer: the answer\'s own "audit" field ("full-audit", "website-audit"), or "business".',
  'meta.website_run': 'The website audit\'s run (its answer\'s tables.audit_runs[0]); null when the answer holds none.',
  'meta.website_run.id': 'Its id.',
  'meta.website_run.started': 'When it started, store time.',
  'meta.website_run.finished': 'When it finished, store time.',
  'meta.website_run.steps': 'How many steps it took.',
  'meta.v2': 'Always true in extract-v2.mjs output. build-report.mjs takes its v2 branches on it.',
  'meta.order': 'Always "loss-first", the owner\'s order: where the store is losing first. build-report.mjs orders the boards, gap lines and checks by it.',
  'meta.extractor': 'Always "extract-v2.mjs".',
  'meta.second_readings': 'The store\'s review windows beside SEOS\'s own snapshots of the same reviews (review_velocity_snapshots), one row per snapshot window. All must agree before review velocity is quoted.',
  'meta.second_readings[]': 'One window.',
  'meta.second_readings[].what': 'Which window, e.g. "reviews in the last 90 days".',
  'meta.second_readings[].here': '[reviews, replied, a month] counted here from the store\'s dated reviews (its reviews reading).',
  'meta.second_readings[].here[]': 'One of those numbers.',
  'meta.second_readings[].seos': '[reviews_in_window, replied_in_window, per_month] from SEOS\'s snapshot.',
  'meta.second_readings[].seos[]': 'One of those numbers.',
  'meta.second_readings[].agree': 'true when both counts are equal and the paces differ by less than 0.011.',
  'meta.facts_check': 'With --facts: the independent facts file and how many shared numbers agree. The build stops on any disagreement. Null without --facts.',
  'meta.facts_check.file': 'The facts file name (gh-facts.json for Green Haven).',
  'meta.facts_check.compared': 'How many numbers were compared.',
  'meta.facts_check.differ': 'How many disagree (always 0 in a written file).',
  'meta.expected_searches': 'settings.expected_searches as given.',
  'meta.expected_searches[]': 'A search the owner expects a map check for.',
  'meta.missing_searches': 'The expected searches with no map check on file. Each becomes a data check, a task, a hold and a "Not compared yet" line.',
  'meta.missing_searches[]': 'A search with no map check on file.',
  // ----- business -----
  'business': 'The store: its Google listing (the store\'s business_info reading, result.business_info.items[0]) with the record\'s address (the first locations row) and the settings.',
  'business.id': 'SEOS business id (businesses.id).',
  'business.name': 'The store\'s name: the listing title, else settings.brand, else businesses.name.',
  'business.short': 'The short name used in sentences: settings.short, else settings.brand, else businesses.name with words such as " Dispensary" cut.',
  'business.vertical': 'businesses.vertical, else settings.vertical, else null. Only "Cannabis" is known to the category check.',
  'business.vertical_from_settings': 'true when the vertical came from the settings file because the record\'s is empty.',
  'business.register_name': 'businesses.name, the name SEOS registered the business under.',
  'business.street': 'locations.street.',
  'business.city': 'locations.city.',
  'business.state': 'locations.state.',
  'business.zip': 'locations.zip.',
  'business.phone': 'The listing\'s phone, else locations.phone.',
  'business.website': 'locations.website.',
  'business.domain': 'The listing\'s domain, else the host of locations.website, without "www.".',
  'business.category': 'The listing\'s main category.',
  'business.category_ids': 'The listing\'s category ids. The category check looks for cannabis_store when the vertical is Cannabis.',
  'business.category_ids[]': 'One category id.',
  'business.extra_categories': 'The listing\'s additional categories.',
  'business.extra_categories[]': 'One category.',
  'business.claimed': 'true when the listing is claimed (is_claimed). The claimed check.',
  'business.rating': 'Star rating (rating.value). The rating check passes at 4.5.',
  'business.ratings': 'How many Google ratings (rating.votes_count).',
  'business.rating_dist': 'Ratings by star level (rating_distribution): "1" to "5", each with a count.',
  'business.rating_dist.*': 'How many ratings with that many stars.',
  'business.photos': 'Photos on the listing (total_photos).',
  'business.hours': 'Opening hours from work_time.work_hours.timetable; null when the listing has none.',
  'business.hours.days': 'One row per weekday, Monday first.',
  'business.hours.days[]': 'One weekday.',
  'business.hours.days[].day': 'The weekday, in lower case.',
  'business.hours.days[].open': 'Opening time as printed ("10 AM"); null when closed.',
  'business.hours.days[].close': 'Closing time as printed; null when closed.',
  'business.hours.days[].openMins': 'Opening time in minutes after midnight; the opening-hours test of each map check uses it.',
  'business.hours.days[].closeMins': 'Closing time in minutes after midnight.',
  'business.hours.summary': 'The week in one line, days with the same hours run together.',
  'business.hours.daysListed': 'Days with hours. The hours check passes at 7.',
  'business.service_options': 'Ways to shop (attributes.available_attributes.service_options), as words.',
  'business.service_options[]': 'One way to shop.',
  'business.attributes': 'Every attribute the listing shows, as words.',
  'business.attributes[]': 'One attribute.',
  'business.topics': 'What customers mention in reviews (place_topics), most mentioned first.',
  'business.topics[]': 'One topic.',
  'business.topics[].label': 'The word Google pulled out.',
  'business.topics[].n': 'How often it comes up.',
  'business.listing_link': 'The listing\'s website link without its query (origin and path).',
  'business.listing_full_link': 'The same link with its tags (utm_*). Team only.',
  'business.listing_path': 'The path of that link ("/" for the front page).',
  'business.listing_is_homepage': 'true when the listing links to the front page.',
  'business.listing_tag': 'utm_source of the listing link; null when it has none. The Competitor Analysis build stops if it prints it.',
  'business.listing_tag_store': 'The store name inside a "gmb-" tag; null otherwise.',
  'business.listing_tag_matches': 'Whether that tag names this store\'s city; null without such a tag.',
  'business.listing_tag_ours': 'true when a utm_* value of the listing link is settings.agency (our own tag).',
  'business.listing_fixed_link': 'Always null in v2 (a v1 field kept for the 25-key contract).',
  'business.also_viewed': 'The stores Google lists beside this one (people_also_search). The review-count check needs 3 or more.',
  'business.also_viewed[]': 'One of them.',
  'business.also_viewed[].name': 'Its name on Google.',
  'business.also_viewed[].short': 'Its name with words such as " Dispensary" cut.',
  'business.also_viewed[].rating': 'Its star rating.',
  'business.also_viewed[].ratings': 'Its rating count.',
  'business.profile_read_at': 'The day the store\'s listing was read (its business_info fetched_at), store time.',
  // ----- stores, you, rivals -----
  'stores': 'The brand\'s stores, for the store picker in the header. Always one row in v2 (extract-v2.mjs line 691).',
  'stores[]': 'One store.',
  'stores[].id': 'Its business id.',
  'stores[].name': 'Its name (business.name).',
  'stores[].label': 'Its city.',
  'stores[].has_run': 'Always true.',
  'stores[].current': 'Always true.',
  'you': 'The store as one of the businesses the main run names (audit_runs.businesses, the subject), with whole-website search figures.',
  'rivals': 'The other businesses the main run names (audit_runs.businesses that are not the subject): the rivals this report follows.',
  'rivals[]': 'One rival.',
  '**.id': 'Id.',
  'you.id': 'The run\'s slug for the store (businesses[].slug). Comparison entries use it.',
  'rivals[].id': 'The run\'s slug for the rival (businesses[].slug). Comparison entries use it.',
  'you.name': 'business.name.',
  'rivals[].name': 'The rival\'s listing title, else its name in the run\'s businesses list.',
  'you.short': 'business.short.',
  'rivals[].short': 'Its short name (the listing or sweep name with words such as " Dispensary" cut; two businesses that would share one keep longer names).',
  'you.is_you': 'Always true.',
  'rivals[].is_you': 'Always false.',
  'you.domain': 'business.domain.',
  'rivals[].domain': 'The rival\'s listing domain, else its website in locations.named_rivals.',
  'you.place_id': 'The store\'s Google place id.',
  'rivals[].place_id': 'The rival\'s Google place id.',
  'you.map_share': 'The share SEOS stored for the store in the run\'s businesses list (solv).',
  'rivals[].map_share': 'The share SEOS stored for the rival in the run\'s businesses list (solv).',
  'you.reviews': 'Always null: the store\'s count comes from its listing (business.ratings).',
  'rivals[].reviews': 'The review count from the rival\'s reviews_collect step note ("<n> reviews collected"); null when that pull stopped at its limit (rule 4).',
  'you.reviews_capped': 'Always false.',
  'rivals[].reviews_capped': 'true when the rival\'s review pull stopped at its limit.',
  'you.visits': 'Estimated visits a month from search, whole website (ranking_signals traffic etv, rounded).',
  'rivals[].visits': 'Estimated visits a month from search for the rival\'s whole website (ranking_signals).',
  'you.keywords': 'Searches the whole website shows up for (ranking_signals traffic organic count).',
  'rivals[].keywords': 'Searches the rival\'s whole website shows up for (ranking_signals).',
  'you.linking_sites': 'Linking sites of the website when its bl_exhaustive read is complete; else null.',
  'rivals[].linking_sites': 'Linking sites of the rival\'s website when its bl_exhaustive read is complete; else null.',
  // ----- maps -----
  'maps': 'Google Maps: the record\'s own map checks (engine_sweeps, engine_sweep_cells, engine_sweep_businesses, engine_actors) read point by point, the software\'s own fit (apex_runs, run_factors, model_versions) and every search on file.',
  'maps.scan_id': 'The sweep the main audit run used (audit_runs.scan_id).',
  'maps.phrase': 'That run\'s search phrase (audit_runs.keyword).',
  'maps.scanned': 'When the run\'s sweep finished, store time.',
  'maps.scanned_clock': 'The clock time of that finish.',
  'maps.started': 'When it started (engine_actors.at); null when no actor row records it.',
  'maps.started_by_hand': 'true when an actor row records who started it.',
  'maps.mode': 'engine_sweeps.started_how of that sweep.',
  'maps.in_hours': 'Whether that sweep finished inside the store\'s posted hours that day; null when unknown.',
  'maps.close': 'The store\'s closing time on that day.',
  'maps.hold': 'Whether that sweep is on hold (rule 1).',
  'maps.hold_reasons': 'Why it is on hold.',
  'maps.hold_reasons[]': 'One reason.',
  'maps.seen': 'Businesses that sweep listed, not counting the store.',
  'maps.far': 'That sweep\'s businesses by distance from the store (engine_sweep_businesses.distance_km).',
  'maps.far.seen': 'Businesses listed, not counting the store.',
  'maps.far.placed': 'Of those, with a distance.',
  'maps.far.within_25': 'Within 25 miles.',
  'maps.far.mid': '25 to 150 miles.',
  'maps.far.over_150': 'More than 150 miles: another area\'s results.',
  'maps.point_counts_that_fit': '[points of the run\'s sweep] (a v1 field).',
  'maps.point_counts_that_fit[]': 'A point count.',
  'maps.board': 'The first 8 businesses of the run\'s sweep by points in Google\'s top 3.',
  'maps.board[]': 'One business.',
  'maps.board[].id': 'Its place id.',
  'maps.board[].short': 'Short name.',
  'maps.board[].name': 'Full name.',
  'maps.board[].is_you': 'true for the store.',
  'maps.board[].share': 'Percent of the points where it is in the top 3 (2 decimals).',
  'maps.board[].points': 'Points where it is in the top 3.',
  'maps.board[].n': 'Points in the sweep.',
  'maps.board[].in100': 'The share in words ("about 48").',
  'maps.scans_on_file': 'Sweeps in the business answer.',
  'maps.earlier_scans': 'Sweeps other than the run\'s.',
  'maps.earlier_in_hours': 'Of those, finished inside posted hours.',
  'maps.sweeps': 'Every sweep in the business answer, read point by point: each point\'s first 20 businesses (engine_sweep_cells.cells[].top), the store\'s rank field, and the sweep\'s business rows. Businesses more than 150 miles from the store are out of the field (rule 1).',
  'maps.sweeps[]': 'One sweep.',
  'maps.sweeps[].id': 'Its scan id.',
  'maps.sweeps[].kw': 'Its search phrase, in lower case.',
  'maps.sweeps[].grid': 'Grid size (points per side).',
  'maps.sweeps[].radius': 'Radius of the grid.',
  'maps.sweeps[].unit': 'Unit of the radius.',
  'maps.sweeps[].n': 'Points held (cells), the count every figure of the sweep is "of" (rule 6).',
  'maps.sweeps[].grid_points': 'Grid size squared.',
  'maps.sweeps[].excluded': 'Grid points left out before the sweep ran.',
  'maps.sweeps[].exclusion_note': 'SEOS\'s note about them (engine_sweeps.exclusion_note).',
  'maps.sweeps[].you': 'Points where the store is in the top 3 of the point\'s list.',
  'maps.sweeps[].found': 'Points where the store is in the first 20.',
  'maps.sweeps[].not_found': 'Points where the store\'s rank field is empty.',
  'maps.sweeps[].place': 'The store\'s place by points in the top 3 among the businesses in this market; null when it is in no top 3.',
  'maps.sweeps[].tied': 'true when another in-market business has the same points.',
  'maps.sweeps[].of': 'In-market businesses seen in a first 20, the store included.',
  'maps.sweeps[].you_lead': 'true when the store is in a top 3 somewhere and no in-market business has more points (a tie counts).',
  'maps.sweeps[].leader': 'Number 1 by points among in-market businesses.',
  'maps.sweeps[].leader.short': 'Short name.',
  'maps.sweeps[].leader.name': 'Full name.',
  'maps.sweeps[].leader.points': 'Its points in the top 3.',
  'maps.sweeps[].best_rival': 'The in-market business with the most points other than the store.',
  'maps.sweeps[].best_rival.short': 'Short name.',
  'maps.sweeps[].best_rival.name': 'Full name.',
  'maps.sweeps[].best_rival.points': 'Its points in the top 3.',
  'maps.sweeps[].top': 'The first 8 of the field by points in the top 3 (far businesses included, as the tool returned them).',
  'maps.sweeps[].top[]': 'One business.',
  'maps.sweeps[].top[].short': 'Short name.',
  'maps.sweeps[].top[].name': 'Full name.',
  'maps.sweeps[].top[].is_you': 'true for the store.',
  'maps.sweeps[].top[].points': 'Points in the top 3.',
  'maps.sweeps[].top[].found': 'Points in the first 20.',
  'maps.sweeps[].top[].rating': 'Star rating on its sweep row (null for the store\'s own row).',
  'maps.sweeps[].top[].reviews': 'Rating count on its sweep row.',
  'maps.sweeps[].top[].miles': 'Miles from the store (distance_km / 1.609344, 1 decimal).',
  'maps.sweeps[].finished': 'When it finished, store time.',
  'maps.sweeps[].started': 'When it started (engine_actors.at), store time; null when not recorded.',
  'maps.sweeps[].store_day_hours': 'The store\'s posted hours that day.',
  'maps.sweeps[].open': 'Whether it finished inside the posted hours; null when unknown.',
  'maps.sweeps[].open_at_start': 'Whether it started inside them; null when the start is not recorded.',
  'maps.sweeps[].started_how': 'engine_sweeps.started_how.',
  'maps.sweeps[].started_by_hand': 'true when an engine_actors row records who started it.',
  'maps.sweeps[].starter_role': 'That actor\'s role ("admin").',
  'maps.sweeps[].far': 'Another area\'s businesses (more than 150 miles from the store) in this sweep.',
  'maps.sweeps[].far.rows': 'Sweep rows more than 150 miles away.',
  'maps.sweeps[].far.of': 'Sweep rows in all.',
  'maps.sweeps[].far.within_25': 'Rows within 25 miles.',
  'maps.sweeps[].far.mid': 'Rows 25 to 150 miles away.',
  'maps.sweeps[].far.over_150': 'Rows more than 150 miles away.',
  'maps.sweeps[].far.miles': '[nearest, farthest] of the far rows in miles; null when there are none.',
  'maps.sweeps[].far.miles[]': 'Miles.',
  'maps.sweeps[].far.towns': 'The two towns most far rows give in their address.',
  'maps.sweeps[].far.towns[]': 'A town, as "Town, ST".',
  'maps.sweeps[].far.points': 'Points with a far business in their first 20.',
  'maps.sweeps[].far.most_in_a_list': 'The most far businesses in one point\'s first 20.',
  'maps.sweeps[].far.in_top3': 'Points with a far business in their top 3. Any such point is read again without them; the sweep goes on hold when the store\'s count would change.',
  'maps.sweeps[].far.not_found_with_far': 'Points where the store was not found and a far business is in the first 20: not a confirmed "not there".',
  'maps.sweeps[].unlisted': 'Businesses in a point\'s list with no business row in the sweep.',
  'maps.sweeps[].share_mismatches': 'Businesses whose SEOS share (engine_sweep_businesses.solv) disagrees with their points.',
  'maps.sweeps[].by_rank': 'The store\'s counts read a second way, from its rank field at each point.',
  'maps.sweeps[].by_rank.top3': 'Points with a rank of 3 or better.',
  'maps.sweeps[].by_rank.found': 'Points with any rank.',
  'maps.sweeps[].hold': 'Whether the sweep is on hold (rule 1): it ran outside posted hours, a far business changed the store\'s count, its points disagree with its header, or two readings of the store disagree.',
  'maps.sweeps[].hold_reasons': 'Why it is on hold.',
  'maps.sweeps[].hold_reasons[]': 'One reason.',
  'maps.factors': 'The software\'s fit for this market: the run_factors rows of the newest apex_runs row.',
  'maps.factors[]': 'One factor.',
  'maps.factors[].factor': 'Its name.',
  'maps.factors[].rho': 'Rank correlation with map share (run_factors.rho).',
  'maps.factors[].partial': 'The same with the software\'s control held (partial_rho).',
  'maps.factors[].q': 'Its q value.',
  'maps.factors[].n': 'Rows the fit used.',
  'maps.factors[].survives': 'Whether it survives the control (survives_control).',
  'maps.factors[].note': 'SEOS\'s note.',
  'maps.factors[].refit': 'For "Distance from grid centre" only: the fit worked out again over every sweep row the software could see, with and without the rows more than 150 miles away.',
  'maps.factors[].refit.all': 'Spearman rho over all those rows.',
  'maps.factors[].refit.rows': 'How many rows.',
  'maps.factors[].refit.without_far': 'Rho without the far rows.',
  'maps.factors[].refit.rows_without_far': 'How many rows then.',
  'maps.factors[].refit.far_rows': 'How many rows were far.',
  'maps.model': 'The model version of that fit (model_versions); null without an apex run.',
  'maps.model.ver': 'Version.',
  'maps.model.fitted': 'The day it was fitted, store time.',
  'maps.model.population': 'Population it was fitted on.',
  'maps.model.notes': 'SEOS\'s notes on it.',
  'maps.apex': 'The newest apex_runs row; null when there is none.',
  'maps.apex.id': 'Its id.',
  'maps.apex.grid': 'Its grid.',
  'maps.apex.solv': 'Its share.',
  'maps.apex.arp': 'Its average rank.',
  'maps.apex.residual': 'Its residual.',
  'maps.scans': 'Each sweep as a row of the team\'s scan table.',
  'maps.scans[]': 'One sweep.',
  'maps.scans[].id': 'Scan id.',
  'maps.scans[].used': 'true for the run\'s own sweep.',
  'maps.scans[].when': 'When it finished, store time.',
  'maps.scans[].open': 'Whether it finished inside posted hours.',
  'maps.scans[].seen': 'Businesses it listed, not counting the store.',
  'maps.scans[].within_25': 'Sweep rows within 25 miles of the store.',
  'maps.scans[].far': 'Sweep rows more than 150 miles away.',
  'maps.scans[].places': 'Each rival\'s place in the sweep\'s field list, by rival id.',
  'maps.scans[].places.*': 'The place (1 = most points); null when the rival is not listed.',
  'maps.list_runs_by_score': 'Always true.',
  'maps.searches': 'Every search on file, losing first, the order both documents use: the market file\'s latest check of each search, plus any record sweep the market file does not carry. A market row and a record sweep of the same search on the same day must agree, else every search goes on hold.',
  'maps.searches[]': 'One search.',
  'maps.searches[].key': 'Its key ("seos-<scan>" from the market file, "scan-<scan>" from the record).',
  '**.kw': 'The search phrase, in lower case.',
  '**.when': 'When the check finished, store time ("Sun, Oct 11, 2026, 7:21 PM").',
  '**.date': 'Its day, store time.',
  '**.n': 'Points in the check.',
  '**.you': 'Points where the store is in Google\'s top 3.',
  '**.found': 'Points where the store is in the first 20.',
  '**.place': 'The store\'s place by points among in-market businesses; null when it is in no top 3.',
  '**.tied': 'true when another in-market business has the same points.',
  '**.of': 'In-market businesses in the field.',
  '**.you_lead': 'true when the store is number 1 (a tie with number 2 counts).',
  '**.leader': 'Number 1\'s short name (the store\'s when it leads).',
  '**.leader_points': 'Number 1\'s points in the top 3.',
  '**.leader_floor': 'true when a business from another area sat in a top 3 and number 1\'s count would rise without it: printed as "at least".',
  '**.second': 'The best other business\'s short name; null when none.',
  '**.second_points': 'Its points.',
  '**.open': 'Whether the check finished inside the store\'s posted hours.',
  '**.hold': 'On hold (rule 1): never quoted to a client.',
  '**.source': '"market" (the market file) or "record" (a sweep in the business answer).',
  // ----- reviews -----
  'reviews': 'The store\'s own Google reviews (its reviews reading), counted here. Null when the reading holds no reviews.',
  'reviews.collected': 'Reviews read.',
  'reviews.collected_at': 'The day the pull ended (result.reviews.collected_at), store time.',
  'reviews.first': 'The oldest review\'s day.',
  'reviews.capped': 'Whether the pull stopped at its limit.',
  'reviews.with_reply': 'Reviews with an owner reply.',
  'reviews.reply_rate': 'Percent with a reply (1 decimal). The replies check passes at 80.',
  'reviews.reply_by_stars': 'Replies by star level, 5 down to 1.',
  'reviews.reply_by_stars[]': 'One star level.',
  'reviews.reply_by_stars[].stars': 'Stars.',
  'reviews.reply_by_stars[].total': 'Reviews with that many stars.',
  'reviews.reply_by_stars[].replied': 'Of those, with a reply.',
  'reviews.last_3': 'Reviews in the last 3 calendar months before the pull ended.',
  'reviews.last_6': 'In the last 6 months.',
  'reviews.last_12': 'In the last 12 months.',
  'reviews.pace_recent': 'last_3 a month (1 decimal).',
  'reviews.pace_before': 'The 9 months before those 3, a month.',
  'reviews.last_90': 'Reviews in the last 90 days.',
  'reviews.last_365': 'In the last 365 days.',
  'reviews.before_90': 'In the 275 days before the last 90.',
  'reviews.pace_90': 'last_90 a month, a month being 30.4375 days. The review-pace check compares it with pace_before_90.',
  'reviews.pace_before_90': 'before_90 a month.',
  'reviews.opening_n': 'Reviews in the first 10 weeks after the first one.',
  'reviews.opening_avg': 'Their average stars.',
  'reviews.since_n': 'Reviews since those 10 weeks.',
  'reviews.since_avg': 'Their average stars; null when none. The recent-rating check fires when it is 0.2 below opening_avg.',
  'reviews.one_star': 'One-star reviews.',
  'reviews.one_star_since': 'Of those, after the first 10 weeks.',
  'reviews.low': 'Reviews of 1 or 2 stars.',
  'reviews.low_replied': 'Of those, with a reply.',
  'reviews.low_12': 'Low-star reviews of the last 12 months.',
  'reviews.low_12_with_text': 'Of those, with text.',
  'reviews.low_subjects': 'What the low-star reviews of the last 12 months are about, by word match, most first. Team only.',
  'reviews.low_subjects[]': 'One subject.',
  'reviews.low_subjects[].label': 'The subject.',
  'reviews.low_subjects[].n': 'Reviews whose text matches it.',
  'reviews.low_open': 'Low-star reviews with no reply.',
  'reviews.low_open_12': 'Of those, from the last 12 months.',
  'reviews.low_open_list': 'Those reviews, newest first, quoted for the team. Never in the Competitor Analysis (the build stops on a quote).',
  'reviews.low_open_list[]': 'One review: date, rating, recent (inside 12 months) and text.',
  'reviews.monthly': 'Reviews by month (store time), oldest first.',
  'reviews.monthly[]': 'One month.',
  'reviews.monthly[].ym': 'Year and month.',
  'reviews.monthly[].label': 'The month as printed ("Dec 2025").',
  'reviews.monthly[].n': 'Reviews that month.',
  'reviews.monthly[].avg': 'Their average stars.',
  'reviews.windows': 'The store\'s 30, 90 and 365-day windows, the ones SEOS\'s snapshots count; null when its pull is missing.',
  '**.d30': 'The last 30 days to the end of the pull; null when the pull stopped at its limit before the window starts (rule 4).',
  '**.d90': 'The last 90 days, as d30.',
  '**.d365': 'The last 365 days, as d30.',
  '**.days': 'Days in the window.',
  '**.replied': 'Of those reviews, with an owner reply.',
  '**.per_month': 'Reviews a month (a month is 30.4375 days), 2 decimals.',
  'map.velocity.you.per_month': 'Reviews a month over the market file\'s 90-day window (a month is 30.44 days), 1 decimal.', 'map.velocity.leader.per_month': 'As for the store.', 'map.velocity.top[].per_month': 'As for the store.',
  'market.velocity.rows[].per_month': 'Reviews a month over the 90-day window (a month is 30.44 days), 1 decimal.',
  'reviews.windows.d30.n': 'Reviews in the window.',
  'reviews.windows.d90.n': 'Reviews in the window.',
  'reviews.windows.d365.n': 'Reviews in the window.',
  'reviews.snapshots': 'SEOS\'s own snapshots of the store\'s review velocity (review_velocity_snapshots).',
  'reviews.snapshots[]': 'One snapshot.',
  'reviews.snapshots[].days': 'Its window (window_days).',
  'reviews.snapshots[].n': 'reviews_in_window.',
  'reviews.snapshots[].per_month': 'per_month.',
  'reviews.snapshots[].replied': 'replied_in_window.',
  'reviews.snapshots[].total': 'reviews_total.',
  // ----- search -----
  'search': 'Google search: whole-website estimates for the store\'s website (the store\'s competitor_domains reading, its own row), plus the v1 fields kept as constants.',
  'search.keywords_total': 'Searches the whole website shows up for in Google\'s first 100 (full_domain_metrics.organic.count). The footprint check.',
  'search.buckets': 'Those searches by position band.',
  'search.buckets[]': 'One band.',
  'search.buckets[].label': '"Top 3", "4 to 10", "11 to 20", "21 to 50" or "51 to 100".',
  'search.buckets[].n': 'Searches in it (sums of pos_1 ... pos_91_100).',
  'search.top10': 'Searches on page 1 (positions 1 to 10).',
  'search.top3': 'Searches in positions 1 to 3.',
  'search.visits': 'Estimated visits a month (organic etv, rounded).',
  'search.moved': 'Searches new, up, down and lost since the vendor\'s last read.',
  'search.moved.new': 'is_new.',
  'search.moved.up': 'is_up.',
  'search.moved.down': 'is_down.',
  'search.moved.lost': 'is_lost.',
  'search.stored': 'Ranked searches read (ranked_keywords reading); 0 when the run did not read them.',
  'search.stored_brand': 'Of those, brand searches (they contain one of settings.brand_terms).',
  'search.stored_plain': 'Of those, the rest.',
  'search.stored_visits': 'Their estimated visits.',
  'search.brand_visit_share': 'Always null in v2.', 'search.plain_visit_share': 'Always null in v2.', 'search.top_search': 'Always null in v2.', 'search.store_slug': 'Always null in v2.',
  'search.store_searches': 'Always null in v2.', 'search.store_visits': 'Always null in v2.', 'search.store_name_visits': 'Always null in v2.', 'search.store_name_searches': 'Always null in v2.', 'search.name_town': 'Always null in v2.',
  'search.top_brand': 'Always empty in v2.', 'search.top_plain': 'Always empty in v2.', 'search.page1_complete': 'Always false in v2.', 'search.town_page1': 'Always null in v2.',
  'search.sister_town_page1': 'Always empty in v2.', 'search.sister_town_page1_n': 'Always 0 in v2.', 'search.sister_town_by_kind': 'Always empty in v2.',
  'search.other_store_page': 'Always null in v2.', 'search.other_store_page_title': 'Always null in v2.', 'search.other_store_page_links': 'Always null in v2.', 'search.tracked': 'Always null in v2.', 'search.tracked_usable': 'Always null in v2.',
  'search.store_page': 'The path the listing links to (business.listing_path).',
  'search.ranked_read': 'Whether the ranked-searches reading is in the answer. When false the ranked-keywords check fails and a software task is made.',
  'search.ranked_setting': 'The run\'s own setting for that part (audit_runs.request.parts.ranked_keywords) as stored; null when the part is not in the request.',
  'search.organic_ranks_setting': 'The run\'s setting for the position checks (parts.organic_ranks); null when absent.',
  'search.others': 'The other websites in the competitor_domains reading.',
  'search.others[]': 'One website.',
  'search.others[].domain': 'Its domain.',
  'search.others[].shared': 'Searches it shares with the store\'s website (intersections).',
  'search.analytics_connected': 'Whether any analytics_bindings row has a ga_property_id. The connected check.',
  'search.search_console_connected': 'Whether any analytics_bindings row has an sc_property.',
  'search.read_at': 'The day of the competitor_domains reading, store time.',
  // ----- website -----
  'website': 'The store\'s page (the page its Google listing links to, the store\'s site_audit and page_speed readings), its whole-site crawl (site_crawl), and each rival\'s page read the same way.',
  'website.url': 'The page read (origin and path).',
  'website.title': 'Its title tag.',
  'website.title_chars': 'Title length. The title check passes at 30 to 65 with a description of 70 or more.',
  'website.description': 'Its meta description.',
  'website.description_chars': 'Description length.',
  'website.words': 'Words the plain reader got (plain_text_word_count).',
  'website.chars': 'Text size (plain_text_size).',
  'website.headings': 'Headings on the page (meta.htags).',
  'website.gate_heading': 'An age-check heading, when one is found ("Are you 21 or older"); else null.',
  'website.gate_headings': 'How many headings repeat it.',
  'website.label_headings': 'Headings that are one word or a slug (widget labels).',
  'website.sample_headings': 'Up to 3 headings with spaces, for the reader card.',
  'website.sample_headings[]': 'A heading.',
  'website.main_heading_in_list': 'Whether an h1 is in the heading list.',
  'website.main_heading_flag_missing': 'The reading\'s own "no h1" check (checks.no_h1_tag). When the two disagree the heading is "not confirmed".',
  'website.main_heading': 'The first h1.',
  'website.has_frame': 'checks.frame.',
  'website.https': 'checks.is_https.',
  'website.status': 'HTTP status (probe.status, else status_code). The basics check.',
  'website.hops': 'Redirects before the page (probe.hops).',
  'website.canonical_self': 'Whether the page names itself as the original (probe canonical flags).',
  'website.structured_data_found': 'checks.has_micromarkup.',
  'website.head_mentions_schema': 'Whether schema.org is among the head hosts.',
  'website.schema_types': 'JSON-LD types the probe found.',
  'website.schema_types[]': 'A type.',
  'website.business_schema': 'Whether the probe found a business type. With structured_data_found it makes the store-details check; two readings that disagree are "not confirmed" (rule 9).',
  'website.age_gate': 'Whether the page has an age gate (age_gate.gated).',
  'website.crawler_words': 'Words a plain crawler got (render.crawler_words).',
  'website.browser_words': 'Words a browser got (render.browser_words).',
  'website.thin_to_crawler': 'Whether a crawler gets far less than a browser (render.thin_to_crawler).',
  'website.onpage': 'The vendor\'s on-page score; null when the plain and the rendered reads disagree (rule 9).',
  'website.flags': 'Flags of the landing_flags reading: the listing links to a weaker version of the address. The landing-flags check.',
  'website.flags[]': 'One flag.',
  '**.phone': 'Google\'s lab speed test on a simulated slow phone (page_speed result.phone); null when not measured.',
  '**.desktop': 'The same test on a desktop.',
  '**.score': 'Score out of 100.',
  '**.band': '"pass" at 90 or more, "watch" at 50 or more, else "fail".',
  '**.metrics': 'Each measure of the test by its id (lcp, fcp, tbt, cls, si, tti).',
  '**.metrics.*': 'One measure.',
  '**.metrics.*.display': 'As printed ("6.8 s").',
  '**.metrics.*.band': 'Its band, from the measure\'s own score.',
  '**.metrics.*.value': 'The raw value.',
  '**.fixes': 'Opportunities with a saving, in the test\'s order.',
  '**.fixes[]': 'One opportunity.',
  '**.fixes[].id': 'Lighthouse id.',
  '**.fixes[].title': 'Plain words for it ("Trim the scripts the page runs").',
  '**.fixes[].saves_s': 'Seconds it would save (2 decimals).',
  'website.whole_site_read': 'Always false in v2.',
  'website.pages_read': 'Pages read one by one (the page plus each page_<n> part with items).',
  'website.sitemap_pages': 'Pages the site\'s sitemaps list (discovery.urls_total).',
  '**.crawl': 'The whole-site crawl (site_crawl result.summary); null when not read.',
  '**.crawl.progress': 'Crawl progress.',
  '**.crawl.pages': 'Pages crawled.',
  '**.crawl.max': 'The crawl\'s page limit.',
  '**.crawl.at_limit': 'Whether it stopped at the limit: its counts are counts within those pages (rule 4).',
  '**.crawl.score': 'On-page score of the crawled pages. On hold when the crawl stopped at its limit.',
  '**.crawl.broken_links': 'Broken links in the crawled pages.',
  '**.crawl.duplicate_title': 'Pages sharing a title.',
  '**.crawl.duplicate_description': 'Pages sharing a description.',
  '**.crawl.no_h1': 'Pages with no h1; null when the summary does not say.',
  'website.llms': 'Whether an llms.txt was found (site_files.llms.found).',
  'website.og_image': 'The og:image size (site_files.og_image).',
  'website.og_image.width': 'Width in pixels.',
  'website.og_image.height': 'Height in pixels.',
  'website.rivals': 'Each rival\'s page, read the same way in the same run (the rival\'s own readings by place id), and its whole-site crawl (the website audit\'s site:<domain> reading).',
  'website.rivals[]': 'One rival.',
  'website.rivals[].id': 'Its id (rivals[].id).',
  'website.rivals[].name': 'Its short name.',
  'website.rivals[].domain': 'Its domain.',
  'website.rivals[].page': 'Its page as read (the same fields for every store).',
  '**.page.pid': 'Place id.',
  '**.page.url': 'The page read.',
  '**.page.read': 'Whether the page reading has an item.',
  '**.page.status': 'HTTP status.',
  '**.page.words': 'Words the plain reader got.',
  '**.page.chars': 'Text size.',
  '**.page.crawler_words': 'Words a plain crawler got.',
  '**.page.browser_words': 'Words a browser got.',
  '**.page.thin_to_crawler': 'Whether a crawler gets far less than a browser.',
  '**.page.blocked': 'Whether the render was blocked.',
  '**.page.gated': 'Whether the page has an age gate.',
  '**.page.onpage_reads': '[plain read, rendered read] of the on-page score.',
  '**.page.onpage_reads[]': 'One read.',
  '**.page.onpage': 'The on-page score; null when the two reads disagree (rule 9).',
  '**.page.title_chars': 'Title length.',
  '**.page.h1': 'How many h1 headings.',
  '**.page.business_schema': 'Whether the probe found a business type.',
  '**.page.microdata_flag': 'checks.has_micromarkup.',
  '**.page.flags': 'landing_flags flags for that store.',
  '**.page.flags[]': 'One flag.',
  '**.page.flag_notes': 'landing_flags notes.',
  '**.page.flag_notes[]': 'One note.',
  '**.page.read_at': 'The day the page was read.',
  'website.read_at': 'The day the store\'s page was read (site_audit fetched_at).',
  // ----- links -----
  'links': 'The store website\'s linking sites and links (its bl_exhaustive reading), classified before counting (rule 8): a linking site is a seller when a link from it sits on a page whose title sells links, or whose title 20 or more linking hosts share, or when SEOS\'s link ledger (bl_ledger) flags its host. Null when the reading is missing.',
  'links.quality': 'What the sites with weight (vendor rank above 0) that are not sellers are, by their pages\' titles.',
  'links.quality.weighted': 'How many such sites.',
  'links.quality.names_store': 'Those whose page title names the store (settings.brand_terms).',
  'links.quality.names_store[]': 'A domain.',
  'links.quality.copied': 'Those carrying one article copied on unrelated sites (a title two or more linking hosts share).',
  'links.quality.copied[]': 'A domain.',
  'links.quality.copied_title': 'That article\'s title; null when none.',
  'links.quality.articles': 'The rest: articles on general sites.',
  'links.quality.articles[]': 'A domain.',
  'links.quality.rows': 'Each site with weight, strongest first.',
  'links.quality.rows[]': 'One site.',
  'links.quality.rows[].domain': 'Domain.',
  'links.quality.rows[].rank': 'Vendor rank.',
  'links.quality.rows[].links': 'Links from it.',
  'links.quality.rows[].spam': 'Highest spam score of its links.',
  'links.quality.rows[].kind': 'Which of the three kinds.',
  'links.quality.rows[].title': 'A page title of its links (80 characters).',
  'links.quality.strict': 'A stricter count per store, by short name: dropping sites with a spam score of 30 or more and titles two or more hosts share. Null for a store whose links were not all read.',
  'links.quality.strict.*': 'One store\'s stricter count.',
  'links.quality.strict.*.not_sellers': 'Sites left.',
  'links.quality.strict.*.with_weight': 'Of those, with weight.',
  'links.quality.strict.*.spam_30': 'Sites dropped for spam score.',
  'links.quality.strict.*.shared_title': 'Sites dropped for a shared title.',
  'links.sites': 'Linking sites (referring domains read).',
  'links.sites_complete': 'Whether every referring domain was read (rd total_count).',
  'links.links': 'Links read.',
  'links.links_total': 'Links the vendor holds (bl total_count).',
  'links.links_complete': 'Whether every link was read. Seller counts need it (rule 4).',
  'links.classified': 'Sites with at least one link read, or that are sellers.',
  'links.unclassified': 'The rest.',
  'links.sellers': 'Link-selling or scheme sites.',
  'links.not_sellers': 'Sites that are not sellers.',
  'links.with_weight': 'Sites with weight (rank above 0).',
  'links.sellers_with_weight': 'Sellers with weight.',
  'links.clean_with_weight': 'Sites that are not sellers and carry weight.',
  'links.by_title': 'Sellers found by page title.',
  'links.by_ledger': 'Hosts the ledger flags as schemes.',
  'links.networks': 'Page titles shared by 20 or more linking hosts.',
  'links.fresh_days': 'The window for new sites: 30 days before the run started.',
  'links.fresh': 'Sites first seen in that window.',
  'links.fresh_sellers': 'Of those, sellers. The link-wave check fires at 20% of all sites.',
  'links.fresh_with_weight': 'New sites with weight.',
  'links.fresh_sellers_with_weight': 'New sellers with weight.',
  'links.fresh_sellers_also_rivals': 'New sellers that also link to two or more rivals (rivals whose sites were read whole).',
  'links.rivals_read_whole': 'Rivals whose linking sites were read whole.',
  'links.seller_title': 'The seller page title shared by the most sites; null when none.',
  'links.seller_title.title': 'The title (90 characters).',
  'links.seller_title.sites': 'Sites carrying it.',
  'links.seller_list': 'Every seller domain, sorted. Team only (the save button of the Action Plan).',
  'links.seller_list[]': 'A domain.',
  '**.wave': 'The largest shared-title wave in the ledger (bl_ledger shared_title_waves); null when none.',
  '**.wave.title': 'Its page title (90 characters).',
  '**.wave.hosts': 'Hosts sharing it.',
  '**.wave.from': 'First seen, earliest.',
  '**.wave.to': 'First seen, latest.',
  'links.daily': 'New linking sites per day over the 45 days to the run\'s start, store time.',
  'links.daily[]': 'One day.',
  'links.daily[].d': 'The date.',
  'links.daily[].label': 'As printed ("Oct 9").',
  'links.daily[].n': 'Sites first seen that day.',
  'links.daily_peak': 'The most in one day.',
  'links.field': 'Always empty in v2.', 'links.field_size': 'Always 0 in v2.', 'links.field_dropped_far': 'Always 0 in v2.',
  'links.top_sites': 'The 12 strongest sites that are not sellers.',
  'links.top_sites[]': 'One site.',
  'links.top_sites[].domain': 'Domain.',
  'links.top_sites[].score': 'Vendor rank.',
  'links.top_sites[].links': 'Backlinks from it.',
  'links.gap_left': 'Sites that link to two or more rivals and not here, sellers left out (bl_link_gap).',
  'links.gap_floor': 'Whether a part of that read stopped at its limit: the count is a floor (rule 4).',
  'links.gap_parts': 'Each part of the bl_link_gap read.',
  'links.gap_parts[]': 'One part.',
  'links.gap_parts[].part': 'Its name (gap_<n>).',
  'links.gap_parts[].got': 'Rows it returned.',
  'links.gap_parts[].total': 'Rows it holds.',
  'links.gap_no_weight': 'Of gap_left, sites with no weight.',
  'links.gap_worth': 'Sites with a score of 10 or more that link to two or more rivals and not here, strongest first.',
  'links.gap_worth[]': 'One site.',
  'links.gap_worth[].domain': 'Domain.',
  'links.gap_worth[].score': 'Its best rank in the intersection.',
  'links.gap_worth[].rivals': 'The rivals it links to.',
  'links.gap_worth[].rivals[]': 'A rival\'s short name.',
  'links.gap_worth[].cannabis': 'Whether the domain looks like a cannabis site (a word list).',
  'links.store_links': 'Links to the store\'s own page (bl_location result.loc.total_count).',
  'links.tagged_total': 'Links whose target carries our tag (settings.agency) or that the vendor marks as tagged.',
  'links.tagged_here': 'The same count.',
  'links.tagged_ours': 'Whether any exist.',
  'links.tagged_top_page': 'Always null in v2.',
  'links.tagged_sites': 'Sites carrying them.',
  'links.tagged_top_two': 'Always 0 in v2.',
  'links.read_at': 'The day the links were read.',
  // ----- listings -----
  'listings': 'Where the store is listed around the web: Google results for its phone, street and name (cit_sweep), the listing pages opened (cit_pages), the directories probed (cit_probe) and SEOS\'s own verdicts (citation_verdicts). Null when neither cit_sweep nor cit_pages is read. Sources that match settings.other_market_sources are left out of every count.',
  'listings.searches': 'Google searches run (cit_sweep queries).',
  'listings.searches_refused': 'Of those, with no result list.',
  'listings.results_seen': 'Distinct results seen.',
  'listings.searches_answered': 'Searches with a result list.',
  'listings.phone_sites': 'Sites whose results show the store\'s phone.',
  'listings.phone_named_sites': 'Sites showing the phone with the store\'s name (settings.brand_terms, else SEOS\'s brand_regex).',
  'listings.phone_named_outside': 'Of those, outside the store\'s own website and Facebook or Instagram. The details-found check passes at 5.',
  'listings.street_sites': 'Sites showing the street address.',
  'listings.street_named_sites': 'Sites showing it with the name.',
  'listings.named_site_list': 'Outside sites showing the name with the phone or street.',
  'listings.named_site_list[]': 'A host.',
  'listings.phone_other': 'Results showing the phone without the name, off the store\'s own website.',
  'listings.phone_other_sites': 'Their hosts. Team only.',
  'listings.phone_other_sites[]': 'A host.',
  'listings.street_other': 'Results showing the street without the name, off the store\'s website.',
  'listings.pages_opened': 'Listing pages opened (cit_pages candidates).',
  'listings.pages_readable': 'Of those, read with content.',
  'listings.pages_empty': 'Of those, empty: could not be read (rule 5).',
  'listings.sister_pages': 'Always 0 in v2.',
  'listings.store_pages': 'Listing pages of this store (all pages opened).',
  'listings.store_pages_read': 'Of those, read.',
  'listings.store_pages_empty': 'Of those, empty.',
  'listings.store_empty_by_site': 'Empty pages by site, most first.',
  'listings.store_empty_by_site[]': 'One site.',
  'listings.store_empty_by_site[].host': 'Host.',
  'listings.store_empty_by_site[].n': 'Empty pages.',
  'listings.table': 'Each site with a listing tied to the store, and whether the phone and the address were seen on the page or in Google\'s result.',
  'listings.table[]': 'One site.',
  'listings.table[].host': 'Host.',
  'listings.table[].url': 'A listing URL.',
  'listings.table[].pages': 'Pages opened on it.',
  'listings.table[].read': 'Of those, read.',
  'listings.table[].phone': 'Phone seen.',
  'listings.table[].street': 'Address seen.',
  'listings.table[].source': 'Where: the page, Google\'s result, both, or nothing (the page came back empty).',
  'listings.table_both': 'Sites where both were seen. The listings-read check.',
  'listings.matter': 'The listings that matter (Google, Apple Maps, Bing, Yelp, Facebook, Weedmaps, Leafly, Dutchie, Foursquare, Yellow Pages), when cit_probe lists the source: SEOS\'s live verdict first, then what Google\'s results showed.',
  'listings.matter[]': 'One listing.',
  'listings.matter[].id': 'Source id.',
  'listings.matter[].label': 'Its name.',
  'listings.matter[].verdict': 'SEOS\'s verdict for the store (citation_verdicts.verdict by domain); null when none.',
  'listings.matter[].nap': 'Its nap_status; null when none.',
  'listings.matter[].seen': 'What the report saw, in words.',
  'listings.directories_listed': 'Directory sources on SEOS\'s list for the store (cit_probe request.sources), other-market sources left out.',
  'listings.directories_listed_all': 'All sources on the list.',
  'listings.directories_other_market': 'The sources left out (settings.other_market_sources).',
  'listings.directories_other_market[]': 'A source id.',
  'listings.directories_tested': 'Sources tested with a lookup of another business (ctl:<source>).',
  'listings.directories_test_passed': 'Of those, readable.',
  'listings.directories_searched': 'Sources searched for this store (biz:<source>). The directory-coverage check passes at half the list.',
  'listings.directories_answered': 'Of those, readable.',
  'listings.directories_showed': 'Of those, showing the store\'s phone or street.',
  'listings.read_at': 'The day of the cit_pages (else cit_sweep) reading.',
  'listings.verdicts': 'SEOS\'s own verdicts for the store\'s directories (citation_verdicts), other-market sources left out; null when there are none.',
  'listings.verdicts.checked': 'Directories with a verdict.',
  'listings.verdicts.listed': 'Verdict "listed".',
  'listings.verdicts.not_listed': 'Verdict "not-listed".',
  'listings.verdicts.undetermined': 'Verdict "undetermined": could not be read either way (rule 5).',
  'listings.verdicts.contested': 'Verdicts marked contested.',
  'listings.verdicts.checked_all': 'Verdicts with the other-market sources in.',
  'listings.verdicts.all': '[listed, not-listed, undetermined] with them in.',
  'listings.verdicts.all[]': 'A count.',
  'listings.verdicts.other_market': 'The other-market verdicts left out. Team only.',
  'listings.verdicts.other_market[]': 'One of them.',
  'listings.verdicts.other_market[].source': 'Source id.',
  'listings.verdicts.other_market[].domain': 'Domain.',
  'listings.verdicts.other_market[].verdict': 'Its verdict.',
  'listings.verdicts.other_market_label': 'settings.other_market_label ("Michigan"); null without it.',
  'listings.verdicts.computed': 'The day SEOS computed the verdicts.',
  'listings.verdicts.rows': 'Each verdict other than "undetermined", sorted.',
  'listings.verdicts.rows[]': 'One directory.',
  'listings.verdicts.rows[].domain': 'Domain.',
  'listings.verdicts.rows[].tier': 'SEOS\'s tier for it.',
  'listings.verdicts.rows[].verdict': 'Verdict.',
  'listings.verdicts.rows[].nap': 'nap_status; null when none.',
  'listings.verdicts.rows[].url': 'listing_url; null when none.',
  'listings.verdicts.rows[].ours': 'Whether that URL carries our tag (settings.agency).',
  'listings.verdicts.by_tier': 'Verdicts by tier, most first.',
  'listings.verdicts.by_tier[]': 'One tier.',
  'listings.verdicts.by_tier[].tier': 'Tier ("none" when empty).',
  'listings.verdicts.by_tier[].n': 'Verdicts in it.',
  'listings.rivals': 'The same readings for each rival (their own cit_sweep, cit_pages and cit_probe), counted the same way.',
  'listings.rivals[]': 'One rival.',
  'listings.rivals[].id': 'Its id.',
  'listings.rivals[].name': 'Its short name.',
  'listings.rivals[].phone_named_outside': 'Outside sites showing its phone with its name.',
  'listings.rivals[].street_named_sites': 'Sites showing its street with its name.',
  'listings.rivals[].directories_searched': 'Directories searched for it.',
  'listings.rivals[].directories_answered': 'Of those, readable.',
  'listings.rivals[].directories_showed': 'Of those, showing it.',
  'listings.rivals[].pages_opened': 'Listing pages opened.',
  'listings.rivals[].pages_readable': 'Of those, readable.',
  'listings.rivals[].searches': 'Google searches run for it.',
  'listings.rivals[].searches_answered': 'Of those, answered.',
  'listings.rivals[].read_at': 'The day of its reading.',
  // ----- ai -----
  'ai': 'AI answers: not collected (no answer-engine surface in SEOS yet). build-report.mjs does not read it: the AI tab is fixed text, in the Action Plan only.',
  'ai.collected': 'Always false.',
  // ----- checks -----
  'checks': 'Every health check, in the order made: one line per thing looked at. A check with weight "data" is about the run, not the store, and never reaches a client; one marked internal is ours.',
  'checks[]': 'One check.',
  'checks[].door': 'The tab it belongs to.',
  'checks[].id': 'Its id ("map-scan-352", "replies", ...).',
  'checks[].weight': 'outcome (a result), rank (tied to map rank), practice, protect, or data (about the run itself).',
  'checks[].status': 'pass, watch, fail, or na (not measured or on hold).',
  'checks[].title': 'What was looked at.',
  'checks[].value': 'The short result ("58 of 121 points").',
  'checks[].detail': 'What was found, for the team.',
  'checks[].task': 'The task it raises when it does not pass; null when none.',
  'checks[].search': 'A map check\'s search phrase.',
  'checks[].sales': 'The client\'s wording, when it differs from the detail.',
  'checks[].unconfirmed': 'Not-found points that are not confirmed (map-listed).',
  'checks[].codes': 'SEOS finding codes behind the page-checks check.',
  'checks[].codes[]': 'A code.',
  'checks[].hold': 'true when the number is on hold: the client reads "Check to come".',
  'checks[].internal': 'true when it is about our own work: never in the client view.',
  'checks[].expected': 'The expected search a map-missing check is about.',
  // ----- tasks -----
  'tasks': 'Every task, numbered in order: one per check that does not pass and names a task, plus the client email, one card per SEOS finding code, and any task another task waits on.',
  'tasks[]': 'One task.',
  'tasks[].id': 'Its id (TASKS in extract-v2.mjs, or "seos-<code>").',
  'tasks[].door': 'The tab it shows on.',
  'tasks[].owner': 'Who does it: us, client, account (the account manager) or software (the software team).',
  'tasks[].group': 'Its group (GROUPS in extract-v2.mjs).',
  'tasks[].internal': 'true when a check behind it is ours.',
  'tasks[].service_only': 'true when it is never in the client\'s plan.',
  'tasks[].status': 'The status of its checks: fail when any fails.',
  'tasks[].title': 'The team\'s title.',
  'tasks[].sales_title': 'The client\'s title; null when it has none.',
  'tasks[].benefit': 'What it gets the store; null when none.',
  'tasks[].why': 'Why: the task\'s own lines and the detail of each check behind it.',
  'tasks[].why[]': 'One line.',
  'tasks[].steps': 'The steps.',
  'tasks[].steps[]': 'One step.',
  'tasks[].done_when': 'When it counts as done.',
  'tasks[].blocked_by': 'Tasks it waits on.',
  'tasks[].blocked_by[]': 'A task id.',
  'tasks[].checks': 'Checks behind it.',
  'tasks[].checks[]': 'A check id.',
  'tasks[].group_label': 'Its group\'s label.',
  'tasks[].n': 'Its number.',
  'tasks[].is_new': 'true when the previous report (--prev) did not have it; every task without --prev.',
  'tasks[].seos': 'true for a card made from SEOS\'s own findings.',
  'tasks[].seos_code': 'That finding code.',
  'task_groups': 'The groups that hold tasks, in order.',
  'task_groups[]': 'One group.',
  'task_groups[].key': 'Group key.',
  'task_groups[].label': 'Its label.',
  'task_groups[].n': 'Tasks in it.',
  'task_groups[].note': 'For the SEOS group: older duplicates still open in SEOS.',
  'task_groups[].dupes': 'Their SEOS task ids.',
  'task_groups[].dupes[]': 'A SEOS task id.',
  'plan': 'The client\'s plan: the tasks a client may see (owner us or client, not internal, not service only), in the owner\'s order (SALES_ORDER). Every such task must have a place, or the build stops.',
  'plan[]': 'One piece of work.',
  'plan[].n': 'Its number.',
  'plan[].id': 'The task id.',
  'plan[].title': 'The client\'s title.',
  'plan[].benefit': 'What it gets the store.',
  'plan[].yours': 'true when the client does it.',
  'holds': 'Numbers on hold: what the team must not quote yet, why and who clears it. The client copy is read for each hold\'s leak patterns and the build stops on a hit.',
  'holds[]': 'One number on hold.',
  'holds[].number': 'The number, as the team reads it.',
  'holds[].where': 'Where it would show.',
  'holds[].why': 'Why it is held.',
  'holds[].clears': 'Who clears it.',
  'holds[].leak': 'Regular expressions (case ignored) the Competitor Analysis must not contain. Never printed: the client build reads the finished page (text, tooltips, labels) for each pattern and stops on a hit, and stops when a hold has no pattern.',
  'holds[].leak[]': 'One pattern.',
  'ledger': 'You, the gap and the yardstick: up to four lines (ratings beside the stores Google lists next to it, review velocity, phone speed, links with weight). extract-v2.mjs reads it in its rule-2 check (a client line carrying our tag stops the build); build-report.mjs prints only its length, on the console.',
  'ledger[]': 'One line.',
  'ledger[].bucket': 'Its area.',
  'ledger[].measure': 'What is measured.',
  'ledger[].you': 'The store\'s figure.',
  'ledger[].gap': 'The gap.',
  'ledger[].gap.lead': 'In words.',
  'ledger[].them': 'The yardstick.',
  'ledger[].them.lead': 'In words.',
  // ----- compare -----
  'compare': 'The store beside the competition on every tab. A row reaches a client only when it is safe to quote (sales true, not on hold).',
  'compare.rivals': 'The rivals this report follows.',
  'compare.rivals[]': 'One rival.',
  'compare.rivals[].id': 'Its id.',
  'compare.rivals[].name': 'Short name.',
  'compare.rivals[].full': 'Full name.',
  'compare.rivals[].domain': 'Its website.',
  'compare.nearby': 'The stores Google lists beside this one, with a rating count.',
  'compare.nearby[]': 'One store.',
  'compare.nearby[].id': '"near-<name>".',
  'compare.nearby[].name': 'Short name.',
  'compare.nearby[].full': 'Full name.',
  'compare.nearby[].rating': 'Stars.',
  'compare.nearby[].ratings': 'Rating count.',
  'compare.rows': 'The comparison cards: one number, the store beside up to five others, best first.',
  'compare.rows[]': 'One card.',
  'compare.rows[].door': 'Its tab.',
  'compare.rows[].id': 'Its id.',
  'compare.rows[].label': 'What is compared.',
  'compare.rows[].scope': 'Map check, This store, Whole website or Store page.',
  'compare.rows[].unit': 'The unit.',
  'compare.rows[].set': '"map" (the top of the map) or "rivals" (the run\'s rivals).',
  'compare.rows[].sales': 'Safe for a client: shown in the Competitor Analysis.',
  'compare.rows[].hold': 'On hold: team only.',
  'compare.rows[].key': 'A key card.',
  'compare.rows[].note': 'The note under the card.',
  'compare.rows[].team_note': 'A note for the team only; null when none.',
  'compare.rows[].entries': 'The stores on the card, best first, then those with no number.',
  'compare.rows[].entries[]': 'One store.',
  'compare.rows[].entries[].id': 'Its id (you.id, a rival id, or "map-<place id>").',
  'compare.rows[].entries[].name': 'Short name.',
  'compare.rows[].entries[].is_you': 'true for the store.',
  'compare.rows[].entries[].v': 'The number; null when there is none.',
  'compare.rows[].entries[].show': 'The number as printed ("58 of 121").',
  'compare.rows[].entries[].why': 'Why there is no number; null otherwise.',
  'compare.rows[].place': 'The store\'s place when every entry has a number; else null.',
  'compare.rows[].of': 'Entries with a number.',
  'compare.rows[].tied': 'true when the store shares its value.',
  'compare.rows[].lead': 'The id of the first entry.',
  'compare.rows[].summary': 'The card\'s line ("Zen Leaf leads with 88 of 111. Green Haven is 3rd of 6.").',
  'compare.rows[].behind': 'true when the store is not first; null when a number is missing.',
  'compare.search_sites': 'The websites that meet the store\'s website most in Google\'s results (competitor_domains).',
  'compare.search_sites[]': 'One website.',
  'compare.search_sites[].domain': 'Domain.',
  'compare.search_sites[].shared': 'Searches shared with the store\'s website.',
  'compare.search_sites[].searches': 'Its own searches in all.',
  'compare.search_sites[].visits': 'Its estimated visits a month.',
  'compare.search_sites[].rival': 'A rival\'s short name when it is a rival\'s website; else null.',
  'compare.missing': 'What the record does not hand back, by tab, for the team\'s "Not compared yet" lists.',
  'compare.missing.maps': 'Expected searches with no map check.',
  'compare.missing.maps[]': 'One line: what, state, task.',
  'compare.missing.search': 'The searches the websites are found for (not read).',
  'compare.missing.search[]': 'One line.',
  'compare.missing.website': 'Always empty in v2.',
  'compare.missing.links': 'Rivals whose links were not all read.',
  'compare.missing.links[]': 'One line.',
  'compare.missing.ai': 'The AI answers (not collected).',
  'compare.missing.ai[]': 'One line.',
  '**.what': 'What is missing.',
  '**.state': 'Where it stands.',
  'compare.missing.search[].task': 'The task that gets it; null when that task is not on the list.',
  'compare.missing.links[].task': 'Always null.',
  'compare.missing.ai[].task': 'The task that gets it; null when that task is not on the list.',
  'compare.listings': 'The Google listings at the top of the map (the run\'s sweep, by points), from each business_info reading; the rivals are added when missing.',
  'compare.listings[]': 'One business.',
  'compare.listings[].short': 'Short name.',
  'compare.listings[].name': 'Full name.',
  'compare.listings[].me': 'true for the store.',
  'compare.listings[].pts': 'Points in the top 3 in the run\'s sweep.',
  'compare.listings[].rating': 'Stars.',
  'compare.listings[].reviews': 'Rating count.',
  'compare.listings[].photos': 'Photos.',
  'compare.listings[].ways': 'Ways to shop.',
  'compare.listings[].attributes': 'Attributes filled in.',
  'compare.listings[].claimed': 'Claimed.',
  'compare.listings[].category': 'Main category.',
  'compare.listings[].extra': 'Additional categories.',
  'compare.listings[].lands': '"home" when the listing links to a front page, "inner" otherwise; null when unknown.',
  'compare.listings[].miles': 'Miles from the store.',
  'compare.listings_of': 'business_info readings in the answers.',
  'compare.listings_kw': 'The run\'s sweep phrase.',
  'compare.listings_n': 'Its points.',
  'compare.velocity': 'Review velocity of the store and each rival over 30, 90 and 365 days, from each store\'s own dated reviews (its reviews reading).',
  'compare.velocity[]': 'One store.',
  'compare.velocity[].name': 'Short name.',
  'compare.velocity[].is_you': 'true for the store.',
  'compare.velocity[].d30.n': 'Reviews in the window.',
  'compare.velocity[].d90.n': 'Reviews in the window.',
  'compare.velocity[].d365.n': 'Reviews in the window.',
  'compare.velocity[].total': 'Reviews read; null when the pull stopped at its limit.',
  'compare.velocity[].capped': 'Whether it did.',
  'compare.velocity[].oldest': 'The oldest review read.',
  'compare.velocity[].points': 'Points in the top 3 in the run\'s sweep.',
  'compare.velocity_window': 'The day the store\'s window ends.',
  'compare.velocity_window.to': 'That day.',
  'compare.velocity_agrees': 'Whether the store\'s windows agree with SEOS\'s snapshots (meta.second_readings).',
  'compare.speed_order_holds': 'Whether the store\'s place by phone and desktop speed is the same on both readings (the full audit\'s listing pages and the website audit\'s front pages). The Website headline quotes the order only then.',
  'compare.website': 'The store page beside each rival\'s, for the side-by-side table.',
  'compare.website[]': 'One store.',
  'compare.website[].name': 'Short name.',
  'compare.website[].is_you': 'true for the store.',
  'compare.website[].url': 'The page read, without its query when it carries utm tags.',
  'compare.website[].status': 'HTTP status.',
  'compare.website[].words': 'Words a crawler got.',
  'compare.website[].browser_words': 'Words a browser got.',
  'compare.website[].onpage': 'On-page score, or "Not confirmed" when two reads disagree.',
  'compare.website[].phone': 'Phone speed score.',
  'compare.website[].desktop': 'Desktop speed score.',
  'compare.website[].lcp': 'Main content time on a phone, as printed.',
  'compare.website[].flags': 'landing_flags flags.',
  'compare.website[].flags[]': 'A flag.',
  'compare.website[].gated': 'Age gate.',
  'compare.website[].schema': 'Business schema found.',
  'compare.website[].crawl': 'Its crawl: pages, max, score, broken links, duplicate titles.',
  'compare.links': 'Linking sites of each website, classified the same way (team table).',
  'compare.links[]': 'One website.',
  'compare.links[].name': 'Short name.',
  'compare.links[].is_you': 'true for the store.',
  'compare.links[].sites': 'Linking sites when read whole; else null.',
  'compare.links[].sites_total': 'Referring domains the vendor holds.',
  'compare.links[].links_read': 'Links read.',
  'compare.links[].links_total': 'Links the vendor holds.',
  'compare.links[].links_complete': 'Whether every link was read.',
  'compare.links[].sellers': 'Sellers; null when the links were not all read.',
  'compare.links[].not_sellers': 'Not sellers; null when the links were not all read.',
  'compare.links[].clean_with_weight': 'Not sellers with weight; null as above.',
  'compare.links[].fresh': 'Sites new in 30 days.',
  'compare.links[].fresh_sellers': 'Of those, sellers; null as above.',
  'compare.links[].strength': 'Link strength score (ranking_signals ranks).',
  // ----- gaps -----
  'gaps': 'The gap to number 1: each number of the store beside the best there is (number 1 on the map, the strongest one-store rival website, or a target). build-report.mjs runs them biggest gap first.',
  'gaps[]': 'One gap line.',
  'gaps[].door': 'Its tab.',
  'gaps[].id': 'Its id.',
  'gaps[].label': 'What is compared.',
  'gaps[].you': 'The store\'s number.',
  'gaps[].you_show': 'As printed.',
  'gaps[].best': 'The best number.',
  'gaps[].best_show': 'As printed.',
  'gaps[].best_name': 'Who has it.',
  'gaps[].who': 'What that is ("Number 1 on the map").',
  'gaps[].lead': 'true when the store is level or ahead.',
  'gaps[].level': 'true when level.',
  'gaps[].text': 'The gap in words ("88 to 37." / "You lead.").',
  'gaps[].note': 'The tooltip note.',
  'gaps[].scope': '"whole" for whole-website lines (never against a chain\'s website, rule 7); else null.',
  'gaps[].hold': 'On hold: team only.',
  'gaps[].deficit': 'How far behind, as a share of the best (negative when ahead). The sort key.',
  // ----- map: the market file read for the documents -----
  'map': 'The market file (--market) read for the documents: the latest check of each search, the main search\'s history, review velocity and directories from the market file. Null without --market.',
  'map.main': 'The main search: the market row of the run\'s phrase, else the search checked most often.',
  'map.main.key': 'Its key in the market file.',
  'map.main.ts': 'When it finished (Unix seconds).',
  '**.leader_full': 'Number 1\'s full name.',
  '**.leader_b': 'Number 1\'s index in market.biz.',
  '**.leader_pid': 'Number 1\'s place id.',
  '**.leader_rating': 'Number 1\'s stars as the check recorded them.',
  '**.leader_ratings': 'Number 1\'s rating count as recorded.',
  '**.second_pid': 'Its place id.',
  '**.checks': 'How many checks of this search the market file holds.',
  '**.hold_reasons': 'Why it is on hold.',
  '**.hold_reasons[]': 'One reason.',
  '**.scan_id': 'The record sweep it matches.',
  '**.far_top3': 'Points with another area\'s business in a top 3.',
  'map.searches': 'The latest check of each search in the market file, with the record\'s holds added where the record holds the same check.',
  'map.searches[]': 'One search.',
  'map.searches[].key': 'Its key in the market file.',
  'map.searches[].ts': 'When it finished (Unix seconds).',
  'map.won': 'Searches where the store is number 1 at every point.',
  'map.won[]': 'One search.',
  'map.word': 'A word of the store\'s name present in every search it wins at every point; else null.',
  'map.town': 'The search that names the store\'s town (the "<city> dispensary" one first); else null.',
  'map.towns': 'Searches naming the town.',
  'map.series': 'Every check of the main search, oldest first.',
  'map.series[]': 'One check.',
  'map.series[].date': 'Its day.',
  'map.series[].you': 'The store\'s points.',
  'map.series[].n': 'Points.',
  'map.series[].leader': 'Number 1\'s short name.',
  'map.series[].leader_points': 'Number 1\'s points.',
  'map.prior': 'Earlier checks of the main search on the same points.',
  'map.middle': 'The store\'s median points over them; null when none.',
  'map.best': 'The earlier check where the store did best; null when none.',
  'map.reports': 'Checks in the market file (source.reports).',
  'map.businesses': 'Businesses in the market file.',
  'map.first': 'The first check\'s day.',
  'map.last': 'The last check\'s day.',
  'map.outside_hours': 'Checks that finished outside the store\'s posted hours.',
  'map.velocity': 'Review velocity from the market file (market.velocity): the store\'s pace, place and the leader\'s; null when the store has no pace there.',
  'map.velocity.live_from': 'The first day counted.',
  'map.velocity.to': 'The last day counted.',
  'map.velocity.stale_days': 'Always 0 with sweeps-market.mjs.',
  'map.velocity.businesses': 'Businesses with a velocity row.',
  'map.velocity.paced': 'Of those, with a pace.',
  'map.velocity.resets': 'Businesses whose count fell between two checks (no pace).',
  'map.velocity.resets[]': 'One business: name, count before and after, and the days.',
  'map.velocity.you': 'The store\'s row, with its place by pace.',
  'map.velocity.leader': 'Number 1\'s row; null when none.',
  'map.velocity.top': 'The rows of the top 5 others of the main search.',
  'map.velocity.top[]': 'One row.',
  '**.velocity.you.name': 'Short name.', '**.velocity.leader.name': 'Short name.', '**.velocity.top[].name': 'Short name.',
  '**.gained': 'Reviews in the window.',
  '**.from': 'Ratings at the start; null with sweeps-market.mjs (it counts dated reviews).',
  '**.to': 'Ratings at the end (the listing\'s rating count).',
  '**.since': 'The window\'s first day.',
  '**.until': 'Its last day.',
  'map.velocity.you.days': 'Days counted.', 'map.velocity.leader.days': 'Days counted.', 'map.velocity.top[].days': 'Days counted.',
  'map.velocity.you.dated': 'Always null.',
  'map.velocity.you.place': 'The store\'s place by pace.',
  'map.velocity.you.of': 'Businesses with a pace.',
  'map.reach': 'Always null.',
  'map.directories': 'Directory verdicts per business from the market file (market.directories).',
  'map.directories.read': 'The day they were computed.',
  'map.directories.rows': 'One row per business.',
  'map.directories.rows[]': 'One business.',
  'map.directories.rows[].name': 'Short name.',
  'map.directories.rows[].is_you': 'true for the store.',
  'map.directories.rows[].is_leader': 'true for number 1 of the main search.',
  'map.directories.rows[].confirmed': 'Verdicts "listed".',
  'map.directories.rows[].not_listed': 'Verdicts "not-listed".',
  'map.directories.rows[].unknown': 'Verdicts "undetermined".',
  'map.listings_read': 'The day of the newest listing read in the market file.',
  'map.leader_listing': 'Number 1\'s listing row from the market file; null when none.',
  'map.leader_listing.read': 'The day it was read.',
  // ----- market: the market file itself, as sweeps-market.mjs wrote it -----
  'market': 'The market file (sweeps-market.mjs output, the HS market.json shape) embedded whole; null without --market. build-report.mjs and mapview.js draw the map from subject, alphabet, biz, geoms and scans; the rest is kept for the team and the checks.',
  'market.subject': 'The store\'s index in biz (always 0).',
  'market.tz': 'The time zone the market file was built in (--tz).',
  'market.alphabet': 'One character per business of a check: each point\'s list is written as a string of these.',
  'market.velocity': 'Review velocity of every business in the sweeps with a readable reviews reading (sweeps-market.mjs); null when none.',
  'market.velocity.built_from': 'What it was built from, in words.',
  'market.velocity.window_days': 'The main window: 90 days.',
  'market.velocity.window_why': 'Why 90 days, in words.',
  'market.velocity.live_from': 'The earliest window start.',
  'market.velocity.to': 'The latest window end.',
  'market.velocity.stale_days': 'Always 0.',
  'market.velocity.rows': 'One row per business with a pace, fastest first.',
  'market.velocity.rows[]': 'One business.',
  '**.b': 'The business\'s index in market.biz.',
  'market.velocity.rows[].first': 'Window start (Unix seconds).',
  'market.velocity.rows[].last': 'Window end (Unix seconds).',
  'market.velocity.rows[].days': 'Always 90.',
  'market.velocity.rows[].drops': 'Always null.',
  'market.velocity.rows[].built_from': '"reviews".',
  'market.velocity.rows[].read': 'The day the pull ended.',
  'market.velocity.rows[].collected': 'Reviews read.',
  'market.velocity.rows[].limited': 'Whether the pull stopped at its limit.',
  'market.velocity.rows[].oldest': 'The oldest review read.',
  'market.velocity.rows[].windows': 'The 30, 90 and 365-day windows.',
  'market.velocity.rows[].windows[]': 'One window.',
  'market.velocity.rows[].windows[].measured': 'Whether the window is whole (a limited pull must reach back past its start).',
  'market.velocity.rows[].windows[].n': 'Reviews in it; null when not measured.',
  'market.velocity.rows[].windows[].per_month': 'A month (30.44 days, 1 decimal); null when not measured.',
  'market.velocity.left_out': 'Businesses with a reviews reading that got no row, and why.',
  'market.velocity.left_out[]': 'One business.',
  'market.velocity.left_out[].pid': 'Place id.',
  'market.velocity.left_out[].name': 'Name.',
  'market.velocity.left_out[].why': 'Why it was left out.',
  'market.velocity.left_out[].read': 'The day it was read, when known.',
  'market.velocity.seos_check': 'The store\'s windows against SEOS\'s snapshots.',
  'market.velocity.seos_check[]': 'One window.',
  'market.velocity.seos_check[].days': 'Its days.',
  'market.velocity.seos_check[].seos': 'SEOS\'s count.',
  'market.velocity.seos_check[].ours': 'This file\'s count.',
  'market.velocity.seos_check[].agree': 'Whether they agree.',
  'market.directories': 'SEOS\'s citation_verdicts counted per business in the sweeps; null when none.',
  'market.directories.read': 'The day the store\'s verdicts were computed.',
  'market.directories.built_from': 'What it was built from, in words.',
  'market.directories.rows': 'One row per business with verdicts.',
  'market.directories.rows[]': 'One business.',
  'market.directories.rows[].slug': 'businesses.brand_slug for the store; null for others.',
  'market.directories.rows[].confirmed': 'Verdicts "listed".',
  'market.directories.rows[].not_listed': 'Verdicts "not-listed".',
  'market.directories.rows[].unknown': 'Verdicts "undetermined".',
  'market.directories.rows[].other': 'Any other verdict.',
  'market.directories.rows[].sources': 'Verdicts in all.',
  'market.directories.rows[].nap_correct': 'Listed with nap-correct.',
  'market.directories.rows[].nap_incomplete': 'Listed with nap-incomplete.',
  'market.directories.rows[].contested': 'Contested.',
  'market.directories.rivals': 'A note when only the store has verdicts; else null.',
  'market.source': 'How the market file was built: the sweeps read, the inputs and their sha256, what was skipped or missing, notes.',
  'market.source.built_by': 'Always "sweeps-market.mjs".',
  'market.source.reports': 'Checks in the file.',
  'market.source.sweeps': 'Each sweep read.',
  'market.source.sweeps[]': 'One sweep.',
  'market.source.sweeps[].key': 'Its key ("seos-<scan>").',
  'market.source.sweeps[].scan_id': 'Scan id.',
  'market.source.sweeps[].kw': 'Phrase.',
  'market.source.sweeps[].from': '"business data" or "extra:<file>".',
  'market.source.skipped': 'Sweeps left out and why.',
  'market.source.skipped[]': '[what, why].',
  'market.source.first': 'The first check (Unix seconds).',
  'market.source.last': 'The last check (Unix seconds).',
  'market.source.sha256': 'sha256 over the inputs\' names and sha256s.',
  'market.source.inputs': 'Each input file.',
  'market.source.inputs[]': 'One input.',
  'market.source.inputs[].file': 'File name.',
  'market.source.inputs[].role': 'Its role.',
  'market.source.inputs[].bytes': 'Size.',
  'market.source.inputs[].sha256': 'sha256.',
  'market.source.top': 'The depth every point is read to: 20.',
  'market.source.all_sweeps': 'With --all-sweeps: SEOS\'s list of every sweep, and the store\'s sweeps not read.',
  'market.source.all_sweeps.total': 'Sweeps SEOS lists.',
  'market.source.all_sweeps.complete': 'Whether the list is whole (total equals the rows).',
  'market.source.all_sweeps.of_this_store': 'The store\'s sweeps in it.',
  'market.source.all_sweeps.of_this_store[]': 'A scan id.',
  'market.source.all_sweeps.not_read': 'The store\'s sweeps that were not read.',
  'market.source.all_sweeps.not_read[]': 'One sweep: scan_id, kw, finished.',
  'market.source.missing': 'Searches asked for (--want) with no sweep, and why.',
  'market.source.missing[]': 'One search: kw, why.',
  'market.source.notes': 'Notes for a reader.',
  'market.source.notes[]': 'One note.',
  'market.biz': 'Every business in any read sweep, the store first, numbered in the order the sweeps rank them.',
  'market.biz[]': 'One business.',
  'market.biz[].pid': 'Place id.',
  'market.biz[].name': 'Name: the store\'s listing title; another business\'s newest sweep row name, else its listing title.',
  'market.biz[].lat': 'Latitude (the store\'s from locations.lat).',
  'market.biz[].lng': 'Longitude.',
  'market.biz[].site': 'Its listing\'s domain; null without a listing read.',
  'market.biz[].cat': 'Its first category id; null without one.',
  'market.biz[].cat_name': 'Its category name.',
  'market.biz[].claimed': 'Whether its listing is claimed; null without a listing read.',
  'market.biz[].lands': '"home" or "inner": where its listing links; null when unknown.',
  'market.biz[].short': 'Short name (two businesses never share one).',
  'market.biz[].km': 'Kilometres from the store (1 decimal).',
  'market.biz[].far': 'More than the cut-off (150 miles) away: another area\'s results, out of every field size, place and table.',
  'market.geoms': 'Point layouts: one per distinct grid.',
  'market.geoms[]': 'One layout.',
  'market.geoms[].size': 'Points per side.',
  'market.geoms[].n': 'Points held.',
  'market.geoms[].radius': 'Radius.',
  'market.geoms[].unit': 'Unit.',
  'market.geoms[].centre': '[lat, lng] of the grid centre, worked out from the points.',
  'market.geoms[].centre[]': 'A coordinate.',
  'market.geoms[].step': '[lat step, lng step] between points.',
  'market.geoms[].step[]': 'A step.',
  'market.geoms[].cells': 'Each point as [row, column], row 0 north, column 0 west.',
  'market.geoms[].cells[]': 'One point.',
  'market.geoms[].cells[][]': 'Row or column.',
  'market.scans': 'Each check, sorted by phrase then time.',
  'market.scans[]': 'One check.',
  'market.scans[].key': '"seos-<scan id>".',
  'market.scans[].ts': 'When it finished (Unix seconds).',
  'market.scans[].day': 'Its day, YYYY-MM-DD.',
  'market.scans[].mins': 'Minutes after midnight.',
  'market.scans[].geom': 'Its point layout (index in geoms).',
  'market.scans[].full': 'Always true.',
  'market.scans[].field': 'Every business in some point\'s first 20, as [b, top 3 points, listed points, average rank, stars, ratings], most top-3 points first.',
  'market.scans[].field[]': 'One business.',
  'market.scans[].field[][]': 'One of those six values.',
  'market.scans[].you': 'The store\'s row in field.',
  'market.scans[].place': 'The store\'s place by top-3 points (the far businesses counted here; the documents leave them out).',
  'market.scans[].tied': 'Whether that place is shared.',
  'market.scans[].res': 'Each point\'s first 20 as a string of alphabet characters (field rows), best first.',
  'market.scans[].res[]': 'One point.',
  'market.scans[].own': 'Always null.',
  'market.scans[].seos': 'What a reader needs before quoting the check: SEOS\'s own fields set beside the points.',
  'market.scans[].seos.scan_id': 'Scan id.',
  'market.scans[].seos.from': '"business data" or "extra:<file>".',
  'market.scans[].seos.started_how': 'engine_sweeps.started_how.',
  'market.scans[].seos.started': 'Start (Unix seconds) from engine_actors; null when not recorded.',
  'market.scans[].seos.started_when': 'The start, store time.',
  'market.scans[].seos.started_by_role': 'The starter\'s role.',
  'market.scans[].seos.by_person': 'Whether a username is recorded (true or false only).',
  'market.scans[].seos.finished': 'Finish (Unix seconds).',
  'market.scans[].seos.read_at': 'engine_sweeps.read_at (Unix seconds). For a sweep from Eagle Eyes it is the export file\'s modification time.',
  'market.scans[].seos.hours_that_day': 'The store\'s posted hours that day.',
  'market.scans[].seos.open_at_start': 'Open at the start; null when unknown.',
  'market.scans[].seos.open_at_finish': 'Open at the finish.',
  'market.scans[].seos.in_hours': 'Both.',
  'market.scans[].seos.exclusion_note': 'SEOS\'s note on points left out.',
  'market.scans[].seos.excluded': 'The grid points left out, as [row, column].',
  'market.scans[].seos.excluded[]': 'One point.',
  'market.scans[].seos.excluded[][]': 'Row or column.',
  'market.scans[].seos.points_kept': 'Points held.',
  'market.scans[].seos.grid_points': 'Grid size squared.',
  'market.scans[].seos.long_lists': 'Points whose list runs past 20 (the centre point carries the whole feed).',
  'market.scans[].seos.long_lists[]': 'One point.',
  'market.scans[].seos.long_lists[].i': 'Its index.',
  'market.scans[].seos.long_lists[].row': 'Row.',
  'market.scans[].seos.long_lists[].col': 'Column.',
  'market.scans[].seos.long_lists[].listed': 'Businesses it lists.',
  'market.scans[].seos.rank_field_disagrees': 'Points where the store\'s rank field disagrees with its place in the list.',
  'market.scans[].seos.rank_field_disagrees[]': 'One point.',
  'market.scans[].seos.centre_stated': 'The centre SEOS stores (engine_sweep_cells.centre_lat, centre_lng).',
  'market.scans[].seos.centre_stated[]': 'A coordinate.',
  'market.scans[].seos.centre_stated_off_m': 'Metres between it and the centre the points give.',
  'market.scans[].seos.stated': 'The store\'s figures in the sweep header.',
  'market.scans[].seos.stated.solv': 'solv.',
  'market.scans[].seos.stated.found_points': 'found_points.',
  'market.scans[].seos.stated.arp': 'arp.',
  'market.scans[].seos.stated.atrp': 'atrp.',
  'market.scans[].seos.disagree': 'Where SEOS\'s own fields disagree with the first 20 of the points.',
  'market.scans[].seos.disagree.appearances': 'Appearances that differ.',
  'market.scans[].seos.disagree.appearances.n': 'How many businesses.',
  'market.scans[].seos.disagree.appearances.explained': 'Of those, explained by a long list.',
  'market.scans[].seos.disagree.appearances.why': 'The explanation in words; null when none.',
  'market.scans[].seos.disagree.appearances.rows': 'The unexplained ones.',
  'market.scans[].seos.disagree.appearances.rows[]': 'One business.',
  'market.scans[].seos.disagree.best_rank': 'Best ranks that differ.',
  'market.scans[].seos.disagree.best_rank[]': 'One business.',
  'market.scans[].seos.disagree.arp': 'Average ranks that differ.',
  'market.scans[].seos.disagree.arp[]': 'One business.',
  'market.scans[].seos.deep': 'Businesses SEOS lists for the check that are in no point\'s first 20.',
  'market.scans[].seos.deep.n': 'How many.',
  'market.scans[].seos.deep.rows': 'Each as [place id, name, best position, km].',
  'market.scans[].seos.deep.rows[]': 'One business.',
  'market.scans[].seos.deep.rows[][]': 'One of those four values.',
  'market.listings': 'The Google listings at the top of each check (the store, and every business in a top 10 by top-3 points); null when none was read.',
  'market.listings.read': 'The newest read day.',
  'market.listings.read_from': 'The oldest read day.',
  'market.listings.rule': 'Which businesses, in words.',
  'market.listings.rows': 'One row per business.',
  'market.listings.rows[]': 'One business.',
  'market.listings.rows[].read': 'The day it was read.',
  'market.listings.rows[].name': 'Its Google listing title.', 'map.leader_listing.name': 'Its Google listing title.',
  'market.listings.not_read': 'Businesses in that set with no listing read.',
  'market.listings.not_read[]': 'A short name.',
  '**.name': 'Name.',
  '**.rating': 'Stars.',
  '**.reviews': 'Rating count.',
  '**.photos': 'Photos.',
  '**.claimed': 'Claimed.',
  '**.category': 'Main category.',
  '**.extra_categories': 'Additional categories.',
  '**.extra_categories[]': 'A category.',
  '**.ways': 'Ways to shop.',
  '**.attributes': 'Attributes filled in.',
  '**.lands': '"home" when its listing links to a front page, "inner" otherwise; null when unknown.',
  'market.far': 'The 150-mile line: which businesses are another area\'s results, and where they show in each check.',
  'market.far.cutoff_mi': 'The line in miles (--far-mi, 150).',
  'market.far.cutoff_km': 'The line in kilometres.',
  'market.far.farthest_inside_km': 'The farthest business inside it.',
  'market.far.nearest_outside_km': 'The nearest business outside it.',
  'market.far.listed_outside': 'Businesses outside it in any read sweep.',
  'market.far.listed_inside': 'Businesses inside it.',
  'market.far.why': 'Why 150 miles, in words.',
  'market.far.businesses': 'The far businesses (indexes in biz).',
  'market.far.businesses[]': 'An index.',
  'market.far.cluster': 'Where they sit: centre and distance range; null when none.',
  'market.far.cluster.centre': '[lat, lng].',
  'market.far.cluster.centre[]': 'A coordinate.',
  'market.far.cluster.km': '[nearest, farthest] in km.',
  'market.far.cluster.km[]': 'A distance.',
  'market.far.scans': 'Per check: far businesses in the field and the points they reach.',
  'market.far.scans[]': 'One check.',
  'market.far.scans[].key': 'Its key.',
  'market.far.scans[].field': 'Far businesses in its field.',
  'market.far.scans[].listed': 'Far businesses SEOS lists for it.',
  'market.far.scans[].deep_only': 'Of those, only past 20.',
  'market.far.scans[].points': 'Each point with one, as [index, row, column, how many, best position].',
  'market.far.scans[].points[]': 'One point.',
  'market.far.scans[].points[][]': 'One of those five values.',
  'market.far.scans[].top3': 'Points with one in the top 3.',
  'market.far.scans[].best': 'The best position a far business reached.',
  // ----- the keys inside the shapes taken from the code (lists that are empty in the Green Haven model) -----
  'reviews.low_open_list[].date': 'The review\'s day, store time.',
  'reviews.low_open_list[].rating': 'Its stars (1 or 2).',
  'reviews.low_open_list[].recent': 'true when it is from the last 12 months.',
  'reviews.low_open_list[].text': 'Its text, or "(no text, stars only)".',
  'compare.missing.maps[].task': 'The task that gets it ("expected-search"); null when that task is not on the list.',
  'map.velocity.resets[].name': 'Short name.',
  'map.velocity.resets[].before': 'Its rating count at the earlier check.',
  'map.velocity.resets[].before_on': 'That check\'s day.',
  'map.velocity.resets[].after': 'Its rating count at the later check, lower than before.',
  'map.velocity.resets[].after_on': 'That check\'s day.',
  'market.source.skipped[][]': 'What was left out, then why.',
  'market.source.all_sweeps.not_read[].scan_id': 'Scan id.',
  'market.source.all_sweeps.not_read[].kw': 'Its phrase as stored.',
  'market.source.all_sweeps.not_read[].finished': 'When it finished, as stored (engine_sweeps.finished_at).',
  'market.source.missing[].kw': 'The search asked for (--want).',
  'market.source.missing[].why': 'Why there is no sweep of it, in words.',
  'market.scans[].seos.rank_field_disagrees[].i': 'The point\'s index.',
  'market.scans[].seos.rank_field_disagrees[].row': 'Its row.',
  'market.scans[].seos.rank_field_disagrees[].col': 'Its column.',
  'market.scans[].seos.rank_field_disagrees[].rank_field': 'The store\'s rank field there (0 when empty).',
  'market.scans[].seos.rank_field_disagrees[].in_list': 'The store\'s place in that point\'s list (0 when absent).',
  'market.scans[].seos.disagree.appearances.rows[].pid': 'Place id.',
  'market.scans[].seos.disagree.appearances.rows[].name': 'Its name on the sweep row.',
  'market.scans[].seos.disagree.appearances.rows[].seos': 'SEOS\'s appearances.',
  'market.scans[].seos.disagree.appearances.rows[].first_20': 'Points with it in the first 20.',
  'market.scans[].seos.disagree.appearances.rows[].whole_list': 'Points with it anywhere in the list.',
  'market.scans[].seos.disagree.appearances.rows[].explained': 'Whether the whole list explains the difference.',
  'market.scans[].seos.disagree.best_rank[].pid': 'Place id.',
  'market.scans[].seos.disagree.best_rank[].seos': 'SEOS\'s best rank.',
  'market.scans[].seos.disagree.best_rank[].first_20': 'Its best rank in the first 20; null when it is in none.',
  'market.scans[].seos.disagree.arp[].pid': 'Place id.',
  'market.scans[].seos.disagree.arp[].seos': 'SEOS\'s average rank.',
  'market.scans[].seos.disagree.arp[].first_20': 'Its average rank over the points where it is in the first 20.',
  'market.scans[].seos.disagree.arp[].from': '"header" when SEOS\'s figure is the sweep header\'s (the store); absent otherwise.',
  // ----- verdict, counts, changes -----
  'verdict': 'The headline, in the owner\'s order: the biggest loss first, the win last. Searches on hold are not used.',
  'verdict.a': 'The headline\'s first part (the biggest loss, else the win).',
  'verdict.b': 'Its second part (the win, else the next loss).',
  'verdict.lead': 'The lead paragraph: one line per search, losses first, then the ratings.',
  'verdict.order': 'Always "loss-first".',
  'verdict.losses': 'Searches lost, biggest first.',
  'verdict.losses[]': 'A phrase.',
  'verdict.wins': 'Searches won.',
  'verdict.wins[]': 'A phrase.',
  'counts': 'Checks per tab a client would see (weight not data, not internal), by status. The tiles\' meters.',
  'counts.*': 'One tab.',
  'counts.*.pass': 'Checks that pass.',
  'counts.*.watch': 'Checks to look at.',
  'counts.*.fail': 'Checks that fail.',
  'counts.*.na': 'Not measured or on hold.',
  'counts.*.total': 'All of them.',
  'changes': 'What changed since the previous report (--prev); without it, first_run and the key numbers.',
  'changes.first_run': 'true without --prev.',
  'changes.numbers': 'The key numbers (ratings, stars, reviews, map points per search, searches, phone speed, linking sites).',
  'changes.numbers[]': 'One number.',
  'changes.numbers[].label': 'Its label.',
  'changes.numbers[].now': 'Its value now.',
});

// ---------- 3. where it shows: the probe ----------
const HTML_TABS = { overview: 'Overview', maps: 'Google Maps', search: 'Google search', ai: 'AI answers', website: 'Website', links: 'Links and listings', plan: null };
const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", nbsp: ' ' };
const text = s => s.replace(/<[^>]*>/g, ' ').replace(/&(amp|lt|gt|quot|#39|nbsp);/g, (m, k) => ENT[k]).replace(/\s+/g, ' ').trim();
const segments = (html, doc) => {
  const out = [];
  const grab = (name, a, b) => { const i = html.indexOf(a); if (i < 0) return; const j = html.indexOf(b, i + a.length); out.push([name, html.slice(i, j < 0 ? html.length : j)]); };
  grab('the page title', '<title>', '</title>');
  grab('the header bar', '<header class="bar">', '</header>');
  grab('the tab strip', '<nav class="tabs"', '</nav>');
  for (const m of html.matchAll(/<section class="tab" id="tab-([a-z]+)">/g)) { const j = html.indexOf('</section>', m.index); const name = HTML_TABS[m[1]] || (doc === 'ca' ? 'The plan' : 'Tasks'); out.push([name, html.slice(m.index, j)]); }
  grab('the footer', '<footer class="foot">', '</footer>');
  grab('the find box', 'id="report-find">', '</script>');
  grab('the task data (copy and spreadsheet)', 'id="report-tasks">', '</script>');
  grab('the link-seller list (save button)', 'id="report-sellers">', '</script>');
  grab('the map data (redraw)', 'id="report-market">', '</script>');
  return out;
};
const HEAD = /<h2[^>]*>([\s\S]*?)<\/h2>|<h3[^>]*>([\s\S]*?)<\/h3>|<p class="card-k"[^>]*>([\s\S]*?)<\/p>|<summary>([\s\S]*?)<\/summary>|<p class="grp"[^>]*>([\s\S]*?)<\/p>|<p class="empty-t">([\s\S]*?)<\/p>/g;
const where = (base, probe, doc) => {
  const A = segments(base, doc), B = segments(probe, doc), parts = [];
  for (const [name, a] of A) {
    const b = (B.find(x => x[0] === name) || [null, null])[1];
    if (b === a) continue;
    if (b === null) { parts.push(`${name} (gone)`); continue; }
    let i = 0; while (i < a.length && i < b.length && a[i] === b[i]) i++;
    if (/^the (find box|task data|link-seller list|map data|page title|header bar|tab strip|footer)/.test(name)) { parts.push(name); continue; }
    // a tab's own headline (h2 "door-h") and a task card's summary carry data: the place is named by the heading above them
    const heads = [...a.slice(0, i).matchAll(HEAD)].filter(m => !/^<h2 class="h1 door-h"/.test(m[0]) && !/class="tk-n"/.test(m[0])).map(m => text(m.slice(1).find(x => x !== undefined) || ''));
    const h = heads.length ? heads[heads.length - 1] : '';
    parts.push(h ? `${name} > ${h.length > 60 ? h.slice(0, 57).trimEnd() + '...' : h}` : `${name} (headline)`);
  }
  return parts;
};
const run = (args) => new Promise(res => execFile(process.execPath, args, { maxBuffer: 1 << 26 }, (err, stdout, stderr) => res({ code: err ? (err.code ?? 1) : 0, stderr: String(stderr || '') })));
// why a build stopped, in the build's own words, up to the first colon: what follows a colon can quote the page. The one
// exception keeps the fixed labels after "still carries:" and drops any quoted page text.
const stopReason = s => {
  const m = /BUILD FAILED: ([^\n]*)/.exec(s);
  if (m) { const t = /^the (client copy|service document) still carries: /.test(m[1]) ? m[1].replace(/ \(".*$/, '') : m[1].split(':')[0]; return 'the build stops (' + t.trim() + ')'; }
  const e = /\b([A-Z][a-zA-Z]*Error)\b/.exec(s); return 'the build stops (' + (e ? e[1] : 'error') + ')';
};

// the leaves: every key that holds a value, with the type to probe it as
const leaves = [];
for (const [p, n] of NODES) {
  if (!p || p.endsWith('[]') && n.types.has('object')) continue;
  const t = [...n.types];
  const scalar = t.filter(x => ['string', 'number', 'boolean'].includes(x));
  if (scalar.length) { leaves.push({ path: p, as: scalar[0] }); continue; }
  if (t.length === 1 && t[0] === 'null') { const ty = TYPE[p] ? [].concat(TYPE[p]).find(x => ['string', 'number', 'boolean'].includes(x)) : null; leaves.push({ path: p, as: ty || null, nullOnly: true }); }
}
const setAt = (obj, p, fn) => { // change every instance of path p
  const segs = segsOf(p); let k = 0;
  const walk = (o, i) => {
    if (o === null || typeof o !== 'object') return;
    const s = segs[i], last = i === segs.length - 1;
    const keys = s === '[]' ? (Array.isArray(o) ? o.keys() : []) : s === '*' ? Object.keys(o) : (Object.prototype.hasOwnProperty.call(o, s) ? [s] : []);
    for (const key of keys) { if (last) { const v = fn(o[key], k++); if (v !== undefined) o[key] = v; } else walk(o[key], i + 1); }
  };
  walk(obj, 0); return k;
};
const perturb = (as, nullOnly) => (v, k) => {
  if (nullOnly) return as === 'string' ? 'QZX' : as === 'number' ? 777 : as === 'boolean' ? true : undefined;
  // text: the last digit moves too (a phone or a date is printed reformatted, which would drop a marker alone)
  if (typeof v === 'string') return v.replace(/(\d)(?=\D*$)/, d => String((Number(d) + 1) % 10)) + ' QZX';
  if (typeof v === 'number') return v + 1 + 7 * k;
  if (typeof v === 'boolean') return !v;
  return undefined;
};

const reach = {};
const probeAll = async () => {
  // --reach-from=<reach.json>: reuse a saved probe of the same model (for editing descriptions only; the published schema is made with a fresh probe)
  if (opt('reach-from')) { const saved = JSON.parse(fs.readFileSync(opt('reach-from'), 'utf8')); const miss = leaves.filter(L => !saved[L.path]).map(L => L.path); if (miss.length) die(`the saved probe lacks ${miss.length} keys, e.g. ${miss.slice(0, 5).join(', ')}`); for (const L of leaves) reach[L.path] = saved[L.path]; console.log('NOTE: the reach comes from a saved probe, ' + path.basename(opt('reach-from'))); return; }
  const work = opt('work') || fs.mkdtempSync(path.join(os.tmpdir(), 'model-probe-'));
  fs.mkdirSync(work, { recursive: true });
  const docArgs = { ca: ['--audience=client', '--doc=Competitor Analysis'], ap: ['--audience=service', '--doc=Action Plan'] };
  const build = async (model, tag) => { const inp = path.join(work, tag + '.json'); fs.writeFileSync(inp, model); const r = {};
    for (const d of ['ca', 'ap']) { const out = path.join(work, `${tag}-${d}.html`); const x = await run([buildPath, inp, out, ...docArgs[d]]); r[d] = x.code === 0 ? fs.readFileSync(out, 'utf8') : { stop: stopReason(x.stderr) }; try { fs.rmSync(out); } catch {} }
    try { fs.rmSync(inp); } catch {} return r; };
  const base = await build(MODEL_RAW, 'base');
  for (const d of ['ca', 'ap']) if (typeof base[d] !== 'string') die(`the baseline ${d} build stops: ${base[d].stop}`);
  if (opt('ca') && fs.readFileSync(opt('ca'), 'utf8') !== base.ca) die('the baseline Competitor Analysis is not byte-identical to ' + path.basename(opt('ca')));
  if (opt('ap') && fs.readFileSync(opt('ap'), 'utf8') !== base.ap) die('the baseline Action Plan is not byte-identical to ' + path.basename(opt('ap')));
  const jobs = Math.max(1, Number(opt('jobs') || 8));
  let next = 0, done = 0;
  const worker = async () => {
    while (next < leaves.length) {
      const L = leaves[next++], id = 'p' + String(leaves.indexOf(L)).padStart(5, '0');
      if (L.nullOnly && !L.as) { reach[L.path] = { probed: false, why: 'null in this model, and not a scalar type to probe it as' }; done++; continue; }
      const m = JSON.parse(MODEL_RAW); const n = setAt(m, L.path, perturb(L.as, L.nullOnly));
      if (!n) { reach[L.path] = { probed: false, why: 'no instance to change' }; done++; continue; }
      const r = await build(JSON.stringify(m, null, 1), id);
      const res = { probed: true, instances: n, as: L.nullOnly ? `null, probed as a ${L.as}` : L.as };
      for (const d of ['ca', 'ap']) res[d] = typeof r[d] !== 'string' ? { state: 'stops', why: r[d].stop } : r[d] === base[d] ? { state: 'same' } : { state: 'changed', where: where(base[d], r[d], d) };
      reach[L.path] = res; done++;
      if (done % 100 === 0) process.stderr.write(`  probed ${done} of ${leaves.length}\n`);
    }
  };
  await Promise.all(Array.from({ length: jobs }, worker));
  // workers finish in any order: put the results back in the model's own key order, so every output is the same run to run
  const ordered = Object.fromEntries(leaves.map(L => [L.path, reach[L.path]]));
  for (const k of Object.keys(reach)) delete reach[k];
  Object.assign(reach, ordered);
  if (!opt('work')) fs.rmSync(work, { recursive: true, force: true });
};

// ---------- emit ----------
const PROBLEMS = [];
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
// the description of a path: an exact entry first, then the most specific pattern (more segments, no "**" before "**")
const MATCHED = {}; // path -> the DESC entry used (--desc-report)
const descOf = p => {
  let best = null, score = -1, bestPat = null;
  for (const [pat, w] of DESC) {
    if (!matches(pat, p)) continue;
    const sc = pat === p ? 1e6 : (pat.startsWith('**') ? 0 : 1000) + segsOf(pat).length * 10 - (pat.match(/\*/g) || []).length;
    if (sc > score) { best = w; score = sc; bestPat = pat; }
  }
  MATCHED[p] = bestPat;
  return best;
};
// where a key shows: its own probe, or (for an object or a list) every probe under it
const reachOf = p => {
  const own = reach[p];
  const under = own ? [own] : Object.entries(reach).filter(([k]) => k.startsWith(p + '.') || k.startsWith(p + '[]')).map(([, v]) => v);
  const probed = under.filter(x => x.probed);
  if (!probed.length) return null;
  const side = d => {
    const st = probed.map(x => x[d]);
    if (st.some(x => x.state === 'changed')) { const w = [...new Set(st.filter(x => x.state === 'changed').flatMap(x => x.where))]; return 'shows in ' + (w.length > 6 ? w.slice(0, 6).join('; ') + `; and ${w.length - 6} more` : w.join('; ')); }
    if (st.some(x => x.state === 'stops')) return [...new Set(st.filter(x => x.state === 'stops').map(x => x.why))].join('; ');
    return 'no change seen';
  };
  return { ca: side('ca'), ap: side('ap'), caState: probed.some(x => x.ca.state === 'changed') ? 'yes' : probed.some(x => x.ca.state === 'stops') ? 'stops' : 'no' };
};
const REACH = {}; // path -> reach summary, for MODEL.md
const describe = (p, dp, extra = '') => {
  if (!dp) return ''; // the root: described where the schema is put together
  const d = descOf(dp);
  if (!d) PROBLEMS.push('no description: ' + dp);
  const r = reachOf(p); REACH[p] = r;
  return `${d || ''}${extra ? ' ' + extra : ''}${r ? ` Competitor Analysis: ${r.ca}. Action Plan: ${r.ap}.` : ' Not probed: no value of it in this model.'}`.trim();
};
const ORDER = ['object', 'array', 'string', 'number', 'boolean', 'null'];
// n: the inferred node; p: the path in this model; dp: the path whose description and overlay apply (a copied shape's source)
const ROWS = []; // every key in schema order, for MODEL.md
// a shape taken from the code (a list that is empty in this model): each key in it gets its description and its row too
const fromCode = (sch, p, dp, note) => {
  const x = { description: describe(p, dp, note), ...sch };
  ROWS.push({ p, dp, s: x });
  if (x.properties) for (const [k, sub] of Object.entries(x.properties)) x.properties[k] = fromCode(sub, join(p, k), join(dp, k), 'From the code.');
  if (x.items && typeof x.items === 'object') x.items = fromCode(x.items, p + '[]', dp + '[]', 'From the code.');
  return x;
};
const emit = (n, p, dp = p) => {
  const s = { description: describe(p, dp) };
  if (p) ROWS.push({ p, dp, s });
  if (has(CONST, dp)) {
    s.const = CONST[dp];
    for (const v of n.seen) if (v !== JSON.stringify(CONST[dp])) die(`${dp}: the model holds ${v}, the code fixes ${JSON.stringify(CONST[dp])}`);
    return s;
  }
  let types = has(TYPE, dp) ? (TYPE[dp] === null ? null : [...TYPE[dp]]) : [...n.types];
  if (types && has(TYPE, dp)) for (const t of n.types) if (!types.includes(t)) die(`${dp}: the model holds a ${t}, the overlay says ${types.join('|')}`);
  if (types && NULLABLE.includes(dp) && !types.includes('null')) types.push('null');
  if (types) { types.sort((a, b) => ORDER.indexOf(a) - ORDER.indexOf(b)); s.type = types.length === 1 ? types[0] : types; }
  const en = Object.entries(ENUM).find(([pat]) => matches(pat, dp));
  if (en) { s.enum = en[1]; for (const v of n.values) if (!en[1].includes(v)) die(`${dp}: the model holds ${JSON.stringify(v)}, not in the enum ${JSON.stringify(en[1])}`); }
  const src = SHAPE[dp] ? NODES.get(SHAPE[dp]) : n, srcPath = SHAPE[dp] || dp;
  if (types && types.includes('object')) {
    if (src.map) s.additionalProperties = emit(src.mapVal, join(p, '*'), join(srcPath, '*'));
    else {
      s.properties = {}; const req = [];
      for (const [k, c] of src.props) { s.properties[k] = emit(c, join(p, k), join(srcPath, k)); if (c.present === src.objects && !(REQUIRED_NOT[srcPath] || []).includes(k)) req.push(k); }
      for (const [k, sch] of Object.entries(EXTRA[srcPath] || {})) if (!s.properties[k]) { const x = { description: describe(join(p, k), join(srcPath, k), 'Not in this model.'), ...sch }; s.properties[k] = x; ROWS.push({ p: join(p, k), dp: join(srcPath, k), s: x }); }
      s.required = req; s.additionalProperties = false;
    }
  }
  if (types && types.includes('array')) {
    const ip = p + '[]', idp = srcPath + '[]';
    if (ITEMS[idp]) s.items = fromCode(JSON.parse(JSON.stringify(ITEMS[idp])), ip, idp, 'Empty in this model; the item shape is from the code.');
    else if (SHAPE[idp]) s.items = emit(NODES.get(SHAPE[idp]), ip, idp);
    else if (src.items && src.items.count) s.items = emit(src.items, ip, idp);
    else PROBLEMS.push('an empty list with no item shape: ' + dp);
  }
  return s;
};

await probeAll();
if (opt('reach-json')) fs.writeFileSync(opt('reach-json'), JSON.stringify(reach, null, 1));
const top = emit(ROOT, '');
const schema = { $schema: 'https://json-schema.org/draft/2020-12/schema', $id: 'report-data.schema.json', title: 'The report model (report-data.json, v2)',
  description: 'report-data.json: the report model extract-v2.mjs writes and build-report.mjs reads, 25 top-level keys. Generated by make-model-schema.mjs from the Green Haven model (SEOS business 48): the structure is inferred from that model and widened by an overlay checked against extract-v2.mjs; each description says what a key means, what makes it, and where it shows in the two documents, measured by changing it and rebuilding both.',
  type: 'object', properties: top.properties, required: Object.keys(MODEL), additionalProperties: false };
for (const [p, n] of NODES) if (p && n.types.size === 1 && n.types.has('null') && !has(CONST, p) && !has(TYPE, p) && !SHAPE[p] && !matches('map.town.*', p)) PROBLEMS.push('null in this model with no type from the code: ' + p);
const noDesc = PROBLEMS.filter(x => x.startsWith('no description')), other = PROBLEMS.filter(x => !x.startsWith('no description'));
if (other.length) console.error(other.join('\n'));
if (noDesc.length) console.error(`${noDesc.length} keys with no description: ${noDesc.map(x => x.slice(16)).join(', ')}`);
if (opt('desc-report')) fs.writeFileSync(opt('desc-report'), Object.entries(MATCHED).map(([p, pat]) => `${p}\t${pat === p ? '=' : pat}`).join('\n') + '\n');
if (PROBLEMS.length) die(`${PROBLEMS.length} problems`);
fs.writeFileSync(outPath, JSON.stringify(schema, null, 1) + '\n');
console.log(`wrote ${path.basename(outPath)}: ${NODES.size} keys, ${leaves.length} probed`);

// ---------- MODEL.md ----------
if (opt('md')) {
  const md = [], L = s => md.push(s);
  const cell = s => String(s ?? '').replace(/\|/g, '\\|').replace(/\s+/g, ' ').trim();
  const typeText = s => {
    if (has(s, 'const')) return `always ${JSON.stringify(s.const)}`;
    const ts = s.type === undefined ? ['any'] : [].concat(s.type);
    const word = t => t === 'array' ? (s.items && s.items.type ? `list of ${[].concat(s.items.type).filter(x => x !== 'null').map(x => x === 'object' ? 'objects' : x === 'array' ? 'lists' : x + 's').join(' or ')}` : 'list') : t === 'object' ? (s.additionalProperties && typeof s.additionalProperties === 'object' ? 'map' : 'object') : t;
    return ts.map(word).join(' or ') + (s.enum ? `: ${s.enum.map(x => JSON.stringify(x)).join(', ')}` : '');
  };
  const valueAt = p => { if (/\[\]|\*/.test(p)) return null; let o = MODEL; for (const k of p.split('.')) { if (o === null || typeof o !== 'object' || !has(o, k)) return undefined; o = o[k]; } return o; };
  const ghText = p => {
    if (/\[\]|\*/.test(p)) return '(per item)';
    const v = valueAt(p);
    if (v === undefined) return '(not in this model)';
    if (Array.isArray(v)) return `${v.length} ${v.length === 1 ? 'item' : 'items'}`;
    if (v !== null && typeof v === 'object') return `${Object.keys(v).length} keys`;
    const j = JSON.stringify(v); return j.length > 70 ? j.slice(0, 67) + '..."' : j;
  };
  const caOf = p => REACH[p] ? REACH[p].ca : 'not probed (no value in this model)';
  const apOf = p => REACH[p] ? REACH[p].ap : 'not probed (no value in this model)';
  // the counts, over the keys that hold a value (the probed leaves)
  const probed = Object.entries(reach).filter(([, v]) => v.probed);
  const cnt = f => probed.filter(([, v]) => f(v)).length;
  const caYes = cnt(v => v.ca.state === 'changed'), apYes = cnt(v => v.ap.state === 'changed'), neither = cnt(v => v.ca.state === 'same' && v.ap.state === 'same');
  const stops = cnt(v => v.ca.state === 'stops' || v.ap.state === 'stops'), apOnly = cnt(v => v.ap.state === 'changed' && v.ca.state === 'same'), caOnly = cnt(v => v.ca.state === 'changed' && v.ap.state === 'same');
  L('# The report model (report-data.json)');
  L('');
  L('Generated by `make-model-schema.mjs` with `report-data.schema.json`. Edit the script, not this file.');
  L('');
  L('`extract-v2.mjs` writes this model from the SEOS answers, and `build-report.mjs` builds both documents from it alone. Nobody writes anything at build time. This file lists every key of the model, grouped by its 25 top-level keys. The Green Haven model (SEOS business 48, `green-haven/report-data.json`) is the example throughout.');
  L('');
  L('How each column was made:');
  L('');
  L('- **Type** is inferred from the Green Haven model: every number is "number", and null is listed where it occurs. Then an overlay in the script, checked against the code, sets what one model cannot show: the type of a key that is null or empty here, values the code fixes ("always ..."), closed sets ("one of ..."), keys the code can add or leave out, and nulls the code can write.');
  L('- **Green Haven** is the value in that model for a key outside any list. Inside a list it reads "(per item)".');
  L('- **Meaning and source** was written from the code of extract-v2.mjs and sweeps-market.mjs: what the key is, and which inputs and rule make it. The input names are those of INPUTS.md.');
  L('- **Competitor Analysis** and **Action Plan** are measured, not written. For every key that holds a value, the script changed that one key in a copy of the model and built both documents from the copy (`build-report.mjs ... --audience=client --doc="Competitor Analysis"` and `--audience=service --doc="Action Plan"`). It then named the first changed place in each tab ("tab > the heading above it"), or the embedded data that changed ("the find box", "the map data"). Text gets a marker and its last digit moves, a number moves, and true/false flips. A key in a list is changed in every item at once.');
  L('  - "No change seen" means neither file changed. The key can still be read by a test whose answer did not flip.');
  L('  - "The build stops" means the documents depend on the key: the changed value broke a rule or a lookup.');
  L('  - For an object or a list, the column joins what its keys showed.');
  L('');
  L(`## Totals (Green Haven)`);
  L('');
  const copies = ROWS.filter(r => r.p !== r.dp).length;
  L(`- ${(ROWS.length - copies).toLocaleString('en-US')} keys described: every key, list item shape and map value once.${copies ? ` The tables also list ${copies} rows for map.town and map.won[], which copy the shape of map.searches[] and are empty here.` : ''}`);
  L(`- ${probed.length.toLocaleString('en-US')} keys hold a value and were probed. ${leaves.length - probed.length} could not be probed: they are null in this model and the code gives them no simple type.`);
  L(`- ${caYes} change the Competitor Analysis and ${apYes} change the Action Plan when they change. ${caOnly} change only the Competitor Analysis, and ${apOnly} only the Action Plan.`);
  L(`- ${neither} changed neither document when they changed ("no change seen").`);
  L(`- ${stops} make one of the builds stop when they change.`);
  L('');
  L('## Closed sets, each checked against the code');
  L('');
  L('| Key | Values | Where the code sets them |');
  L('|---|---|---|');
  const ENUM_WHERE = { 'checks[].status': 'every check() call; the comment at extract-v2.mjs line 743', 'checks[].weight': 'every check() call; line 743', 'checks[].door': 'the first argument of every check() call', 'tasks[].door': 'a check\'s door, a SEOS task\'s door (SEOS_DOOR, line 955) or "overview" (line 987)', 'tasks[].owner': 'TASKS (lines 913-951) use us, client and software. "account" has a label and a filter in build-report.mjs and no task yet', 'tasks[].status': 'lines 987-988: the first check\'s status (never pass, line 991), else "watch"; "fail" when any check fails', 'tasks[].group': 'GROUPS, lines 969-982', 'task_groups[].key': 'GROUPS, lines 969-982', 'compare.rows[].door': 'every cmpRow() call', 'compare.rows[].set': 'every cmpRow() call', 'compare.rows[].scope': 'every cmpRow() call', 'gaps[].door': 'every gap() call', 'gaps[].scope': 'lines 1192-1195 set "whole"; others null (line 1171)', 'maps.searches[].source': 'lines 256 and 276', 'map.searches[].source': 'lines 256 and 276', 'map.main.source': 'lines 256 and 276', 'website.phone.band': 'band(), line 431', 'website.desktop.band': 'band(), line 431', '**.metrics.*.band': 'band(), line 435', '**.page.phone.band': 'band(), line 435', '**.page.desktop.band': 'band(), line 435', 'links.quality.rows[].kind': 'line 571', 'listings.table[].source': 'line 635', 'business.hours.days[].day': 'line 151', 'compare.listings[].lands': 'profileRow, line 697', 'market.biz[].lands': 'sweeps-market.mjs landsOn, line 42', 'market.listings.rows[].lands': 'sweeps-market.mjs line 298', 'map.leader_listing.lands': 'copied from market.listings.rows', 'reviews.low_subjects[].label': 'LOW_SUBJECTS, lines 335-340' };
  for (const [k, v] of Object.entries(ENUM)) L(`| \`${cell(k)}\` | ${cell(v.map(x => JSON.stringify(x)).join(', '))} | ${cell(ENUM_WHERE[k] || '')} |`);
  L('');
  L('## Validating a model');
  L('');
  L('```sh');
  L('node validate-model.mjs report-data.schema.json <report-data.json> [--plant]');
  L('```');
  L('');
  L('`validate-model.mjs` has no dependencies. It applies the part of JSON Schema these schemas use, and refuses a schema that uses anything else. `--plant` also checks three mistakes planted in a copy of the data: a missing required key, a wrong enum value and a wrong type. The results are in parts/B-contract.json.');
  L('');
  L('What the schema can and cannot say:');
  L('');
  L('- It was inferred from one model and widened from the code. It was then tried on 21 more models built in a scratch folder from the same SEOS answers: 15 with one setting left out or changed, 4 with one input left out, and 2 from the original folder without scan 320 (with and without a market file). All pass; the commands are in parts/B-contract.json. A key that is required here but that another business\'s reading lacks (extract-v2.mjs then writes no key) fails validation. That usually means a gap in the data worth a look, not a fault in the schema.');
  L('- Counts are "number", not "integer": one model cannot tell a count from a rating that happens to be whole (business.rating is 5 here).');
  L('- The High Society shape (meta.v2 absent) is not covered. `meta.v2` must be true. build-report.mjs keeps branches for that older shape; they are inert when meta.v2 is true.');
  for (const top of Object.keys(MODEL)) {
    L('');
    L(`## ${top}`);
    L('');
    L(cell(descOf(top) || ''));
    L('');
    L(`Competitor Analysis: ${cell(caOf(top))}. Action Plan: ${cell(apOf(top))}.`);
    L('');
    L('| Key | Type | Green Haven | Meaning and source | Competitor Analysis | Action Plan |');
    L('|---|---|---|---|---|---|');
    for (const r of ROWS.filter(x => x.p !== top && (x.p.startsWith(top + '.') || x.p.startsWith(top + '[]')))) {
      const extra = r.s.description.includes('Not in this model.') ? ' Not in this model.' : r.s.description.includes('Empty in this model') ? ' Empty in this model; shape from the code.' : r.s.description.includes('From the code.') ? ' Empty in this model; from the code.' : '';
      L(`| \`${cell(r.p)}\` | ${cell(typeText(r.s))} | ${cell(ghText(r.p))} | ${cell((descOf(r.dp) || '') + extra)} | ${cell(caOf(r.p))} | ${cell(apOf(r.p))} |`);
    }
  }
  fs.writeFileSync(opt('md'), md.join('\n') + '\n');
  console.log(`wrote ${path.basename(opt('md'))}: ${ROWS.length} keys`);
}
