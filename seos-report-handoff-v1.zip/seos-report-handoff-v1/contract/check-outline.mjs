// check-outline.mjs: confirms outline.json against the two documents, with a reading of its own (it shares no code with
// extract-outline.mjs). For each document and tab:
//   1. every block of outline.json is in the document, in the same order: matched by id where the block has one, else by
//      its heading text (a block with an id must also hold its heading inside that id's element)
//   2. no heading in the document is missing from outline.json (a heading: h1, h2, h3, summary, .card-k, .eyebrow, .grp,
//      .empty-t), and the heading text, the Compare flag (inside data-cmp), the view (data-only) and the team flag
//      (data-internal) agree
//   3. each heading fits its heading_template (slots match any text, "a | b" groups are alternatives)
//   4. with --wording=<wording.json>, every wording id a block names is an entry of the catalog
// usage: node check-outline.mjs <outline.json> <competitor-analysis.html> <action-plan.html> [--wording=<wording.json>]
// Exit 0 and PASS when every check holds; exit 1 and the first disagreements otherwise.
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const [outlinePath, caPath, apPath] = argv.filter(a => !a.startsWith('--'));
if (!outlinePath || !caPath || !apPath) { console.error('usage: node check-outline.mjs <outline.json> <competitor-analysis.html> <action-plan.html> [--wording=<wording.json>]'); process.exit(2); }
const OL = JSON.parse(fs.readFileSync(outlinePath, 'utf8'));
const wArg = argv.find(a => a.startsWith('--wording='));
const WIDS = wArg ? new Set(JSON.parse(fs.readFileSync(wArg.slice(10), 'utf8')).entries.map(e => e.id)) : null;

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", nbsp: ' ' };
const decode = s => s.replace(/&(#x[0-9a-f]+|#[0-9]+|[a-z]+[0-9]*);/gi, (m, k) => k[0] === '#' ? String.fromCodePoint(/^#x/i.test(k) ? parseInt(k.slice(2), 16) : parseInt(k.slice(1), 10)) : (ENT[k] ?? m));
const tidy = s => s.replace(/\s+/g, ' ').replace(/\s+([.,;:!?)])/g, '$1').replace(/([(])\s+/g, '$1').trim();

// the end of the element whose open tag starts at i (depth count over tags of the same name)
const endOf = (src, i, tag) => {
  const re = new RegExp(`<${tag}\\b(?:[^>"']|"[^"]*"|'[^']*')*>|</${tag}\\s*>`, 'gi');
  re.lastIndex = src.indexOf('>', i) + 1;
  let depth = 1, x;
  while ((x = re.exec(src))) { if (x[0][1] === '/') { if (--depth === 0) return re.lastIndex; } else if (!/\/>$/.test(x[0])) depth++; }
  return -1;
};
// cut every element that matches open (a regex for its open tag) out of a piece of markup, keeping what was cut
const cutAll = (src, open, keep) => {
  for (;;) {
    const m = open.exec(src); if (!m) return src;
    const tag = m[1].toLowerCase(), end = endOf(src, m.index, tag);
    if (end < 0) throw new Error(`no end for <${tag}> in a heading`);
    if (keep) keep.push(src.slice(m.index, end));
    src = src.slice(0, m.index) + ' ' + src.slice(end);
  }
};
const textOf = s => tidy(decode(s.replace(/<[^>]*>/g, ' ')));
const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);

function read(file) {
  const src = fs.readFileSync(file, 'utf8').replace(/<style\b[\s\S]*?<\/style>/gi, '').replace(/<script\b[\s\S]*?<\/script>/gi, '');
  // every element with an attribute the outline cares about, with its span
  const spans = [];
  for (const m of src.matchAll(/<([a-zA-Z][a-zA-Z0-9]*)\b((?:[^>"']|"[^"]*"|'[^']*')*)>/g)) {
    const attrs = m[2];
    if (!/\s(id|data-cmp|data-only|data-internal)\b/.test(attrs) || /\/\s*$/.test(attrs)) continue;
    // a void element (input, img, br...) has no end tag: its span is the tag itself
    const end = VOID.has(m[1].toLowerCase()) ? m.index + m[0].length : endOf(src, m.index, m[1].toLowerCase());
    if (end < 0) throw new Error(`no end for <${m[1]}> at ${m.index}`);
    const id = (/\sid="([^"]*)"/.exec(attrs) || [])[1] || null, only = (/\sdata-only="([^"]*)"/.exec(attrs) || [])[1] || null;
    spans.push({ tag: m[1].toLowerCase(), start: m.index, end, id, only, cmp: /\sdata-cmp\b/.test(attrs), internal: /\sdata-internal\b/.test(attrs), tab: m[1].toLowerCase() === 'section' && /\sclass="tab"/.test(attrs) && /^tab-/.test(id || '') ? id.slice(4) : null });
  }
  const tabs = spans.filter(s => s.tab);
  // every heading element, in order; a heading inside another heading is not a block of its own
  const heads = [];
  const HEAD = /<(h1|h2|h3|summary)\b(?:[^>"']|"[^"]*"|'[^']*')*>|<([a-zA-Z][a-zA-Z0-9]*)\b(?=(?:[^>"']|"[^"]*"|'[^']*')*\sclass="(?:[^"]*\s)?(card-k|eyebrow|grp|empty-t)(?:\s[^"]*)?")(?:[^>"']|"[^"]*"|'[^']*')*>/g;
  for (const m of src.matchAll(HEAD)) {
    const tag = (m[1] || m[2]).toLowerCase(), end = endOf(src, m.index, tag);
    if (end < 0) throw new Error(`no end for a heading <${tag}> at ${m.index}`);
    if (heads.length && m.index < heads[heads.length - 1].end) continue;
    const inner = src.slice(src.indexOf('>', m.index) + 1, end).replace(new RegExp(`</${tag}\\s*>$`, 'i'), '');
    const chips = [];
    let body = cutAll(inner, /<(select|button)\b/i);
    body = cutAll(body, /<([a-z]+)\b[^>]*\sclass="(?:[^"]*\s)?tk-side(?:\s[^"]*)?"/i);
    body = cutAll(body, /<([a-z]+)\b[^>]*\sclass="(?:[^"]*\s)?chip(?:\s[^"]*)?"/i, chips);
    const around = spans.filter(s => s.start <= m.index && m.index < s.end);
    const tab = (tabs.find(t => t.start <= m.index && m.index < t.end) || { tab: 'page' }).tab;
    const idEl = around.filter(s => s.id && !s.tab).sort((a, b) => (a.end - a.start) - (b.end - b.start))[0] || null;
    const onlyEl = around.filter(s => s.only).sort((a, b) => (a.end - a.start) - (b.end - b.start))[0] || null;
    heads.push({ start: m.index, end, tab, id: idEl ? idEl.id : null, idSpan: idEl, heading: textOf(body), chips: chips.map(textOf),
      compare_only: around.some(s => s.cmp), view: onlyEl ? onlyEl.only : 'both', team_only: around.some(s => s.internal) });
  }
  return { tabs: tabs.map(t => t.tab), heads, spans };
}

// a heading template as a matcher: {slot} = any text, a group holding " | " = alternatives, "(nothing)" = empty;
// spaces are left out on both sides before matching
const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const tplRe = t => {
  const split = s => { const out = []; let d = 0, cur = ''; for (let i = 0; i < s.length; i++) { const c = s[i]; if (c === '{') d++; if (c === '}') d--; if (d === 0 && s.startsWith(' | ', i)) { out.push(cur); cur = ''; i += 2; continue; } cur += c; } out.push(cur); return out; };
  const seq = s => { let out = '', i = 0; while (i < s.length) { if (s[i] === '{') { let d = 1, j = i + 1; while (j < s.length && d) { if (s[j] === '{') d++; else if (s[j] === '}') d--; j++; } const inner = s.slice(i + 1, j - 1), alts = split(inner); out += alts.length > 1 ? '(?:' + alts.map(alt).join('|') + ')' : '.+?'; i = j; } else { out += reEsc(s[i]); i++; } } return out; };
  const alt = s => s.trim() === '(nothing)' ? '' : seq(s.replace(/\s+/g, ''));
  return new RegExp('^(?:' + split(t).map(alt).join('|') + ')$');
};

const fails = [];
const fail = (where, what) => { fails.push(`${where}: ${what}`); };
const report = [];
let refs = 0;
const DOCS = [['Competitor Analysis', caPath], ['Action Plan', apPath]];
for (const [name, file] of DOCS) {
  const doc = OL.documents?.[name]; if (!doc) { fail(name, 'not in outline.json'); continue; }
  if (doc.file !== path.basename(file)) fail(name, `outline.json reads ${doc.file}, this run was given ${path.basename(file)}`);
  const R = read(file);
  const order = [...R.tabs, ...(R.heads.some(h => h.tab === 'page') ? ['page'] : [])];
  if (JSON.stringify(order) !== JSON.stringify(doc.tabs_in_order)) fail(name, `tabs in the document ${order.join(',')}; in outline.json ${doc.tabs_in_order.join(',')}`);
  let blocks = 0, inOrder = 0, missing = 0, templates = 0;
  for (const tab of new Set([...order, ...Object.keys(doc.tabs)])) {
    const want = doc.tabs[tab]?.blocks || [], got = R.heads.filter(h => h.tab === tab);
    blocks += want.length;
    // 2. no heading of the document is missing from outline.json (counted by heading text, tab by tab)
    const left = want.map(b => b.heading);
    for (const g of got) { const i = left.indexOf(g.heading); if (i < 0) { missing++; fail(`${name} ${tab}`, `heading not in outline.json: "${g.heading}"`); } else left.splice(i, 1); }
    for (const l of left) fail(`${name} ${tab}`, `outline.json block not in the document: "${l}"`);
    // 1. the same order, by id where present, else by heading text; then the text and the flags
    for (let i = 0; i < Math.max(want.length, got.length); i++) {
      const w = want[i], g = got[i], at = `${name} ${tab} block ${i + 1}`;
      if (!w || !g) { fail(at, w ? `outline.json has "${w.heading}", the document has nothing more` : `the document has "${g.heading}", outline.json has nothing more`); break; }
      const same = w.id ? g.id === w.id && g.idSpan && g.idSpan.start <= g.start && g.end <= g.idSpan.end : g.heading === w.heading;
      if (!same) { fail(at, w.id ? `expected the block in #${w.id} ("${w.heading}"), found ${g.id ? '#' + g.id : 'no id'} ("${g.heading}")` : `expected "${w.heading}", found "${g.heading}"`); continue; }
      inOrder++;
      if (g.heading !== w.heading) fail(at, `heading reads "${g.heading}", outline.json "${w.heading}"`);
      if (g.compare_only !== w.compare_only) fail(at, `"${w.heading}": Compare flag ${g.compare_only} in the document, ${w.compare_only} in outline.json`);
      if (g.view !== w.view) fail(at, `"${w.heading}": view ${g.view} in the document, ${w.view} in outline.json`);
      if (g.team_only !== w.team_only) fail(at, `"${w.heading}": team flag ${g.team_only} in the document, ${w.team_only} in outline.json`);
      if (JSON.stringify(g.chips) !== JSON.stringify(w.chips || [])) fail(at, `"${w.heading}": chips ${JSON.stringify(g.chips)} in the document, ${JSON.stringify(w.chips || [])} in outline.json`);
      // 3. the heading fits its template
      if (tplRe(w.heading_template).test(g.heading.replace(/\s+/g, ''))) templates++; else fail(at, `"${g.heading}" does not fit its template ${w.heading_template}`);
      // 4. the wording it names is in the catalog
      if (WIDS) for (const id of w.wording || []) { refs++; if (!WIDS.has(id)) fail(at, `"${w.heading}" names wording ${id}, which is not in the catalog`); }
    }
  }
  report.push(`${name}: ${R.heads.length} headings in the document, ${blocks} blocks in outline.json, ${inOrder} in the same order, ${missing} missing from outline.json, ${templates} fit their template`);
  if (R.heads.length !== doc.block_count) fail(name, `block_count ${doc.block_count} in outline.json, ${R.heads.length} headings in the document`);
}
for (const l of report) console.log(l);
if (WIDS) console.log(`wording references: ${refs} checked against the catalog`);
if (fails.length) { console.log(`FAIL: ${fails.length} disagreements`); for (const f of fails.slice(0, 40)) console.log('  ' + f); process.exit(1); }
console.log('PASS');
