# The decision rules

Every threshold, status, order and cut that turns the SEOS numbers into the two documents: the **Competitor Analysis** (the Sales view, client-safe) and the **Action Plan** (the Service view, a team document). Read off `extract-v2.mjs` (it writes the model, `report-data.json`) and `build-report.mjs` (it writes the documents) as they stand on 2026-10-12. A reference like `extract-v2.mjs:792` is a line of that file in `Product/seos-report/`.

Three files go together:

- **RULES.md** (this file): the rules in words.
- **rules.json**: sections 2 to 5 as data. Each status rule, value line, client-safe flag, sentence and sort is written as a small expression (the language is described in rules.json under `expressions`).
- **check-rules.mjs**: reads a model and rules.json, evaluates every rule it can and compares the result with the model. It holds no threshold of its own: change a number in rules.json and the check changes with it.

```sh
node check-rules.mjs <report-data.json> [--rules=rules.json] [--md=RULES.md] \
     [--client-doc=<competitor-analysis.html>] [--service-doc=<action-plan.html>] [--json=<out.json>]
```

**Scope.** Green Haven Industries, Elizabeth NJ (SEOS business 48), the model `extract-v2.mjs` writes from SEOS's current API (`meta.v2 = true`, `meta.order = 'loss-first'`). `build-report.mjs` also holds branches for an older High Society file without `meta.v2`; they are inert when `meta.v2` is true and are not described here.

**Words used here.**

- *The store*: the business the report is about. *Rivals*: the three stores the SEOS run names beside it. *The field*: every business a map check lists. *Far*: more than 150 miles (241.4 km) from the store (`extract-v2.mjs:206`).
- *Number 1* and *number 2*: the businesses with the most and the second most points in Google's top 3 in a map check, far businesses left out.
- *A check*: one line of the health checks, with an area (the code calls it a door), a weight, a status, a title, a value, a line of detail and the task it names.
- *Status*: pass (shown "Good"), watch ("Needs a look"), fail ("Needs fixing"), na ("Not measured"; also a check on hold).
- *Weight*: outcome, rank, practice, protect, or data (about the run or the record, not the store: team only).
- *Ours* (internal): about our own work or tags. Team only.
- *On hold*: a number that rests on a flawed reading. The team sees it with the reason; a client never does.
- *Client-safe*: a comparison row a client may see (`sales: true` in the model).

## 1. Order: losing first, winning last

`meta.order = 'loss-first'` (`extract-v2.mjs:1349`) is the owner's ordering. `build-report.mjs` reads it (`LOSS`, line 54) and runs every list below with the store's losses first and its wins last. `check-rules.mjs` recomputes 1.1, 1.2, the plan of 1.8 and 1.9 from the model, and checks 1.4, 1.5, the client board of 1.6 and the buckets of 1.8 in the two Green Haven documents. 1.3 and 1.7 are read from the code only.

### 1.1 The map searches (`maps.searches`)

`extract-v2.mjs:739-740`. Every search on file, in this order:

1. Losses before wins (`you_lead` false first). The store *leads* a search when it is in a top 3 at one point or more and has at least as many top-3 points as number 2 (a tie with number 2 counts as a lead: `extract-v2.mjs:210, 272`).
2. Among losses: a search where the store is in no top 3 first; then the largest gap to number 1 as a share of the points, `(number 1's points - the store's points) / points`, largest first.
3. Among wins: the narrowest margin over number 2 first, `(the store's points - number 2's points) / points`, so the widest win is last.

Green Haven: "weed near me" (0 of 121 points, in no first 20), then "cannabis near me" (37 of 111; number 1 holds 88), then "dispensary near me" (58 of 121, number 1 by one point over 57).

Where this order shows: the map on the overview opens on the first search that is not on hold and not won (`build-report.mjs:109`); the client overview's map tiles are the first three searches not on hold, the first one the lead tile (`build-report.mjs:186-192`); the Google Maps tab heading runs the searches in this order (`build-report.mjs:390`). The table "Every search checked on the map" (`build-report.mjs:241-247`) is built only when there is no market file, so not for Green Haven.

### 1.2 The headline (`verdict`): which search heads the page

`extract-v2.mjs:1201-1218`. Only searches not on hold count. Losses run as in 1.1, with one more tie-break: number 1's share of the points, highest first (`extract-v2.mjs:1205`). Wins run the other way from 1.1: the **widest** margin first (`extract-v2.mjs:1206`), so the headline names the widest win.

- **a** (the big line) = the first loss's head, or the first win's head when there is no loss.
- **b** (the second line) = the first win's head when there are losses and wins; else the second loss's head; else empty.
- A loss head: "Nowhere for "<search>"." (no top-3 point and in no first 20), "Outside the top 3 for "<search>"." (no top-3 point), else "<First, Second ... Twelfth, or Number k> for "<search>"." by the store's place among the businesses.
- A win head: "First for "<search>"" or "Tied first ..." (level with number 2), plus ", by k point(s)" when the margin is 1 or 2.
- The lead paragraph runs every loss line, then every win line, then "It has <ratings> Google ratings at <stars> stars."
- With no search off hold: a = "<ratings> ratings at <stars> stars.", b = "The map check comes next."
- **Gate:** the extractor stops when a loss exists and line a does not name the first loss (`extract-v2.mjs:1252`, "EXTRACT FAILED: the headline does not lead with the biggest loss").

Green Haven: a = `Nowhere for "weed near me".`, b = `First for "dispensary near me", by 1 point.`

### 1.3 The first loss (L1)

`extract-v2.mjs:910-912`. The first search not on hold and not won, sorted as the losses in 1.1 (no further tie-break). L1 names the `map-gap` task (its title, client title, benefit and done-when) and the "-1" gap lines (`ratings-1`, `stars-1` ...), which set the store's Google listing beside L1's number 1. Green Haven: L1 is "weed near me".

### 1.4 The gap lines ("The gap to number 1")

`build-report.mjs:134` (`gapOrder`). Lines where the store is behind first, lines where it is level or ahead last; inside each part, whole-website lines after the others; then the largest deficit first (deficit: section 5). The Competitor Analysis leaves out lines on hold.

Green Haven, Competitor Analysis: `map-seos-320`, `replies-90`, `ratings-1`, `photos-1`, `map-seos-353`, `speed`, then the whole-website `visits`, `searches`, `strength`, then level or ahead: `ways-1`, `map-seos-352`, `stars-1`, `details-1`, `clean-sites`. The Action Plan adds `phone-named` (on hold) after `map-seos-353`.

### 1.5 The checks inside each tab

`build-report.mjs:55-56, 160-165, 175-178`. fail, then watch, then not measured, then pass; checks with the same status keep the extractor's order. The Competitor Analysis lists the store's checks a client sees (section 2). The Action Plan lists the store's checks, then a separate block "Checks on the data itself" (weight data), sorted the same way.

Green Haven, Google Maps tab, Competitor Analysis: `map-seos-353` and `map-seos-320` (fail), `review-pace`, `replies`, `review-velocity` (watch), then nine passes.

### 1.6 The Wrong / To look at / Right board

`build-report.mjs:146-151`. Three columns in this order: Wrong (fail), To look at (watch), Right (pass). Checks not measured are named in a note below. The client board leaves out overview, data, internal and AI checks; the team board leaves out overview checks. Inside a column the extractor's order holds. On hold, the client reads "Check to come" in place of the value (`build-report.mjs:147`).

Green Haven: the Competitor Analysis board holds 2 wrong, 14 to look at, 15 right; the Action Plan board 7, 16 and 17.

### 1.7 The comparison cards

`build-report.mjs:98-100`. In each grid of cards, the card where the store is furthest behind comes first (the most entries above the store), cards where it leads or is level come last, and anything that is not a comparison row sits between; ties keep their order. On the Google Maps tab the map-check cards are first sorted worst place first (no place counts as 99) and first place last, then by the same standing (`build-report.mjs:389`). Not recomputed by check-rules.mjs.

Green Haven, Google Maps tab: `map-320` (5th), `map-353` (3rd), `map-352` (1st); then `ratings`, `photos`, `stars`.

### 1.8 The plan (`SALES_ORDER`) and its buckets (`BOARD`)

`extract-v2.mjs:1006-1010`. The Competitor Analysis plan follows one fixed list, the owner's order of the kinds of work, losing first:

`rescan-open-hours`, `map-gap`, `reply-reviews`, `review-gap`, `store-page-check`, `speed`, `claim-listing`, `fix-category`, `add-service-options`, `fix-hours`, `reply-low-stars`, `low-star-subjects`, `content-gap`, `listings-hand-check`, `link-list`, `junk-links`, `connect-google`.

A task takes its place in the plan when it was opened, is not internal, is not service_only and belongs to us or the client. The plan prints its client title (else its title), its benefit, and "With your team" for a client task. **Gate:** a client-facing task missing from SALES_ORDER stops the extractor ("tasks with no place in the sales plan", line 1010).

The "What is missing" cards (`build-report.mjs:202-207`) group the plan in buckets, in this order: The map, Reviews, The store page, Speed, Pages and content, Listings and links, Google Analytics and Search Console; a plan item in no bucket goes last under "The Google listing" (`claim-listing`, `fix-category`, `add-service-options`, `fix-hours`). The plan tab's lead line names the buckets in the order the plan first meets them (`build-report.mjs:550`).

Green Haven plan (10): 1 "Win "weed near me" on the map", 2 "Answer every new review", 3 "Keep new reviews coming as fast as your rivals" (with your team), 4 "Make sure Google reads the store page", 5 "Speed up the store page on a phone", 6 "Name the searches your rivals win and you miss", 7 "Check the listings that matter", 8 "Get links from the sites that link to your rivals", 9 "Watch the wave of link-selling pages", 10 "Connect Google Analytics and Search Console" (with your team). Buckets: The map 1, Reviews 2, The store page 1, Speed 1, Pages and content 1, Listings and links 3, Google Analytics and Search Console 1.

### 1.9 The Action Plan's task list

`extract-v2.mjs:969-1000`. Tasks are numbered by group (the order of `task_groups` in rules.json: Before anything else, Ours to put right, The map, Listing basics, Reviews, The store page, Pages and content, Listings and links, Speed, For the account manager, Found by the software, For the software team), then the task's place in its group's list (99 when not listed), then failing tasks first, then area (Google Maps, Google search, Website, Links and listings, AI answers, Overview), then id.

Green Haven: 1 `client-questions`, 2 `map-gap`, 3 `connect-google`, 4 `reply-reviews`, 5 `review-gap`, 6 `store-page-check`, 7 `content-gap`, 8 `listings-hand-check`, 9 `link-list`, 10 `junk-links`, 11 `speed`, 12 to 26 the fifteen SEOS findings, 27 to 34 the software team's eight.

## 2. Health checks

**How a check reaches each document.**

- A check names a task (`check.task`). The task is **opened** only when the check's status is not pass (`extract-v2.mjs:991`). A task's status is fail when any check that opened it fails, else the status of the first check that opened it, else watch (`extract-v2.mjs:987-988`).
- **A client sees a check** when its area is Google Maps, Google search, Website or Links and listings, its weight is not data and it is not ours (`build-report.mjs:148, 158, 161, 547`). The AI tab is team-only. Overview checks are shown only through their task.
- **On hold**, the client reads "Check to come" in place of the value, and the check's client line (`sales` in the model) in place of the detail when it has one (`build-report.mjs:147, 157, 547`).
- The area tiles count each area's checks that are not data and not ours (`extract-v2.mjs:1221-1222`).
- Thresholds are fixed numbers in the code: 0.8 of number 1's points; 0.9 of the points listed; 4.5 and 4.0 stars; 2 ways to shop; 80% replies; 0.8 of the earlier review pace; 0.8 of the rivals' lower median velocity; 7 days of hours; lab score 0.9 and 0.5; 300 words; under half the browser's words; title 30 to 65 and description 70 characters; 30% link sellers; 20% new link sellers; vendor score 10 for the link list; 5 outside sites; half the directories; 150 miles. None reads the vertical, except the main category (CATEGORY: Cannabis only).

### 2.1 Index

Every check id the code can produce, in the order extract-v2.mjs makes them. "Client sees it" follows the general rule above.

| Check | Tab | Weight | Client sees it | Green Haven (status, value) |
|---|---|---|---|---|
| `map-{search key}` | Google Maps | outcome | Yes | map-seos-353: fail, "37 of 111 points"; map-seos-352: pass, "58 of 121 points"; map-seos-320: fail, "Not found" |
| `map-listed` | Google Maps | practice | Yes | pass, "at least 119 of 121" |
| `map-missing-{expected search}` | Google Maps | data | No: data | none in the model |
| `scan-hours` | Google Maps | data | No: data | pass, "3 of 3" |
| `scan-market` | Google Maps | data | No: data | fail, "31 of 298 far away" |
| `scan-setup` | Google Maps | data | No: data | watch, "3 checks, 11 by 11, 2 mi" |
| `scan-depth` | Google Maps | data | No: data | pass, "Every point" |
| `market-agrees` | Google Maps | data | No: data | not in the model |
| `claimed` | Google Maps | rank | Yes | pass, "Claimed" |
| `category` | Google Maps | rank | Yes | pass, "Cannabis store" |
| `rating` | Google Maps | rank | Yes | pass, "5.0 stars" |
| `service-options` | Google Maps | rank | Yes | pass, "5 listed" |
| `listing-link` | Google Maps | rank | Yes | pass, "The website" |
| `listing-tag` | Google Maps | protect | No: ours | not in the model |
| `review-count` | Google Maps | practice | Yes | pass, "434" |
| `review-pace` | Google Maps | practice | Yes | watch, "14.2 a month" |
| `replies` | Google Maps | practice | Yes | watch, "3.5% answered" |
| `low-open` | Google Maps | protect | Yes | not in the model |
| `recent-rating` | Google Maps | protect | Yes | not in the model |
| `review-velocity` | Google Maps | practice | Yes | watch, "14 a month" |
| `listing-details` | Google Maps | practice | Yes | not in the model |
| `hours` | Google Maps | practice | Yes | pass, "7 days" |
| `footprint` | Google search | practice | Yes | watch, "122" |
| `connected` | Google search | practice | Yes | watch, "Not connected" |
| `ranked-keywords` | Google search | data | No: data | fail, "Not read in this run" |
| `rival-searches` | Google search | data | No: data | fail, "Counts only" |
| `ai-named` | AI answers | outcome | No: the AI tab is team-only | na, "Not collected" |
| `speed-phone` | Website | practice | Yes | watch, "53 of 100" |
| `page-words` | Website | protect | Yes | pass, "2,393 words read" |
| `main-heading` | Website | practice | Yes | pass, "Present" |
| `title` | Website | practice | Yes | pass, "60 and 140 characters" |
| `basics` | Website | protect | Yes | pass, "All clear" |
| `store-details` | Website | practice | Yes | watch, "Not confirmed" |
| `landing-flags` | Website | practice | Yes | pass, "No flag" |
| `page-checks` | Website | practice | Yes | watch, "7 to look at" |
| `whole-site` | Website | data | No: data | watch, "21 pages read, 100 crawled" |
| `linking-sites` | Links and listings | practice | Yes | watch, "171 without the link sellers" |
| `link-wave` | Links and listings | protect | Yes | watch, "1,054 in 30 days" |
| `link-list` | Links and listings | practice | Yes | watch, "5 with some weight" |
| `directory-work` | Links and listings | practice | No: ours | not in the model |
| `details-found` | Links and listings | practice | Yes | pass, "9 sites" |
| `other-names` | Links and listings | protect | Yes | watch, "23 results on 15 sites" |
| `listings-read` | Links and listings | practice | Yes | watch, "4 of 12" |
| `directory-verdicts` | Links and listings | practice | Yes | watch, "15 listed of 136" |
| `directory-sources` | Links and listings | data | No: data | fail, "10 from another market" |
| `directory-coverage` | Links and listings | data | No: data | fail, "7 of 128" |
| `rival-rows` | Overview | data | No: overview (shown only through its task) | not in the model |
| `stored-findings` | Overview | data | No: overview (shown only through its task) | not in the model |
| `own-accounts` | Google Maps | data | No: data | watch, "3 of ours" |
| `answer-scope` | Overview | data | No: overview (shown only through its task) | fail, "28 readings about others" |

### 2.2 Google Maps checks

#### `map-{search key}`

extract-v2.mjs:752-760 · Google Maps · weight outcome · title "Number 1 on the map for "{kw}""

- **Made when:** one per search on file: every search in the market file (--market) plus every SEOS sweep the market file does not carry (same search, same day). The key is the market file's scan key (e.g. seos-353) or scan-<sweep id> for a sweep from the record alone.
- **Status:** na when the search is on hold; pass when the store is number 1 (its top-3 point count is at least number 2's and above 0); watch when its top-3 points are at least 80% of number 1's; fail otherwise.
- **As rules.json writes it:** `hold` -> na; `you_lead` -> pass; `you >= leader_points * 0.8` -> watch; else fail
- **Value:** "Not found" when the store has no top-3 point and is in no first 20; else "<you> of <n> points"
- **Line:** Number 1: "Number 1 for "<kw>": in Google's top 3 at <you> of <n> points, <k> points ahead of / level with <number 2> (<points>). Checked <when>." Otherwise: "<Not in the first 20 at any of the <n> points | In the first 20 at <found> of <n> points and in the top 3 at none | [Tied ]<nth> on the map> for "<kw>"[: in Google's top 3 at <you> of <n> points]. <number 1> is number 1 with [at least ]<points>. Checked <when>."
- **Client line:** On hold only: "A clean check of this search comes first." (the client reads "Check to come" as the value)
- **Task it names:** map-gap unless the store is number 1
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** map-seos-353: fail, "37 of 111 points"; map-seos-352: pass, "58 of 121 points"; map-seos-320: fail, "Not found"

#### `map-listed`

extract-v2.mjs:761-765 · Google Maps · weight practice · title "Listed at nearly every point"

- **Made when:** there is a main search: the search whose phrase is the run's keyword, else the first search on file.
- **Status:** pass when the store is in Google's first 20 at 90% or more of the main search's points; watch otherwise. Never fail.
- **As rules.json writes it:** `found / n >= 0.9` -> pass; else watch
- **Value:** "[at least ]<found> of <n>" ("at least" when some not-found points carry another area's businesses in their first 20)
- **Line:** "Google listed the store in its first 20 results at <found> of <n> points for "<kw>"." plus, when some not-found points are unconfirmed, a sentence that those points carry businesses from another area about <miles> miles away.
- **Client line:** When points are unconfirmed: "At least <found> of the <n> points list the store in Google's first 20 results for "<kw>"."
- **Task it names:** none
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "at least 119 of 121"

#### `map-missing-{expected search}`

extract-v2.mjs:766-770 · Google Maps · weight data · title "A map check of "{kw}" is on file"

- **Made when:** one per search in settings.expected_searches that no search on file matches. The id is the phrase lowercased with everything but a-z and 0-9 removed.
- **Status:** Always na (not measured).
- **As rules.json writes it:** else na
- **Value:** "Not on file"
- **Line:** "No map check of "<kw>" for this store is in the record: it holds <N> sweeps for this store, <phrases>.[ None of the <all> sweeps in the software is a "<kw>" check of this store.] Nothing about "<kw>" is said in this report until one is run."
- **Task it names:** expected-search
- **Client:** No: data.
- **Green Haven:** none in the model

#### `scan-hours`

extract-v2.mjs:771-775 · Google Maps · weight data · title "Map checks ran in opening hours"

- **Made when:** the record holds at least one sweep.
- **Status:** fail when any sweep finished, or (where the starter is on record) started, outside the store's posted hours that weekday, in the store's time zone, ends included; pass when every sweep finished in hours; na otherwise. A weekday with no posted hours (or no timetable) reads as unknown, not as closed, so a sweep run on a day the store does not open is neither out of hours nor held (see findings).
- **As rules.json writes it:** `out > 0` -> fail; `all(open == true)` -> pass; else na
- **Value:** "<k> of <N> after hours" or "<N> of <N>"
- **Line:** Per sweep: ""<kw>" ran <start> to <finish> | finished <finish> on <weekday, date>; the store's hours that day: <hours | not listed>."
- **Task it names:** rescan-open-hours when any sweep ran out of hours
- **Client:** No: data.
- **Green Haven:** pass, "3 of 3"

#### `scan-market`

extract-v2.mjs:776-779 · Google Maps · weight data · title "The map checks' business lists are this market"

- **Made when:** any sweep lists a business more than 150 miles (241.4 km) from the store.
- **Status:** fail when a far business is in a top 3 at any point of any sweep; watch when far businesses are only lower in the lists.
- **As rules.json writes it:** `any(top3 > 0)` -> fail; else watch
- **Value:** "<far rows> of <all rows> far away" (business rows summed over the sweeps)
- **Line:** How many rows, how far, around which towns ("another area's results, where the scan engine's searches come from (its Council Bluffs vantage)"), per sweep the points with a far business in the first 20 and in a top 3, the store's count read again without them, and whether any check is on hold.
- **Task it names:** scan-out-of-market
- **Client:** No: data.
- **Green Haven:** fail, "31 of 298 far away"

#### `scan-setup`

extract-v2.mjs:780-782 · Google Maps · weight data · title "How the map checks were run"

- **Made when:** the record holds at least one sweep.
- **Status:** watch when any sweep left grid points out before it ran (grid x grid minus the cells held is not 0); pass otherwise.
- **As rules.json writes it:** `any(excluded != 0 && excluded != null)` -> watch; else pass
- **Value:** "<N> check(s), <grid> by <grid>, <radius> <unit>[; ...]"
- **Line:** Per sweep: who started it (an admin, a user, or no record), how, its points, and the grid points left out.
- **Task it names:** none
- **Client:** No: data.
- **Green Haven:** watch, "3 checks, 11 by 11, 2 mi"

#### `scan-depth`

extract-v2.mjs:783-785 · Google Maps · weight data · title "Map checks came back in full"

- **Made when:** the record holds at least one sweep.
- **Status:** pass when every sweep has points, the store's own rank field gives the same top-3 count as its place in the lists, no business in a list is missing from the sweep's rows, and the software's share agrees with the points for every business; fail otherwise.
- **As rules.json writes it:** `ok` -> pass; else fail
- **Value:** "Every point" or "Not in full"
- **Line:** Pass: every point is in the record and the three readings agree. Fail: names the sweeps whose readings disagree.
- **Task it names:** scan-points when not in full
- **Client:** No: data.
- **Green Haven:** pass, "Every point"

#### `market-agrees`

extract-v2.mjs:787 (and 306-317) · Google Maps · weight data · title "The market file agrees with the record"

- **Made when:** a market-file search and a record sweep of the same search on the same day disagree on the store's points, the point count or number 1's points. Every search then goes on hold. Not evaluable from the model.
- **Status:** Always fail.
- **As rules.json writes it:** else fail
- **Value:** "<k> disagree"
- **Line:** The disagreements, one per search: market <you> of <n> (number 1 <p>), record <you> of <n> (number 1 <p>).
- **Task it names:** scan-points
- **Client:** No: data.
- **Green Haven:** not in the model

#### `claimed`

extract-v2.mjs:788 · Google Maps · weight rank · title "Listing is claimed"

- **Made when:** always.
- **Status:** pass when the Google listing is claimed; fail otherwise.
- **As rules.json writes it:** `claimed == true` -> pass; else fail
- **Value:** "Claimed" or "Not claimed"
- **Line:** "The Google listing is claimed." / "Nobody has claimed the Google listing."
- **Task it names:** claim-listing when not claimed
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "Claimed"

#### `category`

extract-v2.mjs:789-791 · Google Maps · weight rank · title "Main category fits the store"

- **Made when:** always.
- **Status:** na when the CATEGORY table has no entry for the vertical (only Cannabis -> cannabis_store is there); pass when one of the listing's category ids is in the entry; fail otherwise.
- **As rules.json writes it:** `isnull(want)` -> na; `intersects(want, ids)` -> pass; else fail
- **Value:** The main category as Google shows it, or "None"
- **Line:** "The main category is <category>.[ Also listed: <others>.]"
- **Task it names:** fix-category whenever no listed category id matches, including when the vertical has no entry (status na): see findings
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "Cannabis store"

#### `rating`

extract-v2.mjs:792 · Google Maps · weight rank · title "Star rating"

- **Made when:** the listing has a rating.
- **Status:** pass at 4.5 stars or more; watch from 4.0 to under 4.5; fail under 4.0.
- **As rules.json writes it:** `rating >= 4.5` -> pass; `rating >= 4` -> watch; else fail
- **Value:** "<rating, one decimal> stars"
- **Line:** "<rating> stars from <ratings> ratings."
- **Task it names:** low-star-subjects under 4.5
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "5.0 stars"

#### `service-options`

extract-v2.mjs:793 · Google Maps · weight rank · title "Ways to shop are listed"

- **Made when:** always.
- **Status:** pass with 2 or more ways to shop (service options) on the listing; watch otherwise.
- **As rules.json writes it:** `len(opts) >= 2` -> pass; else watch
- **Value:** "<k> listed"
- **Line:** "Listed: <options, lowercase>." / "No ways to shop are listed."
- **Task it names:** add-service-options under 2
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "5 listed"

#### `listing-link`

extract-v2.mjs:795-796 · Google Maps · weight rank · title "Listing links to the store's own page"

- **Made when:** the listing has a website link.
- **Status:** watch when the listing links to the homepage and the brand has more than one store; pass otherwise. extract-v2.mjs always builds one store (line 691), so it always passes.
- **As rules.json writes it:** `home == true && len(stores) > 1` -> watch; else pass
- **Value:** "The website" (homepage) or the linked path
- **Line:** One store: "The listing links to <domain>, the website of this one store." Inner page: "The listing links to this store's own page, <path>."
- **Task it names:** town-page when it would watch: a task id extract-v2.mjs does not define (see findings)
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "The website"

#### `listing-tag`

extract-v2.mjs:797 · Google Maps · weight protect · ours (internal) · title "Our tag on the listing link"

- **Made when:** the listing link carries a utm_source and one of its utm_* values equals settings.agency.
- **Status:** Always watch. Ours (internal): team only.
- **As rules.json writes it:** else watch
- **Value:** The utm_source value
- **Line:** "The listing link carries our own tags: <k>=<v>, ..."
- **Task it names:** none
- **Client:** No: ours.
- **Green Haven:** not in the model

#### `review-count`

extract-v2.mjs:799 · Google Maps · weight practice · title "Review count against the stores beside it"

- **Made when:** reviews were read and Google lists 3 or more stores beside this one with a ratings count ("people also search").
- **Status:** pass when the store has at least as many ratings as the fewest among those stores; watch otherwise.
- **As rules.json writes it:** `ratings >= min(nonnull(beside))` -> pass; else watch
- **Value:** The ratings count
- **Line:** "<ratings> ratings. The <k> stores Google lists beside this one have <min> to <max>."
- **Task it names:** review-gap when below the fewest
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "434"

#### `review-pace`

extract-v2.mjs:800 (paces at 362-363) · Google Maps · weight practice · title "New reviews keep coming"

- **Made when:** reviews were read.
- **Status:** pass when the last 90 days' pace (reviews / (90 / 30.4375), one decimal) is at least 80% of the pace over the 275 days before (reviews / (275 / 30.4375), one decimal); watch otherwise.
- **As rules.json writes it:** `p90 >= pb * 0.8` -> pass; else watch
- **Value:** "<pace_90> a month"
- **Line:** "<k> reviews in the last 90 days, <pace> a month. The 275 days before brought <k>, <pace> a month. A month here is 30.4 days."
- **Task it names:** review-gap when slower
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "14.2 a month"

#### `replies`

extract-v2.mjs:801-802 · Google Maps · weight practice · title "Reviews get a reply"

- **Made when:** reviews were read.
- **Status:** pass when 80% or more of the collected reviews have an owner reply (rate rounded to one decimal); watch otherwise.
- **As rules.json writes it:** `rate >= 80` -> pass; else watch
- **Value:** "<rate>% answered"
- **Line:** "<k> of <N> reviews have an owner reply, and <k> of the <m> from the last 90 days."
- **Task it names:** under 80%: reply-low-stars when any 1 or 2 star review has no reply, else reply-reviews
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "3.5% answered"

#### `low-open`

extract-v2.mjs:803 · Google Maps · weight protect · title "Low-star reviews are answered"

- **Made when:** any 1 or 2 star review has no reply.
- **Status:** Always watch.
- **As rules.json writes it:** else watch
- **Value:** "<open in the last 12 months> open"
- **Line:** "<k> reviews of 1 or 2 stars from the last 12 months have no reply yet[, and <m> older ones]."
- **Task it names:** reply-low-stars
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** not in the model

#### `recent-rating`

extract-v2.mjs:804 (opening window at 348) · Google Maps · weight protect · title "Recent reviews hold the rating"

- **Made when:** the reviews after the first 70 days average at least 0.2 stars below the reviews of the first 70 days.
- **Status:** Always watch.
- **As rules.json writes it:** else watch
- **Value:** "<average since> lately"
- **Line:** "The rating stands at <rating>. The first 10 weeks of reviews averaged <a>; the <k> since average <b>."
- **Task it names:** low-star-subjects
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** not in the model

#### `review-velocity`

extract-v2.mjs:806-813 (second readings at 377-379) · Google Maps · weight practice · title "Review velocity keeps pace with the rivals"

- **Made when:** the store's own 90-day window is whole and at least one rival's is too.
- **Status:** na (and on hold) when SEOS's own review-velocity snapshots disagree with the store's dated reviews; pass when the store's new reviews a month over 90 days are at least 80% of the rivals' lower median; watch otherwise.
- **As rules.json writes it:** `agrees != true` -> na; `ok` -> pass; else watch
- **Value:** "<per month, rounded> a month"
- **Line:** "Over the 90 days to <date>: the store <k> a month (<n>), <rival> <k> a month (<n>), ... Counted from each store's own dated Google reviews."
- **Client line:** When the second count disagrees: "A second count of the reviews comes first." (value "Check to come")
- **Task it names:** review-gap when not ok (also when na)
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "14 a month"

#### `listing-details`

extract-v2.mjs:814-815 · Google Maps · weight practice · title "Listing details to confirm with the store"

- **Made when:** the listing says parking is both free and paid, or says cash only.
- **Status:** Always watch.
- **As rules.json writes it:** else watch
- **Value:** "<k> to confirm"
- **Line:** "On the Google listing: <items>. Each is worth a yes or no from the store."
- **Task it names:** listings-hand-check
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** not in the model

#### `hours`

extract-v2.mjs:816 · Google Maps · weight practice · title "Opening hours are listed"

- **Made when:** the listing has a timetable.
- **Status:** pass with hours on all 7 days; watch otherwise.
- **As rules.json writes it:** `days == 7` -> pass; else watch
- **Value:** "7 days" or "<k> of 7 days"
- **Line:** "Hours are listed: <summary>."
- **Task it names:** fix-hours under 7 days
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "7 days"

#### `own-accounts`

extract-v2.mjs:893-898 · Google Maps · weight data · title "Our own accounts in this store's map field"

- **Made when:** --locations names a location of another of our businesses whose place is in a sweep's field. It comes with the own-accounts hold.
- **Status:** Always watch. Removed from the Action Plan by the other-accounts cut.
- **As rules.json writes it:** else watch
- **Value:** "<k> of ours"
- **Line:** Each account (name, our business id, city) and the searches it leads, ending "To this client they are businesses on the public map like any rival; never say they are ours."
- **Task it names:** none
- **Client:** No: data.
- **Green Haven:** watch, "3 of ours"

### 2.3 Google search checks

#### `footprint`

extract-v2.mjs:819 · Google search · weight practice · title "Searches the whole website shows up for"

- **Made when:** the vendor's whole-domain keyword count is in the record.
- **Status:** Always watch: the count is shown, not judged.
- **As rules.json writes it:** else watch
- **Value:** The whole-site keyword count
- **Line:** "The whole website shows in Google's first 100 results for <k> searches, <p1> of them on page 1. The rivals' one-store websites: <rival k>, ...[; <chain>'s website covers many stores, so it is not set beside this one]. Which searches they are was not read for this report."
- **Task it names:** content-gap
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "122"

#### `connected`

extract-v2.mjs:820 · Google search · weight practice · title "Google Analytics and Search Console are connected"

- **Made when:** always.
- **Status:** pass when both are connected to SEOS (an analytics binding with a GA property and one with a Search Console property); watch otherwise.
- **As rules.json writes it:** `ga == true && sc == true` -> pass; else watch
- **Value:** "Both connected" or "Not connected"
- **Line:** "Both are connected." / "Neither is connected to the software, so every search number here is an outside estimate." (said even when one of the two is connected: see findings)
- **Task it names:** connect-google unless both
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "Not connected"

#### `ranked-keywords`

extract-v2.mjs:821 · Google search · weight data · title "The searches the website ranks for are in the record"

- **Made when:** always.
- **Status:** pass when the ranked-keywords reading is in the answers; fail otherwise.
- **As rules.json writes it:** `read == true` -> pass; else fail
- **Value:** "Read" or "Not read in this run"
- **Line:** The run settings for ranked keywords and organic positions.
- **Task it names:** ranked-keywords when not read
- **Client:** No: data.
- **Green Haven:** fail, "Not read in this run"

#### `rival-searches`

extract-v2.mjs:822 · Google search · weight data · title "The rivals' searches are in the record"

- **Made when:** always.
- **Status:** Always fail: the record carries the rivals' search counts, never which searches.
- **As rules.json writes it:** else fail
- **Value:** "Counts only"
- **Line:** "The record holds how many searches each rival's website shows up for, and not which ones."
- **Task it names:** rivals-searches
- **Client:** No: data.
- **Green Haven:** fail, "Counts only"

### 2.4 AI answers checks

#### `ai-named`

extract-v2.mjs:825 · AI answers · weight outcome · title "Named in AI answers"

- **Made when:** always.
- **Status:** Always na: SEOS has no answer-engine surface yet.
- **As rules.json writes it:** else na
- **Value:** "Not collected"
- **Line:** "This report did not ask ChatGPT, Perplexity or Google AI Mode which stores they recommend. The software has no answer-engine surface yet."
- **Task it names:** collect-ai
- **Client:** No: the AI tab is team-only.
- **Green Haven:** na, "Not collected"

### 2.5 Website checks

#### `speed-phone`

extract-v2.mjs:828-829 (band at 431, score at 435) · Website · weight practice · title "Speed on a phone"

- **Made when:** Always: measured when a phone lab score is in the record, else the not-measured form.
- **Status:** na when there is no phone lab test. Otherwise the band of the raw Lighthouse score s (0 to 1): pass when s >= 0.9, watch when s >= 0.5, fail below. The model prints round(s x 100); the rules below read that printed score, which agrees with the band except for raw scores from 0.895 up to 0.9 and from 0.495 up to 0.5 (see findings).
- **As rules.json writes it:** `phone == null` -> na; `score >= 90` -> pass; `score >= 50` -> watch; else fail
- **Value:** "<score> of 100" or "Not measured"
- **Line:** "Google's lab speed test on a simulated slow phone scores the store page <s> of 100[ and <d> on a desktop]. Main content shows in <lcp>; the page is blocked for <tbt>." / "No speed test is in the record."
- **Task it names:** speed unless the band is pass (the not-measured form names none)
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "53 of 100"

#### `page-words`

extract-v2.mjs:830-833 · Website · weight protect · title "The store page carries the store's own words"

- **Made when:** the store page's word count was read.
- **Status:** watch when the page is thin to a crawler (the reading says so, or a plain crawler gets under half the words a browser gets) or carries under 300 words; pass otherwise.
- **As rules.json writes it:** `is_thin || words < 300` -> watch; else pass
- **Value:** "<words> words read"
- **Line:** "Our page reader got <k> words from the store page as a plain crawler[ and <m> as a browser].[ The page has an age check, and ...]"
- **Task it names:** store-page-check when watch
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "2,393 words read"

#### `main-heading`

extract-v2.mjs:834-835 · Website · weight practice · title "The page has a main heading"

- **Made when:** the store page's word count was read.
- **Status:** pass when the page's heading list has an h1 and the same reading's "no h1" flag agrees; watch otherwise (none found, or the two fields disagree: rule 9).
- **As rules.json writes it:** `in_list == true && agree` -> pass; else watch
- **Value:** "Present", "None found" or "Not confirmed"
- **Line:** "The page has a main heading: "<h1>"." / "No main heading was found on the page." / "The reading disagrees with itself about the main heading. The page source settles it."
- **Task it names:** store-page-check unless pass
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "Present"

#### `title`

extract-v2.mjs:837 · Website · weight practice · title "Title and description"

- **Made when:** the page title was read.
- **Status:** pass when the title is 30 to 65 characters and the meta description 70 or more; watch otherwise.
- **As rules.json writes it:** `tc >= 30 && tc <= 65 && dc >= 70` -> pass; else watch
- **Value:** "<title chars> and <description chars> characters"
- **Line:** "Title: "<title>"."
- **Task it names:** none, even on watch (see findings)
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "60 and 140 characters"

#### `basics`

extract-v2.mjs:838-839 · Website · weight protect · title "Secure, direct and not duplicated"

- **Made when:** the page's status code was read.
- **Status:** pass when the page answers 200 over https with no redirect and does not name another page as the original; fail otherwise.
- **As rules.json writes it:** `clean` -> pass; else fail
- **Value:** "All clear" or "Status <code>"
- **Line:** "The page answers on a secure address[ with no redirects | after <k> redirects][ and names itself as the original]."
- **Task it names:** store-page-check unless pass
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "All clear"

#### `store-details`

extract-v2.mjs:840-842 · Website · weight practice · title "Store details Google can read from the page"

- **Made when:** the site-audit reading exists (not evaluable from the model).
- **Status:** pass when the page's own code declares a business type and the same reading's micromarkup check agrees; watch otherwise (not found, or the two disagree: "Not confirmed", rule 9).
- **As rules.json writes it:** `schema == true && !two` -> pass; else watch
- **Value:** "Not confirmed", "Found" or "Not found"
- **Line:** Disagree: "The reading disagrees with itself: the page's own code declares <types>, and the same reading's check for store details says none. Google's rich results test settles it."
- **Task it names:** store-page-check unless pass
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "Not confirmed"

#### `landing-flags`

extract-v2.mjs:843-849 · Website · weight practice · title "The listing links to the strongest version of the page address"

- **Made when:** the landing_flags reading has a flags list.
- **Status:** watch when the software flags the address the listing links to (e.g. weak-variant-designated: a version of the address with fewer links than another); pass otherwise.
- **As rules.json writes it:** `len(flags) > 0` -> watch; else pass
- **Value:** "<k> flagged" or "No flag"
- **Line:** What the software compares, the store's flags in words, and the rivals' flags.
- **Task it names:** store-page-check when flagged
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "No flag"

#### `page-checks`

extract-v2.mjs:850-856 · Website · weight practice · title "The software's checks of the store page"

- **Made when:** SEOS has a model run (apex_runs).
- **Status:** watch when the latest SEOS run has PAGE_CHECK_* findings whose task is still open; pass otherwise.
- **As rules.json writes it:** `len(unique(codes)) > 0` -> watch; else pass
- **Value:** "<k> to look at" or "None open" (k = distinct codes, in plain words)
- **Line:** "The software's own checks of the store page raised <k> points to look at: <plain words>."
- **Task it names:** store-page-check when any
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "7 to look at"

#### `whole-site`

extract-v2.mjs:857-859 · Website · weight data · title "The whole site was read"

- **Made when:** always.
- **Status:** Always watch.
- **As rules.json writes it:** else watch
- **Value:** "<pages read> pages read[, <crawled> crawled]"
- **Line:** "<k> pages were read one by one[ of the <s> the site's own sitemaps list].[ The crawl stopped at its limit of <max> pages[, so its counts are counts within those pages].]"
- **Task it names:** crawl-limit
- **Client:** No: data.
- **Green Haven:** watch, "21 pages read, 100 crawled"

### 2.6 Links and listings checks

#### `linking-sites`

extract-v2.mjs:862-867 (sellers at 494-534) · Links and listings · weight practice · title "Sites that link to the website"

- **Made when:** the store's links were read.
- **Status:** watch when link sellers and scheme pages are 30% or more of the linking sites; pass otherwise.
- **As rules.json writes it:** `sellers / sites >= 0.3` -> watch; else pass
- **Value:** "<not sellers> without the link sellers"
- **Line:** Totals, sellers by page title and by the ledger, what the sites with weight are (names the store / copied article / articles), and the stricter count.
- **Client line:** Always (rule 8): "<sellers> of the sites that link to <domain> are link-selling or scheme pages, going by the page each link sits on. <not sellers> are not, and <with weight> of those carry some weight."
- **Task it names:** junk-links when watch
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "171 without the link sellers"

#### `link-wave`

extract-v2.mjs:868-869 · Links and listings · weight protect · title "No wave of link-selling pages"

- **Made when:** link-selling pages first seen in the last 30 days are 20% or more of the linking sites.
- **Status:** Always watch.
- **As rules.json writes it:** else watch
- **Value:** "<k> in 30 days"
- **Line:** "<k> link-selling pages appeared in the last 30 days. <m> of them also link to two or more of the three rivals, so this is a wave across the market and not aimed at one store.[ <h> carry one title, ...]"
- **Task it names:** junk-links
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "1,054 in 30 days"

#### `link-list`

extract-v2.mjs:870 (list at 553-564) · Links and listings · weight practice · title "Sites that link to the rivals' websites and not to this one"

- **Made when:** the store's links were read.
- **Status:** watch when any site links to two or more rivals' websites and not to this one, is not a link seller, has no link-selling words in its name and has a vendor score of 10 or more; pass otherwise.
- **As rules.json writes it:** `len(gw) > 0` -> watch; else pass
- **Value:** "<k> with some weight"
- **Line:** "<k> sites with some weight link to two or more of the three rivals' websites and not to this one."
- **Task it names:** link-list when any
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "5 with some weight"

#### `directory-work`

extract-v2.mjs:871 · Links and listings · weight practice · ours (internal) · title "Our directory work covers this store"

- **Made when:** links to this website carry our tag (a utm_* value equal to settings.agency) or the vendor marks them tagged.
- **Status:** Always watch. Ours (internal): team only.
- **As rules.json writes it:** else watch
- **Value:** "<k> tagged links"
- **Line:** "<k> links to this website carry our own tag."
- **Task it names:** directory-work
- **Client:** No: ours.
- **Green Haven:** not in the model

#### `details-found`

extract-v2.mjs:874 · Links and listings · weight practice · title "Google shows the store's details on other sites"

- **Made when:** the listing searches were read.
- **Status:** pass when 5 or more outside sites (not the store's own website, Facebook or Instagram) show the phone number with the store's name in Google's results; watch otherwise.
- **As rules.json writes it:** `pno >= 5` -> pass; else watch
- **Value:** "<k> sites"
- **Line:** "Searching Google for the store's phone number, street address and name: <k> outside sites show the phone number with the store's name, and <m> sites show the street address with it."
- **Task it names:** listings-hand-check under 5
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** pass, "9 sites"

#### `other-names`

extract-v2.mjs:876-878 · Links and listings · weight protect · title "Results that show the store's number without its name"

- **Made when:** Google results off the store's own website show its phone number without its name.
- **Status:** Always watch.
- **As rules.json writes it:** else watch
- **Value:** "<k> results on <s> sites"
- **Line:** The results, split into phone-lookup or people-search pages (a fixed pattern: phone|people|lookup|whitepages|intelius|spokeo|cloud storage hosts) and the other sites by name. "Each needs a look by hand before anything is said about it."
- **Task it names:** listings-hand-check
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "23 results on 15 sites"

#### `listings-read`

extract-v2.mjs:879 · Links and listings · weight practice · title "Listings that could be read show phone and address"

- **Made when:** the report could tie at least one listing page to the store.
- **Status:** pass when every such listing showed both the phone and the address; watch otherwise.
- **As rules.json writes it:** `both == len(table)` -> pass; else watch
- **Value:** "<both> of <listings>"
- **Line:** "<k> sites carry a listing ... On <m> the phone and the address were both seen. [<e> of its pages came back empty...] An empty read is not a missing listing." (rule 5)
- **Task it names:** listings-hand-check unless pass
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "4 of 12"

#### `directory-verdicts`

extract-v2.mjs:880-881 (verdicts at 673-685) · Links and listings · weight practice · title "Directories the software checked for this store"

- **Made when:** SEOS's citation verdicts exist for the store (sources of another market left out).
- **Status:** watch when more than half the directories could not be read either way (undetermined), or when any says not listed; pass otherwise.
- **As rules.json writes it:** `und > checked / 2` -> watch; `nl > 0` -> watch; else pass
- **Value:** "<listed> listed of <checked>"
- **Line:** "The software checked <k> directories on <date>: <a> list the store, <b> do not, and <c> could not be read either way (walled directories, or listings its search did not find). Could not be read is not "not listed"." (rule 5)
- **Task it names:** listings-hand-check (named always; opened only when not pass)
- **Client:** Yes. On hold the value reads "Check to come".
- **Green Haven:** watch, "15 listed of 136"

#### `directory-sources`

extract-v2.mjs:882-884 · Links and listings · weight data · title "The software's directory list is this store's market"

- **Made when:** verdicts include sources whose id or domain matches settings.other_market_sources.
- **Status:** Always fail: a defect in SEOS's source list, not a finding about the store.
- **As rules.json writes it:** else fail
- **Value:** "<k> from another market"
- **Line:** "The software's directory list for this store holds <k> sources that name <settings.other_market_label> places, left over from another store's list: <domains>. ... this report leaves them out of every directory count: <checked> checked, not <checked all>."
- **Task it names:** directory-sources
- **Client:** No: data.
- **Green Haven:** fail, "10 from another market"

#### `directory-coverage`

extract-v2.mjs:885 · Links and listings · weight data · title "Directories were searched for this store"

- **Made when:** the directory list (cit_probe sources, other market left out) is not empty.
- **Status:** pass when at least half the directories on the list were searched for this store; fail otherwise.
- **As rules.json writes it:** `searched >= listed / 2` -> pass; else fail
- **Value:** "<searched> of <listed>"
- **Line:** How many are on the list, tested with another business, passed, searched for this store, answered, and showed its phone or address.
- **Task it names:** directory-coverage unless pass
- **Client:** No: data.
- **Green Haven:** fail, "7 of 128"

### 2.7 Overview checks

#### `rival-rows`

extract-v2.mjs:887-891 · Overview · weight data · title "Rivals' listings, reviews, pages, speed, links and listings are in the record"

- **Made when:** fewer than all 5 of the rivals' parts (reviews, site_audits, page_speed, exhaustive, cit_pages) ran to done with a reading for every rival. Not evaluable from the model.
- **Status:** Always watch (a pass is never emitted: an overview check shows only through its task).
- **As rules.json writes it:** else watch
- **Value:** "<k> of 5 parts"
- **Line:** "Missing for the rivals: <parts>."
- **Task it names:** rival-rows
- **Client:** No: overview (shown only through its task).
- **Green Haven:** not in the model

#### `stored-findings`

extract-v2.mjs:892 · Overview · weight data · title "Findings and tasks are stored by the software"

- **Made when:** the record has no findings or no tasks. Not evaluable from the model.
- **Status:** Always fail.
- **As rules.json writes it:** else fail
- **Value:** "<findings> and <tasks>"
- **Line:** "The software stored no findings and no tasks." (or the counts)
- **Task it names:** store-findings when there are no findings; none when there are findings but no tasks (see findings)
- **Client:** No: overview (shown only through its task).
- **Green Haven:** not in the model

#### `answer-scope`

extract-v2.mjs:899-905 · Overview · weight data · title "The audit answers hold this store's market only"

- **Made when:** the answers carry Google Analytics or Search Console readings (analytics_watch, gsc_sitemaps) of other places, or readings fetched more than 3 days before the run about places that are neither the store nor its rivals. Not evaluable from the model.
- **Status:** fail when there are analytics readings of other places; watch when there are only old readings. The counts are not in the model.
- **As rules.json writes it:** not evaluable from report-data.json (its inputs are not in the model).
- **Value:** "<k> readings about others"
- **Line:** The counts and the other websites' hosts. Removed from the Action Plan by the other-accounts cut ("another account").
- **Task it names:** answer-isolation
- **Client:** No: overview (shown only through its task).
- **Green Haven:** fail, "28 readings about others"


## 3. Tasks

A task enters the list when a check opens it (section 2), and in three other ways: `client-questions` when reviews, links and listings were all read (`extract-v2.mjs:992`); one `seos-*` task per SEOS finding code that has a task in the record (line 993); and every task a listed task is blocked by (line 994). Each task has an owner (us, the client, the account manager, the software team), a group, a title, steps and a done-when; the client-facing ones also have a client title and a benefit. A task named by no definition stops the extractor (line 985); so does a blocked-by task that is not on the list (line 1001).

### 3.1 Index

"Plan" is the task's place in SALES_ORDER, the Competitor Analysis plan (only when the task was opened, is not internal and is not service_only). "Board" is its "What is missing" bucket.

| Task | Owner | Group | Opened by | Blocked by | Plan | Board | Green Haven |
|---|---|---|---|---|---|---|---|
| `map-gap` | us | map | `map-{search key}` |  | 2 | The map | task 2, fail |
| `expected-search` | us | first | `map-missing-{expected search}` |  | Action Plan only |  | not opened |
| `rescan-open-hours` | us | first | `scan-hours` |  | 1 | The map | not opened |
| `client-questions` | us | first | no check |  | Action Plan only |  | task 1, watch |
| `reply-reviews` | us | reviews | `replies` |  | 3 | Reviews | task 4, watch |
| `low-star-subjects` | us | reviews | `rating`, `recent-rating` |  | 12 | Reviews | not opened |
| `reply-low-stars` | us | reviews | `replies`, `low-open` |  | 11 | Reviews | not opened |
| `review-gap` | client | reviews | `review-count`, `review-pace`, `review-velocity` |  | 4 | Reviews | task 5, watch |
| `store-page-check` | us | page | `page-words`, `main-heading`, `basics`, `store-details`, `landing-flags`, `page-checks` |  | 5 | The store page | task 6, watch |
| `content-gap` | us | content | `footprint` | `rivals-searches`, `ranked-keywords` | 13 | Pages and content | task 7, watch |
| `listings-hand-check` | us | links | `listing-details`, `details-found`, `other-names`, `listings-read`, `directory-verdicts` |  | 14 | Listings and links | task 8, watch |
| `link-list` | us | links | `link-list` |  | 15 | Listings and links | task 9, watch |
| `junk-links` | us | links | `linking-sites`, `link-wave` |  | 16 | Listings and links | task 10, watch |
| `speed` | us | speed | `speed-phone` |  | 6 | Speed | task 11, watch |
| `claim-listing` | client | rank | `claimed` |  | 7 | The Google listing | not opened |
| `fix-category` | us | rank | `category` |  | 8 | The Google listing | not opened |
| `add-service-options` | us | rank | `service-options` |  | 9 | The Google listing | not opened |
| `fix-hours` | client | rank | `hours` |  | 10 | The Google listing | not opened |
| `connect-google` | client | rank | `connected` |  | 17 | Google Analytics and Search Console | task 3, watch |
| `directory-work` | us | ours | `directory-work` |  | Action Plan only |  | not opened |
| `scan-points` | software | data | `scan-depth`, `market-agrees` |  | Action Plan only |  | not opened |
| `scan-out-of-market` | software | data | `scan-market` |  | Action Plan only |  | task 27, fail |
| `ranked-keywords` | software | data | `ranked-keywords` |  | Action Plan only |  | task 28, fail |
| `rivals-searches` | software | data | `rival-searches` |  | Action Plan only |  | task 29, fail |
| `collect-ai` | software | data | `ai-named` |  | Action Plan only |  | task 34, na |
| `crawl-limit` | software | data | `whole-site` |  | Action Plan only |  | task 33, watch |
| `directory-sources` | software | data | `directory-sources` |  | Action Plan only |  | task 31, fail |
| `directory-coverage` | software | data | `directory-coverage` |  | Action Plan only |  | task 30, fail |
| `answer-isolation` | software | data | `answer-scope` |  | Action Plan only |  | task 32, fail |
| `rival-rows` | software | data | `rival-rows` |  | Action Plan only |  | not opened |
| `store-findings` | software | data | `stored-findings` |  | Action Plan only |  | not opened |
| `seos-{finding code}` | us | seos | no check |  | Action Plan only |  | 15 tasks |
| `town-page` |  |  | `listing-link` |  | not defined | The store page (listed in BOARD) | cannot appear (not defined) |

### 3.2 Each task

#### `map-gap`

extract-v2.mjs:914-915 (L1 at 910-912) · owner us · group map

- **Title:** Close the gap to <L1 number 1> for "<L1 search>" (no L1: "Close the gap to number 1 on the map")
- **Client title:** Win "<L1 search>" on the map
- **Benefit (client):** Number 1 for "<L1 search>" holds [at least ]<points> of <n> points; the store holds <you>.
- **Steps:** (1) Set the store's listing beside <number 1>'s, line by line (Google Maps tab): ratings, photos, review velocity, ways to shop, categories. (2) Read the software's own factors for this market before changing anything: the only one that survives its control is the distance from the grid centre. (fixed text: see findings) (3) Change one thing at a time on the listing, and date each change. (4) Check both searches again in opening hours on the same grid every four weeks. (fixed text "both": see findings)
- **Done when:** Number 1 for "<L1 search>", or the gap to <number 1> halved, in a check taken in opening hours.
- **Opened by:** `map-{search key}`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 2 of SALES_ORDER.
- **Note:** L1 = the first loss among searches not on hold: searches with no top-3 point first, then the largest gap to number 1 as a share of the points.
- **Green Haven:** task 2, status fail

#### `expected-search`

extract-v2.mjs:916 · owner us · group first · service_only

- **Title:** Get the "<phrase>" map check on file
- **Steps:** (1) Find the "<phrase>" scan the owner remembers: it is not in the software's records. (2) If it cannot be found, run one in opening hours on the same grid as the others (11 by 11, 2 miles). (fixed grid: see findings) (3) Add it to the market file (sweeps-market --extra). The report picks it up with no change: the headline, the checks and the gap lines.
- **Done when:** A "<phrase>" map check of this store is on file and in the report.
- **Opened by:** `map-missing-{expected search}`
- **Competitor Analysis:** Never: service_only.
- **Green Haven:** not opened

#### `rescan-open-hours`

extract-v2.mjs:917 · owner us · group first

- **Title:** Run the map checks again in opening hours
- **Client title:** Check the map while the store is open
- **Benefit (client):** Shows where the store appears around town while it is open.
- **Steps:** (1) Run them between <Monday's open> and <Monday's close> store time. (Monday's hours stand for every day: see findings) (2) Hold every map number in this report until then.
- **Done when:** Every map check on file ran in opening hours.
- **Opened by:** `scan-hours`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 1 of SALES_ORDER.
- **Green Haven:** not opened

#### `client-questions`

extract-v2.mjs:918 (added at 992) · owner us · group first · service_only

- **Title:** Send the client one email with three questions
- **Steps:** (1) Who replies to Google reviews today? (2) Has anyone ordered links for the website in the last two months? (3) Who holds the logins for the store's listings (Google, Weedmaps, Leafly, Yelp, Apple Maps)? (cannabis directories: see findings)
- **Done when:** All three answers are on file.
- **Opened by:** no check. Always when reviews, links and listings were all read (no check opens it). Its "why" is replaced by three lines: the reply count, the new link-selling pages, the directories that could not be read.
- **Competitor Analysis:** Never: service_only.
- **Green Haven:** task 1, status watch

#### `reply-reviews`

extract-v2.mjs:919-920 · owner us · group reviews

- **Title:** Answer new Google reviews as they come in
- **Client title:** Answer every new review
- **Benefit (client):** Shows customers the store reads what they write, and keeps the <rating> stars working for it.
- **Steps:** (1) Start with the <k> reviews from the last 90 days: <m> have a reply. (2) Draft each reply plainly, in the store's voice, and thank the customer by what they mention. (3) Send the drafts to the store for approval, then post them. (4) Then reply within a week of each new review.
- **Done when:** Every review from the last 90 days has a reply, and new ones get one within a week.
- **Opened by:** `replies`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 3 of SALES_ORDER.
- **Green Haven:** task 4, status watch

#### `low-star-subjects`

extract-v2.mjs:921 · owner us · group reviews

- **Title:** Take the low-star subjects to the store manager
- **Client title:** Read the low-star reviews as a group, with your manager
- **Benefit (client):** Stops the same complaint from costing stars again.
- **Steps:** (1) Read the low-star reviews and confirm the subjects by hand. (2) Agree one change in store for the top subject.
- **Done when:** One change is agreed.
- **Opened by:** `rating`, `recent-rating`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 12 of SALES_ORDER.
- **Green Haven:** not opened

#### `reply-low-stars`

extract-v2.mjs:922 · owner us · group reviews

- **Title:** Draft replies to the <k> low-star reviews that have none
- **Client title:** Answer the open low-star reviews
- **Benefit (client):** Protects the <rating>.
- **Steps:** (1) Draft each reply plainly, with a way to reach the manager. (2) Send the drafts to the store for approval, then post them.
- **Done when:** Every 1 and 2 star review has a reply.
- **Opened by:** `replies`, `low-open`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 11 of SALES_ORDER.
- **Green Haven:** not opened

#### `review-gap`

extract-v2.mjs:923 · owner client · group reviews

- **Title:** Keep review velocity up with the rivals
- **Client title:** Keep new reviews coming as fast as your rivals
- **Benefit (client):** More recent reviews than the stores beside you.
- **Steps:** (1) Put a card at checkout with a code that opens the Google review form. (2) Ask every customer, not only the happy ones. (3) No rewards for reviews: Google bans them.
- **Done when:** New reviews hold at the rivals' pace for three months.
- **Opened by:** `review-count`, `review-pace`, `review-velocity`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 4 of SALES_ORDER.
- **Green Haven:** task 5, status watch

#### `store-page-check`

extract-v2.mjs:924-925 · owner us · group page

- **Title:** Check the store page by hand, as one ticket
- **Client title:** Make sure Google reads the store page
- **Benefit (client):** Google reads the store's details and words from the page its listing sends people to.
- **Steps:** (1) Run the page through Google's rich results test: does it read the store's name, address, phone and hours? (2) Open the page source: is the store-details code there once, and valid? (3) Fix the duplicate meta tags the software found, in the same ticket. (fixed text: see findings)
- **Done when:** Google's rich results test reads the store's details.
- **Opened by:** `page-words`, `main-heading`, `basics`, `store-details`, `landing-flags`, `page-checks`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 5 of SALES_ORDER.
- **Green Haven:** task 6, status watch

#### `content-gap`

extract-v2.mjs:926 · owner us · group content

- **Title:** Name the searches the rivals are found for and this website is not
- **Client title:** Name the searches your rivals win and you miss
- **Benefit (client):** Turns the gap in searches into a short list of pages worth building.
- **Steps:** (1) Get this website's searches and the rivals' page 1 searches for Elizabeth and the towns around it. Neither is in this run. (hard-coded town: see findings) (2) Pick the ten with the most searches a month that this website misses. (3) Plan a page for a group of them only where there is something true and specific to say.
- **Done when:** Ten missed searches are named, with searches a month, and the first three pages are briefed.
- **Blocked by:** `rivals-searches`, `ranked-keywords`
- **Opened by:** `footprint`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 13 of SALES_ORDER.
- **Green Haven:** task 7, status watch

#### `listings-hand-check`

extract-v2.mjs:927-928 · owner us · group links

- **Title:** Check the listings that matter by hand
- **Client title:** Check the listings that matter
- **Benefit (client):** The store's name, address and phone read the same wherever a customer looks.
- **Steps:** (1) Open each listing in the tables on the Links and listings tab: <the listings that matter, up to 8>. (2) Settle the <k> directories the software could not read either way, starting with the core and cannabis ones. (or: note name, address, phone, hours and link on each) (3) Look at the <k> results where the store's phone number shows without its name. (or: fix or claim what is wrong)
- **Done when:** Each listing that matters is marked right, fixed or claimed.
- **Opened by:** `listing-details`, `details-found`, `other-names`, `listings-read`, `directory-verdicts`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 14 of SALES_ORDER.
- **Green Haven:** task 8, status watch

#### `link-list`

extract-v2.mjs:929-930 · owner us · group links

- **Title:** Ask the sites that link to the rivals' websites for a link to this one
- **Client title:** Get links from the sites that link to your rivals
- **Benefit (client):** Relevant sites that already link to the other stores' websites.
- **Steps:** (1) Start with the cannabis sites: <up to 8, by the CANNABIS_SITE name pattern>. (2) Look at the others by hand before asking: <up to 8>. (3) For each one, find how the rivals got listed and ask for the same.
- **Done when:** Listed on each named site, or a no is on file.
- **Opened by:** `link-list`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 15 of SALES_ORDER.
- **Green Haven:** task 9, status watch

#### `junk-links`

extract-v2.mjs:931-932 · owner us · group links

- **Title:** Find out whether anyone bought links, then watch the wave
- **Client title:** Watch the wave of link-selling pages
- **Benefit (client):** Keeps a market-wide wave of link-selling pages from becoming the store's problem.
- **Steps:** (1) In Search Console, open Manual actions: is there one? (Search Console is not connected to the software yet.) (fixed text: see findings) (2) The client email asks whether anyone ordered links. Chase the answer. (3) Disavow only if there is a manual action or the links were bought. Otherwise note it and watch. (4) Count new link-selling pages each week for four weeks.
- **Done when:** We know who placed them, there is no manual action, and four weekly counts are on file.
- **Opened by:** `linking-sites`, `link-wave`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 16 of SALES_ORDER.
- **Green Haven:** task 10, status watch

#### `speed`

extract-v2.mjs:933-934 · owner us · group speed

- **Title:** Trim what slows the store page on a phone
- **Client title:** Speed up the store page on a phone
- **Benefit (client):** A faster first tap on the page Google sends customers to.
- **Steps:** (1) Up to 3 of the phone test's savings, each "<fix in plain words>: about <s> s faster." (2) Name the heaviest scripts from the test and which of them are ours to change. (3) Test again on a phone.
- **Done when:** The phone score is 90 or more, or main content shows in 2.5 s or less.
- **Opened by:** `speed-phone`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 6 of SALES_ORDER.
- **Green Haven:** task 11, status watch

#### `claim-listing`

extract-v2.mjs:935 · owner client · group rank

- **Title:** Claim the Google listing
- **Client title:** Claim the Google listing
- **Benefit (client):** The store controls what Google shows.
- **Steps:** (1) Claim the listing from the business Google account. (2) Add us as a manager.
- **Done when:** The listing reads as claimed.
- **Opened by:** `claimed`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 7 of SALES_ORDER.
- **Green Haven:** not opened

#### `fix-category`

extract-v2.mjs:936 · owner us · group rank

- **Title:** Set the right main category
- **Client title:** Set the right main category
- **Benefit (client):** Google files the store under what it is.
- **Steps:** (1) Change the main category on the listing.
- **Done when:** The listing shows the matching main category.
- **Opened by:** `category`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 8 of SALES_ORDER.
- **Green Haven:** not opened

#### `add-service-options`

extract-v2.mjs:937 · owner us · group rank

- **Title:** List the ways to shop
- **Client title:** List the ways to shop
- **Benefit (client):** Customers see how they can buy.
- **Steps:** (1) Tick every way to shop the store really offers on the listing.
- **Done when:** Two or more ways to shop show on the listing.
- **Opened by:** `service-options`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 9 of SALES_ORDER.
- **Green Haven:** not opened

#### `fix-hours`

extract-v2.mjs:938 · owner client · group rank

- **Title:** List opening hours for every day
- **Client title:** List opening hours for every day
- **Benefit (client):** Customers and Google know when the store is open.
- **Steps:** (1) Fill in the missing days on the listing.
- **Done when:** Seven days of hours show.
- **Opened by:** `hours`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 10 of SALES_ORDER.
- **Green Haven:** not opened

#### `connect-google`

extract-v2.mjs:939 · owner client · group rank

- **Title:** Connect Google Analytics and Search Console
- **Client title:** Connect Google Analytics and Search Console
- **Benefit (client):** Real clicks replace estimates.
- **Steps:** (1) Grant access from the business Google account.
- **Done when:** We can see both connected on our side.
- **Opened by:** `connected`
- **Competitor Analysis:** When opened, unless its opening check is internal (ours): plan position 17 of SALES_ORDER.
- **Green Haven:** task 3, status watch

#### `directory-work`

extract-v2.mjs:940 · owner us · group ours

- **Title:** Review our directory work for this store
- **Steps:** (1) List where our tagged links point.
- **Done when:** The list is on file.
- **Opened by:** `directory-work`
- **Competitor Analysis:** Never: ours (internal).
- **Note:** Internal (its check is ours), so it never reaches the plan; not in SALES_ORDER.
- **Green Haven:** not opened

#### `scan-points`

extract-v2.mjs:941 · owner software · group data

- **Title:** Hand back each map check whole, with readings that agree
- **Steps:** (1) Check the store's rank field, its place in each point's list and the share against each other.
- **Done when:** Every reading of the same points agrees.
- **Opened by:** `scan-depth`, `market-agrees`
- **Competitor Analysis:** Never: a software-team task.
- **Green Haven:** not opened

#### `scan-out-of-market`

extract-v2.mjs:942 · owner software · group data

- **Title:** Keep another area's businesses out of the map checks
- **Steps:** (1) Find why <k> business rows from about <miles> miles away show up in the lists[, around <towns>]. (2) Flag any point whose list carries them, and leave those points out of a check rather than mixing areas.
- **Done when:** Every business in a map check is in this market.
- **Opened by:** `scan-market`
- **Competitor Analysis:** Never: a software-team task.
- **Green Haven:** task 27, status fail

#### `ranked-keywords`

extract-v2.mjs:943 · owner software · group data

- **Title:** Turn on the ranked-searches read and the position checks for this store
- **Steps:** (1) Run the next audit with the ranked-keywords part and the organic positions switched on. (2) Read the rivals' ranked searches the same way.
- **Done when:** The Google search tab names the searches the website ranks for, and the ones it misses.
- **Opened by:** `ranked-keywords`. Also added (unopened) as a blocker of content-gap (line 994).
- **Competitor Analysis:** Never: a software-team task.
- **Green Haven:** task 28, status fail

#### `rivals-searches`

extract-v2.mjs:944 · owner software · group data

- **Title:** Hand back the rivals' page 1 searches
- **Steps:** (1) Include each rival's page 1 searches for the town and nearby towns.
- **Done when:** The report names the searches this website misses.
- **Opened by:** `rival-searches`. Also added (unopened) as a blocker of content-gap (line 994).
- **Competitor Analysis:** Never: a software-team task.
- **Green Haven:** task 29, status fail

#### `collect-ai`

extract-v2.mjs:945 · owner software · group data

- **Title:** Collect AI answers
- **Steps:** (1) Ask ChatGPT, Perplexity and Google AI Mode the questions buyers ask. (2) Store which stores each answer names.
- **Done when:** The AI answers tab has numbers.
- **Opened by:** `ai-named`
- **Competitor Analysis:** Never: a software-team task.
- **Green Haven:** task 34, status na

#### `crawl-limit`

extract-v2.mjs:946 · owner software · group data

- **Title:** Read the whole site, not the first 100 pages (fixed "100": see findings)
- **Steps:** (1) The site's own sitemaps list <k> pages; raise the crawl limit above that. (2) Crawl the rivals' sites the same way, or label their counts as the first 100 pages.
- **Done when:** The crawl reads every page the sitemaps list.
- **Opened by:** `whole-site`
- **Competitor Analysis:** Never: a software-team task.
- **Green Haven:** task 33, status watch

#### `directory-sources`

extract-v2.mjs:947 · owner software · group data

- **Title:** Take the other market's sources out of this store's directory list
- **Steps:** (1) Remove the <k> <other market label> sources from the list the software checks for this store: <source ids>. (2) Check that a new store's list is built from its own market, not copied from another store's.
- **Done when:** The directory list holds this store's market only.
- **Opened by:** `directory-sources`
- **Competitor Analysis:** Never: a software-team task.
- **Green Haven:** task 31, status fail

#### `directory-coverage`

extract-v2.mjs:948 · owner software · group data

- **Title:** Search the directories for this store, not only test them
- **Steps:** (1) Search every readable directory for the store itself. (2) Read the ones that came back empty a second way.
- **Done when:** Most directories on the list have an answer about this store.
- **Opened by:** `directory-coverage`
- **Competitor Analysis:** Never: a software-team task.
- **Green Haven:** task 30, status fail

#### `answer-isolation`

extract-v2.mjs:949 · owner software · group data

- **Title:** Keep other accounts' readings out of this business's answers
- **Steps:** (1) Drop the <k> analytics readings of <hosts> from this business's full-audit answer: they are another account's own data. (2) Drop the <k> readings bought for other reports.
- **Done when:** The answers carry only this store's, its rivals' and its market's readings.
- **Opened by:** `answer-scope`
- **Competitor Analysis:** Never: a software-team task.
- **Note:** Removed from the Action Plan by the other-accounts cut (its steps say "another account").
- **Green Haven:** task 32, status fail

#### `rival-rows`

extract-v2.mjs:950 · owner software · group data

- **Title:** Hand back the rivals' rows
- **Steps:** (1) Include the rivals' readings in the record.
- **Done when:** Every tab compares the store with its rivals.
- **Opened by:** `rival-rows`
- **Competitor Analysis:** Never: a software-team task.
- **Green Haven:** not opened

#### `store-findings`

extract-v2.mjs:951 · owner software · group data

- **Title:** Store findings and tasks in the software
- **Steps:** (1) Save each check and task with its evidence.
- **Done when:** Tasks live in the software.
- **Opened by:** `stored-findings`
- **Competitor Analysis:** Never: a software-team task.
- **Green Haven:** not opened

#### `seos-{finding code}`

extract-v2.mjs:953-968 · owner us · group seos · service_only

- **Title:** The newest SEOS task's statement for the code
- **Steps:** (1) SEOS's brief's fix, when there is a brief; else 'Open the evidence: <url>' (not when the URL carries our tag) and 'Fix it or mark it as will not do, with the reason.'
- **Done when:** The software's next run no longer raises <CODE>.
- **Opened by:** no check. One per SEOS finding code that has a task in the record (every run). The id is the code lowercased with _ as -. Area by code: PAGE_ or SITE_ website, CITATION or LINKS links, PROFILE_REVIEWS maps, else overview.
- **Competitor Analysis:** Never: service_only.
- **Green Haven:** 15 tasks

#### `town-page`

extract-v2.mjs:796 (named), build-report.mjs:202 (board)

- **Title:** (not defined)
- **Opened by:** `listing-link`
- **Note:** Named by the listing-link check when the listing links to the homepage and the brand has more than one store, and listed in the V2 board, but not defined in TASKS: addTask would stop the build (extract-v2.mjs:985). It cannot fire today because extract-v2.mjs builds one store (line 691).
- **Green Haven:** cannot appear


## 4. Holds

`extract-v2.mjs:1012-1041`. **One rule:** the holds table ("Not safe to quote yet", Action Plan overview) lists exactly the numbers the client copy never prints. Each hold carries `leak`, the patterns (regular expressions, matched without regard to case) the client copy must not contain. A number in a pattern is written as the report prints it (thousands commas), and is not matched inside a longer number (`num()`, line 1019); where the bare number is also a different printable value, the pattern carries the words around it (line 1026).

The client build reads the Competitor Analysis the way a reader meets it (the text, the tooltips, labels and alt text, and the find box) and stops on any hit ("BUILD FAILED: the client copy prints a number on hold") or on a hold that names no pattern (`build-report.mjs:662-674`). Green Haven: 9 holds; the Action Plan shows 8 (the `own-accounts` hold is about our other accounts, section 6).

| Hold | Where | Who clears it | Green Haven |
|---|---|---|---|
| `map-search-held` | Google Maps | Us: a clean check of the same search | not raised |
| `expected-search-missing` | Google Maps | Us: find or run the check | not raised |
| `rival-reviews-capped` | Not printed in this report | Software team: pull every review | raised |
| `rival-links-partial` | Links and listings | Software team: read every link | raised |
| `linking-site-totals` | Links and listings | Nobody: compare only the sites that are not link sellers | raised |
| `link-gap-floor` | Links and listings | Software team: raise the limit | raised |
| `chain-whole-website` | Google search, Links and listings | Nobody: compare one-store websites only | raised |
| `crawl-at-limit` | Website | Software team: crawl past 100 pages | raised |
| `unconfirmed-not-found` | Google Maps | Software team: keep other areas out of the sweeps | raised |
| `own-accounts` | Google Maps | Nobody: never said to a client | raised, left out of the Action Plan |
| `phone-named-cross-store` | Links and listings | Software team: answer every search for every store | raised |

### `map-search-held`

extract-v2.mjs:1020

- **Raised when:** A search on file is on hold: its sweep has hold reasons (rule 1: ran outside posted hours; a far business in a top 3 changes the store's own count; the sweep's point count and its cells disagree; the rank field and the lists disagree; the share and the points disagree), or the market file and the record disagree about a search (every search goes on hold).
- **The number (as the team reads it):** "<kw>": <you> of <n> points
- **Where:** Google Maps
- **Why (sentence):** The hold reasons, joined.
- **Who clears it:** Us: a clean check of the same search
- **Leak patterns (holds[].leak, matched without regard to case):** `"<kw>"[^.]{0,80}<you> of <n> (each number as printed, not inside a longer number)`
- **Green Haven:** not raised

### `expected-search-missing`

extract-v2.mjs:1021

- **Raised when:** A search in settings.expected_searches has no map check on file.
- **The number (as the team reads it):** Any "<kw>" result
- **Where:** Google Maps
- **Why (sentence):** No "<kw>" map check of this store is on file. The report says nothing about it until one is.
- **Who clears it:** Us: find or run the check
- **Leak patterns (holds[].leak, matched without regard to case):** `<kw> (the phrase itself)`
- **Green Haven:** not raised

### `rival-reviews-capped`

extract-v2.mjs:1022

- **Raised when:** A rival's review pull stopped at the depth asked for (rule 4).
- **The number (as the team reads it):** <rivals>: review count from our pull (<pulled counts>)
- **Where:** Not printed in this report
- **Why (sentence):** The pull stopped at the depth asked for, so it is not their count. Their ratings count on Google, and their review velocity over the windows the pull reaches back past, are printed.
- **Who clears it:** Software team: pull every review
- **Leak patterns (holds[].leak, matched without regard to case):** `<pulled count> for each capped rival`
- **Green Haven:** raised (1)

### `rival-links-partial`

extract-v2.mjs:1023

- **Raised when:** A rival's links were not all read (the pull stopped at its page limit), so its seller count is a floor (rule 4).
- **The number (as the team reads it):** Link-seller counts for <rivals> (at least <floor> among the links read)
- **Where:** Links and listings
- **Why (sentence):** <rival>: <read> of <total> links read. The pull stopped at its page limit, so sellers among the rest are unknown. Their linking-site totals are whole, and they are held with the other totals below.
- **Who clears it:** Software team: read every link
- **Leak patterns (holds[].leak, matched without regard to case):** `<floor>[^.]{0,40}(sell|scheme)`
- **Green Haven:** raised (1)

### `linking-site-totals`

extract-v2.mjs:1024-1026

- **Raised when:** Always when the store's links were read (rule 8: totals with the link sellers in mostly compare junk).
- **The number (as the team reads it):** Linking-site totals: <store total> here, <rival> <total>, ...
- **Where:** Links and listings
- **Why (sentence):** <sellers> of this website's are link-selling or scheme pages, and the same wave reached the rivals, so the totals mostly compare junk. The report compares the classified counts.
- **Who clears it:** Nobody: compare only the sites that are not link sellers
- **Leak patterns (holds[].leak, matched without regard to case):** `<store total>`; `for each rival with a whole total: "<total> (linking )?sites" | "linking sites[^.]{0,60}<total>" | "<rival>\W{0,3}<total>" not followed by " ratings" or " stars" and followed within 30 characters by sites, links or link`
- **Green Haven:** raised (1)

### `link-gap-floor`

extract-v2.mjs:1027

- **Raised when:** A part of the link-gap reading (sites that link to two or more rivals) stopped at the vendor's row limit, so the count of such sites is a floor (rule 4).
- **The number (as the team reads it):** Sites that link to the rivals and not here: <k> or more
- **Where:** Links and listings
- **Why (sentence):** <got> of <total> and ... rows came back in two of the four parts: the vendor's limit. The total is a floor; the list of sites with some weight is read from the rows that came back. ("two of the four" is fixed text: see findings)
- **Who clears it:** Software team: raise the limit
- **Leak patterns (holds[].leak, matched without regard to case):** `<k>`
- **Green Haven:** raised (1)

### `chain-whole-website`

extract-v2.mjs:1028-1031

- **Raised when:** Per rival whose Google listing links to an inner page (one store's page on a website for many stores): its whole-website figures are never set beside a one-store website (rule 7).
- **The number (as the team reads it):** <rival>'s whole-website figures: <keywords> searches, <visits> visits a month[, link strength <rank>]
- **Where:** Google search, Links and listings
- **Why (sentence):** <rival>'s Google listing links to one store's page on <domain>, a website for many stores. Its whole-website figures cover every store, so they are never set beside <store>'s one-store website. The lines compare the best rival whose listing links to its own front page.
- **Who clears it:** Nobody: compare one-store websites only
- **Leak patterns (holds[].leak, matched without regard to case):** `<keywords>`; `<visits> (the link strength named in the number has no pattern: see findings)`
- **Green Haven:** raised (1)

### `crawl-at-limit`

extract-v2.mjs:1032-1033

- **Raised when:** The store's site crawl stopped at its page limit (rule 4, rule 7).
- **The number (as the team reads it):** Whole-site crawl counts and scores: <k> duplicate titles, <k> duplicate descriptions, score <score>; <rival> <score>, ...
- **Where:** Website
- **Why (sentence):** The crawl stopped at its <max>-page limit[ of the <k> pages the sitemaps list], and so did each rival's. They are counts within the first <max> pages, so no whole website leads on them.
- **Who clears it:** Software team: crawl past 100 pages
- **Leak patterns (holds[].leak, matched without regard to case):** `<store score> and the same to one decimal`; `\d+ duplicate (titles|descriptions)`; `on-page score, whole website`; `whole site: score`; `each rival's score and the same to one decimal`
- **Green Haven:** raised (1)

### `unconfirmed-not-found`

extract-v2.mjs:1034-1036

- **Raised when:** The main search's sweep has points where the store is not in the first 20 and another area's business is (rule 1, rule 5).
- **The number (as the team reads it):** "<kw>": not found at <k> of <n> points
- **Where:** Google Maps
- **Why (sentence):** At each of those points the first 20 carries <k> businesses from another area, so the store may have been pushed out by them. The client copy says "at least <found> of <n>".
- **Who clears it:** Software team: keep other areas out of the sweeps
- **Leak patterns (holds[].leak, matched without regard to case):** `(?<!at least )<found> of (the )?<n>`; `not found at <k>`
- **Green Haven:** raised (1)

### `own-accounts`

extract-v2.mjs:1037

- **Raised when:** --locations names other businesses of ours whose place is in a sweep's field.
- **The number (as the team reads it):** Our own accounts on this map: <name> (business <id>), ...
- **Where:** Google Maps
- **Why (sentence):** They are tracked in our own software. A client hears of them only as businesses on the public map, like any rival.
- **Who clears it:** Nobody: never said to a client
- **Leak patterns (holds[].leak, matched without regard to case):** `business [0-9]+`; `tracked in our own software`; `our own accounts?`; `(also|one of) our (clients|accounts)`
- **Action Plan:** left out (it matches the other-accounts pattern).
- **Green Haven:** raised (1)

### `phone-named-cross-store`

extract-v2.mjs:1038-1041

- **Raised when:** Listings were read and at least one rival has a phone-with-name count (rule 9: the stores' searches were not answered alike).
- **The number (as the team reads it):** Phone shown with the name, store beside store: <store> <k>, <rival> <k>, ...
- **Where:** Links and listings
- **Why (sentence):** The same searches were not answered alike: <store> <answered> of <asked>, <rival> ... A count over fewer answers is not a smaller footprint.
- **Who clears it:** Software team: answer every search for every store
- **Leak patterns (holds[].leak, matched without regard to case):** `outside sites where google shows the phone with the name`
- **Green Haven:** raised (1)


## 5. Comparison rows and gap lines

### 5.1 Comparison rows (`compare.rows`)

`extract-v2.mjs:1050-1161`. One number, the store beside the competition. Sets: *map* (the businesses at the top of the run's own map check, from their Google listings) and *rivals* (the three stores the run names). A row reaches a client only when it is client-safe; a row that is not client-safe is marked for the team (`build-report.mjs:96`) and cut from the Competitor Analysis.

#### Every row

A row is made only when the store has a value and at least 2 entries have one. Entries run highest value first; a rival with the same value as the store comes before the store; entries with no value go last, with the reason. place and tied are given only when every entry has a value. The row reaches a client only when it is client-safe (sales and not on hold). (extract-v2.mjs:1055-1067)

- **place:** `if(whole, 1 + count(have_v > mine_v), null)` (whole = every entry has a value); **tied:** `whole && count(have_v == mine_v) > 1`; **behind:** `if(whole, place > 1, null)`.
- **Summary sentence** (the first case that holds):
  - `set == 'map' && mine_v == 0`: `top_name + ' leads with ' + top_show + '. ' + short + ' is in Google\'s top 3 at none of the points.'`
  - `!whole`: `short + ' has ' + mine_show + '; ' + if(top_is_you, 'the most of those with a number', top_name + ' leads with ' + top_show) + '.'`
  - `place == 1`: `short + ' ' + if(tied, 'shares the lead', 'leads') + '.'`
  - otherwise: `top_name + ' leads with ' + top_show + '. ' + short + ' is ' + if(tied, 'tied for ', '') + ord(place) + ' of ' + str(of) + '.'`
- **Entry order:** `v == null` asc, then `v` desc, then `is_you` asc.

#### The rows

| Row | Tab | Label | Scope | Set | Client-safe | Green Haven |
|---|---|---|---|---|---|---|
| `map-{sweep id or market key}` | Google Maps | Points in Google's top 3 for "<kw>" | Map check | map | Client-safe unless the check is on hold. key: the run's own sweep. | map-352, map-353, map-320 |
| `ratings` | Google Maps | Google ratings | This store | map | Always. | client-safe, store 6 of 7 |
| `stars` | Google Maps | Star rating | This store | map | Always. | client-safe, store 1 of 7 |
| `photos` | Google Maps | Photos on the Google listing | This store | map | Always. | client-safe, store 5 of 7 |
| `velocity` | Google Maps | Review velocity: new reviews a month | This store | rivals | Only when SEOS's own snapshots agree with the store's dated reviews; on hold otherwise. | client-safe, store 4 of 4 |
| `replies-90` | Google Maps | Reviews from the last 90 days with an owner reply | This store | rivals | Always. | client-safe, store 4 of 4 |
| `reviews-pulled` | Google Maps | Reviews our pull collected | This store | rivals | Never (team only); on hold when any rival's pull is capped. | team only, on hold, of 3, no place |
| `searches` | Google search | Searches the website shows up for | Whole website | rivals | Always. | client-safe, of 3, no place |
| `visits` | Google search | Estimated visits a month from search | Whole website | rivals | Always. | client-safe, of 3, no place |
| `speed-phone` | Website | Phone speed, lab test | Store page | rivals | Always. | client-safe, store 2 of 4 |
| `speed-desktop` | Website | Desktop speed, lab test | Store page | rivals | Always. | client-safe, store 1 of 4 |
| `page-words` | Website | Words a crawler gets from the store page | Store page | rivals | Always. | client-safe, store 1 of 4 |
| `crawler-share` | Website | The browser's words a crawler also gets | Store page | rivals | Always. | client-safe, store 1 of 4 |
| `onpage` | Website | On-page score of the store page | Store page | rivals | Always. | client-safe, of 3, no place |
| `crawl-score` | Website | On-page score, whole website | Whole website | rivals | Never (rule 4); on hold when the crawl stopped at its limit. | team only, on hold, store 1 of 4 |
| `strength` | Links and listings | Link strength score | Whole website | rivals | Always. | client-safe, of 3, no place |
| `clean-sites` | Links and listings | Linking sites that are not link sellers | Whole website | rivals | Always. | client-safe, of 3, no place |
| `clean-weight` | Links and listings | Of those, sites that carry some weight | Whole website | rivals | Always. | client-safe, of 3, no place |
| `sites` | Links and listings | Sites that link to the website, all of them | Whole website | rivals | Never (rule 8); always on hold. | team only, on hold, store 3 of 4 |
| `wave` | Links and listings | Link-selling pages new in the last 30 days | Whole website | rivals | Never (team only), not on hold. | team only, of 3, no place |
| `phone-named` | Links and listings | Outside sites where Google shows the phone with the name | This store | rivals | Never; always on hold. | team only, on hold, store 3 of 4 |
| `dirs-showed` | Links and listings | Directories that answered with the store on them | This store | rivals | Always. | client-safe, store 1 of 4 |

- `map-{sweep id or market key}` (extract-v2.mjs:1071-1078): made one per SEOS sweep with points (id map-<sweep id>), plus one per market-file search with no SEOS sweep of the same search on the same day (id map-<market key>). Entries: The store, then the first 5 businesses of the check's field that are not the store and not more than 150 miles away (field order: top-3 points, then points found, then short name). Note: "<n> points on an <g> by <g> grid, <r> <unit> out, checked <when>[, <k> points left out before it ran]." (market rows: "<n> points, checked <when>.") Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `if(sweep != null, sh == true, rh == true)`; key = `sweep != null && ref == if(contains(sweep_ids, str(scan_id)), str(scan_id), first(sweep_ids))`.
- `ratings` (extract-v2.mjs:1079-1082): made when at least one business at the top of the map, or a rival, has its Google listing read. Entries: The store, then up to 6 businesses at the top of the run's own sweep (field order) that are within 150 miles and have a Google listing read; rivals missing from the sweep are appended after them and usually fall past the 6. Note: "As each Google listing showed it when we read it: <dates>. The businesses with the most top-3 points for "<kw>"." Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `true`.
- `stars` (extract-v2.mjs:1083): made as ratings. Entries: As ratings, only those with a rating; shown to one decimal. Note: As ratings. Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `false`.
- `photos` (extract-v2.mjs:1084): made as ratings. Entries: As ratings. Note: As ratings. Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `false`.
- `velocity` (extract-v2.mjs:1086-1088): made when two or more stores (the store and the rivals) have a whole 90-day window. Entries: The store and the three rivals: new reviews a month over 90 days from each store's own dated reviews (rounded for show); a rival not read shows "Not read". Note: "Over the 90 days to <date>, from each store's own dated Google reviews.[ <rival>'s review read stopped at the depth asked for, and still reaches back past the 90 days.]" Flags as rules.json writes them: client-safe = `agrees == true` and not on hold; on hold = `agrees != true`; key = `false`.
- `replies-90` (extract-v2.mjs:1089-1091): made when the store's 90-day window is whole. Entries: The store and the three rivals: 100 x replied / max(1, reviews) over 90 days, one decimal. Note: "Of each store's reviews from the 90 days to <date>." Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `false`.
- `reviews-pulled` (extract-v2.mjs:1092-1093): made when reviews were read. Entries: The store's collected count and each rival's; a capped rival shows "At the pull's limit" (rule 4). Note: "A store whose pull stopped at its limit has more reviews than it shows." Flags as rules.json writes them: client-safe = `false` and not on hold; on hold = `any(capped == true)`; key = `false`.
- `searches` (extract-v2.mjs:1094-1098): made when the store's whole-domain keyword count is known. Entries: The store and the three rivals; a chain rival (listing links to an inner page) has no value and the reason "Not set beside yours: its listing links to one store's page on a website for many stores" (rule 7). Note: "Each bar is a whole website, every store it covers, in Google's first 100 results. An outside estimate." Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `true`.
- `visits` (extract-v2.mjs:1099): made when the store's whole-domain traffic estimate is known. Entries: As searches. Note: "An outside estimate for each whole website, every store it covers. Not real clicks." Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `true`.
- `speed-phone` (extract-v2.mjs:1100-1111): made when the store page has a phone lab score. Entries: The store page and each rival's listing page, read the same way in the same run. Note: "The page each Google listing links to, read the same way for every store on <date>. Google's lab test on a simulated slow phone. Good is 90 or more." Team note: Which reading is used, the front-page readings of the night before, and whether the store's place is the same on both readings (rule 9: an order is quoted only when both give it). Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `true`.
- `speed-desktop` (extract-v2.mjs:1112): made when the store page has a desktop lab score. Entries: As speed-phone. Note: The page note. Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `false`.
- `page-words` (extract-v2.mjs:1113): made when the store page's crawler word count is known. Entries: As speed-phone. Note: The page note, "What our plain page reader got, with no browser." Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `false`.
- `crawler-share` (extract-v2.mjs:1114-1115): made when both word counts of the store page are known. Entries: min(100, round(100 x crawler words / browser words)) for each page. Note: The page note, "100% means a crawler reads everything a visitor's browser shows." Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `false`.
- `onpage` (extract-v2.mjs:1116): made when the store page's on-page score is confirmed (both reads agree). Entries: One decimal; a rival page whose two reads disagree has no value and "Not confirmed: two reads of the page disagree (<a> and <b>)" (rule 9). Note: The page note, "The vendor's own score for the page's build." Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `false`.
- `crawl-score` (extract-v2.mjs:1117-1120): made when the store's site crawl is in the record. Entries: Each site's crawl score, one decimal. Note: "The first <max> pages of each whole website, crawled <date>. Every crawl stopped at that limit." Team note: On hold: scores of the first <max> pages, not of whole websites; broken links in those pages. "Not for a client." Flags as rules.json writes them: client-safe = `false` and not on hold; on hold = `at == true`; key = `false`.
- `strength` (extract-v2.mjs:1123): made when the store's domain rank is known. Entries: As searches (chain rivals without a value). Note: "An outside score for the weight a whole website's links carry, on a scale to 1,000." Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `true`.
- `clean-sites` (extract-v2.mjs:1124-1128): made when the store's links were read. Entries: Each website's linking sites minus link sellers and scheme pages (rule 8); a rival whose links were not all read has no value: "Not counted: <read> of its <total> links were read". Note: "Each website's linking sites, minus the link-selling and scheme pages, classified the same way for every website." Team note: The stricter count (spam score 30 or more dropped, shared page titles dropped) and whether the lead holds on it. Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `true`.
- `clean-weight` (extract-v2.mjs:1129-1130): made when the store's links were read. Entries: Not-seller sites with a vendor score above 0; a partly read rival: "Not counted: part of its links were read". Note: "Linking sites that are not link sellers and that the vendor scores above zero." Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `false`.
- `sites` (extract-v2.mjs:1131): made when the store's links were read. Entries: Total linking sites, sellers left in; whole totals only. Note: "Totals with the link-selling pages left in. They mostly compare junk." Flags as rules.json writes them: client-safe = `false` and not on hold; on hold = `true`; key = `false`.
- `wave` (extract-v2.mjs:1132-1133): made when the store's links were read. Entries: Link-selling sites first seen in the last 30 days; a partly read rival has no value. Note: "The same wave reached every website in the market. A count to watch, not a strength." Flags as rules.json writes them: client-safe = `false` and not on hold; on hold = `false`; key = `false`.
- `phone-named` (extract-v2.mjs:1136-1140): made when listings were read. Entries: The store's and each rival's phone-with-name count. Note: "From the same Google searches for each store's phone number, street address and name, made the same day for every store." Team note: On hold (rule 9): the searches were not answered alike, so a smaller count may be fewer answers, not fewer sites. Flags as rules.json writes them: client-safe = `false` and not on hold; on hold = `true`; key = `false`.
- `dirs-showed` (extract-v2.mjs:1141-1142): made when listings were read. Entries: Directories searched for each store that came back showing its phone or address. Note: "... One that did not answer is not counted against anyone." Flags as rules.json writes them: client-safe = `true` and not on hold; on hold = `false`; key = `false`.

### 5.2 Gap lines (`gaps`, "The gap to number 1")

`extract-v2.mjs:1163-1199`. Each line sets one of the store's numbers beside the best there is and names it.

A line is made only when both numbers exist. lead = the store is the best (a won map search) or its number is at least the best's; level = not the best and equal. deficit is a share of the larger number, negative when the store leads. The sentence depends on diff: times, count, more, or plain ("<k> <unit> short."). A floor (number 1's count rose without far businesses) prefixes "At least". (extract-v2.mjs:1165-1172)

- **lead:** `you_are_best || you >= best`
- **level:** `!you_are_best && you == best`
- **deficit:** `if(lead, -abs(you - best) / max(abs(best), abs(you), 1), (best - you) / max(abs(best), 1))`
- **sentence:** `if(you_are_best, if(you == best, 'Level with number 2.', 'You lead by ' + fmt(show, r2(you - best)) + '.'), if(level, 'Level.', if(lead, 'You lead.', if(diff == 'times', if(you == 0, fmt(show, best) + ' to none.', if(you <= 2 && best / you >= 10, fmt(show, best) + ' to ' + fmt(show, you) + '.', if(best / you >= 1.5, str(r1(best / you)) + ' times yours.', n(r2(best - you)) + ' more than you.'))), if(diff == 'count', n(best - you) + ' to go.', if(diff == 'more', fmt(show, r2(best - you)) + ' more than yours.', fmt(show, r2(best - you)) + ' ' + unit + ' short.'))))))`
- **floor:** `if(floor && !lead, 'At least ' + lower_first(body), body)`
- **printed numbers:** `fmt(show, you)`, `fmt(show, best)` (show: n = thousands commas; fixed1 = one decimal; round_n = rounded, then commas)

| Line | Tab | Label | The best | Diff | Show | Who | Green Haven |
|---|---|---|---|---|---|---|---|
| `map-{search key}` | Google Maps | Map points in Google's top 3 for "<kw>" | Number 1: number 2's top-3 points (0 when none), and the store is the best ("You lead by <k>." / "Level with number 2."). Otherwise number 1's top-3 points, "at least" when number 1's count is a floor (far businesses took points from it). | times when behind | n | Number 1 on the map, or Number 2 on the map when the store leads | map-seos-353: "2.4 times yours."; map-seos-352: "You lead by 1."; map-seos-320: "At least 117 to none." |
| `ratings-1` | Google Maps | Google ratings | L1's number 1's ratings count | times | n | Number 1 for "<L1 search>" | "7.2 times yours." |
| `stars-1` | Google Maps | Star rating | L1's number 1's rating | plain (of a star) | fixed1 | Number 1 for "<L1 search>" | "You lead." |
| `photos-1` | Google Maps | Photos on the Google listing | L1's number 1's photo count | times | n | Number 1 for "<L1 search>" | "6.4 times yours." |
| `ways-1` | Google Maps | Ways to shop on the listing | L1's number 1's service options | times | n | Number 1 for "<L1 search>" | "Level." |
| `details-1` | Google Maps | Details filled in on the listing | L1's number 1's attributes | times | n | Number 1 for "<L1 search>" | "You lead." |
| `velocity-1` | Google Maps | Review velocity: new reviews a month | L1's number 1's 90-day pace | times | round_n | Number 1 for "<L1 search>" | not made |
| `searches` | Google search | Searches the website shows up for | The largest one-store rival website (chains never: rule 7) | more | n | Largest one-store rival website | "343 more than yours." |
| `visits` | Google search | Estimated visits a month from search | As searches. | more | n | Largest one-store rival website | "2,761 more than yours." |
| `strength` | Links and listings | Link strength score | The strongest one-store rival website. | plain (points) | n | Strongest one-store rival website | "67 points short." |
| `clean-sites` | Links and listings | Linking sites that are not link sellers | The one-store rival with the most (a rival whose links were not all read is left out). | more | n | Rival with the most | "You lead." |
| `speed` | Website | Phone speed, lab test | 90 ("good is 90 or more") | plain (points) | n | Google's own mark | "37 points short." |
| `replies-90` | Google Maps | Reviews from the last 90 days with a reply | Every review of the 90 days ("every one of them") | count | n | The target | "42 to go." |
| `phone-named` | Links and listings | Outside sites where Google shows the phone with the name | The rival with the most | times | n | Rival with the most | "2.2 times yours." |

- `map-{search key}` (extract-v2.mjs:1173-1176): made one per search on file that is not on hold. Note: "Of <n> points. [You are number 1. ]Checked <date>."
- `ratings-1` (extract-v2.mjs:1177-1179): made when there is a first loss (L1) and its number 1's Google listing was read. Note: "Yours as read <date>, <number 1>'s on <date>."
- `stars-1` (extract-v2.mjs:1180): made as ratings-1. Note: As ratings-1.
- `photos-1` (extract-v2.mjs:1181): made as ratings-1. Note: As ratings-1.
- `ways-1` (extract-v2.mjs:1182): made as ratings-1. Note: As ratings-1.
- `details-1` (extract-v2.mjs:1183): made as ratings-1. Note: As ratings-1.
- `velocity-1` (extract-v2.mjs:1184-1185): made when the review counts agree (velocity_agrees), the store has a 90-day pace and L1's number 1 is one of the rivals with a 90-day pace. Note: "Over the 90 days to <date>, from each store's own dated reviews."
- `searches` (extract-v2.mjs:1187-1192): made when the store's keyword count is known and a one-store rival (its listing links to its front page) has one. Scope whole: drawn with a "Whole websites" chip and sorted after the other lines of its group. Note: "Whole websites: this one-store website beside the rival one-store website with the most. An outside estimate."
- `visits` (extract-v2.mjs:1193): made as searches, with the visit estimates. Scope whole: drawn with a "Whole websites" chip and sorted after the other lines of its group. Note: As searches.
- `strength` (extract-v2.mjs:1194): made when the store's domain rank is known and a one-store rival has one. Scope whole: drawn with a "Whole websites" chip and sorted after the other lines of its group. Note: "An outside score on a scale to 1,000, for each whole website."
- `clean-sites` (extract-v2.mjs:1195): made when links were read and a one-store rival's links were read whole. Scope whole: drawn with a "Whole websites" chip and sorted after the other lines of its group. Note: "Classified the same way for every website. A rival whose links were not all read is left out."
- `speed` (extract-v2.mjs:1196): made when the store page has a phone lab score. Note: "Out of 100, on a simulated slow phone."
- `replies-90` (extract-v2.mjs:1197): made when the store's 90-day window has reviews. Note: "Of the <k> Google reviews from the 90 days to <date>."
- `phone-named` (extract-v2.mjs:1198-1199): made when listings were read and any rival has a phone-with-name count. On hold: team only. Note: "The same Google searches for each store's phone, street and name. On hold: the searches were not answered alike for every store."

## 6. The two cuts

One model, two documents:

```sh
node build-report.mjs green-haven/report-data.json <out>/competitor-analysis.html --audience=client --doc="Competitor Analysis"
node build-report.mjs green-haven/report-data.json <out>/action-plan.html --audience=service --doc="Action Plan"
```

`build-report.mjs` first builds one page with both views (`data-only="sales"` and `data-only="service"` blocks), then cuts one view out of the file itself (`cut()`, lines 616-629: each element carrying the attribute is removed with everything inside it). Without `--audience` (internal) both views stay, with a switch.

### 6.1 Client audience: the Competitor Analysis

What is cut (`build-report.mjs:631-636`): every element marked `data-only="service"` or `data-team`. That removes the team overview (task cards, the holds table, "Since the last report", health by area), the team's check rows and the data-check blocks, the "Tasks here" lists, the team notes on cards, every comparison card that is not client-safe (line 96), every gap line on hold (line 138), the "Not compared yet" lists (line 102), the store picker, the Present button and the Sales / Service switch. The AI tab button and its content are service-only (lines 452, 587); the empty AI section is then removed (line 633) and the find box lists no AI tab (line 642). The find box keeps only items not marked service (line 634); no task data, no seller list and no run id go into the file (lines 635, 642-643).

**The leak gate** (`build-report.mjs:652-661`). The page body, with the stylesheet and the inline script taken out (the find box data stays in), must not contain any of: a service block (`data-only="service"`); a team-only block (`data-internal`); the view switch (`data-mode-set`); the words "software team" or "on hold"; when the main map check is on hold, its map shares and the map check card (`id="scan"`); the name of a tool we use (Local Falcon, localrankingtracker, lf-static, DataForSEO, Eagle Eyes); the id of a comparison card kept for the team; the "not compared yet" list (`id="cmp-missing-`); a collection limit ("pull's limit", "the pull stops"); our own tag (`utm_`, or the listing's utm_source value); the run id; a low-star review quote (`data-quote`); task internals (`"steps"`, `done_when`). One hit: "BUILD FAILED: the client copy still carries: ...". Then the held-numbers gate (section 4).

### 6.2 Service audience: the Action Plan

**The other-accounts cut** (`build-report.mjs:27-44`). Every check, task and hold whose JSON matches XACCT is left out of the document:

```
\bbusiness [0-9]+\b|tracked in our own software|\bour own accounts?\b|(also|one of) our (clients|accounts)|another account
```

(without regard to case). Each one left out is printed ("left out of the service document (about our other accounts): ...", line 688).

- **Orphan gate** (lines 38-40): the build stops when a kept task is blocked by a task left out, a kept check names a task left out, or a plan item names a task left out. Two of its tests read fields the model does not have (`t.check`, `p.task`), so they never fire; see the known defects.
- **Count gate** (lines 41-42): the build stops when a check left out is not a data check and its area is counted in the tiles (the tiles would then count a check the document does not show).
- The task group counts are recounted (line 43).
- Then every `data-only="sales"` and `data-team` element is cut (line 639): the client headline, the client tiles, "What is missing", the client's check rows, "What we would do here", the client plan and the view switch; the find box drops its sales-only items (line 640). The team-only blocks (`data-internal`) stay: this is the team's document. Its Present button hides team notes, numbers on hold and software-team work while a client can see the screen (line 582).
- **The gate** (lines 676-686): the document, read the way a reader meets it, must hold no Sales-only block, no view switch and nothing matching XACCT. One hit: "BUILD FAILED: the service document still carries: ...".

Green Haven (rebuilt in this session, the builder's own output): left out `own-accounts` (check), `answer-scope` (check), `answer-isolation` (task) and the `own-accounts` hold. Both rebuilt documents are byte-identical to `green-haven/docs/`.

### 6.3 The `--doc` name

`--doc="<name>"` (`build-report.mjs:24`, trimmed) names the document in four places: the browser title "<short name> <city> · <name>" (line 573, in place of "SEO health report"), the header (line 579), the client overview's first line (line 232, in place of "SEO and competition report") and the team overview's first line (line 277, in place of "Service view"). Green Haven: "Green Haven Elizabeth · Competitor Analysis" and "Green Haven Elizabeth · Action Plan".

### 6.4 The find box

On every audience, every place the find box can send a reader must exist on the page, or the build stops ("the find box points at places that are not on the page", `build-report.mjs:648-651`).

## 7. The 10 client-report rules and the code that enforces them

The ten rules at the top of `extract-v2.mjs` (lines 20-34).

| # | Rule | Enforced by | On a breach |
|---|---|---|---|
| 1 | A number that rests on a flawed reading is on hold: shown to the team with the reason and who clears it, never quoted to a client, never leaned on by the headline. | Sweep tests `extract-v2.mjs:225-231`: out of posted hours (226), a far business that changes the store's own count (227), points against cells (228), rank field against lists (229), share against points (230). Market file against record: every search on hold (306-317). The map check goes na with a client line (753, 759). The headline, L1 and the gap lines use searches not on hold only (1204, 910, 1173). The hold row and its leak pattern (1020). The held-numbers gate (`build-report.mjs:662-674`). | A held number in the client copy stops the build. A held search never heads the page. |
| 2 | Evidence that carries the agency's own tag is ours: team only. | `isOurs` (`extract-v2.mjs:142-143`); `listing-tag` and `directory-work` checks are internal (797, 871); SEOS evidence links carrying our tag are never shown (966-967); listing rows flag ours (684). Gate: nothing a client can see carries `utm_<x>=<agency>` (1247-1248). Client leak gate: `utm_` or the listing's tag (`build-report.mjs:660`). | "EXTRACT FAILED: a line a client can see carries our own tag", or BUILD FAILED. |
| 3 | The client copy is a separate file. | `--audience=client` (`build-report.mjs:21-23`), the cut (631-636), the leak gate (652-661). | BUILD FAILED: the client copy still carries ... |
| 4 | A count that stopped at a collection limit is not printed as the count. | Review pulls: count null when capped (`extract-v2.mjs:323-332`, 390). Links: seller counts null when the links were not all read (513, 525). Link gap: "or more" and a floor (556, 585, 1027). Crawl: at the limit (447). Holds 1022, 1023, 1027, 1032-1033 with leak patterns; the crawl-score card is team-only (1118). Client leak gate: "pull's limit" (`build-report.mjs:659`). | A held count in the client copy stops the build. Elsewhere by construction (no count is computed). |
| 5 | An empty read is "could not be read", never "not there". | Listing rows say "nothing: the page came back empty" (`extract-v2.mjs:635`); verdicts say "Could not be read" (647); "Not checked in this report" (648); the check lines (879, 881); not-found points with far businesses are "at least" and held (761-765, 1034-1036). | By construction only; no gate checks the wording (the unconfirmed not-found hold has leak patterns). |
| 6 | Map points are counted from each sweep's own cells: "58 of 121 points". | Counting from each point's first 20 (`extract-v2.mjs:196-205`); the value "<k> of <n> points" (758). When the rank field, the lists or the share disagree the sweep goes on hold (228-230) and `scan-depth` fails (783-785). Line 1250 only prints a note. | The sweep is held (not quoted) and the data check fails; the build does not stop. |
| 7 | Whole-website figures are labelled as whole-website figures. | Rows scoped "Whole website" (`extract-v2.mjs:1098-1099, 1118, 1123, 1126-1133`); gap lines scoped whole (1192-1195) and drawn with a "Whole websites" chip (`build-report.mjs:139`). A chain rival's figures are never set beside the store (398, 1096-1097, 1190-1191) and are held (1029-1031). | A held chain figure in the client copy stops the build. The labels themselves are not gated. |
| 8 | Linking-site totals are classified first (link sellers and scheme pages out), then counted. | The seller and network classification (`extract-v2.mjs:488-534`); the client line of `linking-sites` gives only classified counts (866-867); the totals hold (1024-1026); the totals card is held (1131). | A total in the client copy stops the build. |
| 9 | Say what the tool saw; two fields of one reading that disagree are "not confirmed". | On-page score (`extract-v2.mjs:442-443`, card 1116); `main-heading` (834-835); `store-details` (840-842); review velocity against SEOS's snapshots (377-379, 811-812, 1086); speed order quoted only when both readings give it (1105-1110, `build-report.mjs:472`); phone-with-name counts held (1040-1041, 1138-1140, 1199). | By construction (the check reads "Not confirmed", goes na or is held); no general gate. |
| 10 | The owner's ordering: losing first, winning last (`meta.order = 'loss-first'`). | `extract-v2.mjs:739-740, 910, 1201-1218, 1349`; `build-report.mjs:54-56, 99-100, 109, 134, 146, 186-188`. Gate: the headline names the biggest loss (1252). | "EXTRACT FAILED: the headline does not lead with the biggest loss". The other orders hold by construction; check-rules.mjs verifies them. |

Two more gates in `extract-v2.mjs` serve the same rules: a result claimed for an expected search that is not on file stops the build (line 1254), and with `--facts` every number the model shares with the independent facts file must agree (lines 1256-1340; RUN.md records 185 shared numbers, 0 disagreeing, on 2026-10-12).

## 8. Known defects and non-generic spots

Reported, not fixed (the reference code stays as it is). Each is in `parts/C2-rules.json` with a proposed fix. The ones printed in the Green Haven documents were seen in those files; two others were shown by running the code on copies (marked "shown"); the rest are read from the code and not verified by running it.

- **Printed now in the Green Haven Action Plan:** `map-gap` step 4 says "Check both searches again" with three searches on file (`extract-v2.mjs:915`); the map checks note says "A far-away business in a point's top 3 would put that check on hold" while "weed near me" has one in a top 3 at 66 points and is not held, because the code holds only when the store's own count changes (`build-report.mjs:387` against `extract-v2.mjs:227`; the header comment at lines 23-24 says the same as the note); the "What was read, and when" table prints full times for the map checks because a pattern lacks its backslashes (`build-report.mjs:565`).
- **Would misfire for another business:** a vertical other than Cannabis gets `category` na but still opens `fix-category`, which reaches the client's plan (`extract-v2.mjs:789-791`; shown by running the extractor with a copy of the settings file whose vertical is "Vape shop": "Set the right main category" became plan item 6); `listing-link` names a task `town-page` that is not defined (`extract-v2.mjs:796`; inert while one store is built); `stored-findings` with findings but no tasks names no task, so its find-box link fails the build (`extract-v2.mjs:892`, `build-report.mjs:546, 651`; shown on a model copy: "BUILD FAILED: the find box points at places that are not on the page: tk-null"); a weekday with no posted hours reads as unknown, so a map check run on a day the store does not open is neither out of hours nor held (`extract-v2.mjs:159`, used at 216 and 226); the expected-search gate builds a pattern from the phrase without escaping it (`extract-v2.mjs:1254`; the agency name likewise at 1248); fixed text in task steps: "for Elizabeth and the towns around it" (926), "(11 by 11, 2 miles)" (916), "Fix the duplicate meta tags" (925), "Search Console is not connected" (932), "the only one that survives its control is the distance from the grid centre" (915), "the first 100 pages" (946, 1032), "two of the four parts" (1027), "the three rivals" (869-870, `build-report.mjs:515, 527`), "its Council Bluffs vantage" (779); `rescan-open-hours` uses Monday's hours for every day (917); `connected` says "Neither is connected" when one of the two is (820).
- **Cannabis-specific:** CATEGORY (789), the low-star subjects ("budtender", "bad weed": 335-340), the name shortener (108), the age-gate heading (455), CANNABIS_SITE (492) and its "Cannabis directory" chip (`build-report.mjs:515`), the directories that matter (Weedmaps, Leafly, Dutchie: 594-595), the client email's directories (918), "<city> dispensary" (283), "cannabis articles" (865), "cannabis ones" and "cannabis sites" in task steps (928, 930).
- **Rule edges:** the phone speed band reads the raw score while the page prints it rounded (a raw 0.895 prints 90 and is "Needs a look"; `extract-v2.mjs:431, 435`); the three loss orders differ in their tie-breaks (739, 910, 1205); the chain hold names a link strength its leak patterns do not cover (1030-1031); the orphan gate reads `t.check` and `p.task`, which the model never has (`build-report.mjs:38-39`); `title` names no task even when it is watch (837); `review-count` passes when the store beats the smallest of the stores beside it (799; Green Haven's smallest has 6 ratings); the map's subtitle says "every one taken in opening hours" whenever no check is known to be outside them, including checks whose hours are unknown (`build-report.mjs:115`); the find box's search words for the listing link include "charlotte", a town from another report (`build-report.mjs:219`).
- **Comments that disagree with the code:** the Compare switch is said to be off in the Service view (`build-report.mjs:12-13`) but opens on in both (`client.js:50-53`); the compare sets name a "nearby" set no row uses (`extract-v2.mjs:1051-1053`); `rival-rows` carries a pass wording that can never be emitted (891); DATA-NOTES.md (section 5, rule 10) still says "lead with what they built", the opposite of the code's loss-first rule.

## 9. How this was checked

Run from `Product/seos-report/` on 2026-10-12 with Node 24.15.0:

```sh
node handoff/seos-report-handoff-v1/contract/check-rules.mjs green-haven/report-data.json \
  --md=handoff/seos-report-handoff-v1/contract/RULES.md \
  --client-doc=green-haven/docs/competitor-analysis.html \
  --service-doc=green-haven/docs/action-plan.html
```

Result: **PASS, 940 of 940.** What that covers:

- **Ids:** all 43 checks, 34 tasks, 9 holds, 24 comparison rows and 15 gap lines of the Green Haven model have their rule in rules.json (50 check rules, 33 task rules, 11 holds, 22 comparison rows and 14 gap lines, families counted once).
- **Check statuses:** 34 recomputed from the model's own values with the rule as rules.json writes it; 8 fixed by their rule (always watch, fail or na); 1 not evaluable from the model (`answer-scope`: the counts it rests on are not in report-data.json). 41 value lines recomputed. 45 presence rules tested: a check the rules say is made is in the model, and one they say is not made is absent.
- **Tasks:** owner, group, opening checks, status, ours flag and blocked-by for all 34; the 10-item plan against SALES_ORDER; the task numbers 1 to 34; the task group counts.
- **Holds:** 9, each matched by its "clears" line, each with valid leak patterns.
- **Comparison rows:** 24: client-safe and on-hold flags, key flag, place, tie, the summary sentence and the entry order.
- **Gap lines:** 15: lead, level, deficit, the sentence and the printed numbers; 19 of their numbers traced back to the model.
- **Orders:** the map searches (loss first), the headline's losses, wins and both lines, the area tile counts.
- **The documents:** which checks each one shows and their order on each tab, the Wrong / To look at / Right board, the gap lines, the comparison cards, the plan and its buckets, the holds table (8 rows), the task list (33 tasks).
- **The snapshot:** the 130 Green Haven entries in rules.json agree with the model.
- **RULES.md** names every rule id in rules.json.

The checker can fail. Seventeen deliberate breaks, each made on a copy (a status flipped; a threshold changed in rules.json; an unknown check id; number 1's points lowered; an unknown hold; the plan reordered; a team-only row marked client-safe; a deficit; a value; an owner; the headline; a tile count; a missing check; the search order; a summary; a stray opening check; two gap lines swapped in the Competitor Analysis) were all caught, each in the area expected.

The two documents were also rebuilt from the model into a scratch folder with the commands in section 6: both are byte-identical to `green-haven/docs/` (sha256 `fd7a98cc...` for the Competitor Analysis, `3e599768...` for the Action Plan), and the builder reported the four items it left out of the Action Plan.
