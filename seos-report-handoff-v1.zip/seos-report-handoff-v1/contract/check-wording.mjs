// check-wording.mjs: proves the wording catalog (wording.json) against the documents and the model.
// For every entry that has example_slots:
//   1. each example slot whose example_paths entry is a model path (or a small expression over paths) equals the value at
//      that path in report-data.json; a slot marked "literal: ..." is reported as not read from the model
//   2. the template, rendered with the example slots and the catalog's formats, gives the entry's example exactly
//   3. the example appears verbatim in the readable text of a document (tags stripped, entities decoded; the text of
//      tooltips and labels counts, as data-tip, aria-label, title, placeholder and alt) or inside a string of
//      report-data.json (check, task and hold text lives in the model). Spaces are collapsed on both sides and a space
//      before . , ; : ! ? ) is dropped on both sides before the match.
//   4. with --src, the entry's source line holds its source_probe
// An entry marked "not exercised by the Green Haven data" has no example_slots and is not counted as verified.
// usage: node check-wording.mjs <wording.json> <report-data.json> <competitor-analysis.html> <action-plan.html>
//          [--src=<folder holding build-report.mjs, extract-v2.mjs and mapview.js>] [--md=<out WORDING.md>]
// Exit 0 and PASS when every entry that claims to be verified verifies; exit 1 and the failures otherwise.
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const files = argv.filter(a => !a.startsWith('--'));
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
const [wPath, mPath, caPath, apPath] = files;
if (!wPath || !mPath || !caPath || !apPath) { console.error('usage: node check-wording.mjs <wording.json> <report-data.json> <competitor-analysis.html> <action-plan.html> [--src=<code folder>] [--md=<WORDING.md>]'); process.exit(2); }
const W = JSON.parse(fs.readFileSync(wPath, 'utf8'));
const M = JSON.parse(fs.readFileSync(mPath, 'utf8'));
const NOT_EXERCISED = 'not exercised by the Green Haven data';

// ---------- the formats (the same rules build-report.mjs, extract-v2.mjs and mapview.js print with) ----------
const n = x => x === null || x === undefined ? '' : (Number(x) === 0 ? 0 : Number(x)).toLocaleString('en-US');
const nth = k => `${k}${k % 100 >= 11 && k % 100 <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][k % 10] || 'th'}`;
const PLACE_WORD = ['', 'First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth', 'Ninth', 'Tenth', 'Eleventh', 'Twelfth'];
const listOf = a => (a.length <= 1 ? a.join('') : `${a.slice(0, -1).join(', ')} and ${a[a.length - 1]}`);
const LONG_DASHES = new RegExp('[' + String.fromCharCode(0x2012, 0x2013, 0x2014, 0x2015, 0x2212) + ']', 'g');   // U+2012 to U+2015 and U+2212
const dash = s => String(s).replace(LONG_DASHES, '-');
const FORMATS = {
  n: v => n(v),
  ord: v => nth(v),
  fixed1: v => Number(v).toFixed(1),
  fixed2: v => Number(v).toFixed(2),
  pad2: v => String(v).padStart(2, '0'),
  round: v => n(Math.round(v)),
  lower: v => String(v).toLowerCase(),
  cap1: v => String(v).replace(/^\w/, c => c.toUpperCase()),
  placeword: v => PLACE_WORD[v] || `Number ${v}`,
  placeword_lower: v => (PLACE_WORD[v] || nth(v)).toLowerCase(),
  list: v => listOf(v),
  join_comma: v => v.join(', '),
  join_semi: v => v.join('; '),
  join_and: v => v.join(' and '),
  plural: (v, one, many) => `${n(v)} ${v === 1 ? one : many}`,
  word: (v, one, many) => (v === 1 ? one : many),
  if: (v, text) => (v ? text : ''),
  ifnot: (v, text) => (v ? '' : text),
  dash: v => dash(v),
  escape: v => dash(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'),
};
// {name}, {name|format}, {name|format:arg:arg}, and formats in a chain: {name|ord|cap1}
const render = (tpl, slots) => tpl.replace(/\{([a-zA-Z0-9_]+)((?:\|[a-z0-9_]+(?::[^:|}]*)*)*)\}/g, (m, name, chain) => {
  if (!(name in slots)) throw new Error(`no example value for slot {${name}}`);
  let v = slots[name];
  if (!chain) return String(v ?? '');
  for (const step of chain.slice(1).split('|')) {
    const [fmt, ...args] = step.split(':');
    const f = FORMATS[fmt]; if (!f) throw new Error(`unknown format ${fmt}`);
    v = f(v, ...args);
  }
  return String(v);
});
const slotNames = tpl => [...tpl.matchAll(/\{([a-zA-Z0-9_]+)(?:\|[^}]*)?\}/g)].map(m => m[1]);

// ---------- model paths: a.b[0].c, [key=value] picks the first item, [*key=value] keeps every match ----------
const getPath = (root, p) => {
  let cur = root;
  for (const part of p.match(/[^.[\]]+|\[[^\]]*\]/g) || []) {
    if (cur === null || cur === undefined) return undefined;
    if (part[0] === '[') {
      const inner = part.slice(1, -1);
      if (/^\d+$/.test(inner)) cur = cur[Number(inner)];
      else { const all = inner[0] === '*', [k, v] = (all ? inner.slice(1) : inner).split('='); const hit = x => String(x?.[k]) === v; cur = Array.isArray(cur) ? (all ? cur.filter(hit) : cur.find(hit)) : undefined; }
    } else cur = cur[part];
  }
  return cur;
};
// expressions: a path; len(x); round(x); map(list, key); [x, y]; x - y; x + y; 'text'; a number
const splitTop = s => { const out = []; let d = 0, cur = ''; for (const c of s) { if (c === '[' || c === '(') d++; if (c === ']' || c === ')') d--; if (c === ',' && d === 0) { out.push(cur); cur = ''; } else cur += c; } out.push(cur); return out; };
const evalExpr = (root, e) => {
  e = e.trim(); let m;
  // " + " and " - " outside brackets and parentheses, left to right
  const ops = []; let d = 0;
  for (let i = 0; i < e.length; i++) { const c = e[i]; if (c === '[' || c === '(') d++; else if (c === ']' || c === ')') d--; else if (d === 0 && (e.startsWith(' + ', i) || e.startsWith(' - ', i))) ops.push([i, e[i + 1]]); }
  if (ops.length) {
    let acc = evalExpr(root, e.slice(0, ops[0][0]));
    ops.forEach(([at, op], k) => { const v = evalExpr(root, e.slice(at + 3, k + 1 < ops.length ? ops[k + 1][0] : e.length)); acc = op === '+' ? acc + v : acc - v; });
    return acc;
  }
  if (e[0] === '[' && e[e.length - 1] === ']') return splitTop(e.slice(1, -1)).map(x => evalExpr(root, x));
  if ((m = /^len\((.+)\)$/.exec(e))) { const v = evalExpr(root, m[1]); return v === null || v === undefined ? v : v.length; }
  if ((m = /^round\((.+)\)$/.exec(e))) return Math.round(evalExpr(root, m[1]));
  if ((m = /^map\((.+),\s*([a-z_0-9]+)\)$/i.exec(e))) return evalExpr(root, m[1]).map(x => x[m[2]]);
  if (/^'.*'$/.test(e)) return e.slice(1, -1);
  if (/^-?\d+(\.\d+)?$/.test(e)) return Number(e);
  return getPath(root, e);
};

// a slot as a pattern, for the test of a "not exercised" claim
const reLit = s => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const PLACE_RE = '(?:First|Second|Third|Fourth|Fifth|Sixth|Seventh|Eighth|Ninth|Tenth|Eleventh|Twelfth|Number \\d+)';
const TYPE_RE = { date: '[A-Z][a-z]{2} \\d{1,2}, \\d{4}', number: '-?[\\d,]+(?:\\.\\d+)?' };
const slotRe = (tok, patterns) => {
  const [name, ...chain] = tok.slice(1, -1).split('|');
  const p = patterns[name];
  if (p && p[0] === '=') return reLit(evalExpr(M, p.slice(1)));
  if (p) return TYPE_RE[p] || p;
  const last = chain.length ? chain[chain.length - 1].split(':') : null;
  if (!last) return '(?:[^.!?"]|\\.(?=[0-9a-z])){1,80}?';
  const [fmt, ...args] = last;
  const first = chain[0].split(':')[0];
  if (first === 'ord') return '\\d+(?:st|nd|rd|th)';
  return { n: '-?[\\d,]+', round: '-?[\\d,]+', fixed1: '-?\\d+\\.\\d', fixed2: '-?\\d+\\.\\d\\d', pad2: '\\d{2,}', placeword: PLACE_RE, placeword_lower: PLACE_RE.toLowerCase().replace('number \\\\d+', '\\d+(?:st|nd|rd|th)'),
    plural: `[\\d,]+ (?:${args.map(reLit).join('|')})`, word: `(?:${args.map(reLit).join('|')})`, if: `(?:${args.map(reLit).join('')})?`, ifnot: `(?:${args.map(reLit).join('')})?` }[fmt] || '(?:[^.!?"]|\\.(?=[0-9a-z])){1,80}?';
};

// ---------- the readable text of a document, and the model's strings ----------
const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", nbsp: ' ' };
const decode = s => s.replace(/&(#x[0-9a-f]+|#[0-9]+|[a-z]+[0-9]*);/gi, (m, k) => k[0] === '#' ? String.fromCodePoint(/^#x/i.test(k) ? parseInt(k.slice(2), 16) : parseInt(k.slice(1), 10)) : (ENT[k] ?? m));
const norm = s => String(s).replace(/\s+/g, ' ').replace(/\s+([.,;:!?)])/g, '$1').replace(/([(])\s+/g, '$1').trim();
const readable = file => {
  const src = fs.readFileSync(file, 'utf8').replace(/<style\b[\s\S]*?<\/style>/gi, ' ').replace(/<script\b[\s\S]*?<\/script>/gi, ' ');
  const text = norm(decode(src.replace(/<[^>]*>/g, ' ')));
  const withAttrs = norm(decode(src.replace(/<[^>]*>/g, tag => ' ' + [...tag.matchAll(/\s(?:data-tip|aria-label|title|placeholder|alt)="([^"]*)"/g)].map(m => m[1]).join(' ') + ' ')));
  return { text, withAttrs };
};
const strings = [];
(function walk(x) { if (typeof x === 'string') strings.push(norm(x)); else if (Array.isArray(x)) x.forEach(walk); else if (x && typeof x === 'object') Object.values(x).forEach(walk); })(M);
const DOCS = [['Competitor Analysis', readable(caPath)], ['Action Plan', readable(apPath)]];

// ---------- the source lines ----------
const srcDir = opt('src'), cache = {};
const lineOf = (file, ln) => { cache[file] ||= fs.readFileSync(path.join(srcDir, file), 'utf8').split(/\r?\n/); return cache[file][ln - 1] ?? ''; };

// ---------- run ----------
const fails = [], results = [];
let verified = 0, notExercised = 0, fromModel = 0, literal = 0, probes = 0, cases = 0;
// every format the catalog names exists here, and gives the catalog's cases
for (const [k, f] of Object.entries(W.formats || {})) {
  if (!FORMATS[k]) { fails.push(`format ${k}: not known to this checker`); continue; }
  for (const [args, want] of f.cases || []) { const got = String(FORMATS[k](...args)); if (got !== want) fails.push(`format ${k}: ${JSON.stringify(args)} gives "${got}", the catalog says "${want}"`); else cases++; }
}
const ids = new Set();
for (const e of W.entries) {
  const at = `entry ${e.id}`;
  if (ids.has(e.id)) fails.push(`${at}: the id is used twice`); ids.add(e.id);
  for (const k of ['id', 'where', 'template', 'slots', 'condition', 'source']) if (e[k] === undefined) fails.push(`${at}: no ${k}`);
  for (const s of slotNames(e.template)) if (!e.slots || !(s in e.slots)) fails.push(`${at}: the slot {${s}} is not described in slots`);
  if (srcDir && e.source_probe) {
    const [file, ln] = e.source.split(/[: ]/);
    if (!lineOf(file, Number(ln)).includes(e.source_probe)) fails.push(`${at}: ${file}:${ln} does not hold ${JSON.stringify(e.source_probe)}`); else probes++;
  }
  const r = { id: e.id, status: e.status, found: [] };
  results.push(r);
  if (e.status === NOT_EXERCISED) {
    notExercised++;
    if (e.example_slots || e.example) fails.push(`${at}: marked "${NOT_EXERCISED}" and still carries an example`);
    // the claim itself: no document may hold text that fits the template. A slot matches what its format prints ({x|n}
    // digits, {x|placeword} First to Twelfth...); an unformatted slot matches up to 80 characters within one sentence,
    // unless slot_patterns gives it a type (date, number) or "=path" (the model's own value). A template so loose that it
    // still fits other text names that text in fits_other_text, and the check prints it.
    const re = new RegExp(norm(e.template).split(/(\{[^}]*\})/).map(p => p[0] === '{' ? slotRe(p, e.slot_patterns || {}) : p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join(''));
    const hit = DOCS.map(([name, d]) => [name, re.exec(d.withAttrs)]).find(([, mm]) => mm);
    if (hit && !e.fits_other_text) fails.push(`${at}: marked "${NOT_EXERCISED}", yet ${hit[0]} holds text that fits it: "${hit[1][0].slice(0, 160)}"`);
    if (hit && e.fits_other_text) r.fits_other_text = `${hit[0]}: "${hit[1][0].slice(0, 120)}" (${e.fits_other_text})`;
    if (!hit && e.fits_other_text) fails.push(`${at}: says it fits other text, and no document holds such text now`);
    continue;
  }
  if (e.status !== 'verified') { fails.push(`${at}: status must be "verified" or "${NOT_EXERCISED}"`); continue; }
  if (!e.example_slots || e.example === undefined) { fails.push(`${at}: marked verified with no example_slots or example`); continue; }
  // 1. the example values come from the model
  for (const [slot, val] of Object.entries(e.example_slots)) {
    const src = (e.example_paths || {})[slot];
    if (src === undefined) { fails.push(`${at}: slot ${slot} names no example path`); continue; }
    if (/^literal:/.test(src)) { literal++; continue; }
    const got = evalExpr(M, src);
    if (JSON.stringify(got) !== JSON.stringify(val)) fails.push(`${at}: slot ${slot} = ${JSON.stringify(val)}, the model's ${src} = ${JSON.stringify(got)}`); else fromModel++;
  }
  // 2. the template renders to the example
  let out; try { out = render(e.template, e.example_slots); } catch (err) { fails.push(`${at}: ${err.message}`); continue; }
  if (out !== e.example) { fails.push(`${at}: renders "${out}", the example says "${e.example}"`); continue; }
  // 3. the example is in a document or the model
  const want = norm(e.example);
  for (const [name, d] of DOCS) { if (d.text.includes(want)) r.found.push(name); else if (d.withAttrs.includes(want)) r.found.push(name + ' (tooltip or label)'); }
  if (strings.some(s => s.includes(want))) r.found.push('report-data.json');
  if (!r.found.length) { fails.push(`${at}: "${e.example}" is in neither document nor the model`); continue; }
  verified++;
}

// ---------- WORDING.md: the readable catalog, with what this run proved ----------
const mdPath = opt('md');
if (mdPath && !fails.length) {
  const esc = s => String(s).replace(/\|/g, '\\|');
  const out = ['# The wording of the two documents', '',
    'Generated by `contract/check-wording.mjs` from `contract/wording.json` after it proved every entry; do not edit by hand. Each entry is a fixed phrase or a sentence template the documents are written from: where it shows, the template with `{slots}`, what each slot reads from `report-data.json`, what selects the wording, the code that writes it, and the Green Haven example.', '',
    `Result of the run that wrote this file: ${verified} entries verified (rendered from Green Haven values read from \`report-data.json\` and found verbatim in a document or in the model), ${notExercised} marked "${NOT_EXERCISED}". ${fromModel} example values were read back from the model by their paths; ${literal} are literals (the --doc name and constants).`, '',
    ...(W.intro || []), '',
    '## How a template is written', '', ...(W.syntax || []), '',
    '## Formats', '', '| Format | What it prints | Code |', '|---|---|---|', ...Object.entries(W.formats || {}).map(([k, v]) => `| \`${k}\` | ${esc(v.says)} | ${esc(v.code)} |`), ''];
  for (const sec of W.sections) {
    out.push(`## ${sec.title}`, '', ...(sec.intro ? [sec.intro, ''] : []));
    for (const e of W.entries.filter(x => x.section === sec.id)) {
      const r = results.find(x => x.id === e.id);
      out.push(`### \`${e.id}\``, '', `- **Where:** ${e.where}`, `- **Template:** \`${e.template}\``);
      const sl = Object.entries(e.slots || {}); if (sl.length) out.push(`- **Slots:** ${sl.map(([k, v]) => `\`${k}\` = ${v}`).join('; ')}`);
      out.push(`- **Shown when:** ${e.condition}`, `- **Source:** \`${e.source}\``);
      if (e.status === 'verified') out.push(`- **Example:** "${e.example}"`, `- **Verified:** found in ${r.found.join(', ')}`);
      else out.push(`- **Example:** none: ${NOT_EXERCISED}.`);
      if (r.fits_other_text) out.push(`- **Fits other text:** ${r.fits_other_text}`);
      if (e.note) out.push(`- **Note:** ${e.note}`);
      out.push('');
    }
  }
  fs.writeFileSync(mdPath, out.join('\n'));
}

console.log(`wording: ${W.entries.length} entries | ${verified} verified | ${cases} format cases | ${notExercised} ${NOT_EXERCISED} | example values: ${fromModel} read back from the model, ${literal} literal${srcDir ? ` | ${probes} source lines checked` : ''}`);
if (fails.length) { console.log(`FAIL: ${fails.length}`); for (const f of fails.slice(0, 60)) console.log('  ' + f); process.exit(1); }
console.log('PASS');
