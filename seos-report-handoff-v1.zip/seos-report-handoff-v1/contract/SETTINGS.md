# Per-business settings

The SEOS record does not carry everything the report needs about a business. The rest comes from one small JSON file per business, read by `extract-v2.mjs --settings=<file>`. The file for Green Haven is `green-haven/business-settings-48.json`. The exact rules are in `business-settings.schema.json` next to this file.

How the file is read (`settingsFrom`, extract-v2.mjs lines 72-83):

- A key the extractor does not know stops the build.
- `business_id` is required and must equal `businesses[0].id` of the business answer.
- A file for another business stops the build.
- A malformed list, pattern or time zone stops the build.
- `other_market_sources` without `other_market_label` stops the build.
- Every stop prints `EXTRACT FAILED: <message>` and exits with code 1. One exception: a file holding only `null` crashes with a TypeError (also exit code 1).
- Without `--settings` the extractor uses its built-in `SETTINGS` table, which knows only businesses 26 and 48. Any other business then gets no settings at all, and nothing warns about it.

## The table

"Effect" names the report keys and the parts of the documents each setting changes. The Green Haven column comes from `green-haven/business-settings-48.json`. "In the record today" was checked against `_data/green-haven-2026-10-12-with-ee320/business-48.json` (the business answer) and `tables.json` (SEOS's table catalog).

| Key | Required | Type | Effect | Green Haven value | In the record today | Where SEOS could store it |
|---|---|---|---|---|---|---|
| `business_id` | yes | integer | Guard only. It must equal the business id of the answer. It is not written into the report. | `48` | Yes: `businesses.id` = 48 | Already there |
| `brand` | no | non-blank string | Fallback name. `business.name` is the Google listing title first, then `brand`, then `businesses.name`. `business.short` falls back to `brand` when `short` is missing. Removing it for Green Haven changes nothing: the listing has a title and `short` is set. | `Green Haven Industries` | Yes in effect: the listing title "Green Haven Industries" is in the store's `business_info` reading. `businesses.name` and `locations.name` hold "Green Haven". | Not needed while the listing has a title |
| `short` | no | non-blank string | The name used in sentences, tiles, tables and comparisons (`business.short`, `you.short`, the store's entry on every card, the headline lines, checks, gap lines and the plan). Without it: `brand`, else `businesses.name` with words such as " Dispensary" cut. Removing it for Green Haven turns the short name into "Green Haven Industries" in both documents. | `Green Haven` | Yes: `businesses.name` = "Green Haven" (the register name) | `businesses.name`, or a new `businesses.short_name` |
| `brand_terms` | no | list of non-blank strings | The name and its spellings. Matching ignores case, and a space inside a term may be missing. (1) Ranked searches with a term count as brand searches (`search.stored_brand`). (2) Linking sites with weight whose page title has a term "name the store" (`links.quality`). (3) Google results are tied to the store with these terms instead of SEOS's own `brand_regex` (`listings.phone_named_outside`, `street_named_sites`, `phone_other`, `matter`; checks `details-found`, `other-names`, `listings-read`; the phone-named comparison and gap line). Removing it for Green Haven changes the listing counts in both documents. An empty list is accepted today and matches every result (see Findings). | `["green haven", "greenhaven", "green haven industries"]` | No for 48. `analytics_bindings.brand_terms` (JSON) exists but has 0 rows for 48. The citation readings carry SEOS's own `brand_regex`. | A `brand_terms` JSON column on `businesses`, or fill `analytics_bindings.brand_terms` |
| `agency` | no | non-blank string | Our own name in utm tags. A link tagged with it is ours: team-only checks `listing-tag` and `directory-work`, `listings.verdicts.rows[].ours`, and SEOS evidence links that carry it are dropped. The build stops if a client line carries `utm_<x>=<agency>`. Also `meta.agency`: the header brand mark and "Prepared by Dispenza for Green Haven" in the Competitor Analysis. Removing it for Green Haven changes only `meta.agency`, which changes both documents. | `Dispenza` | No. `locations.citation_vendor_tag` exists and is null for 48. Whether it means the same tag is not verified. | `locations.citation_vendor_tag` if it is the same tag, else a `businesses.agency_tag` column |
| `vertical` | no | non-blank string | Used only when `businesses.vertical` is empty. It sets `business.vertical` and `business.vertical_from_settings`. Only "Cannabis" is known to the category check (the listing must have `cannabis_store`). Any other value, or none, makes that check "not measured", and today the plan still gets "Set the right main category" (see Findings). | `Cannabis` | Column exists, value missing: `businesses.vertical` is null for 48 | `businesses.vertical` (fill it) |
| `expected_searches` | no | list of non-blank strings | Map searches the owner expects. Each is compared exactly with the stored sweep keywords, which are lower case. One with no check on file becomes a "not on file" data check, a team task, a hold that keeps the phrase out of the Competitor Analysis, a "Not compared yet" line and `meta.missing_searches`. The build also stops if any client line quotes it. Green Haven has scan 320 on file, so this only fills `meta.expected_searches`. Write it in lower case: "Weed Near Me" stops the build. | `["weed near me"]` | No. `locations.audit_keyword` holds one phrase ("dispensary near me", the audit's own). `locations.organic_keywords` is null. `scan_schedules.keywords` exists, with 0 rows. | `scan_schedules.keywords` for the store (one scheduled sweep per expected phrase) |
| `other_market_sources` | no | regular expression (string) | Directory sources that name another market's places. Matching `citation_verdicts` rows (by `source_id` or `domain`) and `cit_probe` sources leave every directory count and denominator (`listings.verdicts`, `listings.directories_*`). The team gets the `directory-sources` data check and a software task. Green Haven: 10 of 146 verdicts and 10 of 138 probe sources match. Any value is accepted today, and "" or `{}` drops nearly every directory (see Findings). | `michigan\|new-?buffalo\|berrien\|harbor-?country\|us-?12` | No. Sources have no market or state column. `found_sources` (0 rows) has none either. | Fix it at the source: give each citation source a market in SEOS's source registry and build each store's list from its own market. The setting is then not needed. |
| `other_market_label` | with `other_market_sources` | non-blank string | The name the team reads for those sources, in `listings.verdicts.other_market_label`, the `directory-sources` check, its task and the verdicts card note. Team only. | `Michigan` | No | Same place as the sources' market |
| `timezone` | no | string the runtime's `Intl.DateTimeFormat` accepts | The zone of every local date and time in both documents, each map check's opening-hours test, the review month buckets, the daily link chart and `meta.timezone`. Without it the state table in extract-v2.mjs gives the zone from `locations.state`, and a state outside that table stops the build. `sweeps-market.mjs` takes its own `--tz` (default America/New_York), so keep the two the same. | not set (NJ maps to America/New_York) | No column. `locations.state` = "NJ". `scan_schedules.timezone` exists, with 0 rows. | `scan_schedules.timezone`, or a `locations.timezone` column |
| `note` | no | any | Not read. | a one-line note | n/a | n/a |
| `$schema` | no | any | Not read. | not set | n/a | n/a |

## What each key changed for Green Haven

Each key was removed in turn. The model and both documents were rebuilt into a scratch folder and compared with a baseline. The baseline was rebuilt with the same command as RUN.md step 3 without `--facts`. It is byte-identical to `docs/competitor-analysis.html` and `docs/action-plan.html`, and equal to `report-data.json` apart from `meta.built_at` and `meta.facts_check`.

| Key removed | Report keys that changed | Competitor Analysis | Action Plan |
|---|---|---|---|
| `brand` | none | same | same |
| `short` | 18 paths (business.short, you.short, maps, links.quality, checks, tasks, holds, compare) | changed | changed |
| `brand_terms` | 11 paths (listings phone/street counts and site lists, checks, tasks, holds, compare.rows, gaps) | changed | changed |
| `agency` | 1 path (meta.agency) | changed | changed |
| `vertical` | 8 paths (business.vertical, checks, tasks, task_groups, plan, counts.maps) | changed | changed |
| `expected_searches` | 1 path (meta.expected_searches) | same | same |
| `other_market_sources` | 10 paths (listings.directories_*, listings.verdicts, checks, tasks, task_groups) | changed | changed |
| `timezone` (not set for Green Haven) | none | same | same |
| `note` | none | same | same |

## Values that stop the build, as run

Each line shows a value set in a copy of the Green Haven file and the message `extract-v2.mjs` printed.

| Value in the settings file | Result |
|---|---|
| `"business_id": "48"` | `EXTRACT FAILED: the settings file is for business 48, not 48` |
| `"business_id": 26` | `EXTRACT FAILED: the settings file is for business 26, not 48` |
| no `business_id` | `EXTRACT FAILED: the settings file is for business undefined, not 48` |
| an unknown key `"colour"` | `EXTRACT FAILED: the settings file has keys this extractor does not know: colour` |
| `"brand": ""`, `"brand": null`, `"short": "  "` | `EXTRACT FAILED: settings.<key> must be a non-empty string` |
| `"brand_terms": "green haven"` or a list holding `""` | `EXTRACT FAILED: settings.brand_terms must be a list of non-empty strings` |
| `"expected_searches": ["Weed Near Me"]` | `EXTRACT FAILED: the report claims a result for "Weed Near Me", which has no map check on file` |
| `other_market_sources` without `other_market_label` | `EXTRACT FAILED: settings.other_market_sources needs other_market_label, the name the team reads for those sources` |
| `"other_market_sources": "("` | `EXTRACT FAILED: settings.other_market_sources is not a pattern: Invalid regular expression: /(/i: Unterminated group` |
| `"timezone": "Mars/Base"`, `"timezone": null` | `EXTRACT FAILED: settings.timezone is not a time zone: <value>` |
| the file is not JSON | `EXTRACT FAILED: the settings file <name> is not JSON: <parser message>` |
| the file is `[1,2]` or `"text"` | `EXTRACT FAILED: the settings file has keys this extractor does not know: 0, 1, ...` |
| the file is `null` | a crash: `TypeError: Cannot convert undefined or null to object` (exit code 1) |

## Values accepted today that change the report

| Value | Accepted | What happened for Green Haven |
|---|---|---|
| `"brand_terms": []` | yes | Every Google result counts as naming the store. Outside sites showing the phone with the name went from 9 to 22, sites with the street from 9 to 21, and results with the phone but not the name from 23 to 0. |
| `"other_market_sources": ""` | yes | The pattern matches everything. Directory verdicts went from 136 to none, and directories on the list from 128 to 0. |
| `"other_market_sources": {}` | yes | It is compiled as `[object Object]`, a character class that matches nearly every source. Directory verdicts went from 136 to none, and directories on the list from 128 to 6. |
| `"vertical": "Dental"` | yes | The category check went from "pass" to "not measured", and the task "Set the right main category" joined both plans. |
| `"timezone": "america/new_york"` | yes | Only `meta.timezone` changed: it is written as given. |
| `"note": 5` | yes | No change. |

## Findings (also in parts/B-contract.json)

- `extract-v2.mjs:78` accepts an empty `brand_terms` list. Lines 568 and 610 then build a pattern that matches everything. Fix: refuse an empty list in `settingsFrom`.
- `extract-v2.mjs:79-80` never checks the type of `other_market_sources`. Any value is turned into text and compiled, so `""` or `{}` silently drops the directories. Fix: require a string with a non-blank character.
- `extract-v2.mjs:768` compares `expected_searches` with the lower-cased sweep keywords exactly. Fix: trim and lower-case each phrase in `settingsFrom`.
- `extract-v2.mjs:791` adds the `fix-category` task when the vertical is not in `CATEGORY`, while the check itself says "not measured". Fix: no task unless `CATEGORY[business.vertical]` exists.
- `extract-v2.mjs:76` prints "for business 48, not 48" for a quoted id. Fix: print the value's type, or accept a numeric string.
- `extract-v2.mjs:75` crashes with a TypeError when the file is `null`. Fix: refuse anything that is not a plain object first.
- `extract-v2.mjs:84` falls back to the hard-coded `SETTINGS` table and gives an unknown business `{}` with no warning. Fix: make `--settings` required, or stop when the business is in neither.
