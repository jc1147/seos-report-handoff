// extract-outline.mjs: the outline of the two SEOS report documents, read from the documents themselves and annotated
// from build-report.mjs (and mapview.js / extract-v2.mjs where the words come from there).
//
// usage: node extract-outline.mjs <competitor-analysis.html> <action-plan.html> <out outline.json>
//          [--md=<out OUTLINE.md>] [--src=<folder holding build-report.mjs, extract-v2.mjs and mapview.js>] [--raw]
//   --raw  print every block of each document and stop (no annotations, no output files)
//   --src  check every rule's source line: the probe text must be on the cited line, or the run stops
//
// A block is one heading in a document: an h1, h2, h3 or summary element, or an element whose class is card-k, eyebrow,
// grp (a group label) or empty-t (an empty state's title). For each block the document gives its tab, its id (the id of the
// nearest element around it that has one, the tab section aside), its heading text, its chips (kept apart from the
// heading), the view it is marked for (data-only="sales" / "service", else both), whether it is team-only (data-internal)
// and whether it is a comparison block (inside data-cmp: shown only while the Compare switch is on).
// The RULES table below says, for each kind of block, its heading as a template with {slots}, the model keys that feed
// it, when it is shown or left out, where in the code it is written, and what the reader learns from it. Every block must
// match exactly one rule and every rule must match at least one block, or the run stops (fail closed).
// No network, no clock: the same two documents always give the same outline.json and OUTLINE.md.
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const files = argv.filter(a => !a.startsWith('--'));
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
const die = m => { console.error('OUTLINE FAILED: ' + m); process.exit(1); };

const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
const HEAD_TAGS = new Set(['h1', 'h2', 'h3', 'summary']);
const HEAD_CLASSES = ['card-k', 'eyebrow', 'grp', 'empty-t'];
const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", nbsp: ' ' };
const decode = s => s.replace(/&(#x[0-9a-f]+|#[0-9]+|[a-z]+[0-9]*);/gi, (m, k) => k[0] === '#' ? String.fromCodePoint(k[1] === 'x' || k[1] === 'X' ? parseInt(k.slice(2), 16) : parseInt(k.slice(1), 10)) : (ENT[k] ?? m));
const tidy = s => s.replace(/\s+/g, ' ').replace(/\s+([.,;:!?)])/g, '$1').replace(/([(])\s+/g, '$1').trim();
const attrsOf = src => { const o = {}; for (const m of src.matchAll(/([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g)) o[m[1].toLowerCase()] = decode(m[2] ?? m[3] ?? m[4] ?? ''); return o; };

// ---------- the reader: one pass over the markup with a stack of open elements ----------
// Inside a heading, form controls (select, option, button, .tk-side) are not part of its text, and chips (.chip) are kept
// beside it, not in it. Style and script blocks are dropped first.
export function readBlocks(html) {
  const body = html.replace(/<style\b[\s\S]*?<\/style>/gi, '').replace(/<script\b[\s\S]*?<\/script>/gi, '');
  const stack = [], blocks = [];
  let cur = null, tab = 'page';
  const finish = () => {
    blocks.push({ tab: cur.tab, head: cur.head, id: cur.id, own_id: cur.own_id, heading: tidy(decode(cur.text.join(''))), chips: cur.chips,
      view: cur.view, internal: cur.internal, compare_only: cur.compare_only, task: cur.task, parent: cur.parent, ctx: cur.ctx });
    cur = null;
  };
  const say = s => { if (!cur || cur.skip) return; if (cur.chip) cur.chip.text.push(s); else cur.text.push(s); };
  const tok = /<!--[\s\S]*?-->|<![^>]*>|<\/([a-zA-Z][a-zA-Z0-9]*)\s*>|<([a-zA-Z][a-zA-Z0-9]*)((?:[^>"']|"[^"]*"|'[^']*')*)>|([^<]+)/g;
  const desc = x => x.tag + (x.cls.length ? '.' + x.cls.join('.') : '') + (x.a.id ? '#' + x.a.id : '');
  let m;
  while ((m = tok.exec(body))) {
    if (m[4] !== undefined) { say(m[4]); continue; }
    if (m[2]) {
      const tag = m[2].toLowerCase(), raw = m[3] || '', a = attrsOf(raw), cls = (a.class || '').split(/\s+/).filter(Boolean);
      const selfClose = VOID.has(tag) || /\/\s*$/.test(raw);
      if (tag === 'section' && cls.includes('tab') && /^tab-/.test(a.id || '')) tab = a.id.slice(4);
      if (tag === 'footer') tab = 'page';
      if (cur) {
        say(' ');
        if (!selfClose) {
          if (cur.skip) { if (tag === cur.skip.tag) cur.skip.depth++; }
          else if (['select', 'option', 'button'].includes(tag) || cls.includes('tk-side')) cur.skip = { tag, depth: 1 };
          else if (cur.chip) { if (tag === cur.chip.tag) cur.chip.depth++; }
          else if (cls.includes('chip')) cur.chip = { tag, depth: 1, text: [] };
        }
      }
      if (selfClose) continue;
      stack.push({ tag, a, cls });
      const head = HEAD_TAGS.has(tag) ? tag : HEAD_CLASSES.find(c => cls.includes(c));
      if (head && !cur) {
        const near = k => { for (let i = stack.length - 1; i >= 0; i--) if (k(stack[i])) return stack[i]; return null; };
        const idEl = near(x => x.a.id && !(x.tag === 'section' && /^tab-/.test(x.a.id)));
        const only = near(x => x.a['data-only'] !== undefined);
        cur = { depth: stack.length, tab, head, id: idEl ? idEl.a.id : null, own_id: a.id || null,
          view: only ? only.a['data-only'] : 'both', internal: stack.some(x => x.a['data-internal'] !== undefined), compare_only: stack.some(x => x.a['data-cmp'] !== undefined),
          parent: stack.length > 1 ? desc(stack[stack.length - 2]) : '', ctx: stack.slice(0, -1).map(desc).slice(-3).join(' > '),
          task: (near(x => x.tag === 'details' && x.cls.includes('tk')) || { a: {} }).a['data-task'] || null,
          text: [], chips: [], skip: null, chip: null };
      }
      continue;
    }
    if (m[1]) {
      const tag = m[1].toLowerCase();
      let i = stack.length - 1; while (i >= 0 && stack[i].tag !== tag) i--;
      if (i < 0) continue;
      if (cur) {
        if (i < cur.depth - 1) die(`a </${tag}> closes an element around the heading "${tidy(decode(cur.text.join('')))}" before the heading itself`);
        if (i === cur.depth - 1) { stack.length = i; finish(); continue; }
        if (cur.skip) { if (tag === cur.skip.tag && --cur.skip.depth === 0) cur.skip = null; }
        else if (cur.chip) { if (tag === cur.chip.tag && --cur.chip.depth === 0) { cur.chips.push(tidy(decode(cur.chip.text.join(' ')))); cur.chip = null; } }
        say(' ');
      }
      stack.length = i;
    }
  }
  if (cur) die('the document ends inside a heading');
  return blocks;
}

// ---------- the annotations ----------
// m: what the rule matches (every given field must hold). tab: one tab or a list; id / idRe; heading / headingRe; head
//    (h1 h2 h3 summary card-k eyebrow grp empty-t); view (sales service both); parentRe / ctxRe (the element(s) around it);
//    chip0 (the first chip's text); task (the data-task of the card around it, true = any).
// t: the heading as a template, {slot} = a model key (paths into report-data.json; [] = one per item, [i] = the item shown)
// k: the model keys that feed the block (heading and body)
// w: when it is shown or left out (the conditions in the code)
// s: [file, line, probe] where the block is written; --src checks that the probe text is on that line
// l: what the reader learns from it (OUTLINE.md)
// kind: overrides the kind worked out from the element
const TASK_T = '{tasks[].n} {tasks[].title}';
const TASK_K = ['tasks[].n', 'tasks[].title', 'tasks[].owner', 'tasks[].group_label', 'tasks[].status', 'tasks[].internal', 'tasks[].blocked_by', 'tasks[].is_new', 'tasks[].why', 'tasks[].steps', 'tasks[].done_when'];
const TASK_L = 'A task card. Closed: its number, title and chips (owner, group, status; Ours for our own slips; "Blocked by task N"). Open: Why (the checks behind it), Steps, Done when, Blocked by, a status picker, Who, Due and Note fields and a Copy button.';
const cstat = (id, label, line, probe, keys, w, l) => ({ m: { id: 'cmp-' + id, head: 'card-k' }, kind: 'compare-card', t: label,
  k: ['compare.rows[id=' + id + ']', ...keys], w: 'Compare switch on. ' + w, s: ['extract-v2.mjs', line, probe], s2: ['build-report.mjs', 89, 'const cstat'], l });
const RULES = {
  // ---------- Overview ----------
  'overview.sales-eyebrow': { m: { tab: 'overview', head: 'eyebrow', view: 'sales' }, t: '{--doc} · {business.city}, {business.state} · {meta.report_date}', k: ['--doc', 'business.city', 'business.state', 'meta.report_date'],
    w: 'Sales view, always. Without --doc the first part reads "SEO and competition report".', s: ['build-report.mjs', 232, "'SEO and competition report'"], l: 'Which document this is, the town, and the day the data was read.' },
  'overview.sales-headline': { m: { tab: 'overview', head: 'h1', view: 'sales' }, t: '{verdict.a} {verdict.b}', k: ['verdict.a', 'verdict.b', 'verdict.lead', 'meta.report_date', 'map.first', 'map.last'],
    w: 'Sales view, always. verdict.a is the biggest loss on the map (or the best win when nothing is lost), verdict.b the best win (or the second loss, or empty). Under it: verdict.lead, then the source line. The h1 gets the class h1-long when a and b together pass 44 characters.',
    s: ['build-report.mjs', 233, "e(verdict.a || '')"], l: 'The headline: where the store loses most on the map, then where it wins. The lead gives every search in numbers; the source line says when the store and the map were read.', wording: ['verdict.loss-head.nowhere', 'verdict.win-head.by', 'verdict.lead', 'frame.source.market'] },
  'overview.sales-tile-map': { m: { tab: 'overview', head: 'card-k', view: 'sales', headingRe: /^Google Maps · "/ }, kind: 'tile', t: 'Google Maps · "{maps.searches[i].kw}"',
    k: ['maps.searches[i].kw', 'maps.searches[i].you', 'maps.searches[i].n', 'maps.searches[i].place', 'maps.searches[i].you_lead', 'maps.searches[i].leader', 'maps.searches[i].leader_points', 'maps.searches[i].leader_floor', 'maps.searches[i].second', 'maps.searches[i].second_points', 'maps.searches[i].date'],
    w: 'Sales view. One tile for each of the first 3 searches that are not on hold, in the model order (maps.searches runs loss first); the first is the lead tile. A tile opens the map view.', s: ['build-report.mjs', 187, 'Google Maps · "'], l: 'For one search: the store\'s points in Google\'s top 3 out of the points checked, its place, and who is number 1 (number 2 when the store leads), with the date.' },
  'overview.sales-tile-reviews': { m: { tab: 'overview', head: 'card-k', view: 'sales', heading: 'Reviews', parentRe: /tile/ }, kind: 'tile', t: 'Reviews', k: ['business.ratings', 'business.rating', 'reviews.windows.d90.replied', 'reviews.windows.d90.n'],
    w: 'Sales view. The tiles are cut at five, map tiles first.', s: ['build-report.mjs', 189, '<span class="card-k">Reviews</span>'], l: 'Google ratings and stars, and how many of the last 90 days\' reviews have an owner reply.' },
  'overview.sales-tile-website': { m: { tab: 'overview', head: 'card-k', view: 'sales', heading: 'Website', parentRe: /tile/ }, kind: 'tile', t: 'Website', k: ['website.phone.score', 'website.words'],
    w: 'Sales view. The tiles are cut at five; with three map tiles the Links tile after it is left out.', s: ['build-report.mjs', 190, '<span class="card-k">Website</span>'], l: 'The phone speed score of the store page (lab test) and how many words our page reader got from it.' },
  'overview.service-eyebrow': { m: { tab: 'overview', head: 'eyebrow', view: 'service' }, t: '{--doc} · {business.short}, {business.city} · report of {meta.report_date}', k: ['--doc', 'business.short', 'business.city', 'meta.report_date'],
    w: 'Service view, always. Without --doc the first part reads "Service view".', s: ['build-report.mjs', 277, "'Service view'"], l: 'Which document this is, the store, and the report date.' },
  'overview.service-headline': { m: { tab: 'overview', head: 'h1', view: 'service' }, t: '{count of tasks[] with owner us or client} things to do. Start with these.', k: ['tasks[].owner'],
    w: 'Service view, always. The lead under it splits the count: ours, the client\'s, done (0 when built; the page counts as statuses change), and, team only, the software team\'s and the account manager\'s.', s: ['build-report.mjs', 278, 'things to do.'], l: 'How many tasks are open for us and the client, and who owns them.', wording: ['overview.service.headline', 'overview.service.lead'] },
  'overview.do-first-ours': { m: { tab: 'overview', id: 'do-first', head: 'grp', heading: 'Ours today' }, kind: 'group', t: 'Ours today', k: ['tasks[owner=us]'],
    w: 'Service view, always.', s: ['build-report.mjs', 280, 'Ours today'], l: 'The first three tasks we own, in task order; the first card is open.' },
  'overview.do-first-ours-task': { m: { tab: 'overview', id: 'do-first', head: 'summary', chip0: 'Us' }, kind: 'task-card', t: TASK_T, k: TASK_K,
    w: 'Service view: the first 3 tasks with owner us, in task order. A task marked internal or service_only is a team-only card.', s: ['build-report.mjs', 280, 'firstOurs.map'], s2: ['build-report.mjs', 170, 'const taskCard'], l: TASK_L },
  'overview.do-first-client': { m: { tab: 'overview', id: 'do-first', head: 'grp', heading: 'Ask the client' }, kind: 'group', t: 'Ask the client', k: ['tasks[owner=client]'],
    w: 'Service view, always. With no client task the list reads "Nothing for the client in this report."', s: ['build-report.mjs', 281, 'Ask the client'], l: 'Every task the client owns, with a line on how to copy a task and a button to all tasks.' },
  'overview.do-first-client-task': { m: { tab: 'overview', id: 'do-first', head: 'summary', chip0: 'The client' }, kind: 'task-card', t: TASK_T, k: TASK_K,
    w: 'Service view: every task with owner client.', s: ['build-report.mjs', 281, 'clientTasks.map'], s2: ['build-report.mjs', 170, 'const taskCard'], l: TASK_L },
  'overview.map-view': { m: { id: 'map-view', head: 'h2' }, t: 'The map, point by point', k: ['market', 'map.reports', 'map.searches', 'map.first', 'map.outside_hours', 'maps.searches'],
    w: 'Both views, when the model carries a market file (market and map). The map first drawn is the biggest loss\'s search (loss first), else the main search; the page redraws it on every pick.', s: ['build-report.mjs', 114, 'The map, point by point'],
    l: 'Each map check as a grid of points around the store, numbered with the place Google gave the store at each point. Any search, any date, any business beside the store; the sentence over the grids sets the store against the business beside it.' },
  'overview.map-you': { m: { id: 'mv-you', head: 'card-k' }, kind: 'map-card', t: 'You', k: ['market.scans[].field', 'market.biz', 'business.short'],
    w: 'Always, inside the map view.', s: ['mapview.js', 76, "mine ? 'You'"], l: 'The store\'s grid for the picked search and date, its points in the top 3, its place among the businesses, how many points list it, and its stars and ratings.' },
  'overview.map-them': { m: { id: 'mv-them', head: 'card-k' }, kind: 'map-card', t: 'Number {place} | Tied for number {place} | Not in the top 3 at any point | Not in this check', k: ['market.scans[].field', 'market.biz'],
    w: 'Compare switch on. The business beside the store is number 1, or number 2 when the store is number 1, until the reader picks another.', s: ['mapview.js', 78, "'Tied for number '"], l: 'The grid of the business set beside the store, for the same search and date.' },
  'overview.map-board': { m: { id: 'mv-board', head: 'card-k' }, kind: 'map-card', t: 'The top of the map', k: ['market.scans[].field', 'market.biz'],
    w: 'Compare switch on. Lists the top 10, the store and the business beside it; "Show all N" lists the rest. Another area\'s businesses (the market file\'s far flag) are left out.', s: ['mapview.js', 83, 'The top of the map'], l: 'Every business in the check by its points in Google\'s top 3; picking one sets it beside the store.' },
  'overview.map-trend': { m: { id: 'mv-trend', head: 'card-k' }, kind: 'map-card', t: 'Share of the points in Google\'s top 3, check by check', k: ['market.scans[]'],
    w: 'Always, inside the map view. With one check of the search on file it says there is no line to draw yet.', s: ['build-report.mjs', 127, 'check by check'], l: 'How the store\'s share of the points moved across every check of the search, beside number 1 at each check.' },
  'overview.map-all': { m: { id: 'mv-all', head: 'card-k' }, kind: 'card', t: 'Every search we have checked on the map', k: ['market.scans[]'],
    w: 'Always, inside the map view. The number 1 columns are comparison columns (Compare switch on).', s: ['build-report.mjs', 129, 'Every search we have checked on the map'], l: 'Every search on file at its latest check: the store\'s points and place, number 1 and its points, and how many checks.' },
  'overview.gaps': { m: { id: 'gaps', head: 'h2' }, t: 'The gap to number 1', k: ['gaps[]'],
    w: 'Compare switch on, when gaps is not empty. Lines run where the store is behind first (biggest deficit first, whole-website lines after the others), level or ahead last. A line on hold is team only.', s: ['build-report.mjs', 142, 'The gap to number 1'],
    l: 'Each number set beside the best there is, named: map points per search, ratings, stars, photos, ways to shop, details, review velocity, replies, speed, links. Each line says how far behind or ahead.' },
  'overview.right-wrong': { m: { id: 'right-wrong', head: 'h2' }, t: 'Everything right, everything wrong', k: ['checks[]'],
    w: 'Always. The Sales board lists the checks of the five tabs that are not about the data, not ours and not AI; the Service board every check outside the Overview. Columns run Wrong, To look at, Right (loss first); "Not measured yet:" lists the rest.', s: ['build-report.mjs', 151, 'Everything right, everything wrong'],
    l: 'Every check on one screen, as Wrong, To look at and Right with a count each; a line opens the check on its tab.' },
  'overview.missing': { m: { tab: 'overview', head: 'h2', heading: 'What is missing' }, t: 'What is missing', k: ['plan[]'], w: 'Sales view, always.', s: ['build-report.mjs', 237, 'What is missing'],
    l: 'The plan\'s pieces of work in the buckets the work is sold in, with a button to the plan.' },
  'overview.missing-bucket': { m: { tab: 'overview', head: 'card-k', view: 'sales', parentRe: /^div\.card$/, headingRe: /^(The map|Reviews|The store page|Speed|Pages and content|Listings and links|Google Analytics and Search Console|The Google listing)$/ }, kind: 'card',
    t: '{The map | Reviews | The store page | Speed | Pages and content | Listings and links | Google Analytics and Search Console | The Google listing}', k: ['plan[].id', 'plan[].title'],
    w: 'Sales view. One card per bucket of BOARD (build-report.mjs) that holds at least one plan item, in BOARD order; plan items in no bucket go to a last card, The Google listing.', s: ['build-report.mjs', 202, "['The map', ['rescan-open-hours', 'map-gap']]"], l: 'How many pieces of work fall in the bucket, and their titles.' },
  'overview.known': { m: { tab: 'overview', head: 'h2', heading: 'What we already know about the store' }, t: 'What we already know about the store', k: ['meta.report_date'], w: 'Sales view, always.', s: ['build-report.mjs', 238, 'What we already know about the store'],
    l: 'What Google shows on the store\'s listing and what customers mention, read on the report date.' },
  'overview.known-listing': { m: { tab: 'overview', head: 'card-k', heading: 'On Google' }, kind: 'card', t: 'On Google',
    k: ['business.name', 'business.street', 'business.city', 'business.state', 'business.zip', 'business.phone', 'business.hours.summary', 'business.category', 'business.rating', 'business.ratings', 'business.photos', 'business.service_options', 'business.listing_link'],
    w: 'Sales view, always. A row with no value is left out.', s: ['build-report.mjs', 223, 'On Google'], l: 'The listing\'s name, address, phone, hours, category, rating, photos, ways to shop and link.' },
  'overview.known-topics': { m: { tab: 'overview', head: 'card-k', heading: 'What customers mention in reviews' }, kind: 'card', t: 'What customers mention in reviews', k: ['business.topics[0..9]'],
    w: 'Sales view, always.', s: ['build-report.mjs', 224, 'What customers mention in reviews'], l: 'The words Google pulls out of the reviews (the first 10), with how often each comes up.' },
  'overview.holds': { m: { id: 'holds', head: 'h2' }, t: 'Not safe to quote yet', k: ['holds[].number', 'holds[].where', 'holds[].why', 'holds[].clears'],
    w: 'Service view, team only, when holds is not empty. A hold about our other accounts is left out of the Action Plan.', s: ['build-report.mjs', 260, 'Not safe to quote yet'],
    l: 'Every number the team holds back: what it is, where it would show, why it is on hold and who clears it. The client copy is built never to print any of them.' },
  'overview.since': { m: { id: 'since', head: 'card-k' }, kind: 'card', t: 'Since the last report', k: ['changes.first_run'],
    w: 'Service view. On a first run (changes.first_run) one card says every task is new. From the second run (extract-v2 --prev) it is a section with New problems, Fixed, Still open and the headline numbers that moved.', s: ['build-report.mjs', 254, 'Since the last report'],
    l: 'That this is the first report for the store, so every task is new.' },
  'overview.health': { m: { tab: 'overview', head: 'h2', heading: 'Health by area' }, t: 'Health by area', k: ['counts'], w: 'Service view, always.', s: ['build-report.mjs', 286, 'Health by area'],
    l: 'One tile per area with a headline number and a bar of its checks; a tile opens the tab.' },
  'overview.health-tile': { m: { tab: 'overview', head: 'card-k', view: 'service', parentRe: /tile/ }, kind: 'tile', t: 'Google Maps | Google search | AI answers | Website | Links and listings',
    k: ['counts.maps', 'counts.search', 'counts.ai', 'counts.website', 'counts.links', 'maps.searches[0]', 'search.keywords_total', 'website.phone.score', 'links.not_sellers', 'links.sites'],
    w: 'Service view, always: five tiles. Google Maps shows the first search not on hold ("No check" when there is none); AI answers reads "No data".', s: ['build-report.mjs', 262, 'map points in the top 3'],
    l: 'For each area one number (map points, searches, AI, phone speed, linking sites that are not sellers) and how many of its checks are good.' },
  // ---------- Google Maps ----------
  'maps.eyebrow': { m: { tab: 'maps', head: 'eyebrow' }, t: 'Google Maps · {business.city}, {business.state}', k: ['business.city', 'business.state'], w: 'Both views, always (v2).', s: ['build-report.mjs', 390, 'Google Maps · ${place}'], l: 'The tab and the town.' },
  'maps.headline': { m: { tab: 'maps', head: 'h2' }, kind: 'headline', t: '{verdict.a} {verdict.b}', k: ['verdict.a', 'verdict.b', 'maps.searches[]'],
    w: 'Both views, always (v2). The lead under it has one sentence per search not on hold, then "Checked {dates}."', s: ['build-report.mjs', 390, 'const v2MapsHead'], l: 'The same headline as the Overview; the lead gives each search\'s place and points and who is number 1, and the dates checked.', wording: ['maps.lead.none', 'maps.lead.loss', 'maps.lead.win', 'maps.lead.checked'] },
  'maps.compare': { m: { id: 'cmp-maps', head: 'h3' }, t: 'You and the competition', k: ['compare.rows[door=maps]', 'compare.listings', 'compare.velocity', 'maps.sweeps'],
    w: 'Compare switch on. The line under it differs: Sales names the top of the map and the three stores this report follows; Service names the two sets.', s: ['build-report.mjs', 103, 'You and the competition'], s2: ['build-report.mjs', 388, "cmpPanel('cmp-maps'"],
    l: 'The store beside the competition on the map: points per search, the top listings, ratings, stars, photos, review velocity and replies.' },
  'maps.cmp-map': { m: { idRe: /^cmp-map-/, head: 'card-k' }, kind: 'compare-card', t: 'Points in Google\'s top 3 for "{maps.sweeps[].kw}"', k: ['compare.rows[id=map-{scan id}]'],
    w: 'Compare switch on. One card per map check with points (each sweep in the record, and each market-file search the record lacks). For a client unless the check is on hold. The three cards run where the store is furthest behind first, a lead last.',
    s: ['extract-v2.mjs', 1076, 'Points in Google\'s top 3 for'], s2: ['build-report.mjs', 389, "/^map-/.test(r.id)"], l: 'The store\'s points beside the five businesses with the most, with a line on who leads and the store\'s place, and how the check was run.' },
  'maps.listings': { m: { id: 'cmp-listings', head: 'card-k' }, kind: 'card', t: 'The Google listings at the top of the map', k: ['compare.listings[]', 'compare.listings_kw', 'compare.listings_n', 'business.profile_read_at', 'business.category'],
    w: 'Compare switch on, when compare.listings is not empty. The first 12 rows by top-3 points.', s: ['build-report.mjs', 379, 'The Google listings at the top of the map'],
    l: 'The listings at the top of the map side by side: top-3 points, stars, ratings, photos, ways to shop, details, where the website button leads, claimed, miles away.' },
  'maps.listings-more': { m: { id: 'cmp-listings', head: 'summary' }, kind: 'expandable', t: 'The other {compare.listings.length - 12} businesses in the check with a Google listing read', k: ['compare.listings[12..]'],
    w: 'When compare.listings has more than 12 rows.', s: ['build-report.mjs', 379, 'businesses in the check with a Google listing read'], l: 'The rest of the listings, the same columns.' },
  'maps.cmp-ratings': cstat('ratings', 'Google ratings', 1082, "'Google ratings'", ['business.ratings'], 'Sales row. The cards of this group run where the store is furthest behind first.', 'The store\'s Google ratings beside the top of the map\'s (up to six businesses).'),
  'maps.cmp-photos': cstat('photos', 'Photos on the Google listing', 1084, "'Photos on the Google listing'", ['business.photos'], 'Sales row.', 'Photos on each listing at the top of the map.'),
  'maps.cmp-stars': cstat('stars', 'Star rating', 1083, "'Star rating'", ['business.rating'], 'Sales row.', 'Star ratings at the top of the map.'),
  'maps.cmp-velocity': cstat('velocity', 'Review velocity: new reviews a month', 1086, "'Review velocity: new reviews a month'", ['compare.velocity_agrees'], 'For a client only when the store\'s own windows agree with the software\'s snapshots (compare.velocity_agrees); otherwise team only and on hold.', 'New Google reviews a month over the last 90 days, the store beside the three rivals.'),
  'maps.cmp-replies': cstat('replies-90', 'Reviews from the last 90 days with an owner reply', 1089, "'Reviews from the last 90 days with an owner reply'", ['reviews.windows.d90'], 'Sales row, when the store\'s 90-day window is read.', 'The share of the last 90 days\' reviews with an owner reply, the store beside the rivals.'),
  'maps.pace': { m: { id: 'pace-all', head: 'summary' }, kind: 'expandable', t: 'Review velocity of the store and the {compare.velocity.length - 1} rivals, window by window', k: ['compare.velocity[]', 'compare.velocity_window.to', 'compare.velocity_agrees', 'compare.listings_kw'],
    w: 'Compare switch on, when compare.velocity has two rows or more.', s: ['build-report.mjs', 384, 'window by window'], l: 'New reviews a month over the last 30, 90 and 365 days for each store, the last 90 days answered, and map points.' },
  'maps.scans': { m: { id: 'scans', head: 'card-k' }, kind: 'card', t: 'The map checks the software ran for this store', k: ['maps.sweeps[]'],
    w: 'Service view, team only, Compare switch on, when maps.sweeps is not empty.', s: ['build-report.mjs', 387, 'The map checks the software ran for this store'],
    l: 'Each sweep: search, when it finished (Closed when outside hours), the store\'s hours that day, points (and points left out), how it was started, and far-away businesses in its lists.' },
  'maps.cmp-reviews-pulled': cstat('reviews-pulled', 'Reviews our pull collected', 1092, "'Reviews our pull collected'", ['reviews.collected'], 'Team only (sales: false). Marked On hold when a rival\'s pull stopped at its limit.', 'How many reviews our pull collected per store; a store at the pull\'s limit shows the reason instead of a count.'),
  'maps.reviews': { m: { id: 'reviews', head: 'card-k' }, kind: 'card', t: 'Reviews', k: ['business.ratings', 'business.rating', 'reviews.monthly[]', 'reviews.opening_n', 'reviews.first', 'reviews.last_90', 'reviews.pace_90'],
    w: 'Both views, always.', s: ['build-report.mjs', 399, 'id="reviews"'], l: 'Ratings and stars, a column per month of reviews received, and how many came in the first 10 weeks and in the last 90 days (a month is 30.4 days).' },
  'maps.split': { m: { tab: 'maps', head: 'card-k', heading: 'How the ratings split' }, kind: 'card', t: 'How the ratings split', k: ['business.rating_dist'], w: 'Both views, always (empty when the listing has no spread).', s: ['build-report.mjs', 400, 'How the ratings split'], l: 'How many ratings have 5, 4, 3, 2 and 1 stars.' },
  'maps.listing': { m: { tab: 'maps', head: 'card-k', heading: 'The Google listing' }, kind: 'card', t: 'The Google listing', k: ['business.*', 'business.listing_full_link'],
    w: 'Both views, always. The row "Full link, with its tags" is Service only.', s: ['build-report.mjs', 403, 'The Google listing'], l: 'The listing\'s details, each with an id the find box points at.' },
  'maps.topics': { m: { id: 'topics', head: 'card-k' }, kind: 'card', t: 'What customers mention in reviews', k: ['business.topics[0..9]'], w: 'Both views, always.', s: ['build-report.mjs', 404, 'id="topics"'], l: 'The words Google pulls out of the reviews, with counts.' },
  'maps.why': { m: { id: 'why-low', head: 'card-k' }, kind: 'card', t: 'Why the map looks the way it does: what is in place, what the software\'s own fit for this market says', k: ['checks[door=maps,weight=rank,status=pass]', 'maps.searches[]', 'maps.factors[]', 'maps.model.notes'],
    w: 'Service view, team only, always (v2).', s: ['build-report.mjs', 323, "Why the map looks the way it does"], l: 'What is in place on the listing, each search in one sentence, and what the software\'s own fit says, factor by factor.' },
  // ---------- the parts every door tab shares ----------
  'door.health': { m: { tab: ['maps', 'search', 'website', 'links'], head: 'h3', heading: 'Health checks' }, t: 'Health checks', k: ['checks[door={tab}, weight not data]'],
    w: 'Both views, always. Sales lists the tab\'s checks that are neither ours nor about the data; Service lists every check of the tab that is not about the data (those sit under "Checks on the data itself"), with Ours and On hold chips. Loss first: fail, watch, not measured, pass.', s: ['build-report.mjs', 162, 'Health checks'],
    l: 'Each thing we looked at on this tab and what we found: title, value and a line of detail (a client reads the check\'s sales wording where it has one).' },
  'door.plan': { m: { tab: ['maps', 'search', 'website', 'links'], head: 'h3', heading: 'What we would do here' }, t: 'What we would do here', k: ['plan[] whose task door is the tab'],
    w: 'Sales view, when the tab has plan items (a plan item belongs to the tab of its task).', s: ['build-report.mjs', 176, 'What we would do here'], l: 'The plan items for this tab, numbered as in the plan, with what each one brings.' },
  'door.tasks': { m: { tab: ['maps', 'search', 'website', 'links'], head: 'h3', heading: 'Tasks here' }, t: 'Tasks here', k: ['tasks[owner us or client, door={tab}]'],
    w: 'Service view, when the tab has tasks owned by us or the client.', s: ['build-report.mjs', 177, 'Tasks here'], l: 'The tab\'s task cards.' },
  'door.task': { m: { tab: ['maps', 'search', 'website', 'links'], head: 'summary', task: true, ctxRe: /div\.sec > div\.tasks > details\.tk$/ }, kind: 'task-card', t: TASK_T, k: TASK_K,
    w: 'Service view: every task owned by us or the client whose door is this tab, in task order.', s: ['build-report.mjs', 177, 'mine.map(t => taskCard(t))'], s2: ['build-report.mjs', 170, 'const taskCard'], l: TASK_L },
  'door.data': { m: { tab: ['maps', 'search', 'website', 'links'], head: 'summary', headingRe: /^Checks on the data itself \(\d+\)$/ }, kind: 'expandable', t: 'Checks on the data itself ({count of checks[door={tab}, weight=data]})', k: ['checks[door={tab}, weight=data]'],
    w: 'Service view, team only, when the tab has checks about the data (weight data). Open by default.', s: ['build-report.mjs', 178, 'Checks on the data itself'], l: 'Problems with this run, not with the store: the checks, then the software team\'s and account manager\'s tasks for this tab.' },
  'door.data-task': { m: { head: 'summary', task: true, ctxRe: /div\.more-b > div\.tasks > details\.tk$/ }, kind: 'task-card', t: TASK_T, k: TASK_K,
    w: 'Service view, team only: tasks owned by the software team or the account manager whose door is this tab.', s: ['build-report.mjs', 178, 'sw.map(t => taskCard(t))'], s2: ['build-report.mjs', 170, 'const taskCard'], l: TASK_L },
  'door.missing': { m: { idRe: /^cmp-missing-/, head: 'card-k', heading: 'Not compared yet' }, kind: 'card', t: 'Not compared yet', k: ['compare.missing.{tab}[]'],
    w: 'Service view, team only, Compare switch on, when compare.missing has rows for the tab.', s: ['build-report.mjs', 102, 'Not compared yet'], l: 'What the run read about the rivals and the record does not hand back: what, where it stands, and the task that gets it.' },
  // ---------- Google search ----------
  'search.eyebrow': { m: { tab: 'search', head: 'eyebrow' }, t: 'Google search · {business.domain}', k: ['business.domain'], w: 'Both views, always (v2).', s: ['build-report.mjs', 428, 'Google search · ${B.domain}'], l: 'The tab and the website.' },
  'search.headline': { m: { tab: 'search', head: 'h2' }, kind: 'headline', t: '{search.keywords_total} searches for the whole website. {The fewest of the {of} websites. | {Ord place} of {of} websites. | An outside estimate.}', k: ['search.keywords_total', 'compare.rows[id=searches].place', 'compare.rows[id=searches].of'],
    w: 'Both views, always (v2). The second part reads "An outside estimate." when the searches row has no place (a rival not counted).', s: ['build-report.mjs', 428, 'searches for the whole website.'], l: 'How many searches the whole website shows up for, and where that puts it among the websites compared.', wording: ['search.headline', 'search.headline.place'] },
  'search.compare': { m: { id: 'cmp-search', head: 'h3' }, t: 'You and the competition', k: ['compare.rows[door=search]', 'compare.search_sites'], w: 'Compare switch on.', s: ['build-report.mjs', 422, "cmpPanel('cmp-search'"], l: 'The websites of the stores this report follows, and the websites met most in the same searches.' },
  'search.cmp-searches': cstat('searches', 'Searches the website shows up for', 1098, "'Searches the website shows up for'", ['search.keywords_total'], 'Sales row. A rival whose website covers many stores shows the reason, not a bar.', 'How many searches each whole website shows up for (an outside estimate).'),
  'search.cmp-visits': cstat('visits', 'Estimated visits a month from search', 1099, "'Estimated visits a month from search'", ['search.visits'], 'Sales row.', 'Estimated visits a month from search for each whole website (not real clicks).'),
  'search.sites': { m: { id: 'cmp-search-sites', head: 'card-k' }, kind: 'card', t: 'The websites you meet most in Google\'s results', k: ['compare.search_sites[]', 'search.keywords_total'],
    w: 'Compare switch on, when compare.search_sites is not empty.', s: ['build-report.mjs', 421, "The websites you meet most in Google's results"], l: 'The websites that share the most searches with this one, their searches and estimated visits.' },
  'search.positions': { m: { id: 'positions', head: 'card-k' }, kind: 'card', t: 'Where the website\'s {search.keywords_total} searches rank', k: ['search.buckets[]', 'search.keywords_total', 'search.top10'],
    w: 'Both views, always (v2).', s: ['build-report.mjs', 431, "Where the website's"], l: 'The searches by position band (top 3, 4 to 10, 11 to 20, 21 to 50, 51 to 100), how many are on page 1.' },
  'search.unread': { m: { id: 'search-unread', head: 'card-k' }, kind: 'card', t: 'Which searches they are', k: [], w: 'Both views, always (v2): this run did not read which searches.', s: ['build-report.mjs', 432, 'Which searches they are'], l: 'That the report counts searches but does not yet say which ones; that read comes next.' },
  // ---------- AI answers (Action Plan only) ----------
  'ai.eyebrow': { m: { tab: 'ai', head: 'eyebrow' }, t: 'AI answers', k: [], w: 'Service view only; the tab is not in the client copy.', s: ['build-report.mjs', 452, "head('AI answers'"], l: 'The tab.' },
  'ai.headline': { m: { tab: 'ai', head: 'h2' }, kind: 'headline', t: 'Who do the AI assistants recommend? Not collected yet.', k: ['ai.collected'], w: 'Service view only.', s: ['build-report.mjs', 452, 'Who do the AI assistants recommend?'], l: 'That AI answers are planned and nothing was collected for this report.' },
  'ai.compare': { m: { id: 'cmp-ai', head: 'h3' }, t: 'You and the competition', k: ['compare.missing.ai'], w: 'Service view, Compare switch on.', s: ['build-report.mjs', 453, "cmpPanel('cmp-ai'"], l: 'Nothing to set side by side until the answers are collected.' },
  'ai.empty': { m: { tab: 'ai', head: 'empty-t' }, kind: 'empty-state', t: 'No AI answers in this report', k: [], w: 'Service view, always.', s: ['build-report.mjs', 454, 'No AI answers in this report'], l: 'That the tab stays out of the client view until there is data.' },
  'ai.health': { m: { tab: 'ai', head: 'h3', heading: 'Health checks' }, t: 'Health checks', k: ['checks[door=ai]'], w: 'Service view, always.', s: ['build-report.mjs', 455, 'Health checks'], l: 'The one AI check (Named in AI answers: Not collected).' },
  'ai.tasks': { m: { tab: 'ai', head: 'h3', heading: 'Tasks here' }, t: 'Tasks here', k: ['tasks[id=collect-ai]'], w: 'Service view, team only, when the task collect-ai exists.', s: ['build-report.mjs', 456, 'Tasks here'], l: 'The software team\'s task to collect AI answers.' },
  'ai.task': { m: { tab: 'ai', head: 'summary', task: 'collect-ai' }, kind: 'task-card', t: TASK_T, k: TASK_K, w: 'Service view, team only.', s: ['build-report.mjs', 456, 'taskCard(aiTask)'], s2: ['build-report.mjs', 170, 'const taskCard'], l: TASK_L },
  // ---------- Website ----------
  'website.eyebrow': { m: { tab: 'website', head: 'eyebrow' }, t: 'Website · {business.domain}', k: ['business.domain'], w: 'Both views, always (v2).', s: ['build-report.mjs', 475, 'Website · ${B.domain}'], l: 'The tab and the website.' },
  'website.headline': { m: { tab: 'website', head: 'h2' }, kind: 'headline', t: '{website.phone.score} of 100 on a phone. {The fastest of the store pages on a phone. | {Ord place} of {of} store pages on a phone. | (nothing)}', k: ['website.phone.score', 'compare.rows[id=speed-phone].place', 'compare.rows[id=speed-phone].of', 'compare.speed_order_holds'],
    w: 'Both views, always (v2). The second part is left out when the two speed readings give a different order (compare.speed_order_holds false).', s: ['build-report.mjs', 475, 'of 100 on a phone.'], l: 'The store page\'s phone speed score and where it ranks among the store pages compared.', wording: ['website.headline', 'website.headline.fastest'] },
  'website.compare': { m: { id: 'cmp-website', head: 'h3' }, t: 'You and the competition', k: ['compare.rows[door=website]', 'compare.website[]'], w: 'Compare switch on.', s: ['build-report.mjs', 470, "cmpPanel('cmp-website'"], l: 'The store page beside each rival\'s, read the same way on the same day.' },
  'website.cmp-speed-phone': cstat('speed-phone', 'Phone speed, lab test', 1111, "'Phone speed, lab test'", ['website.phone.score'], 'Sales row; the team note (which reading is used) is Service only.', 'Each store page\'s phone speed score; good is 90 or more.'),
  'website.cmp-speed-desktop': cstat('speed-desktop', 'Desktop speed, lab test', 1112, "'Desktop speed, lab test'", ['website.desktop.score'], 'Sales row.', 'Each store page\'s desktop speed score.'),
  'website.cmp-onpage': cstat('onpage', 'On-page score of the store page', 1116, "'On-page score of the store page'", ['website.onpage'], 'Sales row. A rival whose two reads disagree shows "Not confirmed" with both numbers.', 'The vendor\'s score for each page\'s build.'),
  'website.cmp-page-words': cstat('page-words', 'Words a crawler gets from the store page', 1113, "'Words a crawler gets from the store page'", ['website.crawler_words'], 'Sales row.', 'How many words a plain crawler gets from each store page.'),
  'website.cmp-crawler-share': cstat('crawler-share', 'The browser\'s words a crawler also gets', 1115, "\"The browser's words a crawler also gets\"", ['website.crawler_words', 'website.browser_words'], 'Sales row.', 'The share of a browser\'s words a crawler also gets, per store page.'),
  'website.pages': { m: { id: 'cmp-pages', head: 'card-k' }, kind: 'card', t: 'The store pages side by side', k: ['compare.website[]', 'website.read_at'], w: 'Compare switch on, when compare.website has two rows or more.', s: ['build-report.mjs', 469, 'The store pages side by side'],
    l: 'Each store\'s page: the page its listing links to, phone speed, when main content shows, words a crawler gets, on-page score.' },
  'website.cmp-crawl-score': cstat('crawl-score', 'On-page score, whole website', 1118, "'On-page score, whole website'", ['website.crawl'], 'Team only (sales: false), On hold while every crawl stopped at its page limit.', 'The whole-site crawl score per website, with the reason it is held.'),
  'website.reader': { m: { id: 'reader', head: 'card-k' }, kind: 'card', t: 'What our page reader got from the store page', k: ['website.title', 'website.main_heading', 'website.crawler_words', 'website.browser_words', 'website.age_gate', 'website.thin_to_crawler', 'checks[id=store-details].value'],
    w: 'Both views, always (v2).', s: ['build-report.mjs', 478, 'What our page reader got from the store page'], l: 'The page title, main heading, words as a crawler and in a browser, the age check, and whether store details were found.' },
  'website.speed': { m: { id: 'speed', head: 'card-k', heading: 'Speed, by Google\'s lab test' }, kind: 'card', t: 'Speed, by Google\'s lab test', k: ['website.phone', 'website.desktop'], w: 'Both views, always.', s: ['build-report.mjs', 479, "Speed, by Google's lab test"], l: 'Two dials, phone and desktop, out of 100.' },
  'website.speed-fixes': { m: { id: 'speed', head: 'card-k', heading: 'Where time can be saved on a phone' }, kind: 'card-label', t: 'Where time can be saved on a phone', k: ['website.phone.fixes[]'], w: 'When website.phone.fixes is not empty.', s: ['build-report.mjs', 479, 'Where time can be saved on a phone'], l: 'Each fix in plain words with about how many seconds it saves.' },
  'website.speed-detail': { m: { id: 'speed-detail', head: 'summary' }, kind: 'expandable', t: 'Speed test, measure by measure', k: ['website.phone.metrics', 'website.desktop.metrics'], w: 'Both views, always.', s: ['build-report.mjs', 483, 'Speed test, measure by measure'], l: 'Each speed measure on a phone and on a desktop, with a Good / Needs a look / Needs fixing chip.' },
  'website.speed-detail-device': { m: { id: 'speed-detail', head: 'card-k' }, kind: 'card-label', t: 'On a phone | On a desktop', k: ['website.phone.metrics', 'website.desktop.metrics'], w: 'Both views, always.', s: ['build-report.mjs', 483, 'On a phone'], l: 'The device the measures below are for.' },
  // ---------- Links and listings ----------
  'links.eyebrow': { m: { tab: 'links', head: 'eyebrow' }, t: 'Links and listings · {business.domain}', k: ['business.domain'], w: 'One heading block for each view (the Sales head and the Service head), each with this eyebrow.', s: ['build-report.mjs', 513, 'Links and listings · ${B.domain}'], l: 'The tab and the website.' },
  'links.sales-headline': { m: { tab: 'links', head: 'h2', view: 'sales' }, kind: 'headline', t: '{links.not_sellers} linking sites are not link sellers. {links.gap_worth.length} {site | sites} with some weight link to two or more rivals\' websites and not to yours.', k: ['links.not_sellers', 'links.gap_worth', 'links.fresh_days', 'links.fresh_sellers', 'compare.links[]'],
    w: 'Sales view, always (v2).', s: ['build-report.mjs', 513, 'linking sites are not link sellers.'], l: 'How many linking sites are left once the link sellers are out, and how many sites with weight link to the rivals and not here; the lead names the wave of link-selling pages as something to watch.' },
  'links.service-headline': { m: { tab: 'links', head: 'h2', view: 'service' }, kind: 'headline', t: '{links.sellers} of {links.sites} linking sites are link sellers or scheme pages. {links.clean_with_weight} of the rest carry weight.', k: ['links.sellers', 'links.sites', 'links.clean_with_weight', 'links.not_sellers', 'links.gap_worth'],
    w: 'Service view, always (v2).', s: ['build-report.mjs', 514, 'linking sites are link sellers or scheme pages.'], l: 'How much of the linking-site total is junk, and what to work from instead.' },
  'links.compare': { m: { id: 'cmp-links', head: 'h3' }, t: 'You and the competition', k: ['compare.rows[door=links]', 'compare.links[]', 'links.gap_worth'], w: 'Compare switch on.', s: ['build-report.mjs', 524, "cmpPanel('cmp-links'"], l: 'The websites of the stores this report follows, link sellers taken out the same way for each, and where Google shows each store\'s details.' },
  'links.cmp-strength': cstat('strength', 'Link strength score', 1123, "'Link strength score'", [], 'Sales row, when the store\'s rank is read. A many-store rival shows the reason, not a bar.', 'An outside score (to 1,000) for the weight of each whole website\'s links.'),
  'links.cmp-clean-sites': cstat('clean-sites', 'Linking sites that are not link sellers', 1126, "'Linking sites that are not link sellers'", ['links.not_sellers'], 'Sales row. A rival whose links were not all read shows "Not counted".', 'Linking sites minus the link-selling and scheme pages, for each website.'),
  'links.cmp-clean-weight': cstat('clean-weight', 'Of those, sites that carry some weight', 1129, "'Of those, sites that carry some weight'", ['links.clean_with_weight'], 'Sales row.', 'Of those, the ones the vendor scores above zero.'),
  'links.worth': { m: { id: 'worth', head: 'card-k' }, kind: 'card', t: 'Sites with some weight that link to two or more rivals\' websites and not to yours', k: ['links.gap_worth[]', 'links.gap_left', 'links.gap_floor'],
    w: 'Compare switch on, always (v2). The Score column and the line on the raw list are Service only.', s: ['build-report.mjs', 515, "Sites with some weight that link to two or more rivals' websites and not to yours"], l: 'Each site, the rivals it links to, and (team) its score; a "Cannabis directory" chip marks a site whose name matches the cannabis pattern.' },
  'links.cmp-dirs-showed': cstat('dirs-showed', 'Directories that answered with the store on them', 1141, "'Directories that answered with the store on them'", ['listings.directories_showed'], 'Sales row.', 'Directories searched the same day for every store that came back showing its phone or address.'),
  'links.table': { m: { id: 'cmp-link-table', head: 'card-k' }, kind: 'card', t: 'Linking sites, website by website, classified the same way', k: ['compare.links[]', 'links.fresh_days'], w: 'Service view, team only, Compare switch on, when compare.links has two rows or more.', s: ['build-report.mjs', 523, 'Linking sites, website by website, classified the same way'],
    l: 'For each website: linking sites, sellers and scheme pages, not sellers, of those with weight, new in 30 days, sellers among the new, links read; and the shared-title waves.' },
  'links.cmp-phone-named': cstat('phone-named', 'Outside sites where Google shows the phone with the name', 1138, '"Outside sites where Google shows the phone with the name"', ['listings.phone_named_outside', 'listings.rivals[]'], 'Team only and On hold: the searches behind each store\'s count were not answered alike.', 'The phone-with-name count per store, with why it is not compared for a client.'),
  'links.cmp-sites': cstat('sites', 'Sites that link to the website, all of them', 1131, "'Sites that link to the website, all of them'", ['links.sites'], 'Team only and On hold: the totals keep the link sellers in.', 'Every linking site per website, junk included.'),
  'links.cmp-wave': cstat('wave', 'Link-selling pages new in the last {links.fresh_days} days', 1132, '`Link-selling pages new in the last ${links.fresh_days} days`', ['links.fresh_sellers'], 'Team only (sales: false).', 'New link-selling pages per website in the last 30 days.'),
  'links.wave': { m: { id: 'wave', head: 'card-k' }, kind: 'card', t: 'New linking sites, day by day', k: ['links.daily[]', 'links.daily_peak', 'links.fresh_sellers', 'links.fresh_days', 'links.fresh_sellers_also_rivals', 'links.fresh_sellers_with_weight', 'links.sellers'],
    w: 'Both views, always. The button to save the list of link-selling sites is Service only.', s: ['build-report.mjs', 527, 'New linking sites, day by day'], l: 'New linking sites per day over 45 days, and how many link-selling pages arrived in the last 30 days.' },
  'links.details': { m: { id: 'details', head: 'card-k', heading: 'Where Google shows the store\'s details' }, kind: 'card', t: 'Where Google shows the store\'s details', k: ['listings.phone_named_outside', 'listings.street_named_sites', 'listings.named_site_list[0..15]', 'listings.searches'],
    w: 'Both views, when listings is in the model.', s: ['build-report.mjs', 532, "Where Google shows the store's details"], l: 'How many outside sites show the phone with the store\'s name and the street address with it, and which.' },
  'links.details-other': { m: { id: 'details', head: 'card-k', view: 'service' }, kind: 'card-label', t: 'The phone number shown without the name {business.short}, off the store\'s own website ({listings.phone_other} results on {listings.phone_other_sites.length} sites)', k: ['listings.phone_other', 'listings.phone_other_sites[]'],
    w: 'Service view, team only.', s: ['build-report.mjs', 533, 'The phone number shown without the name'], l: 'The sites that show the store\'s number without its name; open them before telling the client anything.' },
  'links.matter': { m: { id: 'matter', head: 'card-k' }, kind: 'card', t: 'The listings that matter', k: ['listings.matter[]'], w: 'Both views, when listings is in the model.', s: ['build-report.mjs', 534, 'The listings that matter'], l: 'Each listing that matters (Google, Apple Maps, Bing, Yelp, Facebook and the directories of the vertical) and what this report saw of it.' },
  'links.dirs': { m: { id: 'dirs', head: 'card-k' }, kind: 'card', t: 'Listing pages this report could tie to the store', k: ['listings.table[]', 'listings.store_pages', 'listings.store_pages_empty', 'listings.store_empty_by_site'],
    w: 'Service view, when listings is in the model; carries the On hold chip.', s: ['build-report.mjs', 536, 'Listing pages this report could tie to the store'], l: 'Each listing page tied to the store: phone seen, address seen, and from what.' },
  'links.verdicts': { m: { id: 'verdicts', head: 'card-k' }, kind: 'card', t: 'Directories the software checked for this store', k: ['listings.verdicts'], w: 'Both views, when listings.verdicts exists (v2). The other-market line and the table are Service only.', s: ['build-report.mjs', 538, 'Directories the software checked for this store'],
    l: 'How many directories list the store, how many do not, and how many could not be read either way.' },
  'links.weighted': { m: { tab: 'links', head: 'summary', headingRe: /^Linking sites that carry weight/ }, kind: 'expandable', t: 'Linking sites that carry weight ({links.clean_with_weight} that are not link sellers)', k: ['links.top_sites[]', 'links.clean_with_weight'],
    w: 'Both views, always.', s: ['build-report.mjs', 540, 'Linking sites that carry weight'], l: 'The strongest linking sites that are not link sellers, with how many links each.' },
  // ---------- The plan / Tasks ----------
  'plan.sales-eyebrow': { m: { tab: 'plan', head: 'eyebrow', view: 'sales' }, t: 'The plan', k: [], w: 'Sales view, always.', s: ['build-report.mjs', 550, "head('The plan'"], l: 'The tab.' },
  'plan.sales-headline': { m: { tab: 'plan', head: 'h2', view: 'sales' }, kind: 'headline', t: '{plan.length} pieces of work, in this order.', k: ['plan[]'], w: 'Sales view, always. The lead names the buckets in plan order ("Where the store is losing first: ...").', s: ['build-report.mjs', 550, 'pieces of work,'],
    l: 'How many pieces of work, in the order the team would do them; then the numbered list with what each brings.' },
  'plan.service-eyebrow': { m: { tab: 'plan', head: 'eyebrow', view: 'service' }, t: 'All tasks · {business.short}, {business.city}', k: ['business.short', 'business.city'], w: 'Service view, always.', s: ['build-report.mjs', 551, 'All tasks · ${e(B.short)}'], l: 'The tab and the store.' },
  'plan.service-headline': { m: { tab: 'plan', head: 'h2', view: 'service' }, kind: 'headline', t: '{count of tasks[] with owner us or client} open for us and the client. {0} done.', k: ['tasks[].owner'], w: 'Service view, always. The page updates both numbers as statuses change.', s: ['build-report.mjs', 551, 'open for us and the client.'],
    l: 'How many tasks are open; the tools under it filter by owner and status and copy or save the list.' },
  'plan.group': { m: { tab: 'plan', head: 'grp' }, kind: 'group', t: '{task_groups[].label}', k: ['task_groups[]'], w: 'Service view: one per group that holds a task, in GROUPS order (extract-v2.mjs). The groups ours, seos, account and data are team only.', s: ['build-report.mjs', 544, 'class="grp"'], s2: ['extract-v2.mjs', 969, 'const GROUPS'], l: 'The group the task cards under it belong to.' },
  'plan.task': { m: { tab: 'plan', head: 'summary', idRe: /^tk-/ }, kind: 'task-card', t: TASK_T, k: TASK_K, w: 'Service view: every task in the model, under its group, each with the id tk-{task id}.', s: ['build-report.mjs', 544, 'taskCard(t, { id: true })'], s2: ['build-report.mjs', 170, 'const taskCard'], l: TASK_L },
  // ---------- the page footer ----------
  'page.sources': { m: { tab: 'page', head: 'summary' }, kind: 'expandable', t: 'What was read, and when', k: ['business.profile_read_at', 'maps.sweeps[].finished', 'reviews.collected_at', 'search.read_at', 'website.read_at', 'links.read_at', 'listings.read_at'],
    w: 'Both views, always. Above it: "Prepared by {agency} for {short} · {date}" (Sales) or the run line (Service, team only).', s: ['build-report.mjs', 602, 'What was read, and when'], l: 'When each source was read: listing, map checks, reviews, search estimates, store pages, links, listings.' },
};

// what the code can print that these two documents do not show (the code's other branches, v2 only)
const OTHER = {
  overview: [
    { t: 'Every search checked on the map', w: 'v2 with no market file (extract-v2 run without --market): a table of every search, then "The top of the map for \\"{kw}\\"" per sweep (Compare on).', s: 'build-report.mjs:245' },
    { t: 'Links (Sales tile)', w: 'Fewer than three map tiles: the tiles are cut at five.', s: 'build-report.mjs:191' },
    { t: 'Since the last report (section)', w: 'From the second run (extract-v2 --prev): New problems, Fixed, Still open, and a table of the headline numbers that moved ("No headline number moved." when none).', s: 'build-report.mjs:255' },
    { t: 'Nothing for the client in this report.', w: 'Service view, when no task has owner client (a note in place of the client cards).', s: 'build-report.mjs:281' },
  ],
  maps: [
    { t: 'Not compared yet (Google Maps)', w: 'A search the owner expects (settings expected_searches) has no map check on file.', s: 'build-report.mjs:102' },
    { t: 'What the {reviews.low_12} low-star reviews of the last 12 months are about, by word match', w: 'Service view, team only, when reviews.low_12 > 0.', s: 'build-report.mjs:408' },
    { t: 'Low-star reviews with no reply ({reviews.low_open}): ...', w: 'Service view, team only, when reviews.low_open_list is not empty.', s: 'build-report.mjs:410' },
  ],
  search: [],
  ai: [],
  website: [
    { t: 'Not compared yet (Website)', w: 'Never in v2: extract-v2 writes compare.missing.website as an empty list.', s: 'extract-v2.mjs:1149' },
  ],
  links: [],
  plan: [],
  page: [],
};
const HS_LINE = 'build-report.mjs also holds the branches for the older High Society file (meta.v2 absent): the scan card, the town and name searches, the HS listings and pace tables, the directory card. They are inert when meta.v2 is true and are not described here.';

// ---------- matching ----------
const kindOf = b => b.head === 'eyebrow' ? 'eyebrow' : b.head === 'h1' ? 'headline' : b.head === 'grp' ? 'group' : b.head === 'empty-t' ? 'empty-state'
  : b.head === 'summary' ? (/details\.tk/.test(b.parent) ? 'task-card' : 'expandable') : b.head === 'card-k' ? (/tile/.test(b.parent) ? 'tile' : /cstat/.test(b.parent) ? 'compare-card' : 'card') : 'section';
const fits = (r, b) => {
  const m = r.m;
  if (m.tab && !(Array.isArray(m.tab) ? m.tab.includes(b.tab) : m.tab === b.tab)) return false;
  if (m.head && m.head !== b.head) return false;
  if (m.view && m.view !== b.view) return false;
  if (m.id && m.id !== b.id) return false;
  if (m.idRe && !(b.id && m.idRe.test(b.id))) return false;
  if (m.heading && m.heading !== b.heading) return false;
  if (m.headingRe && !m.headingRe.test(b.heading)) return false;
  if (m.parentRe && !m.parentRe.test(b.parent)) return false;
  if (m.ctxRe && !m.ctxRe.test(b.ctx)) return false;
  if (m.chip0 && b.chips[0] !== m.chip0) return false;
  if (m.task === true && !b.task) return false;
  if (typeof m.task === 'string' && b.task !== m.task) return false;
  return true;
};
const DOCS = [['Competitor Analysis', 'client', 'sales'], ['Action Plan', 'service', 'service']];
const TAB_LABEL = { overview: 'Overview', maps: 'Google Maps', search: 'Google search', ai: 'AI answers (Action Plan only)', website: 'Website', links: 'Links and listings', plan: 'The plan (Competitor Analysis) / Tasks (Action Plan)', page: 'Page footer (outside the tabs)' };
const TAB_ORDER = ['overview', 'maps', 'search', 'ai', 'website', 'links', 'plan', 'page'];

// ---------- run ----------
if (files.length < 2) die('usage: node extract-outline.mjs <competitor-analysis.html> <action-plan.html> <out outline.json> [--md=<OUTLINE.md>] [--src=<code folder>] [--raw]');
const read = [files[0], files[1]].map(f => { if (!fs.existsSync(f)) die('no such file: ' + f); return readBlocks(fs.readFileSync(f, 'utf8')); });
if (argv.includes('--raw')) {
  read.forEach((bl, i) => { console.log(`== ${files[i]}: ${bl.length} blocks`); for (const x of bl) console.log(`${x.tab}\t${x.head}\t${x.id || '-'}\t${x.view}${x.internal ? '+int' : ''}${x.compare_only ? '+cmp' : ''}\t${x.heading}${x.chips.length ? '  [' + x.chips.join(' | ') + ']' : ''}\t{${x.ctx}}`); });
  process.exit(0);
}
const outPath = files[2] || die('give the path of outline.json to write');

// every rule's source line holds its probe (when the code folder is given)
const srcDir = opt('src');
let probesChecked = 0;
if (srcDir) {
  const cache = {};
  const lineOf = (file, n) => { cache[file] ||= fs.readFileSync(path.join(srcDir, file), 'utf8').split(/\r?\n/); return cache[file][n - 1] ?? ''; };
  for (const [rid, r] of Object.entries(RULES)) for (const s of [r.s, r.s2].filter(Boolean)) {
    if (!lineOf(s[0], s[1]).includes(s[2])) die(`rule ${rid}: ${s[0]}:${s[1]} does not hold ${JSON.stringify(s[2])}`);
    probesChecked++;
  }
  for (const [tab, list] of Object.entries(OTHER)) for (const o of list) { const [f, ln] = o.s.split(':'); if (!lineOf(f, Number(ln)).length) die(`other branch "${o.t}" (${tab}): ${o.s} is an empty line`); }
}

const used = new Set();
const docs = read.map((blocks, di) => blocks.map((b, i) => {
  const hits = Object.entries(RULES).filter(([, r]) => fits(r, b));
  if (hits.length !== 1) die(`${DOCS[di][0]} block ${i + 1} (${b.tab} ${b.head} ${b.id || '-'} "${b.heading}") matches ${hits.length} rules${hits.length ? ': ' + hits.map(h => h[0]).join(', ') : ''}`);
  const [rid, r] = hits[0]; used.add(rid);
  return { b, rid, r };
}));
const unused = Object.keys(RULES).filter(k => !used.has(k));
if (unused.length) die('rules that match no block in either document: ' + unused.join(', '));

// which document(s) hold each block: same rule and same heading
const keyOf = x => x.rid + '|' + x.b.heading;
const inDoc = docs.map(list => new Set(list.map(keyOf)));
const outline = {
  about: 'The outline of the two SEOS report documents, read from the live Green Haven documents (Product/seos-report/green-haven/docs) by extract-outline.mjs and annotated from build-report.mjs. One block per heading (h1, h2, h3, summary, .card-k, .eyebrow, .grp, .empty-t), in page order, tab by tab. Templates use {model key} slots; [] means one per item, [i] the item shown.',
  heading_elements: ['h1', 'h2', 'h3', 'summary', '.card-k', '.eyebrow', '.grp', '.empty-t'],
  fields: { id: 'the id of the nearest element around the heading that has one (tab sections aside); null when none', own_id: "the heading element's own id", kind: 'eyebrow | headline | section | tile | card | card-label | compare-card | map-card | expandable | task-card | group | empty-state', heading: 'the text as printed in this document (controls and chips left out)', chips: 'chips printed beside the heading', heading_template: 'the heading with {slots}', data_keys: 'the report-data.json keys that feed the block', shown_when: 'when the code shows it or leaves it out', compare_only: 'inside data-cmp: shown only while the Compare switch is on', view: 'sales / service (marked data-only) or both', team_only: 'inside data-internal (hidden by Present, never in a client copy)', documents: 'the documents that print this block', rule: 'the annotation rule in extract-outline.mjs', source: 'file:line in the code' },
  inert_branches: HS_LINE,
  documents: {},
};
const md = [];
docs.forEach((list, di) => {
  const [name, aud, view] = DOCS[di];
  const tabs = {};
  for (const { b, rid, r } of list) {
    const t = (tabs[b.tab] ||= { label: TAB_LABEL[b.tab], blocks: [] });
    t.blocks.push({ n: t.blocks.length + 1, id: b.id, own_id: b.own_id, kind: r.kind || kindOf(b), heading: b.heading, ...(b.chips.length ? { chips: b.chips } : {}), ...(b.task ? { task: b.task } : {}),
      heading_template: r.t, data_keys: r.k, shown_when: r.w, compare_only: b.compare_only, view: b.view, team_only: b.internal,
      documents: DOCS.filter((_, j) => inDoc[j].has(keyOf({ b, rid }))).map(d => d[0]), rule: rid, source: `${r.s[0]}:${r.s[1]}` + (r.s2 ? `, ${r.s2[0]}:${r.s2[1]}` : ''), ...(r.wording ? { wording: r.wording } : {}) });
  }
  for (const k of Object.keys(tabs)) tabs[k].other_branches = OTHER[k] || [];
  outline.documents[name] = { file: path.basename(files[di]), audience: aud, view, build: `node build-report.mjs <report-data.json> <out.html> --audience=${aud} --doc="${name}"`, tabs_in_order: Object.keys(tabs), block_count: list.length, tabs };
});
fs.writeFileSync(outPath, JSON.stringify(outline, null, 1) + '\n');

// ---------- OUTLINE.md: one section per tab, the two documents' blocks merged in page order ----------
const mdPath = opt('md');
if (mdPath) {
  const lcs = (a, b) => { const n = a.length, m = b.length, L = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i][j] = a[i] === b[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
    const out = []; let i = 0, j = 0; while (i < n || j < m) { if (i < n && j < m && a[i] === b[j]) { out.push([i, j]); i++; j++; } else if (j >= m || (i < n && L[i + 1][j] >= L[i][j + 1])) { out.push([i, null]); i++; } else { out.push([null, j]); j++; } } return out; };
  const esc = s => String(s).replace(/\|/g, '\\|');
  const ca = outline.documents['Competitor Analysis'], ap = outline.documents['Action Plan'];
  md.push('# The outline of the two documents', '',
    'Generated by `contract/extract-outline.mjs` from the live Green Haven documents (`green-haven/docs/competitor-analysis.html` and `action-plan.html`); do not edit by hand. `outline.json` holds the same, document by document, with every field.', '',
    '- **Competitor Analysis** is the Sales view alone: `node build-report.mjs <report-data.json> <out.html> --audience=client --doc="Competitor Analysis"`. ' + `${ca.block_count} blocks; tabs ${ca.tabs_in_order.filter(t => t !== 'page').join(', ')} (no AI answers tab).`,
    '- **Action Plan** is the Service view alone: `--audience=service --doc="Action Plan"`. ' + `${ap.block_count} blocks; tabs ${ap.tabs_in_order.filter(t => t !== 'page').join(', ')}. Every check, task and hold about our other accounts is left out of it.`,
    '- A block is one heading: h1, h2, h3, summary, `.card-k`, `.eyebrow`, `.grp` (a group label) or `.empty-t` (an empty state). Templates use `{model key}` slots from `report-data.json`; `[]` means one per item, `[i]` the item shown.',
    '- **In** says which document prints the block: CA (Competitor Analysis), AP (Action Plan) or both. **Compare** marks a comparison block (inside `data-cmp`): shown only while the Compare switch is on. The switch starts on in both documents (`client.js:53` compareDefault() returns "on"; the comment at `build-report.mjs:12-13` still says the Service view starts with it off). **Team** marks a team-only block (inside `data-internal`).',
    '- ' + HS_LINE, '');
  for (const tab of TAB_ORDER) {
    const A = ca.tabs[tab]?.blocks || [], B = ap.tabs[tab]?.blocks || [];
    if (!A.length && !B.length) continue;
    md.push(`## ${TAB_LABEL[tab]}`, '');
    const rows = lcs(A.map(x => x.rule + '|' + x.heading), B.map(x => x.rule + '|' + x.heading)).map(([i, j]) => ({ x: i !== null ? A[i] : B[j], ca: i !== null, ap: j !== null }));
    // a run of blocks from one rule, in the same document(s), prints as one entry
    const merged = [];
    for (const r of rows) { const last = merged[merged.length - 1]; if (last && last.x.rule === r.x.rule && last.ca === r.ca && last.ap === r.ap && (r.x.kind === 'task-card' || r.x.kind === 'tile' || r.x.kind === 'compare-card' || r.x.rule === 'overview.missing-bucket' || r.x.rule === 'plan.group' || r.x.rule === 'website.speed-detail-device')) last.more.push(r.x); else merged.push({ ...r, more: [r.x] }); }
    let k = 0;
    const all = (list, f) => list.every(f), some = (list, f) => list.some(f);
    // the Tasks tab: its group labels and task cards print as one table
    const gi = merged.findIndex(r => r.x.rule === 'plan.group');
    if (gi >= 0) {
      const run = merged.filter(r => r.x.rule === 'plan.group' || r.x.rule === 'plan.task'), rows2 = [];
      for (const r of run) { if (r.x.rule === 'plan.group') rows2.push({ g: r.x, t: [] }); else rows2[rows2.length - 1].t.push(...r.more); }
      const entry = { table: rows2, x: run[0].x, ca: run[0].ca, ap: run[0].ap, more: [] };
      merged.splice(0, merged.length, ...merged.filter(r => !run.includes(r)).slice(0, gi), entry, ...merged.filter(r => !run.includes(r)).slice(gi));
    }
    for (const r of merged) {
      k++;
      if (r.table) {
        const cards = r.table.reduce((s, g) => s + g.t.length, 0);
        md.push(`${k}. **Group labels and task cards (${r.table.length} groups, ${cards} cards)** · group, task-card · ids \`tk-{task id}\` on the cards · AP · service view · \`${RULES['plan.group'].s[0]}:${RULES['plan.group'].s[1]}, ${RULES['plan.task'].s2[0]}:${RULES['plan.task'].s2[1]}\``,
          `   - Templates: group \`${RULES['plan.group'].t}\`; card \`${RULES['plan.task'].t}\`, chips: owner, group, status, "Blocked by task N" where blocked.`,
          `   - Shown when: ${RULES['plan.group'].w} ${RULES['plan.task'].w}`, `   - The reader learns: every task, under its group. ${TASK_L}`, '',
          '   | Group label | Task cards |', '   |---|---|',
          ...r.table.map(g => `   | ${esc(g.g.heading)}${g.g.team_only ? ' (team only)' : ''} | ${g.t.map(t => esc(t.heading) + (t.team_only ? ' (team only)' : '')).join('; ')} |`), '');
        // the numbers are the model's tasks[].n; a task left out of the document leaves its number out
        const nums = r.table.flatMap(g => g.t.map(t => Number((/^(\d+) /.exec(t.heading) || [])[1]))), top = Math.max(...nums), gaps = [];
        for (let i = 1; i <= top; i++) if (!nums.includes(i)) gaps.push(i);
        md.push(`   The card numbers are the model's \`tasks[].n\`, kept as they are when a task is left out of the document: ${gaps.length ? `here the numbers skip ${gaps.join(', ')} (left out of the Action Plan as a task about our other accounts), so ${nums.length} cards run 1 to ${top}.` : `here they run 1 to ${top} with none skipped.`}`, '');
        continue;
      }
      const where = r.ca && r.ap ? 'both' : r.ca ? 'CA' : 'AP';
      const team = all(r.more, x => x.team_only) ? 'Team' : some(r.more, x => x.team_only) ? `Team (${r.more.filter(x => x.team_only).length} of ${r.more.length})` : null;
      const flags = [all(r.more, x => x.compare_only) ? 'Compare' : null, team, r.x.view !== 'both' ? `${r.x.view} view` : null].filter(Boolean).join(', ');
      const rule = RULES[r.x.rule];
      const ids = [...new Set(r.more.map(x => x.id).filter(Boolean))];
      const idTxt = ids.length === 1 ? ` · id \`${ids[0]}\`` : ids.length > 1 && r.x.kind !== 'task-card' ? ` · ids ${ids.map(x => '`' + x + '`').join(', ')}` : r.x.kind === 'task-card' && ids.length ? ' · ids `tk-{task id}`' : '';
      const title = r.more.length === 1 ? `**${esc(r.x.heading)}**${r.x.chips ? ' [' + r.x.chips.join(', ') + ']' : ''}` : `**${r.x.kind === 'task-card' ? 'Task cards' : r.x.kind === 'compare-card' ? 'Comparison cards' : r.x.kind === 'tile' ? 'Tiles' : r.x.kind === 'group' ? 'Group labels' : 'Cards'} (${r.more.length})**`;
      md.push(`${k}. ${title} · ${r.x.kind}${idTxt} · ${where}${flags ? ' · ' + flags : ''} · \`${r.x.source}\``);
      if (r.more.length > 1) md.push(`   - ${r.more.map(t => '"' + esc(t.heading) + '"' + (t.chips && r.x.kind !== 'task-card' ? ' [' + t.chips.join(', ') + ']' : '')).join(', ')}`);
      if (r.x.heading_template !== r.x.heading || r.more.length > 1) md.push(`   - Template: \`${r.x.heading_template}\`${r.x.kind === 'task-card' ? `; chips: owner, group, status${some(r.more, t => (t.chips || []).some(c => /^Blocked by/.test(c))) ? ', "Blocked by task N"' : ''}` : ''}`);
      md.push(`   - Shown when: ${rule.w}`);
      if (r.x.data_keys.length && r.x.kind !== 'task-card') md.push(`   - Model keys: ${r.x.data_keys.map(x => '`' + x + '`').join(', ')}`);
      md.push(`   - The reader learns: ${rule.l}`);
    }
    if ((OTHER[tab] || []).length) { md.push('', `Not in these documents (the code's other v2 branches):`, ''); for (const o of OTHER[tab]) md.push(`- **${esc(o.t)}**: ${o.w} (\`${o.s}\`)`); }
    md.push('');
  }
  fs.writeFileSync(mdPath, md.join('\n'));
}
console.log(`outline: ${DOCS.map(([name], i) => `${name} ${read[i].length} blocks`).join(', ')} | ${Object.keys(RULES).length} rules, every block matched by exactly one${srcDir ? ` | ${probesChecked} source lines checked` : ''}`);
