// check-rules.mjs: checks a report model (report-data.json, written by extract-v2.mjs) against the decision rules in
// rules.json. No network, no clock: the same files in give the same lines out.
//
// usage: node check-rules.mjs <report-data.json> [--rules=<rules.json>] [--md=<RULES.md>]
//                             [--client-doc=<competitor-analysis.html>] [--service-doc=<action-plan.html>] [--json=<out.json>]
//   --rules        the rules file (default: rules.json next to this script)
//   --md           also confirm that RULES.md names every rule id in rules.json
//   --client-doc   also check the Competitor Analysis built from this model: which checks, comparison cards and gap
//                  lines it shows, and in what order
//   --service-doc  the same for the Action Plan
//   --json         write the results as JSON
//
// What it checks, all from the rules as written in rules.json (the script holds no threshold of its own):
//   1. every check, task, hold, comparison row and gap line in the model has its id (or, for a hold, its "clears" line)
//      in rules.json
//   2. every check status the rules can evaluate from the model is recomputed and must equal the model's; so is the
//      check's value line, and whether the check is there at all (where the model holds the inputs)
//   3. tasks: owner, group, the checks that opened them, their status, the sales plan and the task order
//   4. holds: where they are shown and that each names leak patterns
//   5. comparison rows: client-safe and on-hold flags, place, tie, summary sentence, entry order
//   6. gap lines: lead, level, deficit, the sentence, the printed numbers
//   7. orders: the map searches (loss first), the verdict, the counts on the area tiles
//   8. the Green Haven snapshot in rules.json against the model, when the model is that business
// Exit 0 when every check passes, 1 when one fails, 2 on a usage error.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
const [modelPath] = argv.filter(a => !a.startsWith('--'));
if (!modelPath) { console.error('usage: node check-rules.mjs <report-data.json> [--rules=<rules.json>] [--md=<RULES.md>] [--client-doc=<html>] [--service-doc=<html>] [--json=<out.json>]'); process.exit(2); }
const rulesPath = opt('rules') || path.join(here, 'rules.json');
const readJson = p => { const raw = fs.readFileSync(p); return { json: JSON.parse(raw.toString('utf8')), sha256: crypto.createHash('sha256').update(raw).digest('hex'), file: path.basename(p), bytes: raw.length }; };
const M = readJson(modelPath), R = readJson(rulesPath);
const model = M.json, rules = R.json;
const TABLES = rules.tables || {};

// ---------- results ----------
const results = [];
const counts = {};
const bump = (k, by = 1) => { counts[k] = (counts[k] || 0) + by; };
const pass = (area, what) => { results.push({ area, ok: true, what }); };
const fail = (area, what) => { results.push({ area, ok: false, what }); };
const expect = (area, ok, what) => (ok ? pass : fail)(area, what);
const J = x => JSON.stringify(x);

// ---------- the expression language (rules.json "expressions" says the same in words) ----------
const TOKEN = /\s*(?:(\d+(?:\.\d+)?)|'((?:[^'\\]|\\.)*)'|([A-Za-z_][A-Za-z0-9_]*)|(>=|<=|==|!=|&&|\|\||[-+*/()<>!,]))/y;
const tokenize = src => {
  const out = []; let i = 0;
  while (i < src.length) {
    if (!src.slice(i).trim()) break;
    TOKEN.lastIndex = i; const m = TOKEN.exec(src);
    if (!m) throw new Error(`cannot read the expression at "${src.slice(i, i + 24)}" in: ${src}`);
    i = TOKEN.lastIndex;
    if (m[1] !== undefined) out.push({ t: 'num', v: Number(m[1]) });
    else if (m[2] !== undefined) out.push({ t: 'str', v: m[2].replace(/\\(.)/g, '$1') });
    else if (m[3] !== undefined) out.push({ t: 'id', v: m[3] });
    else out.push({ t: 'op', v: m[4] });
  }
  return out;
};
const PARSED = new Map();
const parse = src => {
  if (PARSED.has(src)) return PARSED.get(src);
  const tk = tokenize(String(src)); let p = 0;
  const isOp = v => tk[p] && tk[p].t === 'op' && tk[p].v === v;
  const eat = v => { if (!isOp(v)) throw new Error(`expected "${v}" in: ${src}`); p++; };
  const or = () => { let a = and(); while (isOp('||')) { p++; a = { k: 'or', a, b: and() }; } return a; };
  const and = () => { let a = cmp(); while (isOp('&&')) { p++; a = { k: 'and', a, b: cmp() }; } return a; };
  const cmp = () => { const a = add(); for (const o of ['==', '!=', '>=', '<=', '>', '<']) if (isOp(o)) { p++; return { k: 'bin', o, a, b: add() }; } return a; };
  const add = () => { let a = mul(); while (isOp('+') || isOp('-')) { const o = tk[p++].v; a = { k: 'bin', o, a, b: mul() }; } return a; };
  const mul = () => { let a = unary(); while (isOp('*') || isOp('/')) { const o = tk[p++].v; a = { k: 'bin', o, a, b: unary() }; } return a; };
  const unary = () => { if (isOp('!')) { p++; return { k: 'not', x: unary() }; } if (isOp('-')) { p++; return { k: 'neg', x: unary() }; } return prim(); };
  const prim = () => {
    const x = tk[p++]; if (!x) throw new Error(`the expression ends too soon: ${src}`);
    if (x.t === 'num' || x.t === 'str') return { k: 'lit', v: x.v };
    if (x.t === 'id') {
      if (x.v === 'true') return { k: 'lit', v: true }; if (x.v === 'false') return { k: 'lit', v: false }; if (x.v === 'null') return { k: 'lit', v: null };
      if (isOp('(')) { p++; const args = []; if (!isOp(')')) { args.push(or()); while (isOp(',')) { p++; args.push(or()); } } eat(')'); return { k: 'call', f: x.v, args }; }
      return { k: 'var', name: x.v };
    }
    if (x.t === 'op' && x.v === '(') { const e = or(); eat(')'); return e; }
    throw new Error(`unexpected "${x.v}" in: ${src}`);
  };
  const ast = or();
  if (p !== tk.length) throw new Error(`unexpected "${tk[p].v}" in: ${src}`);
  PARSED.set(src, ast); return ast;
};
// a yes or no, as the JavaScript of extract-v2.mjs reads one; a list is never a yes or no (wrap it in any() or all())
const truth = x => { if (Array.isArray(x)) throw new Error('a list where a yes or no is needed (use any() or all())'); return !!x; };
const isNum = x => typeof x === 'number' && !Number.isNaN(x);
const each1 = (x, f) => (Array.isArray(x) ? x.map(f) : f(x));
const each2 = (a, b, f) => {
  if (Array.isArray(a) && Array.isArray(b)) { if (a.length !== b.length) throw new Error(`two lists of different lengths (${a.length} and ${b.length})`); return a.map((x, i) => f(x, b[i])); }
  if (Array.isArray(a)) return a.map(x => f(x, b)); if (Array.isArray(b)) return b.map(y => f(a, y)); return f(a, b);
};
const num = (x, what) => { if (!isNum(x)) throw new Error(`${what} needs a number, got ${J(x)}`); return x; };
const binop = (o, x, y) => {
  if (o === '+') { if (typeof x === 'string' || typeof y === 'string') return String(x) + String(y); if (x === null || y === null) return null; return num(x, '+') + num(y, '+'); }
  if (o === '-' || o === '*' || o === '/') { if (x === null || y === null) return null; num(x, o); num(y, o); if (o === '/') return y === 0 ? null : x / y; return o === '-' ? x - y : x * y; }
  if (o === '==') return x === y;
  if (o === '!=') return x !== y;
  if (x === null || y === null) return false; // a comparison with nothing is false
  if (!((isNum(x) && isNum(y)) || (typeof x === 'string' && typeof y === 'string'))) throw new Error(`cannot compare ${J(x)} ${o} ${J(y)}`);
  return o === '>' ? x > y : o === '<' ? x < y : o === '>=' ? x >= y : x <= y;
};
const fmtN = x => (x === null || x === undefined ? null : (Number(x) === 0 ? 0 : Number(x)).toLocaleString('en-US'));
const nth = k => `${k}${k % 100 >= 11 && k % 100 <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][k % 10] || 'th'}`;
const FMT = { n: fmtN, fixed1: x => (x === null ? null : Number(x).toFixed(1)), round_n: x => (x === null ? null : fmtN(Math.round(x))) };
const list = (x, f) => { if (!Array.isArray(x)) throw new Error(`${f}() needs a list, got ${J(x)}`); return x; };
const FN = {
  isnull: x => x === null || x === undefined, // the whole value (== null on a list compares item by item)
  len: x => (x === null ? null : (Array.isArray(x) || typeof x === 'string') ? x.length : (() => { throw new Error(`len() of ${J(x)}`); })()),
  any: x => list(x, 'any').some(truth), all: x => list(x, 'all').every(truth), count: x => list(x, 'count').filter(truth).length,
  sum: x => list(x, 'sum').reduce((s, v) => s + num(v, 'sum()'), 0),
  min: (...a) => { const v = a.length === 1 && Array.isArray(a[0]) ? a[0] : a; return v.length ? Math.min(...v.map(x => num(x, 'min()'))) : null; },
  max: (...a) => { const v = a.length === 1 && Array.isArray(a[0]) ? a[0] : a; return v.length ? Math.max(...v.map(x => num(x, 'max()'))) : null; },
  abs: x => (x === null ? null : Math.abs(num(x, 'abs()'))),
  nonnull: x => list(x, 'nonnull').filter(v => v !== null && v !== undefined),
  median_low: x => { const s = list(x, 'median_low').map(v => num(v, 'median_low()')).sort((a, b) => a - b); return s.length ? s[Math.floor((s.length - 1) / 2)] : null; },
  first: x => (x === null ? null : list(x, 'first').length ? x[0] : null),
  unique: x => [...new Set(list(x, 'unique'))],
  join: (x, sep) => list(x, 'join').join(sep),
  lookup: (t, k) => { const tb = TABLES[t]; if (tb === undefined) throw new Error(`no table ${t} in rules.json`); if (k === null || k === undefined) return null; const v = tb[k]; return v === undefined ? null : v; },
  intersects: (a, b) => Array.isArray(a) && Array.isArray(b) && a.some(x => b.includes(x)),
  contains: (a, x) => Array.isArray(a) && a.includes(x),
  pick: (a, mask) => { list(a, 'pick'); list(mask, 'pick'); return a.filter((_, i) => truth(mask[i])); },
  lower: x => each1(x, v => (v === null ? null : String(v).toLowerCase())),
  squash: x => each1(x, v => String(v ?? '').toLowerCase().replace(/[^a-z0-9]/g, '')),
  str: x => each1(x, v => String(v)),
  n: x => each1(x, fmtN),
  fixed1: x => each1(x, FMT.fixed1),
  round: x => each1(x, v => (v === null ? null : Math.round(num(v, 'round()')))),
  r1: x => each1(x, v => (v === null ? null : Math.round(v * 10) / 10)),
  r2: x => each1(x, v => (v === null ? null : Math.round(v * 100) / 100)),
  nz: x => x || 0,
  ord: x => each1(x, v => (v === null ? null : nth(v))),
  fmt: (kind, x) => { if (!FMT[kind]) throw new Error(`fmt() kind ${kind}`); return FMT[kind](x); },
  lower_first: x => (x === null ? null : String(x).charAt(0).toLowerCase() + String(x).slice(1)),
};
const ev = (n, vars) => {
  switch (n.k) {
    case 'lit': return n.v;
    case 'var': if (!Object.prototype.hasOwnProperty.call(vars, n.name)) throw new Error(`unknown name "${n.name}"`); return vars[n.name];
    case 'not': return each1(ev(n.x, vars), v => !truth(v));
    case 'neg': return each1(ev(n.x, vars), v => (v === null ? null : -num(v, 'minus')));
    case 'and': { const a = ev(n.a, vars); if (!Array.isArray(a) && !truth(a)) return false; const b = ev(n.b, vars); return each2(a, b, (x, y) => truth(x) && truth(y)); }
    case 'or': { const a = ev(n.a, vars); if (!Array.isArray(a) && truth(a)) return true; const b = ev(n.b, vars); return each2(a, b, (x, y) => truth(x) || truth(y)); }
    case 'bin': return each2(ev(n.a, vars), ev(n.b, vars), (x, y) => binop(n.o, x, y));
    case 'call': {
      if (n.f === 'if') { if (n.args.length !== 3) throw new Error('if() takes 3'); return truth(ev(n.args[0], vars)) ? ev(n.args[1], vars) : ev(n.args[2], vars); }
      const f = FN[n.f]; if (!f) throw new Error(`unknown function ${n.f}()`);
      return f(...n.args.map(a => ev(a, vars)));
    }
  }
  throw new Error('bad expression node');
};
const evaluate = (src, vars) => ev(parse(src), vars);

// ---------- paths into the model: a.b.c, list[*] (every item), list[field=value] (the items whose field is value),
// key? (a key that may be absent); $self is the object being checked, $<name> a row bound by "bind" ----------
const literal = s => (s === 'true' ? true : s === 'false' ? false : s === 'null' ? null : /^-?\d+(\.\d+)?$/.test(s) ? Number(s) : s.replace(/^'(.*)'$/, '$1'));
const resolve = (pathStr, roots) => {
  const parts = [...String(pathStr).matchAll(/([^.[\]]+)|\[([^\]]*)\]/g)].map(m => (m[1] !== undefined ? { key: m[1] } : { sel: m[2] }));
  let cur, i = 0, proj = false;
  if (parts[0].key.startsWith('$')) { const nm = parts[0].key.slice(1); if (!Object.prototype.hasOwnProperty.call(roots, nm)) throw new Error(`"${pathStr}": nothing is bound to $${nm}`); cur = roots[nm]; i = 1; }
  else cur = model;
  for (; i < parts.length; i++) {
    const pt = parts[i];
    if (pt.sel !== undefined) {
      const pick = arr => {
        if (arr === null || arr === undefined) return [];
        if (!Array.isArray(arr)) throw new Error(`"${pathStr}": [${pt.sel}] needs a list`);
        if (pt.sel === '*') return arr;
        const m = /^([A-Za-z_]\w*)=(.+)$/.exec(pt.sel); if (!m) throw new Error(`"${pathStr}": cannot read [${pt.sel}]`);
        const want = literal(m[2]); return arr.filter(x => x !== null && typeof x === 'object' && x[m[1]] === want);
      };
      cur = proj ? cur.flatMap(pick) : pick(cur); proj = true;
    } else {
      let k = pt.key; const optional = k.endsWith('?'); if (optional) k = k.slice(0, -1);
      const step = x => {
        if (x === null || x === undefined) return null;
        if (typeof x !== 'object') throw new Error(`"${pathStr}": "${k}" of ${J(x)}`);
        if (!Object.prototype.hasOwnProperty.call(x, k)) { if (optional) return null; throw new Error(`"${pathStr}": the model has no key "${k}" here`); }
        return x[k] === undefined ? null : x[k];
      };
      cur = proj ? cur.map(step) : step(cur);
    }
  }
  return cur === undefined ? null : cur;
};
// bind: [{ name, collection, match: { field: 'group:<name>' | '<path>' }, transform: { field: 'lower' }, required }]
const bindRows = (binds, roots, groups, where) => {
  for (const b of binds || []) {
    const coll = resolve(b.collection, roots);
    let row = null;
    if (Array.isArray(coll)) row = coll.find(el => Object.entries(b.match).every(([f, src]) => {
      let want = src.startsWith('group:') ? groups[src.slice(6)] : resolve(src, roots);
      if (b.transform && b.transform[f] === 'lower' && want !== null && want !== undefined) want = String(want).toLowerCase();
      return el && el[f] !== undefined && want !== undefined && want !== null && String(el[f]) === String(want);
    })) || null;
    roots[b.name] = row;
    if (!row && b.required) throw Object.assign(new Error(`${where}: no ${b.collection} row for ${J(b.match)}`), { unbound: true });
  }
};
const varsFor = (rule, roots, base = {}) => {
  const vars = { ...base };
  for (const [k, p] of Object.entries(rule.inputs || {})) vars[k] = resolve(p, roots);
  for (const [k, e] of Object.entries(rule.vars || {})) vars[k] = evaluate(e, vars);
  return vars;
};
const runCases = (cases, vars) => { for (const [when, out] of cases) if (when === 'else' || truth(evaluate(when, vars))) return out; return undefined; };

// ---------- finding the rule for an id ----------
const byId = (entries, id) => {
  const exact = entries.find(r => r.id === id);
  if (exact) return { rule: exact, groups: {} };
  for (const r of entries) if (r.id_pattern) { const m = new RegExp(r.id_pattern).exec(id); if (m) return { rule: r, groups: m.groups || {} }; }
  return null;
};
const ruleKey = r => r.id || r.id_template;
const CHECKS = rules.checks, TASKS = rules.tasks, HOLDS = rules.holds, CMP = rules.compare_rows.rows, GAPS = rules.gap_lines.lines;

// ---------- 1. ids ----------
const unknown = [];
for (const c of model.checks) if (!byId(CHECKS, c.id)) unknown.push('check ' + c.id);
for (const t of model.tasks) if (!byId(TASKS, t.id)) unknown.push('task ' + t.id);
for (const r of model.compare.rows) if (!byId(CMP, r.id)) unknown.push('compare row ' + r.id);
for (const g of model.gaps) if (!byId(GAPS, g.id)) unknown.push('gap line ' + g.id);
const holdRule = h => HOLDS.find(x => x.clears === h.clears) || null;
for (const h of model.holds) if (!holdRule(h)) unknown.push('hold "' + String(h.number).slice(0, 40) + '"');
expect('ids', unknown.length === 0, unknown.length ? `not in rules.json: ${unknown.join('; ')}` : `all ${model.checks.length} checks, ${model.tasks.length} tasks, ${model.holds.length} holds, ${model.compare.rows.length} comparison rows and ${model.gaps.length} gap lines have their id in rules.json`);
counts.model = { checks: model.checks.length, tasks: model.tasks.length, holds: model.holds.length, compare_rows: model.compare.rows.length, gap_lines: model.gaps.length };
counts.rules = { checks: CHECKS.length, tasks: TASKS.length, holds: HOLDS.length, compare_rows: CMP.length, gap_lines: GAPS.length };

// ---------- 2. checks: status, value, presence ----------
const recomputed = { status_from_values: [], status_fixed: [], status_not_evaluable: [], value: [], value_not_evaluable: [] };
for (const c of model.checks) {
  const hit = byId(CHECKS, c.id); if (!hit) continue;
  const { rule, groups } = hit;
  const where = `check ${c.id}`;
  try {
    const roots = { self: c };
    bindRows(rule.bind, roots, groups, where);
    const vars = varsFor(rule, roots);
    const cases = rule.status.cases || [];
    if (rule.status.evaluable === false || !cases.length) recomputed.status_not_evaluable.push(c.id);
    else {
      const want = runCases(cases, vars);
      const fixed = cases.length === 1 && cases[0][0] === 'else';
      (fixed ? recomputed.status_fixed : recomputed.status_from_values).push(c.id);
      expect('check status', want === c.status, `${where}: rules.json gives ${want}, the model has ${c.status}`);
    }
    if (rule.value && rule.value.expr) {
      const v = evaluate(rule.value.expr, vars); recomputed.value.push(c.id);
      expect('check value', v === c.value, `${where} value: rules.json gives ${J(v)}, the model has ${J(c.value)}`);
    } else recomputed.value_not_evaluable.push(c.id);
    // the task the check names: the model's task must be the one rules.json names (or none)
    const named = rule.task ? runCases(rule.task.cases, { ...vars, status: c.status }) : null;
    if (rule.task && rule.task.evaluable === false) bump('check task not evaluable');
    else expect('check task', (named ?? null) === (c.task ?? null), `${where} names task ${J(c.task)}; rules.json gives ${J(named ?? null)}`);
  } catch (e) {
    // a rule whose row the model does not hold (e.g. map-listed when no search is the run's keyword) is not evaluable, when
    // the rule says so; any other error fails
    if (e.unbound && rule.on_missing_bind === 'not_evaluable') { recomputed.status_not_evaluable.push(c.id); recomputed.value_not_evaluable.push(c.id); }
    else fail('check rule', `${where}: ${e.message}`);
  }
  // area, weight and the ours flag come from the rule's entry, whatever its expressions do
  const same = rule.door === c.door && rule.weight === c.weight && !!rule.internal === !!c.internal;
  expect('check door and weight', same, `${where}: ${c.door}, weight ${c.weight}${c.internal ? ', ours' : ''}${same ? '' : ` (rules.json: ${rule.door}, ${rule.weight}, internal ${!!rule.internal})`}`);
}
counts.checks_recomputed = { status_from_model_values: recomputed.status_from_values.length, status_fixed_by_rule: recomputed.status_fixed.length, status_not_evaluable_from_model: recomputed.status_not_evaluable.length, values_recomputed: recomputed.value.length, values_not_evaluable: recomputed.value_not_evaluable.length,
  recomputed_ids: recomputed.status_from_values, fixed_ids: recomputed.status_fixed, not_evaluable_ids: recomputed.status_not_evaluable };
// presence: a check rules.json says is there must be there, and one it says is not must not be
let presence = 0;
for (const rule of CHECKS) {
  const w = rule.emitted_when || {};
  try {
    if (rule.id && w.expr) {
      // presence_inputs when the rule gives them; else the rule's own inputs (and its bound rows) and vars
      const roots = {}; if (!rule.presence_inputs) bindRows(rule.bind, roots, {}, `check ${rule.id}`);
      const vars = rule.presence_inputs ? varsFor({ inputs: rule.presence_inputs }, roots) : varsFor(rule, roots);
      const want = truth(evaluate(w.expr, vars)), have = model.checks.some(c => c.id === rule.id);
      expect('check presence', want === have, `check ${rule.id}: rules.json says ${want ? 'present' : 'absent'}, the model has it ${have ? 'present' : 'absent'}`); presence++;
    } else if (rule.id_pattern && w.expected_ids) {
      const e = w.expected_ids; let src = resolve(e.collection, {}); if (!Array.isArray(src)) src = [];
      if (e.where) src = src.filter(x => Object.entries(e.where).every(([k, v]) => x[k] === v));
      const vals = src.map(x => (e.field ? x[e.field] : x)).map(x => (e.transform === 'squash' ? FN.squash(x) : x));
      const want = vals.map(x => e.prefix + x).sort(), have = model.checks.filter(c => new RegExp(rule.id_pattern).test(c.id) && !CHECKS.some(r => r.id === c.id)).map(c => c.id).sort();
      expect('check presence', J(want) === J(have), `check family ${rule.id_template}: rules.json expects ${J(want)}, the model has ${J(have)}`); presence++;
    } else if (rule.id && w.with_hold) {
      const hr = HOLDS.find(h => h.id === w.with_hold), holdThere = model.holds.some(h => h.clears === hr.clears), have = model.checks.some(c => c.id === rule.id);
      expect('check presence', holdThere === have, `check ${rule.id}: present ${have}, its hold ${w.with_hold} present ${holdThere}; rules.json says they come together`); presence++;
    }
  } catch (e) { fail('check presence', `check ${ruleKey(rule)}: ${e.message}`); }
}
counts.checks_presence_tested = presence;

// ---------- 3. tasks ----------
const checkRuleKey = id => { const h = byId(CHECKS, id); return h ? ruleKey(h.rule) : null; };
for (const t of model.tasks) {
  const hit = byId(TASKS, t.id); if (!hit) continue; const r = hit.rule;
  if (r.defined_in_code === false) { fail('task', `task ${t.id} is in the model, but rules.json says the code does not define it`); continue; }
  expect('task owner and group', r.owner === t.owner && r.group === t.group && !!r.service_only === !!t.service_only, `task ${t.id}: rules.json ${r.owner}/${r.group}/service_only=${!!r.service_only}, model ${t.owner}/${t.group}/service_only=${!!t.service_only}`);
  const opened = (t.checks || []).map(checkRuleKey);
  const stray = opened.filter(k => !(r.opened_by || []).includes(k));
  expect('task opened by', stray.length === 0, `task ${t.id} was opened by ${J(t.checks)}${stray.length ? `; rules.json does not list ${J(stray)} among its opening checks` : ''}`);
  // status: fail when any opening check fails, else the first opening check's status, else watch (extract-v2.mjs:987-988)
  const cs = (t.checks || []).map(id => model.checks.find(c => c.id === id));
  const st = cs.some(c => c && c.status === 'fail') ? 'fail' : cs.length && cs[0] ? cs[0].status : 'watch';
  expect('task status', st === t.status, `task ${t.id}: status by the rule ${st}, model ${t.status}`);
  const internal = cs.some(c => c && c.internal);
  expect('task internal', internal === !!t.internal, `task ${t.id}: internal by the rule ${internal}, model ${!!t.internal}`);
  const blocked = J([...(t.blocked_by || [])].sort()) === J([...(r.blocked_by || [])].sort());
  expect('task blocked by', blocked, `task ${t.id}: blocked by ${J(t.blocked_by)}, rules.json ${J(r.blocked_by || [])}`);
}
// the sales plan: SALES_ORDER, keeping the tasks that exist, are not ours alone, not the team's alone, and are for us or the client
{ const so = rules.sales_order.ids;
  const want = so.map(id => model.tasks.find(t => t.id === id)).filter(t => t && !t.internal && !t.service_only && ['us', 'client'].includes(t.owner));
  const have = model.plan;
  const same = J(want.map(t => t.id)) === J(have.map(p => p.id));
  expect('plan order', same, `plan: by SALES_ORDER ${J(want.map(t => t.id))}, model ${J(have.map(p => p.id))}`);
  if (same) for (const [i, p] of have.entries()) { const t = want[i];
    expect('plan item', p.n === i + 1 && p.title === (t.sales_title || t.title) && p.yours === (t.owner === 'client') && (p.benefit ?? null) === (t.benefit ?? null), `plan ${p.n} ${p.id}: number, client title, benefit and "with your team" mark follow the task`); }
  const left = model.tasks.filter(t => !t.internal && !t.service_only && ['us', 'client'].includes(t.owner) && !so.includes(t.id));
  expect('plan gate', left.length === 0, `every client-facing task has a place in SALES_ORDER${left.length ? ': missing ' + left.map(t => t.id).join(', ') : ''}`); }
// the task list order (the Action Plan's task numbers)
{ const G = rules.task_groups, gi = k => G.findIndex(g => g.key === k), within = t => { const g = G[gi(t.group)]; const i = g ? g.order.indexOf(t.id) : -1; return i < 0 ? 99 : i; };
  const DO = TABLES.DOOR_ORDER;
  const cmp = (a, b) => (gi(a.group) - gi(b.group)) || (within(a) - within(b)) || ((a.status === 'fail' ? 0 : 1) - (b.status === 'fail' ? 0 : 1)) || (DO[a.door] - DO[b.door]) || a.id.localeCompare(b.id);
  const sorted = [...model.tasks].sort(cmp);
  const same = J(sorted.map(t => t.id)) === J(model.tasks.map(t => t.id)) && model.tasks.every((t, i) => t.n === i + 1);
  expect('task order', same, `tasks run by group, place in the group, failing first, area, id: ${same ? 'the model\'s numbers 1 to ' + model.tasks.length + ' agree' : 'they do not agree'}`);
  for (const g of model.task_groups) { const rg = G.find(x => x.key === g.key); expect('task groups', !!rg && rg.label === g.label && g.n === model.tasks.filter(t => t.group === g.key).length, `task group ${g.key}: label and count`); } }

// ---------- 4. holds ----------
for (const h of model.holds) {
  const r = holdRule(h); if (!r) continue;
  expect('hold', r.where === h.where || (r.where_any || []).includes(h.where), `hold ${r.id}: shown under "${h.where}"${r.where === h.where ? '' : `, rules.json says "${r.where}"`}`);
  expect('hold leak patterns', Array.isArray(h.leak) && h.leak.length > 0 && h.leak.every(s => { try { new RegExp(s, 'i'); return true; } catch { return false; } }), `hold ${r.id}: ${Array.isArray(h.leak) ? h.leak.length : 0} leak patterns, each a valid pattern`);
}

// ---------- 5. comparison rows ----------
const common = rules.compare_rows.common;
for (const row of model.compare.rows) {
  const hit = byId(CMP, row.id); if (!hit) continue; const r = hit.rule;
  try {
    const roots = { self: row };
    bindRows(r.bind, roots, hit.groups, `compare row ${row.id}`);
    if (r.bind_one_of && !r.bind_one_of.some(nm => roots[nm])) throw new Error(`no row for ${row.id} in ${r.bind_one_of.join(' or ')}`);
    const vars = varsFor(r, roots, hit.groups);
    const oSales = truth(evaluate(r.flags.sales_flag, vars)), hold = truth(evaluate(r.flags.hold, vars));
    expect('compare flags', row.hold === hold && row.sales === (oSales && !hold), `compare row ${row.id}: on hold ${hold}, client-safe ${oSales && !hold} by the rules; model ${row.hold}, ${row.sales}`);
    if (r.flags.key) { const key = truth(evaluate(r.flags.key, vars)); expect('compare flags', row.key === key, `compare row ${row.id}: key ${key} by the rules, model ${row.key}`); }
    expect('compare door, scope and set', row.door === r.door && row.scope === r.scope && row.set === r.set, `compare row ${row.id}: ${row.door}/${row.scope}/${row.set}${row.door === r.door && row.scope === r.scope && row.set === r.set ? '' : `, rules.json ${r.door}/${r.scope}/${r.set}`}`);
    // place, tie, summary: the same for every row (rules.json compare_rows.common)
    const cv = varsFor(common, { self: row, business: model.business });
    for (const f of ['place', 'of', 'tied', 'behind']) expect('compare place', J(cv[f]) === J(row[f]), `compare row ${row.id} ${f}: rules ${J(cv[f])}, model ${J(row[f])}`);
    const sumExpr = runCases(common.summary_cases, cv), summary = sumExpr === undefined ? undefined : evaluate(sumExpr, cv);
    expect('compare summary', summary === row.summary, `compare row ${row.id} summary: rules ${J(summary)}, model ${J(row.summary)}`);
    // the entries' order
    const ks = common.entry_order.keys, keyOf = el => ks.map(k => evaluate(k.expr, varsFor({ inputs: common.entry_order.inputs }, { el })));
    let ordered = true; for (let i = 1; i < row.entries.length; i++) if (cmpKeys(keyOf(row.entries[i - 1]), keyOf(row.entries[i]), ks) > 0) ordered = false;
    expect('compare entry order', ordered, `compare row ${row.id}: entries run highest first, the store after a rival with the same number, entries with no number last`);
    bump('compare rows recomputed');
  } catch (e) { fail('compare row', `compare row ${row.id}: ${e.message}`); }
}
function cmpKeys(a, b, ks) {
  for (let i = 0; i < ks.length; i++) {
    let x = a[i], y = b[i]; if (x === y) continue;
    if (x === null) return 1; if (y === null) return -1;
    if (typeof x === 'boolean') x = Number(x); if (typeof y === 'boolean') y = Number(y);
    const c = x < y ? -1 : x > y ? 1 : 0; if (c) return ks[i].dir === 'desc' ? -c : c;
  }
  return 0;
}

// ---------- 6. gap lines ----------
const gcommon = rules.gap_lines.common;
for (const g of model.gaps) {
  const hit = byId(GAPS, g.id); if (!hit) continue; const r = hit.rule;
  try {
    const roots = { self: g };
    bindRows(r.bind, roots, hit.groups, `gap line ${g.id}`);
    const vars = varsFor(r, roots);
    const yab = truth(evaluate(r.you_are_best || 'false', vars)), floor = truth(evaluate(r.floor || 'false', vars));
    const diff = r.diff_expr ? evaluate(r.diff_expr, vars) : (r.diff ?? null);
    const gv = varsFor({ vars: gcommon.vars }, {}, { you: g.you, best: g.best, you_are_best: yab, floor, diff, show: r.show || 'n', unit: r.unit ?? null });
    for (const f of ['lead', 'level', 'deficit', 'text', 'you_show', 'best_show']) expect('gap line', J(gv[f]) === J(g[f]), `gap line ${g.id} ${f}: rules ${J(gv[f])}, model ${J(g[f])}`);
    expect('gap line', !!g.hold === truth(evaluate(r.hold || 'false', vars)) && (g.scope ?? null) === (r.scope ?? null) && g.door === r.door, `gap line ${g.id}: door ${g.door}, scope ${g.scope}, on hold ${g.hold}`);
    if (r.who_expr || r.who) { const who = r.who_expr ? evaluate(r.who_expr, vars) : r.who; expect('gap line', who === g.who, `gap line ${g.id} who: rules ${J(who)}, model ${J(g.who)}`); }
    // the two numbers themselves, where the model holds where they come from
    for (const [f, e] of [['you', r.you_expr], ['best', r.best_expr]]) if (e) { const v = evaluate(e, vars); expect('gap line numbers', J(v) === J(g[f]), `gap line ${g.id} ${f}: from the model ${J(v)}, the line has ${J(g[f])}`); bump('gap line numbers traced'); }
    bump('gap lines recomputed');
  } catch (e) { fail('gap line', `gap line ${g.id}: ${e.message}`); }
}
// which gap lines are there: one per map search not on hold, the rest by their own condition where the model holds it
for (const r of GAPS) { const w = r.emitted_when || {};
  try {
    if (r.id_pattern && w.expected_ids) { const e = w.expected_ids; let src = resolve(e.collection, {}); if (e.where) src = src.filter(x => Object.entries(e.where).every(([k, v]) => x[k] === v));
      const want = src.map(x => e.prefix + x[e.field]).sort(), have = model.gaps.filter(g => new RegExp(r.id_pattern).test(g.id)).map(g => g.id).sort();
      expect('gap presence', J(want) === J(have), `gap family ${r.id_template}: rules.json expects ${J(want)}, the model has ${J(have)}`); }
    else if (r.id && w.expr) { const vars = varsFor({ inputs: r.presence_inputs || {} }, {}); const want = truth(evaluate(w.expr, vars)), have = model.gaps.some(g => g.id === r.id);
      expect('gap presence', want === have, `gap line ${r.id}: rules.json says ${want ? 'present' : 'absent'}, model ${have ? 'present' : 'absent'}`); }
  } catch (e) { fail('gap presence', `gap ${ruleKey(r)}: ${e.message}`); } }

// ---------- 7. orders: the map searches, the verdict, the tile counts ----------
const O = rules.orders;
const sortedOk = (rows, spec) => { const keyOf = el => spec.keys.map(k => evaluate(k.expr, varsFor({ inputs: spec.inputs, vars: spec.vars }, { el }))); for (let i = 1; i < rows.length; i++) if (cmpKeys(keyOf(rows[i - 1]), keyOf(rows[i]), spec.keys) > 0) return `${rows[i - 1].kw} before ${rows[i].kw}`; return null; };
{ const bad = sortedOk(model.maps.searches, O.maps_searches);
  expect('order', !bad, `maps.searches run losing first, winning last${bad ? ': out of order at ' + bad : ` (${model.maps.searches.map(s => s.kw).join(', ')})`}`); }
{ const usable = model.maps.searches.filter(s => !s.hold), V = model.verdict;
  const L = V.losses.map(kw => usable.find(s => s.kw === kw)), W = V.wins.map(kw => usable.find(s => s.kw === kw));
  expect('verdict', J([...V.losses].sort()) === J(usable.filter(s => !s.you_lead).map(s => s.kw).sort()) && J([...V.wins].sort()) === J(usable.filter(s => s.you_lead).map(s => s.kw).sort()), `verdict: losses ${J(V.losses)}, wins ${J(V.wins)} are the searches not on hold, split by number 1`);
  const bl = L.every(Boolean) ? sortedOk(L, O.verdict_losses) : 'a loss is not in maps.searches', bw = W.every(Boolean) ? sortedOk(W, O.verdict_wins) : 'a win is not in maps.searches';
  expect('verdict', !bl && !bw, `verdict: losses run biggest first, wins widest first${bl || bw ? ': ' + (bl || bw) : ''}`);
  const head = (spec, s) => evaluate(spec.expr, varsFor({ inputs: spec.inputs, vars: spec.vars }, { el: s }));
  if (usable.length) {
    const a = L.length ? head(O.verdict_heads.loss, L[0]) : head(O.verdict_heads.win, W[0]);
    const b = L.length && W.length ? head(O.verdict_heads.win, W[0]) : L.length > 1 ? head(O.verdict_heads.loss, L[1]) : '';
    expect('verdict', a === V.a && b === V.b, `verdict heads: rules ${J([a, b])}, model ${J([V.a, V.b])}`);
    expect('verdict', V.order === 'loss-first' && model.meta.order === 'loss-first', `meta.order and verdict.order are loss-first`);
  }
}
{ const doors = rules.general.tile_doors, want = {};
  for (const d of doors) { const cs = model.checks.filter(c => c.door === d && !rules.general.team_weights.includes(c.weight) && !c.internal); want[d] = { pass: cs.filter(c => c.status === 'pass').length, watch: cs.filter(c => c.status === 'watch').length, fail: cs.filter(c => c.status === 'fail').length, na: cs.filter(c => c.status === 'na').length, total: cs.length }; }
  expect('tile counts', J(want) === J(model.counts), `area tile counts leave out data checks and our own: ${J(want) === J(model.counts) ? 'agree' : `rules ${J(want)}, model ${J(model.counts)}`}`); }

// ---------- 8. the Green Haven snapshot in rules.json ----------
if (rules.reference && model.business && model.business.id === rules.reference.business_id) {
  let n = 0;
  for (const r of CHECKS) { const gh = r.green_haven; if (!gh) continue;
    if (r.id) { const c = model.checks.find(x => x.id === r.id);
      if (!gh.in_model) expect('snapshot', !c, `snapshot: check ${r.id} is not in the Green Haven model`);
      else expect('snapshot', !!c && c.status === gh.status && J(c.value) === J(gh.value), `snapshot: check ${r.id} ${gh.status} ${J(gh.value)}${c ? '' : ' (missing from the model)'}`); }
    else { const have = model.checks.filter(x => new RegExp(r.id_pattern).test(x.id) && !CHECKS.some(y => y.id === x.id)).map(c => ({ id: c.id, status: c.status, value: c.value }));
      expect('snapshot', J(have) === J(gh.instances || []), `snapshot: checks ${r.id_template} ${J((gh.instances || []).map(x => x.id))}`); }
    n++; }
  for (const r of TASKS) { const gh = r.green_haven; if (!gh) continue; const t = r.id ? model.tasks.find(x => x.id === r.id) : null;
    if (r.id) expect('snapshot', gh.in_model ? !!t && t.n === gh.n && t.status === gh.status : !t, `snapshot: task ${r.id} ${gh.in_model ? `number ${gh.n}, ${gh.status}` : 'not in the model'}`);
    else expect('snapshot', model.tasks.filter(x => new RegExp(r.id_pattern).test(x.id)).length === gh.count, `snapshot: ${gh.count} tasks ${r.id_template}`);
    n++; }
  for (const r of HOLDS) { const gh = r.green_haven; if (!gh) continue; const k = model.holds.filter(h => h.clears === r.clears).length; expect('snapshot', k === gh.count, `snapshot: hold ${r.id} x ${gh.count}`); n++; }
  for (const r of CMP) { const gh = r.green_haven; if (!gh) continue;
    if (r.id) { const x = model.compare.rows.find(y => y.id === r.id); expect('snapshot', gh.in_model ? !!x && x.sales === gh.sales && x.hold === gh.hold : !x, `snapshot: compare row ${r.id} ${gh.in_model ? `client-safe ${gh.sales}, on hold ${gh.hold}` : 'not in the model'}`); }
    else { const ids = model.compare.rows.filter(y => new RegExp(r.id_pattern).test(y.id)).map(y => y.id); expect('snapshot', J(ids) === J(gh.ids || []), `snapshot: compare rows ${r.id_template} ${J(gh.ids || [])}`); }
    n++; }
  for (const r of GAPS) { const gh = r.green_haven; if (!gh) continue;
    if (r.id) { const x = model.gaps.find(y => y.id === r.id); expect('snapshot', gh.in_model ? !!x && x.text === gh.text : !x, `snapshot: gap line ${r.id} ${gh.in_model ? J(gh.text) : 'not in the model'}`); }
    else { const xs = model.gaps.filter(y => new RegExp(r.id_pattern).test(y.id)).map(y => ({ id: y.id, text: y.text })); expect('snapshot', J(xs) === J(gh.instances || []), `snapshot: gap lines ${r.id_template}`); }
    n++; }
  counts.snapshot_entries = n;
} else counts.snapshot_entries = 0;

// ---------- --md: RULES.md names every rule ----------
if (opt('md')) { const md = fs.readFileSync(opt('md'), 'utf8'); const keys = [...CHECKS, ...TASKS, ...HOLDS, ...CMP, ...GAPS].map(ruleKey); const missing = [...new Set(keys)].filter(k => !md.includes('`' + k + '`'));
  expect('RULES.md', missing.length === 0, `RULES.md names every rule id in rules.json${missing.length ? ': missing ' + missing.join(', ') : ` (${new Set(keys).size} ids)`}`); }

// ---------- the documents: what each one shows, and in what order ----------
const docText = p => fs.readFileSync(p, 'utf8');
// the page as its readers meet it: the inline stylesheet and the inline script (client.js, which names these attributes
// as selectors) are taken out first, as build-report.mjs's own gates do (build-report.mjs:654, 680)
const markupOf = html => html.replace(/<style>[\s\S]*?<\/style>/, '').replace(/<script>[\s\S]*?<\/script>/g, '');
const idsIn = (html, prefix) => [...html.matchAll(new RegExp(`\\sid="${prefix}([^"]+)"`, 'g'))].map(m => m[1]);
// a stable sort by the keys a rules.json order names (each key an expression over $el)
const sortBy = (rows, spec) => rows.map((el, i) => [el, i, spec.keys.map(k => evaluate(k.expr, varsFor({ inputs: spec.inputs, vars: spec.vars }, { el })))])
  .sort((a, b) => cmpKeys(a[2], b[2], spec.keys) || (a[1] - b[1])).map(x => x[0]);
const lossSort = cs => sortBy(cs, rules.orders.checks_in_tab);
const gapOrder = gs => sortBy(gs, rules.orders.gap_order).map(g => g.id);
const XACCT = new RegExp(rules.cuts.service.xacct_pattern, 'i');
const gs = rules.general;
const clientSees = c => gs.client_doors.includes(c.door) && !gs.team_weights.includes(c.weight) && !c.internal;
if (opt('client-doc')) {
  const html = docText(opt('client-doc'));
  const shown = new Set(idsIn(html, 'cks-'));
  const wrong = model.checks.filter(c => clientSees(c) !== shown.has(c.id)).map(c => c.id);
  expect('client document', wrong.length === 0, `Competitor Analysis shows exactly the checks a client sees (${shown.size})${wrong.length ? ': differs for ' + wrong.join(', ') : ''}`);
  const seq = idsIn(html, 'cks-');
  for (const d of gs.client_doors) { const want = lossSort(model.checks.filter(c => c.door === d && clientSees(c))).map(c => c.id), have = seq.filter(id => model.checks.find(c => c.id === id)?.door === d);
    expect('client document order', J(want) === J(have), `Competitor Analysis, ${d} tab: checks run fail, watch, not measured, pass${J(want) === J(have) ? '' : `: want ${J(want)}, have ${J(have)}`}`); }
  const board = [...html.matchAll(/data-goto="cks-([^"]+)"/g)].map(m => m[1]), boardWant = rules.orders.right_wrong.columns.flatMap(([st]) => model.checks.filter(c => c.status === st && c.door !== 'overview' && clientSees(c) && c.door !== 'ai').map(c => c.id));
  expect('client document order', J(board) === J(boardWant), `Competitor Analysis, Wrong / To look at / Right board: ${board.length} items in that order`);
  const cols = [...html.matchAll(/class="card rw-c rw-([a-z]+)"/g)].map(m => m[1]);
  expect('client document order', J(cols) === J(rules.orders.right_wrong.columns.map(c => c[0])), `Competitor Analysis board columns run ${cols.join(', ')}`);
  const gapsShown = idsIn(html, 'gap-'), gapsWant = gapOrder(model.gaps.filter(g => !g.hold));
  expect('client document order', J(gapsShown) === J(gapsWant), `Competitor Analysis gap lines: biggest gap first, whole-website lines after the others, level or ahead last${J(gapsShown) === J(gapsWant) ? '' : `: want ${J(gapsWant)}, have ${J(gapsShown)}`}`);
  const cards = new Set(idsIn(html, 'cmp-')), cardWrong = model.compare.rows.filter(r => r.sales !== cards.has(r.id)).map(r => r.id);
  expect('client document', cardWrong.length === 0, `Competitor Analysis carries exactly the client-safe comparison cards${cardWrong.length ? ': differs for ' + cardWrong.join(', ') : ''}`);
  const labels = [...html.matchAll(/<div class="card"><p class="card-k">([^<]+)<\/p><div class="big">\d+<span class="unit">(?:piece of work|pieces of work)/g)].map(m => m[1].replace(/&amp;/g, '&'));
  const B = rules.board.buckets, buckets = B.map(b => ({ label: b.label, n: model.plan.filter(p => b.ids.includes(p.id)).length })).filter(b => b.n).map(b => b.label);
  if (model.plan.some(p => !B.some(b => b.ids.includes(p.id)))) buckets.push(rules.board.leftover_label);
  expect('client document order', J(labels) === J(buckets), `Competitor Analysis "What is missing" buckets: ${labels.join(', ')}`);
  const pl = html.indexOf('id="plan-list"'), planBlock = pl < 0 ? '' : html.slice(pl, html.indexOf('</section>', pl));
  const planTitles = [...planBlock.matchAll(/<p class="plan-t">([^<]*)/g)].map(m => m[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&').trim());
  expect('client document order', J(planTitles) === J(model.plan.map(p => p.title)), `Competitor Analysis plan tab: ${planTitles.length} items in SALES_ORDER order`);
  const mk = markupOf(html);
  expect('client document', !/id="holds"/.test(mk) && !/id="tk-/.test(mk) && !/data-only="service"/.test(mk) && !/data-internal/.test(mk), 'Competitor Analysis carries no holds table, no task cards, no service block and no team-only block');
}
if (opt('service-doc')) {
  const html = docText(opt('service-doc'));
  const gone = c => XACCT.test(J(c));
  const shown = new Set(idsIn(html, 'ck-'));
  const wrong = model.checks.filter(c => (c.door !== 'overview' && !gone(c)) !== shown.has(c.id)).map(c => c.id);
  expect('service document', wrong.length === 0, `Action Plan shows every check but the overview ones and those about our other accounts (${shown.size})${wrong.length ? ': differs for ' + wrong.join(', ') : ''}`);
  const seq = idsIn(html, 'ck-');
  for (const d of ['maps', 'search', 'ai', 'website', 'links']) { const keep = model.checks.filter(c => c.door === d && !gone(c));
    const want = [...lossSort(keep.filter(c => !gs.team_weights.includes(c.weight))), ...lossSort(keep.filter(c => gs.team_weights.includes(c.weight)))].map(c => c.id), have = seq.filter(id => model.checks.find(c => c.id === id)?.door === d);
    expect('service document order', J(want) === J(have), `Action Plan, ${d} tab: the store's checks fail first, then the checks on the data, fail first${J(want) === J(have) ? '' : `: want ${J(want)}, have ${J(have)}`}`); }
  const tk = idsIn(html, 'tk-'), tkWant = model.tasks.filter(t => !gone(t)).map(t => t.id);
  expect('service document order', J(tk) === J(tkWant), `Action Plan task list: ${tk.length} tasks in task-number order, those about our other accounts left out`);
  const gapsShown = idsIn(html, 'gap-'), gapsWant = gapOrder(model.gaps);
  expect('service document order', J(gapsShown) === J(gapsWant), `Action Plan gap lines, held ones included: ${gapsShown.length} in the documented order`);
  const holdRows = (html.match(/<h2 class="h2">Not safe to quote yet<\/h2>[\s\S]*?<\/tbody>/) || [''])[0].split('<tr>').length - 2;
  const holdWant = model.holds.filter(h => !gone(h)).length;
  expect('service document', holdRows === holdWant, `Action Plan holds table: ${holdRows} rows, the model's ${model.holds.length} less those about our other accounts (${holdWant})`);
  const cards = new Set(idsIn(html, 'cmp-')), cardMissing = model.compare.rows.filter(r => !cards.has(r.id)).map(r => r.id);
  expect('service document', cardMissing.length === 0, `Action Plan carries every comparison card, client-safe or not${cardMissing.length ? ': missing ' + cardMissing.join(', ') : ''}`);
  const mk = markupOf(html);
  expect('service document', !/data-only="sales"/.test(mk) && !/data-mode-set/.test(mk) && !/id="cks-/.test(mk), 'Action Plan carries no Sales-only block, no view switch and no client check rows');
}

// ---------- report ----------
const failed = results.filter(r => !r.ok);
const byArea = {}; for (const r of results) { const a = (byArea[r.area] ||= { pass: 0, fail: 0 }); a[r.ok ? 'pass' : 'fail']++; }
console.log(`check-rules: ${M.file} (sha256 ${M.sha256.slice(0, 12)}) against ${R.file} (sha256 ${R.sha256.slice(0, 12)})`);
for (const [a, v] of Object.entries(byArea)) console.log(`  ${a.padEnd(28)} ${String(v.pass).padStart(4)} pass${v.fail ? `, ${v.fail} FAIL` : ''}`);
const cr = counts.checks_recomputed;
console.log(`checks: ${cr.status_from_model_values} statuses recomputed from the model's values, ${cr.status_fixed_by_rule} fixed by their rule, ${cr.status_not_evaluable_from_model} not evaluable from the model (${cr.not_evaluable_ids.join(', ') || 'none'}); ${cr.values_recomputed} value lines recomputed; ${counts.checks_presence_tested} presence rules tested`);
console.log(`compare rows recomputed ${counts['compare rows recomputed'] || 0}, gap lines recomputed ${counts['gap lines recomputed'] || 0}, snapshot entries ${counts.snapshot_entries}`);
for (const f of failed.slice(0, 60)) console.log('  FAIL ' + f.area + ': ' + f.what);
console.log(failed.length ? `RESULT: FAIL (${failed.length} of ${results.length})` : `RESULT: PASS (${results.length} of ${results.length})`);
if (opt('json')) fs.writeFileSync(opt('json'), JSON.stringify({ model: { file: M.file, bytes: M.bytes, sha256: M.sha256 }, rules: { file: R.file, bytes: R.bytes, sha256: R.sha256 }, passed: results.length - failed.length, failed: failed.length, by_area: byArea, counts, failures: failed }, null, 1));
process.exit(failed.length ? 1 : 0);
