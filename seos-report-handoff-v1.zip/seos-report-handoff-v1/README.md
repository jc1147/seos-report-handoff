# SEOS report style: hand-off package, version 1

For Dan (SEOS / APEX), from James's team, 2026-10-12.

## What this is

Our SEO report, made into a fixed procedure that SEOS can run for any business. From SEOS's own answers about one
business (`GET /businesses/{id}`, `/full-audit-result`, `/website-audit-result`) and one small settings file, one command
writes two documents:

- **Competitor Analysis**: the Sales view, safe to send to the client.
- **Action Plan**: the Service view, the team's working list.

No person and no AI writes anything at build time. Every sentence is a fixed template filled from the data, and rules
decide the order (losing first, winning last), each status, and what is held back from the client. The same answers give
the same documents, byte for byte, every time; the conformance test below proves it on Green Haven Industries (SEOS
business 48), whose real answers, scrubbed, are the test fixture.

## Start here

Needs Node 24. No npm packages. Chrome only for the optional browser checks.

```sh
# 1. The proof: rebuild Green Haven from its SEOS answers and compare with the expected files, byte for byte (about 3 s)
node conformance/conformance.mjs --no-browser
#    -> CONFORMANCE: PASS (...)        (drop --no-browser to add 46 checks in headless Chrome, about 17 s)

# 2. A run you can open: writes the two documents, the map file, the model and a run log into a new folder
node run-report.mjs --data=fixtures/green-haven-48/input --settings=fixtures/green-haven-48/settings.json \
  --extra-sweep=fixtures/green-haven-48/input/extra-ee/eagleeyes-scan-320-weed-near-me.json \
  --out=<new folder> --no-browser
```

Step 2's documents match `fixtures/green-haven-48/expected/` byte for byte. Its `market.json` and `report-data.json` need
not: the Eagle Eyes export's file time is stamped into them (OPEN-ITEMS M13), and unzipping may change it; and without
`--facts`, `meta.facts_check` is null. Step 1 is the byte-for-byte proof: it pins the file time and passes `--facts`.

Then read, in this order:

1. `SPEC.md` sections 1, 2 and 12: what it promises, the chain, and the recommended way into SEOS (run it as it is, accept
   it by the conformance test, port later only if wanted).
2. `OPEN-ITEMS.md` sections 0 and 1: what is decided on our side, and what is on SEOS's side.
3. The contract files when you need the detail.

## What is in the folder

| Path | What it is |
|---|---|
| `SPEC.md` | The specification: chain, inputs, settings, model, rules, outline, wording, the two cuts, determinism, variable data, how to build it into SEOS, what was checked. |
| `OPEN-ITEMS.md` | Everything still open, with file and line, how it is known, and a proposed fix. |
| `VARIANTS.md` | Six runs on changed data (a missing search, one search, another trade, missing readings) and exactly what each did to the documents. |
| `run-report.mjs` | The one command: SEOS's answers and the settings in, the two documents out. Stops at the first failed gate. |
| `reference/` | The reference code, byte-identical to ours: `extract-v2.mjs`, `sweeps-market.mjs`, `build-report.mjs` and their checks, the page's `report.css`, `client.js`, `mapview.js` and fonts, the Eagle Eyes converter, and the password gate used to publish the Action Plan. |
| `conformance/` | `conformance.mjs` (the acceptance test; also `--model=` and `--documents=` for a port) and `check-documents.mjs` (the browser checks). |
| `contract/` | The data contract and the style, each with its own checker: `INPUTS.md`, `SETTINGS.md` and `business-settings.schema.json`, `MODEL.md` and `report-data.schema.json`, `RULES.md` and `rules.json`, `OUTLINE.md` and `outline.json`, `WORDING.md` and `wording.json`. |
| `fixtures/green-haven-48/` | The test fixture: `input/` (SEOS's answers, scrubbed, plus two files only the facts oracle reads: `business_info-history-green-haven.json` and `engine_sweep_businesses-green-haven-anywhere.json`; `input/SCRUBBED.md` says what was removed), `settings.json`, `expected/` (the outputs, with `SHA256SUMS`), `oracle/` (an independent facts file), `variants/`, and `scrub.mjs`. |
| `parts/` | The four builders' own reports: every check they ran, every finding, what they could not verify. See `parts/README.md`. |
| `MANIFEST.json`, `SHA256SUMS` | Every file's size and sha256. Check with `sha256sum -c SHA256SUMS` (macOS: `shasum -a 256 -c SHA256SUMS`). |
| `.gitattributes` | `* -text`: no line-ending conversion if the package goes into a git repository. The documents inline files from `reference/`, and the test compares bytes. |

## Contract checks

Run from this folder.

```sh
E=fixtures/green-haven-48/expected
node contract/validate-model.mjs contract/report-data.schema.json $E/report-data.json --plant
node contract/validate-model.mjs contract/business-settings.schema.json fixtures/green-haven-48/settings.json
node contract/check-rules.mjs $E/report-data.json --rules=contract/rules.json --md=contract/RULES.md \
  --client-doc=$E/competitor-analysis.html --service-doc=$E/action-plan.html
node contract/check-outline.mjs contract/outline.json $E/competitor-analysis.html $E/action-plan.html --wording=contract/wording.json
node contract/check-wording.mjs contract/wording.json $E/report-data.json $E/competitor-analysis.html $E/action-plan.html --src=reference
node fixtures/green-haven-48/variants/run-variants.mjs
```

The last command rebuilds `VARIANTS.md` and `fixtures/green-haven-48/variants/results.json` in place (about 25 s); they
must come out byte-identical (compare their sha256 before and after). Its runs go to a new folder under the system temp
folder (about 13 MB); `--work=<folder>` puts them elsewhere.

## Privacy

- The fixture is a real client's data, scrubbed. Removed or emptied: another account's Google Analytics and Search Console
  readings (their request and result), tables and columns named for tokens, credentials or account links, the SEOS console
  users' e-mail addresses (replaced by `person-<n>@example.invalid`), the Eagle Eyes scan machine's network address and
  provider, and the location rows the chain does not read. `input/SCRUBBED.md` gives every count. Keep the package
  private: not in a public repository, not on a public host.
- The Action Plan is a team document. It names our other accounts nowhere, but it carries everything else.
- Other files here do name our other accounts and say they are ours: `VARIANTS.md`, `fixtures/green-haven-48/variants/results.json`
  and `expected/report-data.json` (the `own-accounts` check and its hold: three businesses on Green Haven's map, with
  their SEOS business ids, one of them its number 1 for "weed near me"); and, by website, the two accounts whose
  readings were emptied (`expected/report-data.json`, `expected/market.json`, the fixture's input, `parts/A-build.json`).
  Only a built Competitor Analysis may ever reach a client; never forward any other file of this package.
- No key, token or password is in the package: a scan for the SEOS API key and the preview password found none, and a
  scan for the values of the other accounts' emptied readings found none.

## Verification record (2026-10-12, Windows 11, Node 24.15.0)

- `conformance/conformance.mjs`: PASS, after the last change to the fixture (18.0 s with the browser checks).
- Inside that run: map file second reading 1,697 checks, 0 disagree; facts 185 shared numbers, 0 disagree; comparison
  second reading 283 checks, 0 disagree; class checks PASS on both documents; browser checks 46 of 46.
- Contract checks, as listed above, run from this folder on its own files: model schema PASS (14,647 values, planted
  mistakes caught); settings schema PASS; rules PASS 940 of 940; outline PASS (91 and 188 headings); wording PASS (247
  entries, 212 verified); the outline regenerated byte-identical.
- The two expected documents are byte-identical to the live Green Haven documents (Competitor Analysis sha256
  `fd7a98cc...09cf92`, Action Plan `3e599768...8992e7`).
- Port acceptance: `conformance.mjs --model=` and `--documents=` PASS on a run made the production way (no `--facts`), and
  `--model=` FAILS on a copy with one value changed, at that one path.
- An independent check (a separate agent that did not build the package) re-ran every test above and both privacy
  scans, all PASS, and checked 63 groups of claims in these documents against the code and outputs: 53 confirmed, 7
  wrong, 3 not provable from the package. The wrong ones are corrected in this version; its 26 findings are fixed here
  or listed in `OPEN-ITEMS.md`.
- The zip this folder comes in was unzipped into a clean folder and checked there: the manifest, conformance (with and
  without the browser checks), every contract check, the variants rebuild and both privacy scans: PASS.
