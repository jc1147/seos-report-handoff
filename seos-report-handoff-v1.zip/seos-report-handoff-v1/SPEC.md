# SEOS report style: the specification

Version 1, 2026-10-12. Worked example and test fixture: Green Haven Industries, Elizabeth NJ (SEOS business 48), built
from SEOS's answers fetched on 2026-10-12. Everything below was read from the reference code in `reference/` or measured
by running it; section 14 lists the runs.

## 1. What this package promises

From SEOS's own answers about one business, plus one small settings file, `run-report.mjs` writes two documents:

| Document | What it is | Built with |
|---|---|---|
| **Competitor Analysis** | The Sales view alone. Client-safe: nothing of the team's side is in the file. | `build-report.mjs --audience=client --doc="Competitor Analysis"` |
| **Action Plan** | The Service view alone. The team's working document: every check, task and hold, minus anything about our other accounts. | `build-report.mjs --audience=service --doc="Action Plan"` |

- **No person and no AI writes anything at build time.** Every sentence is a fixed template whose slots are filled from
  the data. Rules pick which template, the order, each status and what is held back from the client.
- **Same answers and same settings give the same bytes.** `market.json` and both documents are byte-identical from run to
  run; `report-data.json` is equal apart from `meta.built_at`, the one clock read, which no document prints. One more
  input counts when an Eagle Eyes export is folded in: its file time, which reaches `market.json` and the model, never
  the documents (OPEN-ITEMS M13). Section 10 says what makes this hold and how it was shown.
- **Other data gives other documents by the same rules.** More or fewer searches, rivals, directories or readings change
  the content, never the method. Missing or doubtful data is said plainly ("Not measured", "could not be read", or a
  number on hold that the client never sees) instead of guessed. Gaps remain, each listed in `OPEN-ITEMS.md`: some
  sentences carry Green Haven's facts or state a fact the code does not read (section 2), and data missing in certain
  ways crashes a stage or prints a wrong line (section 4).

## 2. The chain

```
SEOS API, saved as files                     settings.json (one per business)      Eagle Eyes scan export(s), optional
  business-<id>.json                                   |                            (a stopgap until SEOS sweeps every
  full-audit-<id>.json                                 |                             expected search itself)
  website-audit-<id>.json                              |                                   |
  engine_sweeps-all.json   (optional)                  |                       ee-scan-to-seos.mjs: SEOS sweep rows
  locations-all.json       (optional)                  |                       merge-sweep.mjs: a copy of the answers
        |                                              |                                   |   with those rows added
        +----------------------------------------------+-----------------------------------+
                                     |
  1. sweeps-market.mjs   -> market.json        the map file: each sweep's points, field, leaders, far rows, velocity
     check-sweeps-market.mjs                   second reading of the map file against the raw answers
  2. extract-v2.mjs      -> report-data.json   the model: 25 top-level keys, every number, status and sentence
     check-compare-v2.mjs                      second reading of the comparison rows against the raw answers
  3. build-report.mjs    -> competitor-analysis.html   (client cut + leak gate)
     build-report.mjs    -> action-plan.html           (service cut + other-accounts gate)
     verify-classes.mjs                        every class used in each file is styled
  4. check-documents.mjs (optional)            the two files in headless Chrome: 46 checks
```

| Stage | Script (in `reference/`) | Reads | Writes | Stops the run when | Time here |
|---|---|---|---|---|---|
| 0 | `ee-scan-to-seos.mjs`, `merge-sweep.mjs` | an Eagle Eyes export; the answers | `extra/<name>.seos.json`; `data/` (a copy) | the export is about another place; the sweep is already held | 0.2 s |
| 1 | `sweeps-market.mjs` | business answer, full audit, the store's place id, `--tz`, `--want` | `market.json` | a sweep header disagrees with its points; no sweep of the store | 0.3 s |
| 1b | `check-sweeps-market.mjs` | business answer, `market.json`, full audit | log | any of its 1,697 checks disagrees | 0.2 s |
| 2 | `extract-v2.mjs` | the three answers, settings, `market.json`, the two tables | `report-data.json` | a settings, answer or rule check fails (section 6) | 1.4 s |
| 2b | `check-compare-v2.mjs` | the three answers, `report-data.json` | log | any of its 283 checks disagrees | 0.2 s |
| 3 | `build-report.mjs` (twice) | `report-data.json`, `report.css`, `client.js`, `mapview.js`, `fonts/` | the two documents | a leak, hold, other-accounts, orphan or find-box gate fails (section 9) | 0.2 s |
| 3b | `verify-classes.mjs` (twice) | each document | log | a class has no style | 0.2 s |
| 4 | `conformance/check-documents.mjs` | model and both documents | screenshots | any of 46 browser checks fails | 14 s |

`run-report.mjs` runs the stages in that order as child processes. The first stage that exits non-zero stops the run:
no later stage runs, but what the earlier stages wrote stays in `<out>`, both documents included when a check after the
builds failed. A finished run is exit 0 and `<out>/SHA256SUMS`, which is written last. Each stage's full output is kept
in `<out>/logs/`. `<out>/run-log.txt` records the sha256 of the settings file and of each Eagle Eyes export, the time zone
used and every stage's exit code and time; the SEOS answers' sizes and sha256 are recorded in `market.json`
(`source.inputs`) and `report-data.json` (`meta.sources`). A whole run takes
about 3 s without the browser check and about 17 s with it, on this machine (Windows 11, Node 24.15.0).

Requirements: Node 24 (only `node:` built-in modules; no npm packages). Chrome only for stage 4, which `--no-browser`
skips. The scripts make no network calls; stage 4 talks to Chrome's DevTools port on 127.0.0.1. The documents load
nothing from the network: fonts, styles and scripts are inlined (0 external resources in either file; the only outside
references are ordinary links, 2 in the Competitor Analysis and 28 in the Action Plan).

## 3. Inputs (full detail: `contract/INPUTS.md`)

| Answer | API path | File name the runner expects |
|---|---|---|
| The business and every table linked to it | `GET /api/data/v1/businesses/{id}` | `business-<id>.json` |
| What the Full audit fetched (the readings) | `GET /api/data/v1/businesses/{id}/full-audit-result` | `full-audit-<id>.json` |
| What the Website audit fetched | `GET /api/data/v1/businesses/{id}/website-audit-result` | `website-audit-<id>.json` |
| Every sweep in SEOS (optional) | `GET /api/data/v1/tables/engine_sweeps` | `engine_sweeps-all.json` |
| Every location in SEOS (optional) | `GET /api/data/v1/tables/locations` | `locations-all.json` |

- The answers are read as SEOS returns them. The chain reads 17 tables, 19 reading kinds, 130 columns and 124 paths inside
  readings; `INPUTS.md` lists each one with the script that reads it, the model key it feeds and what happens when it is
  missing.
- A reading is picked by its `kind` and the `place_id` it is about, newest `fetched_at` first. The store's readings use
  its place id, a rival's use the rival's.
- The store is the business answer's first `locations` row (one store per report today; see OPEN-ITEMS G16).
- Must be present, or no documents are built: the first `businesses` and `locations` rows; a time zone (the state table or
  `settings.timezone`); the audit run and its subject; both audit answers for the same business and run; the store's
  `business_info` reading; each sweep's `engine_sweep_businesses` rows; the store's `bl_exhaustive` reading; for the map
  file, at least one sweep of the store and the store's coordinates. Some of these stop with a clear message, others
  crash today (OPEN-ITEMS section 4).
- Everything else may be missing. The report then says "Not measured", "could not be read" or "not in the record", or
  leaves the line out.
- The fixture's `input/` also holds two files SEOS is not asked for: `business_info-history-green-haven.json` and
  `engine_sweep_businesses-green-haven-anywhere.json`. Only the independent facts oracle reads them.

## 4. Settings (full detail: `contract/SETTINGS.md`, `contract/business-settings.schema.json`)

The SEOS record does not carry everything the report needs. The rest is one JSON file per business, read by
`extract-v2.mjs --settings` (`run-report.mjs` always passes it). Green Haven's is `fixtures/green-haven-48/settings.json`:

```json
{
  "business_id": 48,
  "brand": "Green Haven Industries",
  "short": "Green Haven",
  "brand_terms": ["green haven", "greenhaven", "green haven industries"],
  "agency": "Dispenza",
  "vertical": "Cannabis",
  "expected_searches": ["weed near me"],
  "other_market_sources": "michigan|new-?buffalo|berrien|harbor-?country|us-?12",
  "other_market_label": "Michigan"
}
```

| Key | What it does |
|---|---|
| `business_id` (required) | Guard: must equal the business answer's id. |
| `brand`, `short` | The full and the short name used in sentences, tiles and comparisons. |
| `brand_terms` | The name's spellings: brand searches, linking sites that name the store, Google results tied to the store. |
| `agency` | Our tag in utm links: evidence with it is ours (team only); also "Prepared by ..." in the header. |
| `vertical` | Used when `businesses.vertical` is empty. Only "Cannabis" is known to the category check today. |
| `expected_searches` | Map searches the owner expects. One with no sweep on file becomes a team task and a hold; the client copy never mentions it. |
| `other_market_sources`, `other_market_label` | Directory sources from another market: left out of every directory count, flagged to the team. |
| `timezone` | IANA zone, when the store's state is not in the state table. |

The file fails closed: an unknown key, a file for another business, a malformed list, pattern or zone, or sources without
a label each stop the build with a message. `SETTINGS.md` records every refusal as run, the values still accepted that
should not be (OPEN-ITEMS section 5), what each key changed for Green Haven when removed, and where SEOS could store each
key so the file can be written from SEOS's own record.

## 5. The model: `report-data.json` (full detail: `contract/MODEL.md`, `contract/report-data.schema.json`)

`extract-v2.mjs` writes the model; `build-report.mjs` builds both documents from the model alone (plus its own stylesheet,
scripts and fonts). The model is the seam between "read SEOS" and "write the documents".

25 top-level keys: `meta`, `business`, `stores`, `you`, `rivals`, `maps`, `reviews`, `search`, `website`, `links`,
`listings`, `ai`, `checks`, `tasks`, `task_groups`, `plan`, `holds`, `ledger`, `compare`, `gaps`, `map`, `market`,
`verdict`, `counts`, `changes`. Green Haven: 43 checks, 34 tasks, 9 holds, 10 plan items, 24 comparison rows, 15 gap lines.

- `MODEL.md` describes all 1,472 keys: type, Green Haven value, meaning and source, and where each one shows. The last was
  measured, not written: each of 1,070 keys was changed in a copy and both documents rebuilt. 225 keys reach the
  Competitor Analysis, 338 the Action Plan, 697 neither, and a change to 28 stops a build.
- Closed sets checked against the code: check `status` (pass, watch, fail, na), `weight` (outcome, rank, practice, protect,
  data), `door` (maps, search, ai, website, links, overview); task `owner` (us, client, account, software); task `group`
  (first, ours, map, rank, reviews, page, content, links, speed, account, seos, data); and 20 more in `MODEL.md`.
- `node contract/validate-model.mjs contract/report-data.schema.json <report-data.json> [--plant]` checks a model against
  the schema (no dependencies). The schema was inferred from the Green Haven model, widened from the code, and passed on 21
  more models built from altered copies of the same answers.

## 6. The rules (full detail: `contract/RULES.md`, `contract/rules.json`, `contract/check-rules.mjs`)

Every threshold, status, order and cut, read off the code. `rules.json` holds them as data (50 check rules, 33 task rules,
11 kinds of hold, 22 comparison rows, 14 gap lines); `check-rules.mjs` re-evaluates them against a model and both documents
and holds no threshold of its own.

- **Loss first** (`meta.order = 'loss-first'`). The headline names the biggest loss, then the best win ("Nowhere for
  "weed near me"." then "First for "dispensary near me", by 1 point."). Map searches, gap lines and checks inside each tab
  run loss first; the board runs Wrong, To look at, Right; the plan follows a fixed order (`SALES_ORDER`) in buckets.
- **Statuses**: pass ("Good"), watch ("Needs a look"), fail ("Needs fixing"), na ("Not measured", also a check on hold).
  Weight `data` marks a check about the run or the record, not the store: team only.
- **Holds**: a number that rests on a flawed reading is shown to the team with the reason and who clears it, and never
  quoted to a client. 11 kinds, from a map check taken out of hours to a count stopped at a collection limit.
- **The ten client-report rules** (top of `extract-v2.mjs`): holds; our own tags are ours; the client copy is a separate
  file; no capped counts; an empty read is "could not be read"; map counts printed as "58 of 121 points"; whole-website
  figures labelled; linking sites classified before counting; say what the tool saw; loss first. `RULES.md` section 7 maps
  each rule to the code and the gate that enforces it.
- **Gates inside the extractor**: a result claimed for an expected search with no sweep on file stops the build; a line a
  client can see that carries our tag stops it; the headline must lead with the biggest loss; with `--facts`, every number
  the model shares with the independent facts file must agree (Green Haven: 185 shared numbers, 0 disagree).

## 7. The outline (full detail: `contract/OUTLINE.md`, `contract/outline.json`, `contract/check-outline.mjs`)

| Document | Tabs | Blocks (headings) |
|---|---|---|
| Competitor Analysis | Overview, Google Maps, Google search, Website, Links and listings, The plan | 91 |
| Action Plan | Overview, Google Maps, Google search, AI answers, Website, Links and listings, Tasks | 188 |

Each block in `outline.json` has its heading template (with `{model key}` slots), the model keys it reads, when it is
shown, whether it is a comparison block (shown while the Compare switch is on), whether it is team-only, which document
prints it, the rule that places it and the source line. `check-outline.mjs` reads both documents independently and checks
every heading, its order and its template.

## 8. The wording (full detail: `contract/WORDING.md`, `contract/wording.json`, `contract/check-wording.mjs`)

247 entries in 16 sections: the headline rule, the frame, tiles, the map view, gaps, checks, tasks and plan, each tab,
comparison cards, empty states and formats. Each entry is a fixed phrase or a template with `{slots}`, what each slot reads
from the model, the condition that selects it, and the code line that writes it. Example, entry `verdict.loss-line.none`
(`extract-v2.mjs:1209`), the line under the headline when the store is in no top 3 and not in the first 20 at any point:

```
For "{kw}" {short} is not in Google's top 3 at any of the {n} map points, and not in the first 20 at any of them;
{leader}, at number 1, holds {floor|if:at least }{leader_points}.
```

Green Haven: "For "weed near me" Green Haven is not in Google's top 3 at any of the 121 map points, and not in the first 20
at any of them; Joyleaf, at number 1, holds at least 117." Its siblings `verdict.loss-line.lower` (listed lower down) and
`verdict.loss-line.placed` (in some top 3s) are chosen by the same rule from the same search's counts.

212 entries are verified: rendered from Green Haven's values, read back from the model by path, and found verbatim in a
document. 35 are branches the Green Haven data does not reach, read from the code; `check-wording.mjs` checks that no
document text fits them. Numbers, ordinals, place words, lists, plurals and escaping follow the formats table at the top
of `WORDING.md` (en-US thousands separators; long dashes print as hyphens).

## 9. The two cuts (full detail: `contract/RULES.md` section 6)

`build-report.mjs` first builds one page holding both views, then cuts one view out of the file itself.

- **Competitor Analysis** (`--audience=client`): every Service-only and team block is removed. Then the leak gate reads the
  finished file: no Service block, no team block, no view switch, no "software team" or "on hold", no number on hold (each
  hold carries its own patterns), no tool name, no `utm_` tag of ours, no capped count. One hit stops the build.
- **Action Plan** (`--audience=service`): every check, task and hold about our other accounts is left out (matched by the
  `XACCT` pattern; Green Haven: 2 checks, 1 task, 1 hold), and the build prints what it left out. Gates: no kept item may
  point at one left out, and the tiles may not count one. Then every Sales-only block is removed, and the finished file is
  read again for Sales blocks, the view switch and `XACCT`.
- `--doc="<name>"` names the document in the browser title ("Green Haven Elizabeth · Action Plan"), the header and the
  overview's first line.
- Publishing the Action Plan to a public host: `reference/static-password-gate/gate.mjs` encrypts the finished file
  (PBKDF2-SHA256, 250,000 rounds, then AES-256-GCM, decrypted in the browser). The password comes from the `PASSOFF_PW`
  environment variable and is never stored in a file. A gated file on a public host can be attacked offline, so use a
  long random passphrase, not a number (OPEN-ITEMS N8); better, SEOS serves the Action Plan behind its own login.

## 10. Determinism: what makes it repeatable, and the proof

| Source of variation | How it is handled |
|---|---|
| The clock | One read: `meta.built_at` in the model. No document prints it, and conformance leaves it out. |
| The Eagle Eyes export's file time | `ee-scan-to-seos.mjs:70` stamps the sweep's `read_at` with it, and that reaches `market.json` and the model (never the documents). `conformance.mjs` pins the recorded time before the run. A fix is open (OPEN-ITEMS M13). |
| The input files' bytes | `market.json` and the model record each input file's size and sha256. The same values written with other bytes give the same documents and different provenance fields only. A port must hash each input file's raw bytes as read. With an Eagle Eyes export folded in, the business answer recorded is `merge-sweep.mjs`'s copy; `<out>/data/merged-from.json` holds the original's sha256. |
| The package's own bytes | The documents inline `reference/report.css`, `client.js`, `mapview.js` and the fonts, and conformance compares bytes, so a line-ending conversion breaks it (shown: those three files in CRLF fail conformance). Keep every file exactly as shipped; the package's `.gitattributes` (`* -text`) stops git from converting them. |
| Sort order | JavaScript's `Array.prototype.sort` is stable (ECMAScript 2019 and later), and the code sorts on explicit keys. About 15 tie-breaks call `localeCompare` with no locale, so they follow the host's default collation; POSIX and Danish collation were simulated and gave the same bytes here. A port must sort stably on the same keys, comparing strings with an explicit locale (en-US) or by code point. |
| Dates, times and number formats | `Intl` with the business's IANA zone and en-US formats, from Node's bundled ICU and time zone data. Pin the Node major version (24) where SEOS runs it, and run conformance after any Node upgrade. |
| Fonts, styles, scripts | Inlined from `reference/fonts`, `report.css`, `client.js` and `mapview.js` at build time: the documents depend on those exact files. |
| The network | None. Every stage reads files and writes files. |

The proof, all on 2026-10-12:

- **From the raw SEOS answers** (unscrubbed, outside this package), `run-report.mjs` rebuilt `market.json` and both
  documents byte-identical to the live Green Haven files, and `report-data.json` equal apart from `meta.built_at`.
- **From the scrubbed fixture in this package**, both documents are byte-identical to the live ones: Competitor Analysis
  sha256 `fd7a98cc…09cf92`, Action Plan `3e599768…8992e7`. `market.json` and the model differ from the live ones only in
  the recorded size and sha256 of the scrubbed input files (5 and 13 paths); no computed value differs.
- **`node conformance/conformance.mjs`**: PASS (market.json and both documents byte for byte, the model apart from
  `meta.built_at`), 18.0 s, run after the last change to the fixture. The fixture's builder ran it twice earlier, and the
  independent check twice more: PASS every time.
- **Run twice by hand** (README step 2, twice, by the independent check): every output file byte-identical apart from
  `report-data.json`'s `meta.built_at`. With the export's file time changed: both documents byte-identical; `market.json`
  differs at 3 paths and the model at 5, as OPEN-ITEMS M13 says.

## 11. Variable data (full detail: `VARIANTS.md`)

The rules are written for any business's data, not for Green Haven's: any number of searches, rivals, directories,
reviews and linking sites; any mix of readings present or missing. Six variants, each one scripted change of the fixture,
were run through the same chain:

| Variant | What changed | Outcome |
|---|---|---|
| no-weed-scan | SEOS's answers alone, no "weed near me" sweep | Built. Headline becomes "Third for "cannabis near me"."; the Action Plan's task 1 is "Get the "weed near me" map check on file"; the Competitor Analysis never mentions "weed near me". |
| one-search | Only the "dispensary near me" sweep | Built. The headline has the win line only; the map-gap task drops out. |
| no-expected-search | As no-weed-scan, and no expected searches in the settings | Built. No missing-search task or hold. |
| other-vertical | `vertical` "Dental" | Built, but cannabis words remain in code-written sentences and a "Set the right main category" task appears for an unmeasured check (OPEN-ITEMS V1, section 3). |
| no-store-reviews | The store's Google reviews reading removed | Stopped at `check-sweeps-market.mjs` with a misleading message; past it, `extract-v2.mjs` crashes (OPEN-ITEMS M1, M2). |
| no-rival-pages | Every rival reading removed from the website audit | Built; two sentences come out malformed (OPEN-ITEMS M8, M9). |

`VARIANTS.md` gives, for each variant, the checks, tasks, holds and plan items added and removed, and the sentences that
appeared and went, quoted from the documents. `node fixtures/green-haven-48/variants/run-variants.mjs` rebuilds it, byte
for byte.

## 12. How to build it into SEOS

**Recommended route: run the reference as it is, as one step of SEOS, and accept it by conformance. Port it later only if
you want it in SEOS's own language, one stage at a time, with the model as the seam.** Running it as-is keeps every rule,
sentence and gate that is already proven, adds no dependency beyond Node 24, and the fixture test shows at once whether
the server's runtime gives the same bytes.

1. On the SEOS host: Node 24, and this package's `run-report.mjs`, `reference/`, `conformance/` and `fixtures/`, every
   file exactly as shipped (section 10). Run `node conformance/conformance.mjs --no-browser`; it must print
   `CONFORMANCE: PASS`. With Chrome installed, run it without `--no-browser` too (46 browser checks; set `CHROME_PATH` if
   Chrome is not in a usual place; run it as a normal user: as root Chrome needs `--no-sandbox`, which
   `check-documents.mjs` does not pass).
2. Store each business's settings (SETTINGS.md, "Where SEOS could store it") and write them out as the settings file.
3. Per report: save the three answers (and the two tables) for business `{id}` into a new folder under the names in
   section 3, exactly as the API returns them. The tables come in pages: merge every page into one list and keep the
   `total`. `locations-all.json` is every account's locations; the report reads it only to spot our own accounts on the
   map. Then run `node run-report.mjs --data=<folder> --settings=<file> --out=<new folder> --no-browser`.
4. Exit 0 (and `<out>/SHA256SUMS` present): publish `<out>/competitor-analysis.html` to the client side and
   `<out>/action-plan.html` to the team only. Keep the rest of `<out>` (the map file, the model, `SHA256SUMS`,
   `run-log.txt`, `logs/`, and with an export `data/` and `extra/`, with the browser check `screenshots/`) as the record
   of what was read and built. Any other exit: publish nothing, even when documents are in `<out>`: a stage after the
   builds (the class check, the browser check) may have failed with both documents already written (OPEN-ITEMS E13).
   `run-log.txt` and `logs/` name the stage that stopped the run and why. That is by design: a report that cannot be built
   correctly is not published.

What SEOS has to add for this to work for any business, beyond the code (OPEN-ITEMS section 1): stored settings; a sweep
of every expected search (until then an Eagle Eyes export can be folded in with `--extra-sweep`); and three data defects
the report itself flags in Green Haven's answers (another account's readings in the full audit, another market's
directory sources, map checks searched from a far vantage).

Before reports go out for businesses other than Green Haven, the reference code needs the fixes in OPEN-ITEMS sections 2
and 4: today a few sentences carry Green Haven's facts (for example "for Elizabeth and the towns around it"), and some
missing readings crash a stage.

**Porting later.** Port stage 2 (answers to model) or stage 3 (model to documents) on its own, and accept each with the
same fixture:

- A model from a port: `node conformance/conformance.mjs --model=<its report-data.json>` (equal to `expected/` apart from
  `meta.built_at` and `meta.facts_check`, the record of the Green Haven facts check, which a port need not have; every
  differing path is printed), then `validate-model.mjs`, `check-rules.mjs` and `check-wording.mjs`. Build the port's
  fixture model from `fixtures/green-haven-48/input/` with the export's file time pinned to the one in `fixture.json`
  (OPEN-ITEMS M13), as `conformance.mjs` does.
- Documents from a port: `node conformance/conformance.mjs --documents=<folder holding both files>` (byte for byte; the
  first differing byte is shown with its context), then `check-outline.mjs` and `check-wording.mjs`.
- A port must also hash input files' raw bytes, sort stably on the same keys, and format numbers, dates and escapes as the
  formats table in `WORDING.md` says.

## 13. Paths named in the contract files

The contract files were generated in our working tree, so some of them name its paths. In this package:

| Named in the contract files | In this package |
|---|---|
| `Product/seos-report/<script>` (extract-v2.mjs, build-report.mjs, sweeps-market.mjs, ...) and line numbers in it | `reference/<script>`: byte-identical copies, so every line number holds |
| `green-haven/merge-sweep.mjs` | `reference/merge-sweep.mjs` (byte-identical) |
| `green-haven/gh-facts.mjs`, `green-haven/gh-facts.json` | `fixtures/green-haven-48/oracle/` (byte-identical) |
| `green-haven/business-settings-48.json` | `fixtures/green-haven-48/settings.json` (byte-identical) |
| `green-haven/docs/competitor-analysis.html`, `action-plan.html` | `fixtures/green-haven-48/expected/` (byte-identical) |
| `green-haven/report-data.json`, `green-haven/market.json` | `fixtures/green-haven-48/expected/`: the same values apart from the scrubbed inputs' recorded size and sha256 (and `meta.built_at`) |
| `_data/green-haven-2026-10-12/` and `..._with-ee320/` (the raw SEOS answers) | `fixtures/green-haven-48/input/`, scrubbed (`input/SCRUBBED.md`) |
| `parts/*.json` | `parts/`: the four builders' own reports (see `parts/README.md`) |
| `RUN.md`, `DATA-NOTES.md` | not included: our working notes; this file and `OPEN-ITEMS.md` carry what they say that matters |

## 14. What was checked, and how

Run from the package root on 2026-10-12, Windows 11, Node 24.15.0, Chrome for the browser checks.

| Check | Command | Result |
|---|---|---|
| The whole chain on the fixture | `node conformance/conformance.mjs` | PASS: market.json and both documents byte for byte, the model apart from `meta.built_at`; 18.0 s |
| Stages inside that run | (logged by `run-report.mjs`) | map file second reading 1,697 checks, 0 disagree; facts 185 shared numbers, 0 disagree; comparison second reading 283 checks, 0 disagree; class checks PASS on both; browser checks 46 of 46 |
| Outline | `node contract/check-outline.mjs contract/outline.json <CA> <AP> --wording=contract/wording.json` | PASS: 91 and 188 headings, all in order, all fit their template |
| Outline is reproducible | `node contract/extract-outline.mjs <CA> <AP> <tmp>/outline.json --md=<tmp>/OUTLINE.md --src=reference` | both files byte-identical to `contract/` |
| Wording | `node contract/check-wording.mjs contract/wording.json <model> <CA> <AP> --src=reference` | PASS: 247 entries, 212 verified, 35 not exercised, 45 format cases, 371 values read back from the model, 247 source lines checked |
| Rules | `node contract/check-rules.mjs <model> --rules=contract/rules.json --md=contract/RULES.md --client-doc=<CA> --service-doc=<AP>` | PASS, 940 of 940: every check, task, hold, comparison row and gap line has its rule; 34 statuses and 41 values recomputed; orders, cuts and both documents agree |
| Model schema | `node contract/validate-model.mjs contract/report-data.schema.json <model> --plant` | PASS, 14,647 values; each planted mistake fails where it was planted |
| Settings schema | `node contract/validate-model.mjs contract/business-settings.schema.json fixtures/green-haven-48/settings.json` | PASS, 15 values |
| Variants | `node fixtures/green-haven-48/variants/run-variants.mjs` | 5 built, 1 stopped (as in section 11); `VARIANTS.md` and `results.json` byte-identical on rerun |
| Scrub | not rerunnable from the package: `fixtures/green-haven-48/scrub.mjs` needs the unscrubbed SEOS answers, and by default it rewrites `fixtures/green-haven-48/input/` | its own checks are recorded in `input/SCRUBBED.md` and `fixture.json` |
| Port acceptance modes | `conformance.mjs --model=` and `--documents=` on a run made the production way (no `--facts`); `--model=` on a copy with one value changed | PASS and PASS; the changed copy FAILS at that one path |
| Independent check | a separate agent re-ran every test above, checked 63 groups of claims in these documents against the code and the outputs, and re-ran both privacy scans | all tests PASS; 53 claim groups confirmed, 7 wrong and 3 not provable from the package. The 7 wrong ones, and its 26 findings, are fixed in this version or listed in `OPEN-ITEMS.md` |

`<CA>`, `<AP>` and `<model>` are `fixtures/green-haven-48/expected/competitor-analysis.html`, `action-plan.html` and
`report-data.json`.

Not verified: the browser checks on macOS or Linux (only the Windows Chrome path was run); a run with more than one
`--extra-sweep` (only one export exists); SEOS's table answers past 1,000 rows (paging); other businesses, other verticals
and multi-location brands beyond the scripted variants. The full lists are in `OPEN-ITEMS.md` section 9 and in each
part's `unverified` list in `parts/`.
