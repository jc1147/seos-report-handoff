// Password-encrypt the pass-off pages for squah-previews (public GitHub Pages).
// Same mechanism as squah-previews/build-system/index.html (commit b97dbc6d): PBKDF2-SHA256 250,000
// iterations -> AES-256-GCM, decrypted in the browser with WebCrypto, then document.write. The published
// file holds only ciphertext; the password is read from the env and never written to disk.
// Addition for a multi-page set: the password is remembered in sessionStorage (this tab only) so the
// links between the pages open without asking again; a stale value is dropped if it fails.
// Usage: PASSOFF_PW=... node gate.mjs <srcDir> <outDir> <file.html>...
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const PW = process.env.PASSOFF_PW;
const [SRC, OUT, ...FILES] = process.argv.slice(2);
if (!PW || !SRC || !OUT || !FILES.length) throw new Error('need PASSOFF_PW env, srcDir, outDir, files');
const ITER = 250000;
const KEYNAME = 'passoff-' + path.basename(OUT);

const gate = (salt, iv, data, title) => `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Protected — enter password</title>
<style>
  :root{color-scheme:dark}
  html,body{margin:0;height:100%}
  body{background:#0c0c0f;color:#f4f2ee;font-family:system-ui,-apple-system,Segoe UI,sans-serif;display:grid;place-items:center}
  .gate{width:min(92vw,380px);text-align:center;padding:34px 30px;border:1px solid rgba(255,255,255,.10);border-radius:16px;background:linear-gradient(180deg,#141418,#101013);box-shadow:0 24px 60px rgba(0,0,0,.5)}
  .lock{font-size:30px;margin-bottom:6px}
  h1{font-size:17px;font-weight:800;letter-spacing:-.01em;margin:0 0 4px}
  p{font-size:13px;color:rgba(255,255,255,.55);margin:0 0 18px}
  input{width:100%;box-sizing:border-box;padding:13px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.16);background:#0c0c0f;color:#f4f2ee;font-size:15px;outline:none}
  input:focus{border-color:#d51522}
  button{width:100%;margin-top:12px;padding:13px 14px;border:0;border-radius:10px;background:#d51522;color:#fff;font-weight:800;font-size:15px;cursor:pointer}
  .err{color:#ff6b74;font-size:12.5px;min-height:16px;margin-top:10px}
</style></head>
<body>
  <form class="gate" id="g" autocomplete="off">
    <div class="lock">&#128274;</div>
    <h1>${title}</h1>
    <p>Enter the password to view.</p>
    <input id="pw" type="password" inputmode="numeric" placeholder="Password" aria-label="Password" autofocus>
    <button type="submit">Unlock</button>
    <div class="err" id="e"></div>
  </form>
<script>
(function(){
  var SALT="${salt}",IV="${iv}",DATA="${data}",ITER=${ITER},KEY="${KEYNAME}";
  function b(s){return Uint8Array.from(atob(s),function(c){return c.charCodeAt(0);});}
  async function unlock(pw){
    var enc=new TextEncoder();
    var bk=await crypto.subtle.importKey("raw",enc.encode(pw),"PBKDF2",false,["deriveKey"]);
    var k=await crypto.subtle.deriveKey({name:"PBKDF2",salt:b(SALT),iterations:ITER,hash:"SHA-256"},bk,{name:"AES-GCM",length:256},false,["decrypt"]);
    var pt=await crypto.subtle.decrypt({name:"AES-GCM",iv:b(IV)},k,b(DATA));
    return new TextDecoder().decode(pt);
  }
  function show(html){document.open();document.write(html);document.close();}
  function remember(pw){try{sessionStorage.setItem(KEY,pw);}catch(_){}}
  var saved=null;try{saved=sessionStorage.getItem(KEY);}catch(_){}
  if(saved){unlock(saved).then(show).catch(function(){try{sessionStorage.removeItem(KEY);}catch(_){}});}
  document.getElementById("g").addEventListener("submit",function(ev){
    ev.preventDefault();
    var e=document.getElementById("e"),pw=document.getElementById("pw").value;e.textContent="Checking...";
    unlock(pw).then(function(html){remember(pw);show(html);}).catch(function(){ e.textContent="Wrong password."; });
  });
})();
</script>
</body></html>
`;

fs.mkdirSync(OUT, { recursive: true });
for (const f of FILES) {
  const plain = fs.readFileSync(path.join(SRC, f));
  const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12);
  const key = crypto.pbkdf2Sync(PW, salt, ITER, 32, 'sha256');
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([c.update(plain), c.final(), c.getAuthTag()]); // WebCrypto wants ciphertext||tag
  // round-trip before writing: the file must decrypt to the exact source bytes
  const d = crypto.createDecipheriv('aes-256-gcm', key, iv);
  d.setAuthTag(ct.subarray(ct.length - 16));
  const back = Buffer.concat([d.update(ct.subarray(0, ct.length - 16)), d.final()]);
  if (!back.equals(plain)) throw new Error(`${f}: round-trip mismatch`);
  const html = gate(salt.toString('base64'), iv.toString('base64'), ct.toString('base64'), 'Team pass-off');
  if (html.includes(PW)) throw new Error(`${f}: password leaked into the page`);
  fs.writeFileSync(path.join(OUT, f), html);
  console.log(`${f}: ${plain.length} B plain -> ${html.length} B gated (round-trip OK)`);
}
