// extract-v2.mjs: the SEO health report's data from SEOS's three-answer data API, in the same 25-key contract
// extract.mjs writes (build-report.mjs reads it). The business answer (GET /businesses/{id}) carries the business
// tables and the map sweeps; the full-audit and website-audit answers carry the vendor readings, keyed by place:
// the store's own, its rivals' and the field's. Every reading is picked by kind AND place id. (extract.mjs's
// reading(k) takes the first row of a kind, which in these answers would be a rival's.)
// usage: node extract-v2.mjs <business.json> <full-audit.json> <website-audit.json> <out report-data.json>
//          [--settings=file] [--market=file] [--prev=file] [--all-sweeps=file] [--locations=file] [--facts=gh-facts.json]
//   --settings    the business's settings as a file (brand, short name, name spellings, agency tag, vertical, the searches
//                 the owner expects, another market's directory sources and their label, and a time zone for a state the
//                 table below lacks). It takes the place of the
//                 SETTINGS table below, so a new business needs no code change; without it the table is used, as before.
//   --facts       the independent facts file (green-haven/gh-facts.mjs): every number both hold must agree, or the build stops
//   --market      the market file sweeps-market.mjs builds from the store's map sweeps (the HS market.json schema).
//                 A sweep added to it later (sweeps-market --extra) reaches the verdict, the checks and the gap
//                 lines with no code change here.
//   --prev        the report-data.json of the run before this one; turns on "what changed since the last run"
//   --all-sweeps  SEOS's list of every sweep (engine_sweeps-all.json); only used to say how many were searched for
//   --locations   SEOS's list of every location (locations-all.json): our own accounts in the map field, a team-only line
//                 a search the owner expects and the record does not hold
// Rules kept here (each was a blocker on the HS build; where a check is possible it is made in code):
//   1. A number that rests on a flawed reading is ON HOLD: shown to the team with the reason and who clears it,
//      never quoted to a client, never leaned on by the headline. Each sweep is tested for its time against the
//      posted hours in the store's time zone, how it was started, points left out, and an out-of-market field
//      (a far business in any top 3 puts the sweep on hold; far businesses lower in the lists are a note).
//   2. Evidence that carries the agency's own tag (utm_* = the agency) is OURS: team only.
//   3. The client copy is a separate file: build-report.mjs --audience=client.
//   4. A count that stopped at a collection limit is not printed as the count (step notes and reading totals).
//   5. An empty read is "could not be read", never "not there".
//   6. Map points are counted from each sweep's own cells, so counts are printed: "58 of 121 points".
//   7. Whole-website figures are labelled as whole-website figures.
//   8. Linking-site totals are classified first (link sellers and scheme pages out), then counted.
//   9. Say what the tool saw; two fields of one reading that disagree are "not confirmed".
//  10. The owner's ordering for this report: where the store is losing first, where it is winning last
//      (meta.order = 'loss-first', which build-report.mjs reads).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const argv = process.argv.slice(2);
const [bizPath, fullPath, webPath, outPath] = argv.filter(a => !a.startsWith('--'));
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
const prevPath = opt('prev'), marketPath = opt('market'), allSweepsPath = opt('all-sweeps');
if (!bizPath || !fullPath || !webPath || !outPath) { console.error('usage: node extract-v2.mjs <business.json> <full-audit.json> <website-audit.json> <out.json> [--market=file] [--prev=file] [--all-sweeps=file]'); process.exit(2); }
const die = m => { console.error('EXTRACT FAILED: ' + m); process.exit(1); };
const load = p => { const raw = fs.readFileSync(p); let json; try { json = JSON.parse(raw.toString('utf8')); } catch (e) { die(`${path.basename(p)} is not JSON: ${e.message}`); } return { raw, json, file: path.basename(p), bytes: raw.length, sha256: crypto.createHash('sha256').update(raw).digest('hex') }; };
const A = load(bizPath), FA = load(fullPath), WA = load(webPath);
const t = A.json.tables || die('the business answer has no tables');
const biz = t.businesses?.[0] || die('no business row');
const loc = t.locations?.[0] || die('no location row');
for (const [x, kind] of [[FA, 'full-audit'], [WA, 'website-audit']]) {
  if (x.json.business_id !== biz.id) die(`${x.file} is about business ${x.json.business_id}, not ${biz.id}`);
  if (x.json.audit !== kind) die(`${x.file} is not the ${kind} answer`);
}

// What the record does not carry about a business. Everything else is read from the record.
//   brand / short: the name as Google shows it, and the short form the page uses
//   brandTerms: the name and its close spellings
//   agency: our own name as it appears in the tags we put on links (utm_medium)
//   vertical: the record's vertical is empty for some businesses
//   expect: searches the owner expects a map check for; one that is missing becomes a task, never a result
//   otherMarketSources: directory sources in the software's list for this store that name another market's places
//     (the record does not carry a source's state). Green Haven's list still holds the New Buffalo, Michigan sources
//     copied from High Society's registry: Michigan, New Buffalo, Berrien County, Harbor Country, the US-12 Heritage
//     Trail. They are left out of every directory count and denominator, and named to the team as a defect.
const SETTINGS = {
  26: { brand: 'High Society', brandTerms: ['high society', 'hi society', 'highsociety', 'hisociety', 'higher society', 'high social'], agency: 'Dispenza' },
  48: { brand: 'Green Haven Industries', short: 'Green Haven', brandTerms: ['green haven', 'greenhaven', 'green haven industries'], agency: 'Dispenza', vertical: 'Cannabis', expect: ['weed near me'],
    otherMarketSources: /michigan|new-?buffalo|berrien|harbor-?country|us-?12/i, otherMarketLabel: 'Michigan' },
};
// --settings: the same settings read from a file (snake_case keys, business-settings.schema.json). Fails closed on a key it
// does not know, a file about another business, a malformed list or pattern, and sources with no label to name them by.
const settingsFrom = p => {
  let s; try { s = JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { die(`the settings file ${path.basename(p)} is not JSON: ${e.message}`); }
  const known = ['$schema', 'note', 'business_id', 'brand', 'short', 'brand_terms', 'agency', 'vertical', 'expected_searches', 'other_market_sources', 'other_market_label', 'timezone'];
  const unknown = Object.keys(s).filter(k => !known.includes(k)); if (unknown.length) die(`the settings file has keys this extractor does not know: ${unknown.join(', ')}`);
  if (s.business_id !== biz.id) die(`the settings file is for business ${s.business_id}, not ${biz.id}`);
  for (const k of ['brand', 'short', 'agency', 'vertical', 'other_market_label']) if (s[k] !== undefined && (typeof s[k] !== 'string' || !s[k].trim())) die(`settings.${k} must be a non-empty string`);
  for (const k of ['brand_terms', 'expected_searches']) if (s[k] !== undefined && (!Array.isArray(s[k]) || !s[k].every(x => typeof x === 'string' && x.trim()))) die(`settings.${k} must be a list of non-empty strings`);
  if (s.other_market_sources !== undefined && !s.other_market_label) die('settings.other_market_sources needs other_market_label, the name the team reads for those sources');
  let re; if (s.other_market_sources !== undefined) { try { re = new RegExp(s.other_market_sources, 'i'); } catch (e) { die(`settings.other_market_sources is not a pattern: ${e.message}`); } }
  if (s.timezone !== undefined) { try { new Intl.DateTimeFormat('en-US', { timeZone: s.timezone }); } catch { die(`settings.timezone is not a time zone: ${s.timezone}`); } }
  return { brand: s.brand, short: s.short, brandTerms: s.brand_terms, agency: s.agency, vertical: s.vertical, expect: s.expected_searches, otherMarketSources: re, otherMarketLabel: s.other_market_label, timezone: s.timezone };
};
const set = opt('settings') ? settingsFrom(opt('settings')) : (SETTINGS[biz.id] || {});
const TZ = { MI: 'America/Detroit', OH: 'America/New_York', PA: 'America/New_York', NY: 'America/New_York', NJ: 'America/New_York', MA: 'America/New_York', FL: 'America/New_York', CT: 'America/New_York',
  IL: 'America/Chicago', TX: 'America/Chicago', OK: 'America/Chicago', MN: 'America/Chicago', MO: 'America/Chicago', WI: 'America/Chicago',
  CO: 'America/Denver', NM: 'America/Denver', MT: 'America/Denver', AZ: 'America/Phoenix', CA: 'America/Los_Angeles', NV: 'America/Los_Angeles', WA: 'America/Los_Angeles', OR: 'America/Los_Angeles' };
const tz = set.timezone || TZ[loc.state] || die(`no time zone known for state ${loc.state}: give settings.timezone`);

// ---------- small helpers (as in extract.mjs) ----------
const squash = s => String(s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
const sum = (a, f = x => x) => a.reduce((s, x) => s + (f(x) || 0), 0);
const mean = a => a.length ? sum(a) / a.length : null;
const r1 = x => x === null || x === undefined ? null : Math.round(x * 10) / 10;
const r2 = x => x === null || x === undefined ? null : Math.round(x * 100) / 100;
const tally = (a, f) => a.reduce((o, x) => { const k = f(x); o[k] = (o[k] || 0) + 1; return o; }, {});
const host = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return String(u || '').replace(/^www\./, ''); } };
const pathOf = u => { try { return new URL(u).pathname; } catch { return String(u || ''); } };
const param = (u, p) => { try { return new URL(u).searchParams.get(p); } catch { return null; } };
const when = s => { if (!s) return null; let x = String(s).trim().replace(' +00:00', 'Z').replace('+00:00', 'Z').replace(' ', 'T').replace(/(\.\d{3})\d+/, '$1'); if (!/Z$/.test(x)) x += 'Z'; const d = new Date(x); return isNaN(d) ? null : d; };
const local = (d, o) => d ? new Intl.DateTimeFormat('en-US', { timeZone: tz, ...o }).format(d) : null;
const day = d => local(d, { month: 'short', day: 'numeric', year: 'numeric' });
const dayTime = d => d ? `${local(d, { weekday: 'short', month: 'short', day: 'numeric' })}, ${local(d, { hour: 'numeric', minute: '2-digit' })}` : null;
const clock = d => local(d, { hour: 'numeric', minute: '2-digit' });
const localParts = d => Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23', weekday: 'long' }).formatToParts(d).map(p => [p.type, p.value]));
const storeDay = d => { const p = localParts(d); return `${p.year}-${p.month}-${p.day}`; };
const clip = (s, n) => { const a = Array.from(String(s ?? '').replace(/\s+/g, ' ').trim()); return a.length > n ? a.slice(0, n - 1).join('').trimEnd() + '…' : a.join(''); };
const shortName = nm => { let x = String(nm).split(' - ')[0]; for (const w of [' Weed', ' Cannabis', ' Dispensary', ' Marijuana', ' Recreational']) { const i = x.indexOf(w); if (i >= 3) x = x.slice(0, i); } return x.trim(); };
const title = s => String(s).replace(/^(has|is|welcomes|serves|offers|accepts|requires)_/, '').replace(/_/g, ' ').replace(/^\w/, c => c.toUpperCase());
const n = x => x === null || x === undefined ? null : (Number(x) === 0 ? 0 : Number(x)).toLocaleString('en-US');
const plural = (k, one, many) => `${n(k)} ${k === 1 ? one : many}`;
const cap = s => String(s).replace(/(^|\s|-)\w/g, c => c.toUpperCase());
const nth = k => `${k}${k % 100 >= 11 && k % 100 <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][k % 10] || 'th'}`;
const listOf = a => (a.length <= 1 ? a.join('') : `${a.slice(0, -1).join(', ')} and ${a[a.length - 1]}`);
const KM_PER_MI = 1.609344;

// ---------- the readings: both audit answers, picked by kind AND place ----------
const READS = [];
for (const x of [FA, WA]) for (const r of x.json.tables?.vendor_readings || []) READS.push({ ...r, answer: x.json.audit });
const readingOf = (k, pid) => READS.filter(r => r.kind === k && r.place_id === pid).sort((a, b) => String(b.fetched_at).localeCompare(String(a.fetched_at)))[0] || null;

// ---------- the run this report is built on: the one with the most steps; the full-audit answer must be it ----------
const runs = [...(t.audit_runs || [])].sort((a, b) => (b.steps?.length || 0) - (a.steps?.length || 0));
const run = runs[0] || die('no audit run in the record');
if (FA.json.tables?.audit_runs?.[0]?.id !== run.id) die(`the full-audit answer is about run ${FA.json.tables?.audit_runs?.[0]?.id}, the record's main run is ${run.id}`);
const webRun = WA.json.tables?.audit_runs?.[0] || null;
const runStart = when(run.started_at), runEnd = when(run.finished_at);
const parts = run.request?.parts || {};
const subject = run.businesses.find(b => b.is_subject) || die('run names no subject');
const subjectPid = subject.place_id;
if (subjectPid !== loc.place_id) die('the run is about another place than the location row');
const reading = k => readingOf(k, subjectPid);
const profileOf = pid => readingOf('business_info', pid)?.result?.business_info?.items?.[0] || null;

// ---------- Google listing ----------
const biR = reading('business_info') || die('no Google listing reading for the store');
const bi = biR.result?.business_info?.items?.[0] || die('the store\'s Google listing reading is empty');
const listingUrl = (() => { try { return new URL(bi.url); } catch { return null; } })();
const domain = (bi.domain || host(loc.website)).replace(/^www\./, '');
const citySlug = squash(loc.city);
const agency = (set.agency || '').toLowerCase();
const tagOf = u => { try { const x = new URL(u); return [...x.searchParams].filter(([k]) => /^utm_/i.test(k)); } catch { return []; } };
const isOurs = u => !!agency && tagOf(u).some(([, v]) => v.toLowerCase() === agency);
const tag = listingUrl?.searchParams.get('utm_source') || null;
const tagStore = tag && /^gmb-/i.test(tag) ? tag.replace(/^gmb-/i, '').replace(/^outlet-/i, '') : null;
const tagOurs = !!listingUrl && isOurs(listingUrl.toString());
const avail = bi.attributes?.available_attributes || {};
const hours = (() => {
  const tt = bi.work_time?.work_hours?.timetable; if (!tt) return null;
  const h = v => { const ap = v.hour >= 12 ? 'PM' : 'AM'; const hh = v.hour % 12 || 12; return `${hh}${v.minute ? ':' + String(v.minute).padStart(2, '0') : ''} ${ap}`; };
  const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].map(d => ({ day: d, open: tt[d]?.[0] ? h(tt[d][0].open) : null, close: tt[d]?.[0] ? h(tt[d][0].close) : null, closeMins: tt[d]?.[0] ? tt[d][0].close.hour * 60 + tt[d][0].close.minute : null, openMins: tt[d]?.[0] ? tt[d][0].open.hour * 60 + tt[d][0].open.minute : null }));
  const same = days.every(d => d.open && d.open === days[0].open && d.close === days[0].close);
  // the week as Google lists it, run together where days share hours
  const runsOf = []; for (const d of days) { const last = runsOf[runsOf.length - 1]; if (last && last.open === d.open && last.close === d.close) last.to = d.day; else runsOf.push({ from: d.day, to: d.day, open: d.open, close: d.close }); }
  const dn = s => cap(s.slice(0, 3));
  const week = runsOf.map(r => `${dn(r.from)}${r.to !== r.from ? ' to ' + dn(r.to) : ''} ${r.open ? `${r.open} to ${r.close}` : 'closed'}`).join(', ');
  return { days, summary: same ? `${days[0].open} to ${days[0].close}, every day` : week, daysListed: days.filter(d => d.open).length };
})();
const inHours = d => { if (!d || !hours) return null; const p = localParts(d), row = hours.days.find(x => x.day === p.weekday.toLowerCase()); if (!row || row.closeMins === null) return null; const m = Number(p.hour) * 60 + Number(p.minute); return m >= row.openMins && m <= row.closeMins; };
const hoursOn = d => { if (!d || !hours) return null; const p = localParts(d); const r = hours.days.find(x => x.day === p.weekday.toLowerCase()); return r && r.open ? `${r.open} to ${r.close}` : null; };
const closeOn = d => { if (!d || !hours) return null; const p = localParts(d); return hours.days.find(x => x.day === p.weekday.toLowerCase())?.close || null; };
const business = {
  id: biz.id, name: bi.title || set.brand || biz.name, short: set.short || set.brand || shortName(biz.name), vertical: biz.vertical || set.vertical || null, vertical_from_settings: !biz.vertical && !!set.vertical,
  register_name: biz.name,
  street: loc.street, city: loc.city, state: loc.state, zip: loc.zip, phone: bi.phone || loc.phone, website: loc.website, domain,
  category: bi.category, category_ids: bi.category_ids || [], extra_categories: bi.additional_categories || [],
  claimed: bi.is_claimed === true, rating: bi.rating?.value ?? null, ratings: bi.rating?.votes_count ?? null,
  rating_dist: bi.rating_distribution || null, photos: bi.total_photos ?? null,
  hours, service_options: (avail.service_options || []).map(title),
  attributes: Object.entries(avail).flatMap(([, list]) => list.map(title)),
  topics: Object.entries(bi.place_topics || {}).map(([label, c]) => ({ label, n: c })).sort((a, b) => b.n - a.n),
  listing_link: listingUrl ? listingUrl.origin + listingUrl.pathname : null, listing_full_link: listingUrl ? listingUrl.toString() : null, listing_path: listingUrl?.pathname || null,
  listing_is_homepage: listingUrl ? (listingUrl.pathname === '/' || listingUrl.pathname === '') : null,
  listing_tag: tag, listing_tag_store: tagStore, listing_tag_matches: tagStore ? squash(tagStore) === citySlug : null, listing_tag_ours: tagOurs, listing_fixed_link: null,
  also_viewed: (bi.people_also_search || []).map(p => ({ name: p.title, short: shortName(p.title), rating: p.rating?.value ?? null, ratings: p.rating?.votes_count ?? null })),
  profile_read_at: day(when(biR.fetched_at)),
};

// ---------- the map sweeps, point by point (business answer: engine_sweeps, _cells, _businesses, _fields, engine_actors) ----------
const sweepRows = t.engine_sweeps || [];
const namesSeen = new Map(); // place id -> the name a sweep listed it under
for (const b of t.engine_sweep_businesses || []) if (b.name && !b.is_subject) namesSeen.set(b.place_id, b.name);
// short names, kept apart where two businesses would share one ("Green Leaf" is two stores here)
const fullName = pid => pid === subjectPid ? business.name : (profileOf(pid)?.title || namesSeen.get(pid) || pid);
const shortOf = (() => { const pids = [...new Set([...namesSeen.keys(), ...run.businesses.map(b => b.place_id)])].filter(p => p !== subjectPid); const base = Object.fromEntries(pids.map(p => [p, shortName(fullName(p))])); const counts = tally(Object.values(base), x => x.toLowerCase());
  return pid => pid === subjectPid ? business.short : (counts[(base[pid] || '').toLowerCase()] > 1 ? clip(fullName(pid), 34) : base[pid] || shortName(fullName(pid))); })();
const farAddr = rows => { const towns = tally(rows.map(b => { const m = String(b.address || '').match(/,\s*([A-Za-z .'-]+),\s*([A-Z]{2})\b/); return m ? `${m[1].trim()}, ${m[2]}` : null; }).filter(Boolean), x => x); return Object.entries(towns).sort((a, b) => b[1] - a[1]).map(([k]) => k); };
const SW = sweepRows.map(s => {
  const cellsRow = (t.engine_sweep_cells || []).find(c => c.scan_id === s.scan_id) || null;
  const cells = cellsRow?.cells || [];
  const rows = (t.engine_sweep_businesses || []).filter(b => b.scan_id === s.scan_id);
  const nPts = cells.length;
  const count = new Map();
  // each point's list is read to its first 20, the depth every point has: the centre point also carries the whole feed
  // (118 places in 352), and a business seen only past 20 there is not "seen on the map" (integration fix, 2026-10-12)
  const first20 = c => (c.top || []).slice(0, 20);
  for (const c of cells) first20(c).forEach((pid, i) => { const o = count.get(pid) || { top3: 0, found: 0 }; o.found++; if (i < 3) o.top3++; count.set(pid, o); });
  const mine = count.get(subjectPid) || { top3: 0, found: 0 };
  // a second reading of the store's own points: its rank field at each point
  const byRank = { top3: cells.filter(c => c.rank !== null && c.rank !== undefined && c.rank <= 3).length, found: cells.filter(c => c.rank !== null && c.rank !== undefined).length };
  const field = rows.map(b => { const c = count.get(b.place_id) || { top3: 0, found: 0 }; return { pid: b.place_id, name: fullName(b.place_id), short: shortOf(b.place_id), is_you: b.place_id === subjectPid, top3: c.top3, found: c.found, solv: b.solv, rating: b.rating, reviews: b.reviews, km: b.distance_km, lat: b.lat, lng: b.lng }; })
    .sort((a, b) => b.top3 - a.top3 || b.found - a.found || a.short.localeCompare(b.short));
  const unlisted = [...count.keys()].filter(p => !rows.some(b => b.place_id === p)).length;
  // the software's share for each business is a third reading of the same points
  const shareOff = rows.filter(b => typeof b.solv === 'number' && nPts && Math.abs(100 * (count.get(b.place_id)?.top3 || 0) / nPts - b.solv) > 0.01);
  const farRows = rows.filter(b => typeof b.distance_km === 'number' && b.distance_km > 150 * KM_PER_MI), farSet = new Set(farRows.map(b => b.place_id));
  // another area's businesses (more than 150 miles away) are never part of the field: not in its size, not in a place
  const others = field.filter(f => !f.is_you && !farSet.has(f.pid));
  const lead = field.find(f => !farSet.has(f.pid)) || null, best = others[0] || null;
  const you_lead = !!lead && mine.top3 > 0 && mine.top3 >= (best ? best.top3 : 0);
  // a place by share only when the store is in a top 3 somewhere
  const place = mine.top3 ? 1 + others.filter(f => f.top3 > mine.top3).length : null;
  const tied = others.some(f => f.top3 === mine.top3 && mine.top3 > 0);
  const actor = (t.engine_actors || []).find(a => a.kind === 'scan' && a.ref === String(s.scan_id)) || null;
  const finished = when(s.finished_at), started = when(actor?.at);
  const open = inHours(finished), openAtStart = started ? inHours(started) : null;
  const farPts = cells.filter(c => first20(c).some(p => farSet.has(p))), farTop3 = cells.filter(c => (c.top || []).slice(0, 3).some(p => farSet.has(p))).length;
  const notFound = cells.filter(c => c.rank === null || c.rank === undefined);
  // rule 1 and rule 9: a far business in a point's top 3 pushes the businesses below it down. The second reading takes the far
  // businesses out of each point's list and reads its top 3 again. When it gives the store the same count, the store's numbers
  // stand and the check is quoted; the others' counts are what the tool saw, and a floor (the second reading can only lift them).
  const cleanTop3 = pid => cells.filter(c => (c.top || []).filter(p => !farSet.has(p)).slice(0, 3).includes(pid)).length;
  const youClean = farTop3 ? cleanTop3(subjectPid) : mine.top3, leadClean = farTop3 && lead ? cleanTop3(lead.pid) : (lead ? lead.top3 : null);
  const grid = (s.grid_size || 0) * (s.grid_size || 0);
  const holdReasons = [
    open === false || openAtStart === false ? `It ran at ${clock(started || finished)} to ${clock(finished)} on ${local(finished, { weekday: 'long' })}, outside the posted hours (${hoursOn(finished) || 'closed'}). A closed store can rank differently from an open one.` : null,
    farTop3 && youClean !== mine.top3 ? `At ${farTop3} of its ${nPts} points a business about ${n(Math.round(Math.min(...farRows.map(b => b.distance_km)) / KM_PER_MI))} miles away is in the top 3, and without it the store's count would be ${youClean}, not ${mine.top3}.` : null,
    nPts !== s.total_points ? `The sweep says ${s.total_points} points and its cells hold ${nPts}.` : null,
    byRank.top3 !== mine.top3 ? `The store's own rank field gives ${byRank.top3} points in the top 3, its place in the lists gives ${mine.top3}.` : null,
    shareOff.length ? `The software's share and the points disagree for ${shareOff.length} businesses.` : null,
  ].filter(Boolean);
  return {
    id: String(s.scan_id), kw: String(s.keyword || '').toLowerCase(), grid: s.grid_size, radius: s.radius, unit: s.unit, n: nPts, total_points: s.total_points, grid_points: grid, excluded: grid ? grid - nPts : null, exclusion_note: s.exclusion_note || null,
    you: { top3: mine.top3, found: mine.found, by_rank: byRank, solv: s.solv, arp: s.arp, atrp: s.atrp, not_found_points: notFound.length }, field, unlisted, share_mismatches: shareOff.length,
    // the field: businesses in a first 20 at one point or more (the market file's field, which the map table prints)
    place, tied, of: field.filter(f => (f.found > 0 || f.is_you) && !farSet.has(f.pid)).length, of_all: field.filter(f => f.found > 0 || f.is_you).length, rows_listed: field.length, you_lead, lead, best, finished, started, open, open_at_start: openAtStart,
    // the store's not-found points that carry another area's business in their first 20: not a confirmed "not there"
    unconfirmed_not_found: notFound.filter(c => first20(c).some(p => farSet.has(p))).map(c => first20(c).filter(p => farSet.has(p)).length),
    started_how: s.started_how || null, started_by_hand: !!actor, starter_role: actor?.role || null,
    far: { rows: farRows.length, of: rows.length, within_25: rows.filter(b => typeof b.distance_km === 'number' && b.distance_km <= 25 * KM_PER_MI).length, mid: rows.filter(b => typeof b.distance_km === 'number' && b.distance_km > 25 * KM_PER_MI && b.distance_km <= 150 * KM_PER_MI).length,
      over_150: farRows.length, miles: farRows.length ? [Math.round(Math.min(...farRows.map(b => b.distance_km)) / KM_PER_MI), Math.round(Math.max(...farRows.map(b => b.distance_km)) / KM_PER_MI)] : null,
      towns: farAddr(farRows).slice(0, 2), points: farPts.length, most_in_a_list: farPts.length ? Math.max(...farPts.map(c => first20(c).filter(p => farSet.has(p)).length)) : 0, in_top3: farTop3,
      not_found_with_far: notFound.filter(c => first20(c).some(p => farSet.has(p))).length },
    hold: holdReasons.length > 0, hold_reasons: holdReasons, centre: cellsRow ? [cellsRow.centre_lat, cellsRow.centre_lng] : null,
    far_pids: [...farSet], leader_floor: !!(farTop3 && lead && leadClean !== lead.top3),
    clean: farTop3 ? { you: youClean, top: field.filter(f => !farSet.has(f.pid) && !f.is_you).slice(0, 4).map(f => ({ short: f.short, tool: f.top3, clean: cleanTop3(f.pid) })) } : null,
  };
});
const mainSweep = SW.find(s => s.id === String(run.scan_id)) || SW[0] || null;

// one row per search on file, the same shape whether it comes from the record or from the market file
const searchRow = s => ({ key: 'scan-' + s.id, scan_id: s.id, kw: s.kw, when: `${local(s.finished, { weekday: 'short' })}, ${day(s.finished)}, ${clock(s.finished)}`, date: day(s.finished), ts: Math.round(+s.finished / 1000),
  n: s.n, you: s.you.top3, found: s.you.found, place: s.place, tied: s.tied, of: s.of, you_lead: s.you_lead,
  leader: s.you_lead ? business.short : s.lead.short, leader_full: s.you_lead ? business.name : s.lead.name, leader_pid: s.you_lead ? subjectPid : s.lead.pid, leader_points: s.you_lead ? s.you.top3 : s.lead.top3,
  second: s.best ? s.best.short : null, second_pid: s.best ? s.best.pid : null, second_points: s.best ? s.best.top3 : null,
  open: s.open, hold: s.hold, hold_reasons: s.hold_reasons, checks: 1, source: 'record', leader_floor: !!s.leader_floor, far_top3: s.far.in_top3 });
const recordSearches = SW.filter(s => s.n > 0).map(searchRow);

// ---------- the market file (optional): our map checks, every search and date, drawn by mapview.js ----------
const market = marketPath ? JSON.parse(fs.readFileSync(marketPath, 'utf8')) : null;
if (market && market.biz?.[market.subject]?.pid !== subjectPid) die('--market is about a different store');
const mk = (() => {
  if (!market) return null;
  const MB = market.biz, MS = market.scans || [];
  if (!MS.length) die('--market holds no map checks');
  const kws = [...new Set(MS.map(s => String(s.kw).toLowerCase()))];
  const latest = kw => MS.filter(s => String(s.kw).toLowerCase() === kw).sort((a, b) => b.ts - a.ts)[0];
  const youIn = s => (Number.isInteger(s.you) && s.you >= 0 && s.field[s.you]) ? s.field[s.you] : null;
  // a business the market file flags far (another area's results) is not part of the field: not counted, never number 1
  const inMk = f => !(MB[f[0]] && MB[f[0]].far);
  const row = s => { const mine = youIn(s), top = s.field.find(inMk) || s.field[0], d = new Date(s.ts * 1000), others = s.field.filter(f => f[0] !== market.subject && inMk(f)), sec = others[0] || null;
    const you = mine ? mine[1] : 0, found = mine ? mine[2] : 0, lead = !!mine && mine[1] > 0 && (!sec || mine[1] >= sec[1]);
    return { key: s.key, kw: String(s.kw).toLowerCase(), when: `${local(d, { weekday: 'short' })}, ${day(d)}, ${clock(d)}`, date: day(d), ts: s.ts, n: s.n, you, found, place: mine && you > 0 ? 1 + others.filter(f => f[1] > you).length : null, tied: you > 0 && others.some(f => f[1] === you), of: s.field.filter(inMk).length,
      leader: lead ? business.short : MB[top[0]].short, leader_full: lead ? business.name : MB[top[0]].name, leader_b: lead ? market.subject : top[0], leader_pid: lead ? subjectPid : MB[top[0]].pid, leader_points: lead ? you : top[1], leader_rating: top[4] ?? null, leader_ratings: top[5] ?? null,
      second: sec ? MB[sec[0]].short : null, second_pid: sec ? MB[sec[0]].pid : null, second_points: sec ? sec[1] : null,
      you_lead: lead, open: inHours(d), checks: MS.filter(x => String(x.kw).toLowerCase() === String(s.kw).toLowerCase()).length, hold: false, hold_reasons: [], source: 'market' }; };
  const searches = kws.map(kw => row(latest(kw)));
  const runKw = String(run.keyword || '').toLowerCase();
  const main = searches.find(s => s.kw === runKw) || [...searches].sort((a, b) => b.checks - a.checks)[0];
  const tok = x => String(x).toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  const won = searches.filter(s => s.you_lead && s.you === s.n);
  const word = won.length ? tok(business.name).find(w => won.every(s => tok(s.kw).includes(w)) && searches.filter(s => tok(s.kw).includes(w)).every(s => s.you >= s.n * 0.8)) || null : null;
  const plain = `${loc.city} dispensary`.toLowerCase();
  const town = searches.filter(s => squash(s.kw).includes(citySlug) && !(word && tok(s.kw).includes(word))).sort((a, b) => (b.kw === plain) - (a.kw === plain) || a.you / a.n - b.you / b.n || b.leader_points - a.leader_points || a.kw.localeCompare(b.kw));
  const series = MS.filter(s => String(s.kw).toLowerCase() === main.kw).sort((a, b) => a.ts - b.ts).map(s => { const m = youIn(s); return { date: day(new Date(s.ts * 1000)), you: m ? m[1] : 0, n: s.n, leader: MB[s.field[0][0]].short, leader_points: s.field[0][1] }; });
  const prior = series.slice(0, -1).filter(x => x.n === main.n), sorted = prior.map(x => x.you).sort((a, b) => a - b);
  const middle = sorted.length ? sorted[Math.floor((sorted.length - 1) / 2)] : null, best = prior.length ? [...prior].sort((a, b) => b.you - a.you)[0] : null;
  const lead = market.listings ? market.listings.rows.find(r => r.b === main.leader_b) || null : null;
  const closed = MS.filter(s => inHours(new Date(s.ts * 1000)) === false).length;
  const mainScan = MS.find(s => s.key === main.key), dated = x => day(when(x + 'T12:00:00'));
  const V = market.velocity || null, vOf = b => (V ? V.rows.find(r => r.b === b) || null : null);
  const vRow = r => (r && r.per_month !== null ? { name: MB[r.b].short, per_month: r.per_month, gained: r.gained, from: r.from, to: r.to, days: Math.round(r.days), since: day(new Date(r.first * 1000)), until: day(new Date(r.last * 1000)) } : null);
  const meV = vOf(market.subject), paced = V ? V.rows.filter(r => r.per_month !== null) : [];
  const velocity = meV && meV.per_month !== null ? { live_from: dated(V.live_from), to: dated(V.to), stale_days: V.stale_days, businesses: V.rows.length, paced: paced.length,
    resets: V.rows.filter(r => r.per_month === null && r.reset).map(r => ({ name: MB[r.b].short, before: r.reset.before, before_on: day(new Date(r.reset.before_ts * 1000)), after: r.reset.after, after_on: day(new Date(r.reset.after_ts * 1000)) })),
    you: { ...vRow(meV), dated: null, place: 1 + paced.filter(r => r.per_month > meV.per_month).length, of: paced.length },
    leader: vRow(vOf(main.leader_b)), top: mainScan.field.filter(f => f[0] !== market.subject).slice(0, 5).map(f => vRow(vOf(f[0]))).filter(Boolean) } : null;
  const directories = market.directories ? { read: dated(market.directories.read), rows: market.directories.rows.map(r => ({ name: MB[r.b].short, is_you: r.b === market.subject, is_leader: r.b === main.leader_b, confirmed: r.confirmed, not_listed: r.not_listed, unknown: r.unknown })) } : null;
  return { main, searches, won, word, town: town[0] || null, towns: town.length, series, prior: prior.length, middle, best, reports: market.source?.reports ?? MS.length, businesses: MB.length,
    first: day(new Date((market.source?.first ?? Math.min(...MS.map(s => s.ts))) * 1000)), last: day(new Date((market.source?.last ?? Math.max(...MS.map(s => s.ts))) * 1000)), outside_hours: closed, velocity, reach: null, directories,
    listings_read: market.listings ? day(when(market.listings.read + 'T12:00:00')) : null,
    leader_listing: lead ? { read: day(when(market.listings.read + 'T12:00:00')), ...lead } : null };
})();
// the searches every verdict, check and gap line is built on: the market file's, plus any sweep it does not carry.
// A market row and a record sweep of the same search on the same day are the same check read twice: they must agree.
const marketDisagree = [];
const SEARCHES = (() => {
  if (!mk) return recordSearches;
  const out = [...mk.searches];
  for (const r of recordSearches) {
    const m = out.find(x => x.kw === r.kw && x.date === r.date);
    if (!m) { out.push(r); continue; }
    if (m.you !== r.you || m.n !== r.n || m.leader_points !== r.leader_points) marketDisagree.push(`"${r.kw}" ${r.date}: market ${m.you} of ${m.n} (number 1 ${m.leader_points}), record ${r.you} of ${r.n} (number 1 ${r.leader_points})`);
    else { m.scan_id = r.scan_id; m.hold = r.hold; m.hold_reasons = r.hold_reasons; m.of = r.of; m.place = r.place; m.tied = r.tied; m.leader_floor = r.leader_floor; m.far_top3 = r.far_top3; }
  }
  if (marketDisagree.length) for (const s of out) { s.hold = true; s.hold_reasons = [...(s.hold_reasons || []), 'The market file and the record disagree about the same check.']; }
  return out;
})();
const runKw = String(run.keyword || '').toLowerCase();
const mainSearch = SEARCHES.find(s => s.kw === runKw) || SEARCHES[0] || null;

// ---------- reviews: the store's own pull, and every pull in the answer for the rivals ----------
const reviewNote = pid => { const note = run.steps.find(s => s.part === 'reviews_collect' && s.place_id === pid)?.note || ''; const m = note.match(/(\d[\d,]*)\s+reviews collected/); return m ? { n: Number(m[1].replace(/,/g, '')), capped: /capped/i.test(note) } : { n: null, capped: false }; };
const pullOf = pid => {
  const rd = readingOf('reviews', pid); const r = rd?.result?.reviews; if (!r?.items?.length) return null;
  const note = reviewNote(pid), capped = r.capped === true || note.capped;
  const items = r.items.map(i => ({ at: when(i.timestamp), rating: i.rating, replied: !!String(i.owner_reply || '').trim() })).filter(i => i.at);
  const collected = when(r.collected_at) || when(rd.fetched_at);
  const oldest = new Date(Math.min(...items.map(i => +i.at)));
  // a pull that stopped at its limit kept the newest reviews, so a window it reaches back past is still whole
  const win = days => { const from = new Date(+collected - days * 864e5); if (capped && +oldest > +from) return null; const k = items.filter(i => +i.at >= +from); return { days, n: k.length, replied: k.filter(i => i.replied).length, per_month: r2(k.length / (days / 30.4375)) }; };
  return { pid, count: capped ? null : items.length, capped, collected_at: day(collected), oldest: day(oldest), d30: win(30), d90: win(90), d365: win(365) };
};
const rvR = reading('reviews')?.result?.reviews || null;
const LOW_SUBJECTS = [
  ['a discount or a deal', /discount|deal|price|coupon|% off|percent off|first.time|new customer|promo|honor/i],
  ['staff or service', /rude|staff|employee|budtender|manager|service|attitude|disrespect/i],
  ['the product', /quality|dry|old|stale|weak|moldy|bad weed|product/i],
  ['hours, waiting or being closed', /closed|close early|hours|wait|line|slow|door/i],
];
const reviews = (() => {
  if (!rvR?.items?.length) return null;
  const items = rvR.items.map(i => ({ at: when(i.timestamp), rating: i.rating, text: (i.text || '').trim(), replied: !!(i.owner_reply || '').trim() })).filter(i => i.at);
  const collected = when(rvR.collected_at) || runEnd;
  const back = m => { const d = new Date(collected); d.setUTCMonth(d.getUTCMonth() - m); return d; };
  const since = m => items.filter(i => i.at >= back(m));
  const first = new Date(Math.min(...items.map(i => +i.at)));
  const early = items.filter(i => +i.at <= +first + 70 * 864e5), later = items.filter(i => +i.at > +first + 70 * 864e5);
  const ym = d => { const p = localParts(d); return `${p.year}-${p.month}`; };
  const byMonth = {}; for (const i of items) (byMonth[ym(i.at)] ||= []).push(i.rating);
  const monthly = Object.keys(byMonth).sort().map(k => ({ ym: k, label: new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', month: 'short', year: 'numeric' }).format(new Date(k + '-15T00:00:00Z')), n: byMonth[k].length, avg: r2(mean(byMonth[k])) }));
  const l3 = since(3), l12 = since(12), prior9 = l12.filter(i => i.at < back(3));
  // day-based windows (the ones SEOS's own snapshots count): a month is 30.4375 days, never a calendar month
  const inDays = k => items.filter(i => +i.at >= +collected - k * 864e5), d90 = inDays(90), d365 = inDays(365), before90 = d365.filter(i => +i.at < +collected - 90 * 864e5);
  const low = items.filter(i => i.rating <= 2), low12 = low.filter(i => i.at >= back(12));
  const lowOpen = low.filter(i => !i.replied).sort((a, b) => b.at - a.at);
  const pull = pullOf(subjectPid);
  return {
    collected: items.length, collected_at: day(collected), first: day(first), capped: pull?.capped || false,
    with_reply: items.filter(i => i.replied).length, reply_rate: r1(100 * items.filter(i => i.replied).length / items.length),
    reply_by_stars: [5, 4, 3, 2, 1].map(s => ({ stars: s, total: items.filter(i => i.rating === s).length, replied: items.filter(i => i.rating === s && i.replied).length })),
    last_3: l3.length, last_6: since(6).length, last_12: l12.length, pace_recent: r1(l3.length / 3), pace_before: r1(prior9.length / 9),
    last_90: d90.length, last_365: d365.length, before_90: before90.length, pace_90: r1(d90.length / (90 / 30.4375)), pace_before_90: r1(before90.length / (275 / 30.4375)),
    opening_n: early.length, opening_avg: r2(mean(early.map(i => i.rating))), since_n: later.length, since_avg: later.length ? r2(mean(later.map(i => i.rating))) : null,
    one_star: items.filter(i => i.rating === 1).length, one_star_since: later.filter(i => i.rating === 1).length,
    low: low.length, low_replied: low.filter(i => i.replied).length, low_12: low12.length, low_12_with_text: low12.filter(i => i.text).length,
    low_subjects: LOW_SUBJECTS.map(([label, re]) => ({ label, n: low12.filter(i => re.test(i.text)).length })).sort((a, b) => b.n - a.n),
    low_open: lowOpen.length, low_open_12: lowOpen.filter(i => i.at >= back(12)).length,
    low_open_list: lowOpen.map(i => ({ date: day(i.at), rating: i.rating, recent: i.at >= back(12), text: i.text || '(no text, stars only)' })),
    monthly,
    // review velocity from the store's own dated reviews, the windows SEOS also computes
    windows: pull ? { d30: pull.d30, d90: pull.d90, d365: pull.d365 } : null,
    snapshots: (t.review_velocity_snapshots || []).filter(s => s.place_id === subjectPid).map(s => ({ days: s.window_days, n: s.reviews_in_window, per_month: s.per_month, replied: s.replied_in_window, total: s.reviews_total })),
  };
})();
// the store's windows against SEOS's own snapshots: two readings of the same reviews
const secondReadings = [];
if (reviews?.windows) for (const s of reviews.snapshots) { const w = reviews.windows['d' + s.days]; if (w) secondReadings.push({ what: `reviews in the last ${s.days} days`, here: [w.n, w.replied, w.per_month], seos: [s.n, s.replied, s.per_month], agree: w.n === s.n && w.replied === s.replied && Math.abs(w.per_month - s.per_month) < 0.011 }); }
const velocityOk = secondReadings.length > 0 && secondReadings.every(x => x.agree);

// ---------- rivals: the three stores the run names beside the store ----------
const rs = reading('ranking_signals')?.result || null;
const trafficOf = d => { const i = rs?.traffic?.items?.find(x => x.target === d); return i ? { visits: Math.round(i.metrics.organic.etv), keywords: i.metrics.organic.count } : { visits: null, keywords: null }; };
const rankOf = d => rs?.ranks?.items?.find(x => x.target === d)?.rank ?? null;
const domainOf = pid => { if (pid === subjectPid) return domain; const p = profileOf(pid); const w = p?.domain || (loc.named_rivals || []).find(r => r.place_id === pid)?.website || null; return w ? host(/^https?:/.test(w) ? w : 'https://' + w) : null; };
const who = b => {
  const d = domainOf(b.place_id);
  const rv = reviewNote(b.place_id), tr = d ? trafficOf(d) : { visits: null, keywords: null };
  return { id: b.slug, name: b.is_subject ? business.name : (profileOf(b.place_id)?.title || b.name), short: b.is_subject ? business.short : shortOf(b.place_id), is_you: !!b.is_subject, domain: d, place_id: b.place_id, map_share: b.solv ?? null,
    reviews: b.is_subject || rv.capped ? null : rv.n, reviews_capped: !b.is_subject && rv.capped,
    visits: tr.visits, keywords: tr.keywords, linking_sites: null };
};
const you = who(subject);
const rivals = run.businesses.filter(b => !b.is_subject).map(who);
const RV_PIDS = rivals.map(r => r.place_id);
// a rival whose Google listing links to an inner page of a website for many stores: its whole-website figures cover every
// store, so they are never set beside a one-store website (rule 7)
const chainRivals = rivals.filter(r => { const p = profileOf(r.place_id); try { const u = new URL(p?.url); return !(u.pathname === '/' || u.pathname === ''); } catch { return false; } });
const isChain = r => chainRivals.some(c => c.id === r.id);

// ---------- Google search: what the run read (whole-website estimates; the ranked-keywords read was switched off) ----------
const cdItems = reading('competitor_domains')?.result?.competitors?.items || [];
const selfCd = cdItems.find(i => i.domain === domain) || null;
const rkR = reading('ranked_keywords')?.result?.ranked || null;
const brandTerms = set.brandTerms || [business.short.toLowerCase()];
const isBrand = kw => { const s = squash(kw); return brandTerms.some(b => s.includes(squash(b))); };
const search = (() => {
  const o = selfCd?.full_domain_metrics?.organic || null;
  const buckets = o ? [
    { label: 'Top 3', n: o.pos_1 + o.pos_2_3 }, { label: '4 to 10', n: o.pos_4_10 }, { label: '11 to 20', n: o.pos_11_20 },
    { label: '21 to 50', n: o.pos_21_30 + o.pos_31_40 + o.pos_41_50 }, { label: '51 to 100', n: o.pos_51_60 + o.pos_61_70 + o.pos_71_80 + o.pos_81_90 + o.pos_91_100 }] : null;
  const kws = (rkR?.items || []).map(i => ({ kw: i.keyword, volume: i.search_volume, rank: i.rank_group, visits: i.etv, page: pathOf(i.url), brand: isBrand(i.keyword) }));
  return {
    keywords_total: o ? o.count : null, buckets, top10: o ? o.pos_1 + o.pos_2_3 + o.pos_4_10 : null, top3: o ? o.pos_1 + o.pos_2_3 : null,
    visits: o ? Math.round(o.etv) : null, moved: o ? { new: o.is_new, up: o.is_up, down: o.is_down, lost: o.is_lost } : null,
    stored: kws.length, stored_brand: kws.filter(k => k.brand).length, stored_plain: kws.filter(k => !k.brand).length, stored_visits: Math.round(sum(kws, k => k.visits)),
    brand_visit_share: null, plain_visit_share: null, top_search: null, store_slug: null, store_searches: null, store_visits: null, store_name_visits: null, store_name_searches: null, name_town: null,
    top_brand: [], top_plain: [], page1_complete: false, town_page1: null, sister_town_page1: [], sister_town_page1_n: 0, sister_town_by_kind: {},
    store_page: business.listing_path, other_store_page: null, other_store_page_title: null, other_store_page_links: null,
    tracked: null, tracked_usable: null,
    ranked_read: !!rkR, ranked_setting: parts.ranked_keywords ?? null, organic_ranks_setting: parts.organic_ranks ?? null,
    others: cdItems.filter(i => i.domain !== domain).map(i => ({ domain: i.domain, shared: i.intersections })),
    analytics_connected: (t.analytics_bindings || []).some(b => b.ga_property_id), search_console_connected: (t.analytics_bindings || []).some(b => b.sc_property),
    read_at: day(when(reading('competitor_domains')?.fetched_at)),
  };
})();
for (const r of [you, ...rivals]) { const tr = r.domain ? trafficOf(r.domain) : null; if (tr) { r.visits = tr.visits; r.keywords = tr.keywords; } }

// ---------- website: the store page, the rivals' store pages (same run, same settings), and whole-site crawls ----------
const PLAIN_FIX = { 'bootup-time': 'Trim the scripts the page runs', 'mainthread-work-breakdown': 'Lighten what the page does while it loads', 'unused-css-rules': 'Drop styles the page does not use', 'unused-javascript': 'Drop scripts the page does not use', 'render-blocking-insight': 'Stop files from holding up the first paint', 'render-blocking-resources': 'Stop files from holding up the first paint', 'cls-culprits-insight': 'Stop the layout from jumping while it loads', 'image-delivery-insight': 'Serve smaller images', 'lcp-discovery-insight': 'Let the main image start loading sooner' };
const band = s => s >= 0.9 ? 'pass' : s >= 0.5 ? 'watch' : 'fail';
const pageRead = pid => {
  const sa = readingOf('site_audit', pid), ps = readingOf('page_speed', pid), lf = readingOf('landing_flags', pid);
  const R = sa?.result || null, pg = R?.page?.items?.[0] || null, probe = R?.probe || null, P = ps?.result || null;
  const speed = d => { const x = P?.[d]; if (!x || (x.error && !x.score)) return null; return { score: Math.round(x.score * 100), band: band(x.score), metrics: Object.fromEntries(Object.entries(x.metrics || {}).map(([k, v]) => [k, { display: v.display, band: band(v.score), value: v.value }])),
    fixes: (x.fixes || []).filter(f => f.savings_ms > 0).map(f => ({ id: f.id, title: PLAIN_FIX[f.id] || f.title, saves_s: r2(f.savings_ms / 1000) })) }; };
  const schema = probe?.tags?.schema || null;
  return { pid, url: pg?.url || sa?.target || null, read: !!pg, status: probe?.status ?? pg?.status_code ?? null, words: pg?.meta?.content?.plain_text_word_count ?? null, chars: pg?.meta?.content?.plain_text_size ?? null,
    crawler_words: R?.render?.crawler_words ?? null, browser_words: R?.render?.browser_words ?? null, thin_to_crawler: R?.render?.thin_to_crawler ?? null, blocked: R?.render?.blocked ?? null,
    gated: R?.age_gate?.gated ?? null,
    // rule 9: the plain reader's on-page score and the browser's for the same page; when they disagree the score is not confirmed
    onpage_reads: [pg?.onpage_score ?? null, R?.page_rendered?.items?.[0]?.onpage_score ?? null],
    onpage: pg && R?.page_rendered?.items?.[0] && R.page_rendered.items[0].onpage_score !== pg.onpage_score ? null : (pg?.onpage_score ?? null), title_chars: pg?.meta?.title_length ?? null, h1: (pg?.meta?.htags?.h1 || []).length,
    business_schema: schema ? !!schema.business_type : null, microdata_flag: pg?.checks?.has_micromarkup ?? null,
    flags: lf?.result?.flags ?? null, flag_notes: lf?.result?.notes ?? [], phone: speed('phone'), desktop: speed('desktop'), read_at: day(when(sa?.fetched_at)) };
};
const crawlOf = key => { const r = readingOf('site_crawl', key)?.result?.summary || null; return r ? { progress: r.progress, pages: r.pages_crawled, max: r.max_pages, at_limit: r.pages_crawled >= r.max_pages, score: r.onpage_score, broken_links: r.broken_links, duplicate_title: r.duplicate_title, duplicate_description: r.duplicate_description, no_h1: r.checks?.no_h1_tag ?? null } : null; };
const saR = reading('site_audit')?.result || null;
const psR = reading('page_speed')?.result || null;
const website = (() => {
  const pg = saR?.page?.items?.[0] || null, probe = saR?.probe || null;
  const me = pageRead(subjectPid);
  const heads = pg?.meta?.htags || {};
  const allHeads = Object.entries(heads).flatMap(([lvl, list]) => list.map(text => ({ lvl, text })));
  const gate = allHeads.find(h => /\b(are you )?(18|19|21)\s*(\+|or older|years)/i.test(h.text) || /age (verification|check|gate)|verify your age/i.test(h.text)) || null;
  const wordy = allHeads.map(h => h.text).filter(x => /\s/.test(x.trim()) && !/^[a-z0-9]+(-[a-z0-9]+)+$/.test(x.trim()));
  const sitemapPages = saR?.discovery?.urls_total ?? null;
  const pagesRead = 1 + Object.keys(saR || {}).filter(k => /^page_\d+$/.test(k) && saR[k]?.items?.length).length;
  const crawl = crawlOf(subjectPid);
  return {
    url: pg?.url ? (() => { try { const u = new URL(pg.url); return u.origin + u.pathname; } catch { return pg.url; } })() : null,
    title: pg?.meta?.title ?? null, title_chars: pg?.meta?.title_length ?? null, description: pg?.meta?.description ?? null, description_chars: pg?.meta?.description_length ?? null,
    words: pg?.meta?.content?.plain_text_word_count ?? null, chars: pg?.meta?.content?.plain_text_size ?? null,
    headings: allHeads.length, gate_heading: gate ? gate.text : null, gate_headings: allHeads.filter(h => gate && h.text === gate.text).length, label_headings: allHeads.length - wordy.length, sample_headings: [...new Set(wordy)].slice(0, 3),
    main_heading_in_list: (heads.h1 || []).length > 0, main_heading_flag_missing: pg?.checks?.no_h1_tag ?? null, main_heading: (heads.h1 || [])[0] || null,
    has_frame: pg?.checks?.frame === true,
    https: pg?.checks?.is_https === true, status: probe?.status ?? pg?.status_code ?? null, hops: probe?.hops ?? null,
    canonical_self: probe ? (probe.canonical_offhost === false && probe.canonical_elsewhere_path === false) : null,
    structured_data_found: pg?.checks?.has_micromarkup === true, head_mentions_schema: (probe?.head_hosts || []).includes('schema.org'),
    schema_types: probe?.tags?.schema?.jsonld_types || [], business_schema: me.business_schema,
    age_gate: saR?.age_gate?.gated ?? null, crawler_words: me.crawler_words, browser_words: me.browser_words, thin_to_crawler: me.thin_to_crawler,
    onpage: me.onpage, flags: me.flags,
    phone: me.phone, desktop: me.desktop,
    whole_site_read: false, pages_read: pagesRead, sitemap_pages: sitemapPages, crawl,
    llms: saR?.site_files?.llms?.found ?? null, og_image: saR?.site_files?.og_image ? { width: saR.site_files.og_image.width, height: saR.site_files.og_image.height } : null,
    rivals: rivals.map(r => ({ id: r.id, name: r.short, domain: r.domain, page: pageRead(r.place_id), crawl: r.domain ? crawlOf('site:' + r.domain) : null })),
    read_at: day(when(reading('site_audit')?.fetched_at)),
  };
})();

// ---------- links: every referring domain and every link the run read, for the store and each rival ----------
// A linking site is a link seller (or part of a link network) when a link from it, or from a host under it, sits on
// a page whose title sells links, or on a page whose title is shared by 20 or more linking hosts (one page title on
// 20 hosts is a network, not 20 sites choosing to link: e.g. "Cannabis Flower Elizabeth NJ" on 38 listing sites),
// or when the software's own link ledger flags the host. Hosts are joined to linking sites by name and by the
// sub-host ("13.bhs-links-rf.xyz" belongs to "bhs-links-rf.xyz"): joined by exact name, 10 of this store's sellers
// and 151 of Budzooka's were counted as clean (integration check against the raw links, 2026-10-12).
const SELLS_LINKS = /\b(backlinks?|link[\s-]*building|seo[\s-]+links?|high[\s-]*authority|domain[\s-]*authority|guest[\s-]*posts?|pbn|black[\s-]*hat|bhs[\s-]*links)\b/i;
const WAVE_HOSTS = 20;
const bareHost = h => String(h || '').toLowerCase().replace(/^www\./, '');
const titleKey = s => String(s || '').toLowerCase().replace(/\s*[-|–—]\s*page\s*[\d,]+\s*$/, '').replace(/\s+/g, ' ').trim();
const CANNABIS_SITE = /canna|leaf|ganja|weed|420|bud|dispens|marijuana|kush/i;
const freshCut = new Date(+runStart - 30 * 864e5);
const linkRead = pid => {
  const exR = readingOf('bl_exhaustive', pid), ex = exR?.result; if (!ex) return null;
  const rdParts = Object.entries(ex).filter(([k, v]) => /^rd_\d+$/.test(k) && Array.isArray(v?.items)), blParts = Object.entries(ex).filter(([k, v]) => /^bl_\d+$/.test(k) && Array.isArray(v?.items));
  const rd = [...new Map(rdParts.flatMap(([, v]) => v.items).map(i => [i.domain, i])).values()], bl = blParts.flatMap(([, v]) => v.items);
  const rdTotal = rdParts.length ? Math.max(...rdParts.map(([, v]) => v.total_count || 0)) : null, blTotal = blParts.length ? Math.max(...blParts.map(([, v]) => v.total_count || 0)) : null;
  const ledger = readingOf('bl_ledger', pid)?.result || null;
  const scheme = new Set((ledger?.hosts || []).filter(h => h.scheme_like).map(h => bareHost(h.host)));
  const titlesOf = {}; for (const b of bl) (titlesOf[bareHost(b.domain_from)] ||= []).push(b.page_from_title || '');
  const hostsByTitle = new Map(); for (const b of bl) { const k = titleKey(b.page_from_title); if (!k) continue; if (!hostsByTitle.has(k)) hostsByTitle.set(k, new Set()); hostsByTitle.get(k).add(bareHost(b.domain_from)); }
  const waveTitles = new Set([...hostsByTitle].filter(([, s]) => s.size >= WAVE_HOSTS).map(([k]) => k));
  const titleSells = ti => SELLS_LINKS.test(ti || '') || waveTitles.has(titleKey(ti));
  const byTitleHosts = new Set(Object.entries(titlesOf).filter(([, ts]) => ts.some(titleSells)).map(([h]) => h));
  const sellerHosts = new Set([...byTitleHosts, ...scheme]);
  const under = (hosts, d) => { const x = bareHost(d); for (const h of hosts) if (h === x || h.endsWith('.' + x)) return true; return false; };
  const isSeller = d => under(sellerHosts, d);
  const sellers = rd.filter(i => isSeller(i.domain)), sellerSet = new Set(sellers.map(i => i.domain));
  const byTitleCount = rd.filter(i => under(byTitleHosts, i.domain)).length;
  const fresh = rd.filter(i => { const d = when(i.first_seen); return d && +d > +freshCut; });
  const wave = (ledger?.shared_title_waves || []).slice().sort((a, b) => b.hosts - a.hosts)[0] || null;
  const linksDone = blTotal !== null && bl.length >= blTotal, sitesDone = rdTotal !== null && rd.length >= rdTotal;
  // a second, stricter pass over the sites that are not sellers, from the links' own fields (no network): a site goes when
  // any of its links carries a spam score of 30 or more, or when its page title (the part before " | ") is shared by two or
  // more linking hosts (a copied article or a small network, under the 20-host wave cut). A lead that survives this holds.
  const shortTitle = s => String(s || '').toLowerCase().replace(/\s*\|.*$/, '').replace(/\s+/g, ' ').trim();
  const hostsByShort = new Map(); for (const b of bl) { const k = shortTitle(b.page_from_title); if (!k) continue; if (!hostsByShort.has(k)) hostsByShort.set(k, new Set()); hostsByShort.get(k).add(bareHost(b.domain_from)); }
  const linksOf = d => { const x = bareHost(d); return bl.filter(b => { const h = bareHost(b.domain_from); return h === x || h.endsWith('.' + x); }); };
  const quality = i => { const L = linksOf(i.domain); return { domain: i.domain, rank: i.rank, links: L.length, spam: L.length ? Math.max(...L.map(b => b.backlink_spam_score ?? 0)) : null, shared: L.some(b => { const k = shortTitle(b.page_from_title); return k && hostsByShort.get(k).size >= 2; }), title: clip(String(L[0]?.page_from_title || '').replace(/[^ -~]/g, ' '), 80) }; };
  const cleanQ = linksDone ? rd.filter(i => !isSeller(i.domain)).map(quality) : null;
  const strict = cleanQ ? cleanQ.filter(q => !(q.spam !== null && q.spam >= 30) && !q.shared) : null;
  return { pid, domain: exR.target, rd, bl, sites: rd.length, sites_total: rdTotal, sites_complete: sitesDone, links: bl.length, links_total: blTotal, links_complete: linksDone,
    // the seller count rests on the links read; one that stopped at the pull's limit is not printed (rule 4)
    sellers: linksDone ? sellers.length : null, sellers_floor: sellers.length, not_sellers: linksDone ? rd.length - sellers.length : null,
    with_weight: rd.filter(i => i.rank > 0).length, clean_with_weight: linksDone ? rd.filter(i => i.rank > 0 && !sellerSet.has(i.domain)).length : null,
    fresh: fresh.length, fresh_sellers: linksDone ? fresh.filter(i => sellerSet.has(i.domain)).length : null, fresh_clean: linksDone ? fresh.filter(i => !sellerSet.has(i.domain)).length : null,
    strict: strict ? { not_sellers: strict.length, with_weight: strict.filter(q => q.rank > 0).length, spam_30: cleanQ.filter(q => q.spam !== null && q.spam >= 30).length, shared_title: cleanQ.filter(q => q.shared).length } : null,
    weighted_quality: cleanQ ? cleanQ.filter(q => q.rank > 0).sort((a, b) => b.rank - a.rank) : null,
    sellerSet, titlesOf, titleSells, isSellerHost: h => sellerHosts.has(bareHost(h)), by_title: byTitleCount, networks: waveTitles.size,
    scheme_flagged: scheme.size, ledger_hosts: ledger?.hosts?.length ?? null, tagged_rows: ledger?.tagged_rows ?? null,
    wave: wave ? { title: clip(String(wave.title).replace(/[^ -~]/g, ' '), 90), hosts: wave.hosts, from: wave.first_seen_min, to: wave.first_seen_max } : null,
    landing: readingOf('bl_landing', pid)?.result?.land || null, read_at: day(when(exR.fetched_at)) };
};
const LK = Object.fromEntries([subjectPid, ...RV_PIDS].map(p => [p, linkRead(p)]));
for (const r of [you, ...rivals]) { const k = LK[r.place_id]; if (k && k.sites_complete) r.linking_sites = k.sites; }
const blRows = LK[subjectPid]?.bl || [];
const gapR = reading('bl_link_gap');
const links = (() => {
  const me = LK[subjectPid]; if (!me) return null;
  const rd = me.rd;
  const sellers = rd.filter(i => me.sellerSet.has(i.domain));
  const classified = rd.filter(i => me.titlesOf[bareHost(i.domain)] || me.sellerSet.has(i.domain));
  const sellerTitleSites = {}; for (const b of blRows) if (me.isSellerHost(b.domain_from) && me.titleSells(b.page_from_title)) (sellerTitleSites[b.page_from_title] ||= new Set()).add(bareHost(b.domain_from));
  const topSellerTitle = Object.entries(sellerTitleSites).sort((a, b) => b[1].size - a[1].size)[0] || null;
  const fresh = rd.filter(i => { const d = when(i.first_seen); return d && +d > +freshCut; }), freshSellers = fresh.filter(i => me.sellerSet.has(i.domain));
  const byDay = tally(rd.filter(i => when(i.first_seen)), i => storeDay(when(i.first_seen)));
  const lastDay = storeDay(runStart);
  const daily = []; for (let k = 44; k >= 0; k--) { const d0 = new Date(Date.parse(lastDay + 'T12:00:00Z') - k * 864e5); const key = d0.toISOString().slice(0, 10); daily.push({ d: key, label: new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', month: 'short', day: 'numeric' }).format(d0), n: byDay[key] || 0 }); }
  // new link-selling pages that also link to two or more of the rivals: each rival's own list of linking sites, read whole
  const rivalSets = RV_PIDS.map(p => LK[p]).filter(k => k && k.sites_complete).map(k => new Set(k.rd.map(i => i.domain)));
  const alsoRivals = freshSellers.filter(i => rivalSets.filter(s => s.has(i.domain)).length >= 2).length;
  // sites that link to at least two of the rivals and not here (the vendor's own intersection; parts that stopped at their limit are floors)
  const mySites = new Set(rd.map(i => i.domain));
  const combos = gapR ? Object.keys(gapR.request || {}).filter(k => /^gap_\d+$/.test(k)).map(k => ({ part: k, targets: gapR.request[k].targets || {} })) : [];
  const gapParts = combos.map(c => ({ part: c.part, got: gapR.result?.[c.part]?.items?.length ?? 0, total: gapR.result?.[c.part]?.total_count ?? null }));
  const gap = {};
  for (const c of combos) for (const i of gapR.result?.[c.part]?.items || []) {
    const site = Object.values(i.domain_intersection)[0].target;
    const g = (gap[site] ||= { domain: site, score: 0, rivals: new Set() });
    for (const [k, x] of Object.entries(i.domain_intersection)) { g.score = Math.max(g.score, x.rank || 0); const rv = rivals.find(r => r.domain === c.targets[k]); if (rv) g.rivals.add(rv.short); }
  }
  const gapAll = Object.values(gap), gapLeft = gapAll.filter(g => !mySites.has(g.domain) && !me.sellerSet.has(g.domain));
  const worth = gapLeft.filter(g => g.score >= 10 && !SELLS_LINKS.test(g.domain)).sort((a, b) => b.score - a.score).map(g => ({ domain: g.domain, score: g.score, rivals: [...g.rivals], cannabis: CANNABIS_SITE.test(g.domain) }));
  const tagged = blRows.filter(b => isOurs(b.url_to || '') || b.vendor_tagged === true);
  // what the sites that carry weight are, by the links' own titles: listing pages that name the store, one article
  // copied on unrelated sites, and articles on general sites
  const wq = me.weighted_quality || [], nameRe = new RegExp(brandTerms.map(x => x.replace(/\s+/g, '\\s*')).join('|'), 'i');
  const kinds = { names_store: wq.filter(q => nameRe.test(q.title)), copied: wq.filter(q => !nameRe.test(q.title) && q.shared), articles: wq.filter(q => !nameRe.test(q.title) && !q.shared) };
  const quality = { weighted: wq.length, names_store: kinds.names_store.map(q => q.domain), copied: kinds.copied.map(q => q.domain), copied_title: kinds.copied[0] ? kinds.copied[0].title.replace(/\s*\|.*$/, '') : null, articles: kinds.articles.map(q => q.domain),
    rows: wq.map(q => ({ domain: q.domain, rank: q.rank, links: q.links, spam: q.spam, kind: nameRe.test(q.title) ? 'names the store' : q.shared ? 'copied article' : 'article', title: q.title })),
    strict: Object.fromEntries([subjectPid, ...RV_PIDS].map(p => [shortOf(p), LK[p]?.strict || null])) };
  return {
    quality,
    sites: rd.length, sites_complete: me.sites_complete, links: blRows.length, links_total: me.links_total, links_complete: me.links_complete, classified: classified.length, unclassified: rd.length - classified.length,
    sellers: sellers.length, not_sellers: rd.length - sellers.length, with_weight: me.with_weight, sellers_with_weight: sellers.filter(i => i.rank > 0).length, clean_with_weight: me.clean_with_weight,
    by_title: me.by_title, by_ledger: me.scheme_flagged, networks: me.networks,
    fresh_days: 30, fresh: fresh.length, fresh_sellers: freshSellers.length, fresh_with_weight: fresh.filter(i => i.rank > 0).length, fresh_sellers_with_weight: freshSellers.filter(i => i.rank > 0).length,
    fresh_sellers_also_rivals: alsoRivals, rivals_read_whole: rivalSets.length,
    seller_title: topSellerTitle ? { title: clip(topSellerTitle[0].replace(/[^ -~]/g, ' '), 90), sites: topSellerTitle[1].size } : null, seller_list: sellers.map(i => i.domain).sort(),
    wave: me.wave,
    daily, daily_peak: Math.max(...daily.map(d => d.n)),
    field: [], field_size: 0, field_dropped_far: 0,
    top_sites: rd.filter(i => i.rank > 0 && !me.sellerSet.has(i.domain)).sort((a, b) => b.rank - a.rank).slice(0, 12).map(i => ({ domain: i.domain, score: i.rank, links: i.backlinks })),
    gap_left: gapLeft.length, gap_floor: gapParts.some(p => p.total !== null && p.got < p.total), gap_parts: gapParts, gap_no_weight: gapLeft.filter(g => g.score === 0).length, gap_worth: worth,
    store_links: reading('bl_location')?.result?.loc?.total_count ?? null,
    tagged_total: tagged.length, tagged_here: tagged.length, tagged_ours: tagged.length > 0, tagged_top_page: null, tagged_sites: new Set(tagged.map(b => b.domain_from)).size, tagged_top_two: 0,
    read_at: me.read_at,
  };
})();

// ---------- listings around the web: the store in full; each rival by the same three readings ----------
// id, label, the hosts a Google result is matched on, the domain the software's citation verdict is filed under
const MATTER = [['google-business-profile', 'Google Business Profile', /(^|\.)google\.com$/, 'google.com'], ['apple-maps', 'Apple Maps', /(^|\.)maps\.apple\.com$/, 'maps.apple.com'], ['bing-places', 'Bing Places', /(^|\.)bing\.com$/, 'bing.com'], ['yelp', 'Yelp', /(^|\.)yelp\.com$/, 'yelp.com'], ['facebook', 'Facebook', /(^|\.)facebook\.com$/, 'facebook.com'],
  ['weedmaps', 'Weedmaps', /(^|\.)weedmaps\.com$/, 'weedmaps.com'], ['leafly', 'Leafly', /(^|\.)leafly\.com$/, 'leafly.com'], ['dutchie', 'Dutchie', /(^|\.)dutchie\.com$/, 'dutchie.com'], ['foursquare', 'Foursquare', /(^|\.)foursquare\.com$/, 'foursquare.com'], ['yellowpages', 'Yellow Pages', /(^|\.)yellowpages\.com$/, 'yellowpages.com']];
const listingsOf = pid => {
  const cs = readingOf('cit_sweep', pid), cp = readingOf('cit_pages', pid), cpr = readingOf('cit_probe', pid);
  if (!cs && !cp) return null;
  const prof = pid === subjectPid ? null : profileOf(pid);
  const phoneSrc = pid === subjectPid ? (loc.phone_e164 || loc.phone) : prof?.phone;
  const digits = String(phoneSrc || '').replace(/\D/g, '').slice(-10);
  const phoneRe = digits.length === 10 ? new RegExp(`\\(?${digits.slice(0, 3)}\\)?[\\s.\\-]{0,2}${digits.slice(3, 6)}[\\s.\\-]{0,2}${digits.slice(6)}`) : null;
  const tgt = cs?.request?.target || cp?.request?.target || {};
  const street = pid === subjectPid ? loc.street : (prof?.address_info?.address || '');
  const streetNo = (String(street).match(/^\d+/) || [null])[0];
  const streetRe = (() => { try { return tgt.street_regex ? new RegExp(tgt.street_regex, 'i') : null; } catch { return null; } })() || (streetNo ? new RegExp(`(?<![0-9])${streetNo}(?![0-9])`) : null);
  const nameForRe = pid === subjectPid ? business.name : (prof?.title || '');
  // the store's name is matched by its brand terms ("Green Haven" as well as "Green Haven Industries"): the software's own
  // brand_regex wants the full name, so a result that says "Green Haven" would count as one without the store's name
  const termsRe = pid === subjectPid && set.brandTerms ? new RegExp(set.brandTerms.map(x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s*')).join('|'), 'i') : null;
  const brandRe = termsRe || (() => { try { return tgt.brand_regex ? new RegExp(tgt.brand_regex, 'i') : null; } catch { return null; } })() || new RegExp(shortName(nameForRe).replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s*'), 'i');
  const ownDomain = domainOf(pid) || '___';
  const seen = new Map();
  for (const q of Object.values(cs?.result || {})) for (const i of q?.items || []) {
    const text = `${i.title || ''} ${i.description || ''} ${i.url || ''}`;
    const row = seen.get(i.url) || { url: i.url, host: host(i.url), title: clip(i.title, 70), phone: false, street: false, brand: false };
    row.phone ||= !!(phoneRe && phoneRe.test(text)); row.street ||= !!(streetRe && streetRe.test(text)); row.brand ||= brandRe.test(text);
    seen.set(i.url, row);
  }
  const found = [...seen.values()];
  const hosts = rows => [...new Set(rows.map(r => r.host))];
  const ownOrSocial = h => h.endsWith(ownDomain) || /(^|\.)facebook\.com$|(^|\.)instagram\.com$/.test(h);
  const key = u => { try { const x = new URL(u); return x.hostname.replace(/^www\./, '') + '/' + x.pathname.split('/').filter(Boolean).slice(0, 2).join('/'); } catch { return String(u); } };
  const googleSays = new Map();
  for (const r of found) if (r.brand && (r.street || r.phone)) { const o = googleSays.get(key(r.url)) || { phone: false, street: false }; o.phone ||= r.phone; o.street ||= r.street; googleSays.set(key(r.url), o); }
  const cands = cp?.request?.candidates || [];
  const readable = v => !!(v && v.items && v.items.length && !v.crawl_status);
  const pages = cands.map((c, i) => {
    const v = cp.result?.[`page-${i}`]; const ok = readable(v); const text = ok ? JSON.stringify(v.items[0].page_content) : '';
    const phone = ok && phoneRe ? phoneRe.test(text) : null, st = ok && streetRe ? streetRe.test(text) : null;
    const g = googleSays.get(key(c.url)) || null;
    return { host: host(c.url), url: c.url, key: key(c.url), readable: ok, phone, street: st, google: g, store: 'here' };
  });
  const byListing = new Map(); for (const p of pages) { const o = byListing.get(p.host) || { host: p.host, url: p.url, pages: 0, read: 0, phone: false, street: false, by_page: false, by_google: false }; o.pages++; if (p.readable) o.read++; if (p.phone || p.street) o.by_page = true; if (p.google) o.by_google = true; o.phone ||= !!(p.phone || p.google?.phone); o.street ||= !!(p.street || p.google?.street); byListing.set(p.host, o); }
  const table = [...byListing.values()].sort((a, b) => a.host.localeCompare(b.host)).map(o => ({ host: o.host, url: o.url, pages: o.pages, read: o.read, phone: o.phone, street: o.street, source: o.by_page && o.by_google ? 'the page and Google' : o.by_page ? 'the page' : o.by_google ? "Google's result" : 'nothing: the page came back empty' }));
  const namedPhone = found.filter(r => r.phone && r.brand), namedStreet = found.filter(r => r.street && r.brand);
  // sources in the software's list that name another market's places (SETTINGS.otherMarketSources) count for nothing here
  const otherMkt = id => !!(set.otherMarketSources && set.otherMarketSources.test(String(id)));
  const groups = k => cpr ? Object.keys(cpr.request || {}).filter(x => x.startsWith(k + ':') && !otherMkt(x.slice(k.length + 1))) : [];
  const showsStore = k => readable(cpr.result?.[k]) && ((phoneRe && phoneRe.test(JSON.stringify(cpr.result[k]))) || (streetRe && streetRe.test(JSON.stringify(cpr.result[k]))));
  // the listings that matter: the software's own verdict for the directory (its live check) first, then what Google's
  // results showed. "Not checked" only when no reading at all covers the source.
  const verdictOf = dom => pid === subjectPid ? (t.citation_verdicts || []).find(c => c.place_id === pid && c.domain === dom) || null : null;
  const NAP = { 'nap-correct': 'name, address and phone correct', 'nap-incomplete': 'name, address or phone incomplete' };
  const matter = MATTER.filter(([id]) => (cpr?.request?.sources || []).includes(id)).map(([id, label, re, dom]) => { const hit = found.filter(r => re.test(r.host) && r.brand && (r.phone || r.street)), v = verdictOf(dom);
    const g = hit.length ? `Seen in Google's results: ${[hit.some(r => r.phone) ? 'phone' : null, hit.some(r => r.street) ? 'address' : null].filter(Boolean).join(' and ')}` : null;
    const sv = !v ? null : v.verdict === 'listed' ? `Listed${NAP[v.nap_status] ? `, ${NAP[v.nap_status]}` : ''} (the software's live check)` : v.verdict === 'not-listed' ? "Not listed (the software's live check)" : 'Could not be read';
    return { id, label, verdict: v ? v.verdict : null, nap: v ? v.nap_status || null : null, seen: id === 'google-business-profile' ? 'Read for this report' : sv && g ? `${sv}. ${g}` : sv || g || 'Not checked in this report' }; });
  const offSite = r => !r.host.endsWith(ownDomain);
  const phoneOther = found.filter(r => r.phone && !r.brand && offSite(r));
  return {
    searches: cs ? Object.keys(cs.result || {}).length : null, searches_refused: cs ? Object.values(cs.result || {}).filter(v => !v || !Array.isArray(v.items)).length : null, results_seen: found.length,
    searches_answered: cs ? Object.values(cs.result || {}).filter(v => v && Array.isArray(v.items)).length : null,
    phone_sites: hosts(found.filter(r => r.phone)).length, phone_named_sites: hosts(namedPhone).length, phone_named_outside: hosts(namedPhone).filter(h => !ownOrSocial(h)).length,
    street_sites: hosts(found.filter(r => r.street)).length, street_named_sites: hosts(namedStreet).length,
    named_site_list: hosts(found.filter(r => r.brand && (r.phone || r.street))).filter(h => !ownOrSocial(h)).sort(),
    // results that show the phone number without the store's name, off its own website
    phone_other: phoneOther.length, phone_other_sites: hosts(phoneOther).sort(),
    street_other: found.filter(r => r.street && !r.brand && offSite(r)).length,
    pages_opened: cands.length, pages_readable: pages.filter(p => p.readable).length, pages_empty: pages.filter(p => !p.readable).length,
    sister_pages: 0, store_pages: pages.length, store_pages_read: pages.filter(p => p.readable).length,
    store_pages_empty: pages.filter(p => !p.readable).length, store_empty_by_site: Object.entries(tally(pages.filter(p => !p.readable), p => p.host)).sort((a, b) => b[1] - a[1]).map(([h, c]) => ({ host: h, n: c })),
    table, table_both: table.filter(r => r.phone && r.street).length,
    matter,
    directories_listed: cpr?.request?.sources ? cpr.request.sources.filter(x => !otherMkt(x)).length : null, directories_listed_all: cpr?.request?.sources?.length ?? null,
    directories_other_market: cpr?.request?.sources ? cpr.request.sources.filter(otherMkt) : [],
    directories_tested: groups('ctl').length, directories_test_passed: groups('ctl').filter(k => readable(cpr.result?.[k])).length,
    directories_searched: groups('biz').length, directories_answered: groups('biz').filter(k => readable(cpr.result?.[k])).length,
    directories_showed: groups('biz').filter(showsStore).length,
    read_at: day(when((cp || cs).fetched_at)),
  };
};
const listings = (() => {
  const L0 = listingsOf(subjectPid); if (!L0) return null;
  const cvAll = (t.citation_verdicts || []).filter(c => c.place_id === subjectPid);
  // rule 5 and the market: a source that names another market's places is in no count and no denominator
  const otherMkt = c => !!(set.otherMarketSources && (set.otherMarketSources.test(String(c.source_id)) || set.otherMarketSources.test(String(c.domain))));
  const cv = cvAll.filter(c => !otherMkt(c)), cvOther = cvAll.filter(otherMkt);
  const vt = tally(cv, c => c.verdict), vtAll = tally(cvAll, c => c.verdict);
  L0.verdicts = cv.length ? { checked: cv.length, listed: vt.listed || 0, not_listed: vt['not-listed'] || 0, undetermined: vt.undetermined || 0, contested: cv.filter(c => c.contested).length,
    checked_all: cvAll.length, all: [vtAll.listed || 0, vtAll['not-listed'] || 0, vtAll.undetermined || 0],
    other_market: cvOther.map(c => ({ source: c.source_id, domain: c.domain, verdict: c.verdict })), other_market_label: set.otherMarketLabel || null,
    computed: day(when(cv[0].computed_at)),
    rows: cv.filter(c => c.verdict !== 'undetermined').sort((a, b) => a.verdict.localeCompare(b.verdict) || a.domain.localeCompare(b.domain)).map(c => ({ domain: c.domain, tier: c.tier, verdict: c.verdict, nap: c.nap_status || null, url: c.listing_url || null, ours: !!(c.listing_url && isOurs(c.listing_url)) })),
    by_tier: Object.entries(tally(cv, c => c.tier || 'none')).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ tier: k, n: v })) } : null;
  L0.rivals = rivals.map(r => ({ id: r.id, name: r.short, ...(() => { const x = listingsOf(r.place_id); return x ? { phone_named_outside: x.phone_named_outside, street_named_sites: x.street_named_sites, directories_searched: x.directories_searched, directories_answered: x.directories_answered, directories_showed: x.directories_showed, pages_opened: x.pages_opened, pages_readable: x.pages_readable, searches: x.searches, searches_answered: x.searches_answered, read_at: x.read_at } : null; })() }));
  return L0;
})();

// ---------- the brand's stores: one store, no sister stores ----------
const stores = [{ id: biz.id, name: business.name, label: loc.city, has_run: true, current: true }];

// ---------- the top of the map, side by side: every Google listing the run read for the field ----------
const profileRow = (pid, pts) => { const p = pid === subjectPid ? bi : profileOf(pid); if (!p) return null; const u = (() => { try { return new URL(p.url); } catch { return null; } })(); const av = p.attributes?.available_attributes || {};
  return { pid, short: shortOf(pid), name: pid === subjectPid ? business.name : p.title, me: pid === subjectPid, pts, rating: p.rating?.value ?? null, reviews: p.rating?.votes_count ?? null, photos: p.total_photos ?? null,
    ways: (av.service_options || []).length, attributes: Object.values(av).reduce((s, l) => s + l.length, 0), claimed: p.is_claimed === true, category: p.category || null, extra: (p.additional_categories || []).length,
    lands: u ? (u.pathname === '/' || u.pathname === '' ? 'home' : 'inner') : null, km: null }; };
const farPid = f => typeof f.km === 'number' && f.km > 150 * KM_PER_MI;
const topOfMap = mainSweep ? mainSweep.field.filter(f => f.is_you || (profileOf(f.pid) && !farPid(f))).map(f => ({ ...profileRow(f.pid, f.top3), km: f.km })).filter(r => r.pid) : [];
for (const rv of rivals) if (!topOfMap.some(r => r.pid === rv.place_id)) { const f = mainSweep?.field.find(x => x.pid === rv.place_id); const row = profileRow(rv.place_id, f ? f.top3 : null); if (row) topOfMap.push({ ...row, km: f?.km ?? null }); }
const profilesRead = READS.filter(r => r.kind === 'business_info').length;

// ---------- the software's own why-it-ranks layer ----------
const apex = [...(t.apex_runs || [])].sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))[0] || null;
const factors = apex ? (t.run_factors || []).filter(f => f.run_id === apex.id).map(f => ({ factor: f.factor, rho: f.rho, partial: f.partial_rho, q: f.q, n: f.n, survives: f.survives_control === true, note: f.note || null })) : [];
// "Distance from grid centre" is the stored distance of each sweep row against its share (Spearman, ties averaged). It is
// worked out again here over every row, then without the rows of businesses more than 150 miles away (another area's
// results), so the team can see whether the one factor that survives control leans on them.
const distanceFit = (() => {
  const ranked = xs => { const ix = xs.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]), out = new Array(xs.length); for (let i = 0; i < ix.length;) { let j = i; while (j + 1 < ix.length && ix[j + 1][0] === ix[i][0]) j++; for (let k = i; k <= j; k++) out[ix[k][1]] = (i + j) / 2 + 1; i = j + 1; } return out; };
  const rho = rows => { if (rows.length < 3) return null; const a = ranked(rows.map(r => r.distance_km)), b = ranked(rows.map(r => r.solv)), ma = mean(a), mb = mean(b); let sab = 0, saa = 0, sbb = 0; for (let i = 0; i < a.length; i++) { sab += (a[i] - ma) * (b[i] - mb); saa += (a[i] - ma) ** 2; sbb += (b[i] - mb) ** 2; } return Math.round(10000 * sab / Math.sqrt(saa * sbb)) / 10000; };
  // only the sweeps the software's fit could have seen: those finished before its latest model run (a scan folded in later is not)
  const fitRun = apex, fitSweeps = new Set((t.engine_sweeps || []).filter(w => !fitRun || +when(w.finished_at) <= +when(fitRun.created_at)).map(w => String(w.scan_id)));
  const rows = (t.engine_sweep_businesses || []).filter(r => fitSweeps.has(String(r.scan_id)) && typeof r.distance_km === 'number' && typeof r.solv === 'number'), near = rows.filter(r => r.distance_km <= 150 * KM_PER_MI);
  return { all: rho(rows), rows: rows.length, without_far: rho(near), rows_without_far: near.length, far_rows: rows.length - near.length };
})();
for (const f of factors) if (/distance from grid centre/i.test(f.factor)) f.refit = distanceFit;
const model = apex ? (t.model_versions || []).find(m => m.ver === apex.model_ver) || null : null;

// ---------- the maps block (the HS fields the builder reads, plus each sweep in full) ----------
const in100 = s => s === null ? null : (s < 1 ? 'fewer than 1' : `about ${Math.round(s)}`);
const maps = {
  scan_id: run.scan_id ?? null, phrase: run.keyword ?? null, scanned: dayTime(mainSweep?.finished), scanned_clock: clock(mainSweep?.finished), started: dayTime(mainSweep?.started), started_by_hand: !!mainSweep?.started_by_hand, mode: mainSweep?.started_how || null,
  in_hours: mainSweep ? mainSweep.open : null, close: closeOn(mainSweep?.finished), hold: !!mainSweep?.hold, hold_reasons: mainSweep?.hold_reasons || [],
  seen: mainSweep ? mainSweep.field.length - 1 : null, far: mainSweep ? { seen: mainSweep.field.length - 1, placed: mainSweep.field.filter(f => !f.is_you && typeof f.km === 'number').length, within_25: mainSweep.field.filter(f => !f.is_you && f.km <= 25 * KM_PER_MI).length, mid: mainSweep.field.filter(f => !f.is_you && f.km > 25 * KM_PER_MI && f.km <= 150 * KM_PER_MI).length, over_150: mainSweep.field.filter(f => !f.is_you && f.km > 150 * KM_PER_MI).length } : null,
  point_counts_that_fit: mainSweep ? [mainSweep.n] : [],
  board: mainSweep ? mainSweep.field.slice(0, 8).map(f => ({ id: f.pid, short: f.short, name: f.name, is_you: f.is_you, share: r2(100 * f.top3 / mainSweep.n), points: f.top3, n: mainSweep.n, in100: in100(100 * f.top3 / mainSweep.n) })) : [],
  scans_on_file: SW.length, earlier_scans: Math.max(0, SW.length - 1), earlier_in_hours: SW.filter(s => s !== mainSweep && s.open === true).length,
  sweeps: SW.map(s => ({ id: s.id, kw: s.kw, grid: s.grid, radius: s.radius, unit: s.unit, n: s.n, grid_points: s.grid_points, excluded: s.excluded, exclusion_note: s.exclusion_note,
    you: s.you.top3, found: s.you.found, not_found: s.you.not_found_points, place: s.place, tied: s.tied, of: s.of, you_lead: s.you_lead,
    leader: s.lead ? { short: s.lead.short, name: s.lead.name, points: s.lead.top3 } : null, best_rival: s.best ? { short: s.best.short, name: s.best.name, points: s.best.top3 } : null,
    top: s.field.slice(0, 8).map(f => ({ short: f.short, name: f.name, is_you: f.is_you, points: f.top3, found: f.found, rating: f.rating, reviews: f.reviews, miles: typeof f.km === 'number' ? r1(f.km / KM_PER_MI) : null })),
    finished: dayTime(s.finished), started: dayTime(s.started), store_day_hours: hoursOn(s.finished), open: s.open, open_at_start: s.open_at_start, started_how: s.started_how, started_by_hand: s.started_by_hand, starter_role: s.starter_role,
    far: s.far, unlisted: s.unlisted, share_mismatches: s.share_mismatches, by_rank: s.you.by_rank, hold: s.hold, hold_reasons: s.hold_reasons })),
  factors, model: model ? { ver: model.ver, fitted: day(when(model.fitted_at)), population: model.population_n, notes: model.notes } : null, apex: apex ? { id: apex.id, grid: apex.grid, solv: apex.solv, arp: apex.arp, residual: apex.residual } : null,
  scans: SW.map(s => ({ id: s.id, used: s === mainSweep, when: dayTime(s.finished), open: s.open, seen: s.field.length - 1, within_25: s.far.within_25, far: s.far.over_150, places: Object.fromEntries(rivals.map(r => [r.id, (s.field.findIndex(f => f.pid === r.place_id) + 1) || null])) })),
  list_runs_by_score: true,
};
const lossFirst = list => [...list].sort((a, b) => (a.you_lead - b.you_lead) || (!a.you_lead ? ((a.you === 0) !== (b.you === 0) ? (a.you === 0 ? -1 : 1) : (b.leader_points - b.you) / b.n - (a.leader_points - a.you) / a.n) : (a.you - (a.second_points || 0)) / a.n - (b.you - (b.second_points || 0)) / b.n));
maps.searches = lossFirst(SEARCHES).map(s => ({ key: s.key, kw: s.kw, when: s.when, date: s.date, n: s.n, you: s.you, found: s.found, place: s.place, tied: s.tied, of: s.of, you_lead: s.you_lead, leader: s.leader, leader_points: s.leader_points, leader_floor: !!s.leader_floor, second: s.second, second_points: s.second_points, open: s.open, hold: !!s.hold, source: s.source }));

// ---------- health checks ----------
// status: pass | watch | fail | na (not measured, or on hold). weight: outcome | rank | practice | protect | data.
const checks = [];
const check = (door, id, weight, status, ttl, value, detail, task = null, extra = {}) => checks.push({ door, id, weight, status, title: ttl, value, detail, task, ...extra });
const beside = business.also_viewed.map(a => a.ratings).filter(v => v !== null);
const pulls = Object.fromEntries([subjectPid, ...RV_PIDS].map(p => [p, pullOf(p)]));
const myPull = pulls[subjectPid];
const qk = s => `"${s.kw}"`;

// Google Maps: every search on file, where the store stands against number 1
for (const s of SEARCHES) {
  const st = s.hold ? 'na' : s.you_lead ? 'pass' : s.you >= s.leader_points * 0.8 ? 'watch' : 'fail';
  const placeTxt = s.you === 0 && s.found === 0 ? `Not in the first 20 at any of the ${s.n} points` : s.you === 0 ? `In the first 20 at ${s.found} of ${s.n} points and in the top 3 at none` : `${s.tied ? 'Tied ' : ''}${nth(s.place)} on the map`;
  const detail = s.you_lead
    ? `Number 1 for ${qk(s)}: in Google's top 3 at ${s.you} of ${s.n} points${s.second ? `, ${s.you === s.second_points ? 'level with' : `${plural(s.you - s.second_points, 'point', 'points')} ahead of`} ${s.second} (${s.second_points})` : ''}. Checked ${s.when}.`
    : `${placeTxt} for ${qk(s)}${s.you ? `: in Google's top 3 at ${s.you} of ${s.n} points` : ''}. ${s.leader} is number 1 with ${s.leader_floor ? 'at least ' : ''}${s.leader_points}. Checked ${s.when}.`;
  check('maps', 'map-' + s.key, 'outcome', st, `Number 1 on the map for ${qk(s)}`, s.you === 0 && s.found === 0 ? 'Not found' : `${s.you} of ${s.n} points`, detail, s.you_lead ? null : 'map-gap',
    s.hold ? { hold: true, sales: 'A clean check of this search comes first.', search: s.kw } : { search: s.kw });
}
if (mainSearch) { const sw0 = SW.find(w => w.kw === mainSearch.kw && w.n === mainSearch.n) || null, unc = sw0 ? sw0.unconfirmed_not_found : [];
  // a point where the store is not in the first 20 while another area's businesses are in it is not a confirmed "not there"
  const uncTxt = unc.length ? ` The ${plural(unc.length, 'point', 'points')} where it was not found ${unc.length === 1 ? 'is' : 'are'} not confirmed: ${unc.length === 1 ? 'its' : 'each one\'s'} first 20 carries ${unc.every(x => x === unc[0]) ? `${unc[0]}` : listOf(unc.map(String))} businesses from another area${sw0.far.miles ? `, about ${n(sw0.far.miles[0])} miles away` : ''}, which may have pushed the store out.` : '';
  check('maps', 'map-listed', 'practice', mainSearch.found / mainSearch.n >= 0.9 ? 'pass' : 'watch', 'Listed at nearly every point', `${unc.length ? 'at least ' : ''}${mainSearch.found} of ${mainSearch.n}`, `Google listed the store in its first 20 results at ${mainSearch.found} of ${mainSearch.n} points for ${qk(mainSearch)}.${uncTxt}`, null,
    unc.length ? { sales: `At least ${mainSearch.found} of the ${mainSearch.n} points list the store in Google's first 20 results for ${qk(mainSearch)}.`, unconfirmed: unc.length } : {}); }
// a search the owner expects and the record does not hold: a task for the team, never a result
const allSweeps = allSweepsPath ? (() => { const j = JSON.parse(fs.readFileSync(allSweepsPath, 'utf8')); return Array.isArray(j) ? j : j.rows || []; })() : null;
const missingSearches = (set.expect || []).filter(kw => !SEARCHES.some(s => s.kw === kw));
for (const kw of missingSearches) check('maps', 'map-missing-' + squash(kw), 'data', 'na', `A map check of "${kw}" is on file`, 'Not on file',
  `No map check of "${kw}" for this store is in the record: it holds ${plural(SW.length, 'sweep', 'sweeps')} for this store, ${listOf(SW.map(s => `"${s.kw}"`))}.${allSweeps ? ` None of the ${n(allSweeps.length)} sweeps in the software is a "${kw}" check of this store.` : ''} Nothing about "${kw}" is said in this report until one is run.`, 'expected-search', { expected: kw });
// rule 1, sweep by sweep: the time against the posted hours, how it was started, points left out, an out-of-market field
if (SW.length) {
  const outHours = SW.filter(s => s.open === false || s.open_at_start === false);
  check('maps', 'scan-hours', 'data', outHours.length ? 'fail' : SW.every(s => s.open === true) ? 'pass' : 'na', 'Map checks ran in opening hours', outHours.length ? `${outHours.length} of ${SW.length} after hours` : `${SW.length} of ${SW.length}`,
    SW.map(s => `"${s.kw}" ${s.started ? `ran ${clock(s.started)} to ${clock(s.finished)}` : `finished ${clock(s.finished)}`} on ${local(s.finished, { weekday: 'long', month: 'short', day: 'numeric' })}; the store's hours that day: ${hoursOn(s.finished) || 'not listed'}.`).join(' '), outHours.length ? 'rescan-open-hours' : null);
  const farAny = SW.filter(s => s.far.over_150), farTop = SW.filter(s => s.far.in_top3);
  const allFar = sum(SW, s => s.far.over_150), allRows = sum(SW, s => s.far.of);
  if (farAny.length) check('maps', 'scan-market', 'data', farTop.length ? 'fail' : 'watch', "The map checks' business lists are this market", `${allFar} of ${allRows} far away`,
    `${allFar} of the ${allRows} business rows the ${plural(SW.length, 'check', 'checks')} listed sit ${n(Math.min(...farAny.map(s => s.far.miles[0])))} to ${n(Math.max(...farAny.map(s => s.far.miles[1])))} miles away${[...new Set(farAny.flatMap(s => s.far.towns))].length ? `, around ${listOf([...new Set(farAny.flatMap(s => s.far.towns))].slice(0, 3))}` : ''}: another area's results, where the scan engine's searches come from (its Council Bluffs vantage), not this market. ${farAny.map(s => `In "${s.kw}" they show up in the first 20 at ${s.far.points} of ${s.n} points, at most ${s.far.most_in_a_list} in one list${s.far.not_found_with_far ? `; ${plural(s.far.not_found_with_far, 'of the points where the store was not found carries', 'of the points where the store was not found carry')} them` : ''}${s.far.in_top3 ? `; one reached a top 3 at ${s.far.in_top3} points. Read again with them taken out of each list, the store's count is ${s.clean && s.clean.you === s.you.top3 ? `the same (${s.you.top3})` : `${s.clean ? s.clean.you : 'not known'}, not ${s.you.top3}`}${s.clean ? `, and the others' rise: ${s.clean.top.map(x => `${x.short} ${x.tool} to ${x.clean}`).join(', ')}` : ''}. The tool's counts are printed, with "at least" for number 1 where it would rise` : ''}`).join('. ')}. ${farTop.some(s => s.hold) ? 'Where one moved the store\'s own count, that check is on hold.' : farTop.length ? 'None moved the store\'s own count, so every check stands.' : 'None reached a top 3 at any point, so the top-3 counts stand.'} They are left out of every field size, place, picker and table; the ranks at each point are as the tool returned them.`, 'scan-out-of-market');
  const excl = SW.filter(s => s.excluded);
  check('maps', 'scan-setup', 'data', excl.length ? 'watch' : 'pass', 'How the map checks were run', `${SW.length} ${SW.length === 1 ? 'check' : 'checks'}, ${[...new Set(SW.map(s => `${s.grid} by ${s.grid}, ${s.radius} ${s.unit}`))].join('; ')}`,
    `${SW.map(s => `"${s.kw}": ${s.started_by_hand ? `started by ${s.starter_role === 'admin' ? 'an admin' : 'a user'}` : 'the software holds no record of who started it or when'}${s.started_how ? ` (${String(s.started_how).replace(/_/g, ' ')})` : ''}, ${s.n} points${s.excluded ? `, ${s.excluded} of the ${s.grid_points} grid points left out before it ran` : ''}`).join('; ')}. ${excl.length ? `Counts for ${listOf(excl.map(s => `"${s.kw}"`))} are of ${listOf(excl.map(s => String(s.n)))} points, not ${excl[0].grid_points}.` : ''}`.trim(), null);
  const depthOk = SW.every(s => s.n > 0 && s.you.by_rank.top3 === s.you.top3 && !s.unlisted && !s.share_mismatches);
  check('maps', 'scan-depth', 'data', depthOk ? 'pass' : 'fail', 'Map checks came back in full', depthOk ? 'Every point' : 'Not in full',
    depthOk ? `Every point is in the record: the store's place at each point and the first 20 businesses there. The store's own rank field, its place in the lists and the software's share agree at every point of ${SW.length === 1 ? 'the check' : `all ${SW.length} checks`}.` : `The readings of the same points disagree: ${SW.filter(s => s.you.by_rank.top3 !== s.you.top3 || s.unlisted || s.share_mismatches).map(s => `"${s.kw}"`).join(', ')}.`, depthOk ? null : 'scan-points');
}
if (marketDisagree.length) check('maps', 'market-agrees', 'data', 'fail', 'The market file agrees with the record', `${marketDisagree.length} disagree`, marketDisagree.join('; '), 'scan-points');
check('maps', 'claimed', 'rank', business.claimed ? 'pass' : 'fail', 'Listing is claimed', business.claimed ? 'Claimed' : 'Not claimed', business.claimed ? 'The Google listing is claimed.' : 'Nobody has claimed the Google listing.', business.claimed ? null : 'claim-listing');
const CATEGORY = { Cannabis: ['cannabis_store'] };
const catOk = (CATEGORY[business.vertical] || []).some(c => business.category_ids.includes(c));
check('maps', 'category', 'rank', CATEGORY[business.vertical] ? (catOk ? 'pass' : 'fail') : 'na', 'Main category fits the store', business.category || 'None', `The main category is ${business.category}.${business.extra_categories.length ? ` Also listed: ${business.extra_categories.join(', ')}.` : ''}`, catOk ? null : 'fix-category');
if (business.rating !== null) check('maps', 'rating', 'rank', business.rating >= 4.5 ? 'pass' : business.rating >= 4 ? 'watch' : 'fail', 'Star rating', `${business.rating.toFixed(1)} stars`, `${business.rating.toFixed(1)} stars from ${n(business.ratings)} ratings.`, business.rating >= 4.5 ? null : 'low-star-subjects');
check('maps', 'service-options', 'rank', business.service_options.length >= 2 ? 'pass' : 'watch', 'Ways to shop are listed', `${business.service_options.length} listed`, business.service_options.length ? `Listed: ${business.service_options.join(', ').toLowerCase()}.` : 'No ways to shop are listed.', business.service_options.length >= 2 ? null : 'add-service-options');
// one store: its website is the store's own page
if (business.listing_is_homepage !== null) check('maps', 'listing-link', 'rank', business.listing_is_homepage && stores.length > 1 ? 'watch' : 'pass', "Listing links to the store's own page", business.listing_is_homepage ? 'The website' : business.listing_path,
  business.listing_is_homepage ? (stores.length > 1 ? 'The listing links to the homepage instead of a page for this store.' : `The listing links to ${domain}, the website of this one store.`) : `The listing links to this store's own page, ${business.listing_path}.`, business.listing_is_homepage && stores.length > 1 ? 'town-page' : null);
if (tag && isOurs(listingUrl.toString())) check('maps', 'listing-tag', 'protect', 'watch', 'Our tag on the listing link', tag, `The listing link carries our own tags: ${tagOf(listingUrl.toString()).map(([k, v]) => `${k}=${v}`).join(', ')}.`, null, { internal: true });
if (reviews) {
  if (beside.length >= 3) check('maps', 'review-count', 'practice', business.ratings >= Math.min(...beside) ? 'pass' : 'watch', 'Review count against the stores beside it', n(business.ratings), `${n(business.ratings)} ratings. The ${beside.length} stores Google lists beside this one have ${n(Math.min(...beside))} to ${n(Math.max(...beside))}.`, business.ratings >= Math.min(...beside) ? null : 'review-gap');
  check('maps', 'review-pace', 'practice', reviews.pace_90 >= reviews.pace_before_90 * 0.8 ? 'pass' : 'watch', 'New reviews keep coming', `${reviews.pace_90} a month`, `${reviews.last_90} reviews in the last 90 days, ${reviews.pace_90} a month. The 275 days before brought ${reviews.before_90}, ${reviews.pace_before_90} a month. A month here is 30.4 days.`, reviews.pace_90 >= reviews.pace_before_90 * 0.8 ? null : 'review-gap');
  const w90 = reviews.windows?.d90;
  check('maps', 'replies', 'practice', reviews.reply_rate >= 80 ? 'pass' : 'watch', 'Reviews get a reply', `${reviews.reply_rate}% answered`, `${n(reviews.with_reply)} of ${n(reviews.collected)} reviews have an owner reply${w90 ? `, and ${w90.replied} of the ${w90.n} from the last 90 days` : ''}.`, reviews.reply_rate >= 80 ? null : (reviews.low_open ? 'reply-low-stars' : 'reply-reviews'));
  if (reviews.low_open > 0) check('maps', 'low-open', 'protect', 'watch', 'Low-star reviews are answered', `${reviews.low_open_12} open`, `${plural(reviews.low_open_12, 'review', 'reviews')} of 1 or 2 stars from the last 12 months ${reviews.low_open_12 === 1 ? 'has' : 'have'} no reply yet${reviews.low_open > reviews.low_open_12 ? `, and ${reviews.low_open - reviews.low_open_12} older ones` : ''}.`, 'reply-low-stars');
  if (reviews.since_avg !== null && reviews.opening_avg - reviews.since_avg >= 0.2) check('maps', 'recent-rating', 'protect', 'watch', 'Recent reviews hold the rating', `${reviews.since_avg} lately`, `The rating stands at ${business.rating}. The first 10 weeks of reviews averaged ${reviews.opening_avg}; the ${n(reviews.since_n)} since average ${reviews.since_avg}.`, 'low-star-subjects');
}
// review velocity: the store's own dated reviews beside each rival's, counted the same way over the same 90 days
const velRows = [subjectPid, ...RV_PIDS].map(p => ({ pid: p, short: shortOf(p), me: p === subjectPid, pull: pulls[p] })).filter(x => x.pull && x.pull.d90);
if (myPull?.d90 && velRows.length > 1) {
  const others = velRows.filter(x => !x.me).map(x => x.pull.d90.per_month).sort((a, b) => a - b), mid = others[Math.floor((others.length - 1) / 2)];
  const ok = myPull.d90.per_month >= mid * 0.8;
  check('maps', 'review-velocity', 'practice', velocityOk ? (ok ? 'pass' : 'watch') : 'na', 'Review velocity keeps pace with the rivals', `${n(Math.round(myPull.d90.per_month))} a month`,
    `Over the 90 days to ${myPull.collected_at}: ${velRows.map(x => `${x.me ? 'the store' : x.short} ${n(Math.round(x.pull.d90.per_month))} a month (${x.pull.d90.n})`).join(', ')}. Counted from each store's own dated Google reviews.${velocityOk ? '' : " The software's own count of the store's reviews disagrees, so the pace is not quoted."}`, ok ? null : 'review-gap', velocityOk ? {} : { hold: true, sales: 'A second count of the reviews comes first.' });
}
{ const at = business.attributes, odd = [at.includes('Parking lot free') && at.includes('Parking lot paid') ? 'parking is marked both free and paid' : null, at.includes('Cash only') ? 'the listing says cash only' : null].filter(Boolean);
  if (odd.length) check('maps', 'listing-details', 'practice', 'watch', 'Listing details to confirm with the store', `${odd.length} to confirm`, `On the Google listing: ${odd.join('; ')}. Each is worth a yes or no from the store.`, 'listings-hand-check'); }
if (hours) check('maps', 'hours', 'practice', hours.daysListed === 7 ? 'pass' : 'watch', 'Opening hours are listed', hours.daysListed === 7 ? '7 days' : `${hours.daysListed} of 7 days`, `Hours are listed: ${hours.summary}.`, hours.daysListed === 7 ? null : 'fix-hours');

// Google search
if (search.keywords_total !== null) check('search', 'footprint', 'practice', 'watch', 'Searches the whole website shows up for', n(search.keywords_total), `The whole website shows in Google's first 100 results for ${n(search.keywords_total)} searches, ${n(search.top10)} of them on page 1. The rivals' one-store websites: ${rivals.filter(r => r.keywords !== null && !isChain(r)).map(r => `${r.short} ${n(r.keywords)}`).join(', ')}${chainRivals.length ? `; ${listOf(chainRivals.map(r => r.short))}'s website covers many stores, so it is not set beside this one` : ''}. Which searches they are was not read for this report.`, 'content-gap');
check('search', 'connected', 'practice', search.analytics_connected && search.search_console_connected ? 'pass' : 'watch', 'Google Analytics and Search Console are connected', search.analytics_connected && search.search_console_connected ? 'Both connected' : 'Not connected', search.analytics_connected && search.search_console_connected ? 'Both are connected.' : 'Neither is connected to the software, so every search number here is an outside estimate.', search.analytics_connected && search.search_console_connected ? null : 'connect-google');
check('search', 'ranked-keywords', 'data', search.ranked_read ? 'pass' : 'fail', 'The searches the website ranks for are in the record', search.ranked_read ? 'Read' : 'Not read in this run', search.ranked_read ? 'Read.' : `This run's settings left the ranked-searches read and the position checks off (ranked keywords: ${search.ranked_setting === null ? 'off' : JSON.stringify(search.ranked_setting)}, positions: ${search.organic_ranks_setting === null ? 'off' : JSON.stringify(search.organic_ranks_setting)}). The tab shows whole-website counts only.`, search.ranked_read ? null : 'ranked-keywords');
check('search', 'rival-searches', 'data', 'fail', "The rivals' searches are in the record", 'Counts only', "The record holds how many searches each rival's website shows up for, and not which ones.", 'rivals-searches');

// AI answers
check('ai', 'ai-named', 'outcome', 'na', 'Named in AI answers', 'Not collected', 'This report did not ask ChatGPT, Perplexity or Google AI Mode which stores they recommend. The software has no answer-engine surface yet.', 'collect-ai');

// Website
if (website.phone) check('website', 'speed-phone', 'practice', website.phone.band, 'Speed on a phone', `${website.phone.score} of 100`, `Google's lab speed test on a simulated slow phone scores the store page ${website.phone.score} of 100${website.desktop ? ` and ${website.desktop.score} on a desktop` : ''}. Main content shows in ${website.phone.metrics.lcp?.display}; the page is blocked for ${website.phone.metrics.tbt?.display}.`, website.phone.band === 'pass' ? null : 'speed');
else check('website', 'speed-phone', 'practice', 'na', 'Speed on a phone', 'Not measured', 'No speed test is in the record.');
if (website.words !== null) {
  const thin = website.thin_to_crawler === true || (website.crawler_words !== null && website.browser_words && website.crawler_words < website.browser_words * 0.5);
  check('website', 'page-words', 'protect', thin || website.words < 300 ? 'watch' : 'pass', "The store page carries the store's own words", `${n(website.words)} words read`,
    `Our page reader got ${n(website.crawler_words ?? website.words)} words from the store page as a plain crawler${website.browser_words !== null ? ` and ${n(website.browser_words)} as a browser` : ''}.${website.age_gate ? ` The page has an age check${thin ? ', and the crawler gets far less text than the browser' : ', and it does not keep the text from a crawler'}.` : ''}`, thin || website.words < 300 ? 'store-page-check' : null);
  const agree = website.main_heading_in_list === (website.main_heading_flag_missing === false);
  check('website', 'main-heading', 'practice', website.main_heading_in_list && agree ? 'pass' : 'watch', 'The page has a main heading', website.main_heading_in_list ? 'Present' : agree ? 'None found' : 'Not confirmed', agree ? (website.main_heading_in_list ? `The page has a main heading: "${website.main_heading}".` : 'No main heading was found on the page.') : 'The reading disagrees with itself about the main heading. The page source settles it.', website.main_heading_in_list && agree ? null : 'store-page-check');
}
if (website.title) check('website', 'title', 'practice', website.title_chars >= 30 && website.title_chars <= 65 && website.description_chars >= 70 ? 'pass' : 'watch', 'Title and description', `${website.title_chars} and ${website.description_chars} characters`, `Title: "${website.title}".`, null);
if (website.status !== null) { const clean = website.status === 200 && website.https && website.hops === 0 && website.canonical_self !== false;
  check('website', 'basics', 'protect', clean ? 'pass' : 'fail', 'Secure, direct and not duplicated', clean ? 'All clear' : `Status ${website.status}`, `The page answers on a secure address${website.hops === 0 ? ' with no redirects' : ` after ${website.hops} redirects`}${website.canonical_self ? ' and names itself as the original' : ''}.`, clean ? null : 'store-page-check'); }
if (saR) { const two = website.business_schema !== null && website.business_schema !== website.structured_data_found;
  check('website', 'store-details', 'practice', website.business_schema && !two ? 'pass' : 'watch', 'Store details Google can read from the page', two ? 'Not confirmed' : website.business_schema ? 'Found' : 'Not found',
    two ? `The reading disagrees with itself: the page's own code declares ${listOf(website.schema_types.slice(-3))}, and the same reading's check for store details says none. Google's rich results test settles it.` : website.business_schema ? 'The page carries the store details in the form Google reads.' : 'The reading found none of the store details Google reads from a page.', website.business_schema && !two ? null : 'store-page-check'); }
// landing_flags reads the Google listing, the page and the links each version of its address carries (bl_variants): it
// flags a listing that links to a weaker version of the address (http or https, www or not, a closing slash), and notes
// redirects. That is what the check says; the software's page checks are a separate check below.
{ const fl = website.flags, FLAG = { 'weak-variant-designated': 'links to a version of its address that carries fewer links than another version' }, said = f => FLAG[f] || String(f).replace(/-/g, ' ');
  const flagged = website.rivals.filter(r => r.page.flags && r.page.flags.length);
  if (fl) check('website', 'landing-flags', 'practice', fl.length ? 'watch' : 'pass', 'The listing links to the strongest version of the page address', fl.length ? `${fl.length} flagged` : 'No flag',
    `The software sets the address the Google listing links to beside the other versions of the same address (http or https, with or without www or a closing slash) by the links each carries. ${fl.length ? `The store's listing ${fl.map(said).join('; ')}.` : "The store's listing links to the version that carries the most."}${flagged.length ? ` ${listOf(flagged.map(r => r.name))}: the listing ${listOf([...new Set(flagged.flatMap(r => r.page.flags.map(said)))])}.` : ''}`, fl.length ? 'store-page-check' : null); }
// the software's own checks of the store page: its latest run's open page-check findings, in words a client can read
{ const lastRun = [...(t.apex_runs || [])].sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))[0] || null;
  const PAGE_CHECK = { DUPLICATE_META_TAGS: 'duplicate meta tags', FRAME: 'a frame on the page', HAS_RENDER_BLOCKING_RESOURCES: 'files that hold up the first paint', LOW_CONTENT_RATE: "little text for the page's size", META_CHARSET_CONSISTENCY: 'a character set that is not declared the same way throughout', NO_IMAGE_ALT: 'images without alt text', NO_IMAGE_TITLE: 'images without a title' };
  const open = lastRun ? (t.findings || []).filter(f => f.run_id === lastRun.id && /^PAGE_CHECK_/.test(f.code) && (t.tasks || []).some(x => x.finding_id === f.id && x.state === 'open')) : [];
  const words = [...new Set(open.map(f => PAGE_CHECK[f.code.replace(/^PAGE_CHECK_/, '')] || f.code.replace(/^PAGE_CHECK_/, '').toLowerCase().replace(/_/g, ' ')))];
  if (lastRun) check('website', 'page-checks', 'practice', words.length ? 'watch' : 'pass', "The software's checks of the store page", words.length ? `${words.length} to look at` : 'None open',
    words.length ? `The software's own checks of the store page raised ${plural(words.length, 'point', 'points')} to look at: ${listOf(words)}.` : "The software's own checks of the store page raised nothing.", words.length ? 'store-page-check' : null, { codes: open.map(f => f.code) }); }
{ const c = website.crawl;
  check('website', 'whole-site', 'data', 'watch', 'The whole site was read', c ? `${website.pages_read} pages read, ${c.pages} crawled` : `${website.pages_read} pages read`,
    `${plural(website.pages_read, 'page was', 'pages were')} read one by one${website.sitemap_pages ? ` of the ${n(website.sitemap_pages)} the site's own sitemaps list` : ''}.${c ? ` The crawl stopped at its limit of ${c.max} pages${c.at_limit ? ', so its counts are counts within those pages' : ''}.` : ''}`, 'crawl-limit'); }

// Links and listings
if (links) {
  check('links', 'linking-sites', 'practice', links.sellers / links.sites >= 0.3 ? 'watch' : 'pass', 'Sites that link to the website', `${n(links.not_sellers)} without the link sellers`,
    `${n(links.sites)} sites link to ${business.domain}. ${n(links.sellers)} of them are link-selling or scheme pages: ${n(links.by_title)} by the title of the page each link sits on (a title that sells links, or one title shared by 20 or more linking sites), ${n(links.by_ledger)} flagged by the software's own link ledger, some by both. That leaves ${n(links.not_sellers)}, and ${n(links.clean_with_weight)} of those carry some weight.${(() => { const q = links.quality; if (!q || !q.weighted) return ''; const st = Object.entries(q.strict).filter(([, v]) => v);
      return ` What the ${q.weighted} with weight are, by their pages' titles: ${plural(q.names_store.length, 'carries', 'carry')} the store's name in the page title, directory pages and articles (${q.names_store.join(', ')}); ${q.copied.length ? `${q.copied.length} carry one article copied on unrelated sites ("${q.copied_title}": ${q.copied.join(', ')}); ` : ''}${plural(q.articles.length, 'is a cannabis article', 'are cannabis articles')} on general sites without the name in the title (${q.articles.join(', ')}). A stricter pass over the sites that are not sellers, dropping any with a spam score of 30 or more and any page title two or more linking hosts share, leaves ${st.map(([k, v]) => `${k} ${n(v.not_sellers)} (${n(v.with_weight)} with weight)`).join(', ')}.`; })()}`, links.sellers / links.sites >= 0.3 ? 'junk-links' : null,
    // rule 8: a client reads the classified counts only, never the total with the junk left in
    { sales: `${n(links.sellers)} of the sites that link to ${business.domain} are link-selling or scheme pages, going by the page each link sits on. ${n(links.not_sellers)} are not, and ${n(links.clean_with_weight)} of those carry some weight.` });
  if (links.fresh_sellers / Math.max(1, links.sites) >= 0.2) check('links', 'link-wave', 'protect', 'watch', 'No wave of link-selling pages', `${n(links.fresh_sellers)} in ${links.fresh_days} days`,
    `${n(links.fresh_sellers)} link-selling pages appeared in the last ${links.fresh_days} days. ${n(links.fresh_sellers_also_rivals)} of them also link to two or more of the three rivals, so this is a wave across the market and not aimed at one store.${links.wave ? ` ${n(links.wave.hosts)} carry one title, "${links.wave.title}", first seen ${links.wave.from} to ${links.wave.to}.` : ''}`, 'junk-links');
  check('links', 'link-list', 'practice', links.gap_worth.length ? 'watch' : 'pass', "Sites that link to the rivals' websites and not to this one", `${links.gap_worth.length} with some weight`, `${plural(links.gap_worth.length, 'site with some weight links', 'sites with some weight link')} to two or more of the three rivals' websites and not to this one.`, links.gap_worth.length ? 'link-list' : null);
  if (links.tagged_total > 0) check('links', 'directory-work', 'practice', 'watch', 'Our directory work covers this store', `${n(links.tagged_total)} tagged links`, `${n(links.tagged_total)} links to this website carry our own tag.`, 'directory-work', { internal: true });
}
if (listings) {
  check('links', 'details-found', 'practice', listings.phone_named_outside >= 5 ? 'pass' : 'watch', "Google shows the store's details on other sites", `${listings.phone_named_outside} sites`, `Searching Google for the store's phone number, street address and name: ${listings.phone_named_outside} outside sites show the phone number with the store's name, and ${listings.street_named_sites} sites show the street address with it.`, listings.phone_named_outside >= 5 ? null : 'listings-hand-check');
  // say what was seen: results off the store's own website that show its number and not the name, by kind of site
  if (listings.phone_other) { const LOOKUP = /phone|people|lookup|whitepages|intelius|spokeo|\.storage|googleapis\.com$|amazonaws\.com$|windows\.net$/i, look = listings.phone_other_sites.filter(h => LOOKUP.test(h)), rest = listings.phone_other_sites.filter(h => !LOOKUP.test(h));
    check('links', 'other-names', 'protect', 'watch', "Results that show the store's number without its name", `${listings.phone_other} results on ${listings.phone_other_sites.length} sites`,
      `${plural(listings.phone_other, 'Google result', 'Google results')} on ${plural(listings.phone_other_sites.length, 'site', 'sites')} show the store's phone number without the name ${business.short}, off its own website: ${[look.length ? `${plural(look.length, 'phone-lookup or people-search page', 'phone-lookup or people-search pages')}` : null, rest.length ? rest.join(', ') : null].filter(Boolean).join(', and ')}. Each needs a look by hand before anything is said about it.`, 'listings-hand-check'); }
  if (listings.table.length) check('links', 'listings-read', 'practice', listings.table_both === listings.table.length ? 'pass' : 'watch', 'Listings that could be read show phone and address', `${listings.table_both} of ${listings.table.length}`, `${listings.table.length} sites carry a listing for this store that the report could tie to it. On ${listings.table_both} the phone and the address were both seen. ${listings.store_pages_empty ? `${listings.store_pages_empty} of its pages came back empty${listings.store_empty_by_site[0] ? `, ${listings.store_empty_by_site[0].n} of them on ${listings.store_empty_by_site[0].host}` : ''}. ` : ''}An empty read is not a missing listing.`, listings.table_both === listings.table.length ? null : 'listings-hand-check');
  if (listings.verdicts) { const v = listings.verdicts; check('links', 'directory-verdicts', 'practice', v.undetermined > v.checked / 2 ? 'watch' : v.not_listed ? 'watch' : 'pass', "Directories the software checked for this store", `${v.listed} listed of ${v.checked}`,
    `The software checked ${v.checked} directories on ${v.computed}: ${v.listed} list the store, ${v.not_listed} ${v.not_listed === 1 ? 'does' : 'do'} not, and ${v.undetermined} could not be read either way (walled directories, or listings its search did not find). Could not be read is not "not listed".`, 'listings-hand-check');
    // the team's line: sources in the software's list that belong to another market are a defect in the list, not a finding
    if (v.other_market.length) check('links', 'directory-sources', 'data', 'fail', "The software's directory list is this store's market", `${v.other_market.length} from another market`,
      `The software's directory list for this store holds ${plural(v.other_market.length, 'source that names', 'sources that name')} ${v.other_market_label || "another market's"} places, left over from another store's list: ${v.other_market.map(x => x.domain).join(', ')}. ${v.other_market.every(x => x.verdict === 'undetermined') ? 'All of them came back could not be read. ' : ''}They are a defect in the software's source list for this store, and this report leaves them out of every directory count: ${v.checked} checked, not ${v.checked_all}.`, 'directory-sources'); }
  if (listings.directories_listed) check('links', 'directory-coverage', 'data', listings.directories_searched >= listings.directories_listed / 2 ? 'pass' : 'fail', 'Directories were searched for this store', `${listings.directories_searched} of ${listings.directories_listed}`, `${listings.directories_listed} directories are on the list. ${listings.directories_tested} were tested with a lookup of another business to see whether they can be read, and ${listings.directories_test_passed} passed. ${listings.directories_searched} were searched for this store; ${listings.directories_answered} answered and ${listings.directories_showed} showed its phone or address.`, listings.directories_searched >= listings.directories_listed / 2 ? null : 'directory-coverage');
}
// the run and the answers themselves
const ranFor = p => run.steps.filter(s => s.part === p && s.place_id !== subjectPid);
const rivalParts = ['reviews', 'site_audits', 'page_speed', 'exhaustive', 'cit_pages'].filter(p => ranFor(p).length && ranFor(p).every(s => s.state === 'done') && RV_PIDS.every(pid => READS.some(r => r.place_id === pid)));
// an overview check shows only through its task, so one that passes (and has none) is not emitted
if (rivalParts.length !== 5) check('overview', 'rival-rows', 'data', 'watch', "Rivals' listings, reviews, pages, speed, links and listings are in the record", rivalParts.length === 5 ? 'In the record' : `${rivalParts.length} of 5 parts`, rivalParts.length === 5 ? "The full-audit answer hands back each rival's own readings, so every tab sets the store beside them." : `Missing for the rivals: ${['reviews', 'site_audits', 'page_speed', 'exhaustive', 'cit_pages'].filter(p => !rivalParts.includes(p)).join(', ')}.`, rivalParts.length === 5 ? null : 'rival-rows');
if (!((t.findings || []).length && (t.tasks || []).length)) check('overview', 'stored-findings', 'data', 'fail', 'Findings and tasks are stored by the software', `${(t.findings || []).length} and ${(t.tasks || []).length}`, (t.findings || []).length ? `The software stored ${(t.findings || []).length} findings and ${(t.tasks || []).length} tasks over ${new Set((t.findings || []).map(f => f.run_id)).size} runs. Each is on the Tasks tab, marked as the software's own.` : 'The software stored no findings and no tasks.', (t.findings || []).length ? null : 'store-findings');
// our own accounts in this store's map field (--locations=SEOS's list of every location): rivals on this map like any other,
// never named as ours to this client. Team only, and on the hold table so the client copy is checked for it.
const locPath = opt('locations');
const ownAccounts = locPath ? (() => { const j = JSON.parse(fs.readFileSync(locPath, 'utf8')); const rows = Array.isArray(j) ? j : j.rows || j.locations || j.tables?.locations || [];
  return rows.filter(r => r.place_id && r.business_id !== biz.id && SW.some(w => w.field.some(f => f.pid === r.place_id))).map(r => ({ business: r.business_id, name: profileOf(r.place_id)?.title || r.name, city: r.city, state: r.state, pid: r.place_id, leads: SEARCHES.filter(x => !x.you_lead && x.leader_pid === r.place_id).map(x => x.kw) })); })() : [];
if (ownAccounts.length) check('maps', 'own-accounts', 'data', 'watch', "Our own accounts in this store's map field", `${ownAccounts.length} of ours`, `${ownAccounts.map(a => `${a.name} (our business ${a.business}${a.city ? `, ${a.city} ${a.state}` : ''})${a.leads.length ? `, number 1 for ${listOf(a.leads.map(k => `"${k}"`))}` : ''}`).join('; ')}: tracked in our own software too. To this client they are businesses on the public map like any rival; never say they are ours.`, null);
// readings in the answer that are not about this store, its rivals or this run's market
const otherAnalytics = READS.filter(r => ['analytics_watch', 'gsc_sitemaps'].includes(r.kind) && r.place_id !== subjectPid);
const fieldPids = new Set(SW.flatMap(s => s.field.map(f => f.pid)));
const farPids = new Set(SW.flatMap(s => s.field.filter(f => typeof f.km === 'number' && f.km > 150 * KM_PER_MI).map(f => f.pid)));
const oldReads = READS.filter(r => r.fetched_at && +when(r.fetched_at) < +runStart - 3 * 864e5 && r.place_id !== subjectPid && !RV_PIDS.includes(r.place_id));
if (otherAnalytics.length || oldReads.length) check('overview', 'answer-scope', 'data', otherAnalytics.length ? 'fail' : 'watch', "The audit answers hold this store's market only", `${otherAnalytics.length + oldReads.length} readings about others`,
  `${otherAnalytics.length ? `The full-audit answer carries ${otherAnalytics.length} Google Analytics and Search Console readings of ${new Set(otherAnalytics.map(r => host(r.target))).size} other businesses' websites (${[...new Set(otherAnalytics.map(r => host(r.target)))].join(', ')}): another account's own data. They are not used here. ` : ''}${oldReads.length ? `${oldReads.length} more readings were bought for other reports (${[...new Set(oldReads.map(r => day(when(r.fetched_at))))].join(', ')}), ${oldReads.filter(r => farPids.has(r.place_id)).length} of them about businesses the checks placed hundreds of miles away; they are not used either.` : ''}`.trim(), 'answer-isolation');

// ---------- tasks ----------
const fixSteps = (website.phone?.fixes || []).slice(0, 3).map(f => `${f.title}: about ${f.saves_s} s faster.`);
const worthCannabis = (links?.gap_worth || []).filter(g => g.cannabis).map(g => g.domain), worthOther = (links?.gap_worth || []).filter(g => !g.cannabis).map(g => g.domain);
const lossRows = SEARCHES.filter(s => !s.you_lead && !s.hold).sort((a, b) => (a.you === 0) !== (b.you === 0) ? (a.you === 0 ? -1 : 1) : (b.leader_points - b.you) / b.n - (a.leader_points - a.you) / a.n);
const L1 = lossRows[0] || null;
const L1prof = L1 ? profileRow(L1.leader_pid, L1.leader_points) : null;
const TASKS = {
  'map-gap': { owner: 'us', group: 'map', title: L1 ? `Close the gap to ${L1.leader} for "${L1.kw}"` : 'Close the gap to number 1 on the map', sales_title: L1 ? `Win "${L1.kw}" on the map` : 'Win more of the map', benefit: L1 ? `Number 1 for "${L1.kw}" holds ${L1.leader_floor ? 'at least ' : ''}${L1.leader_points} of ${L1.n} points; the store holds ${L1.you}.` : 'More of the map in Google\'s top 3.',
    steps: [L1 ? `Set the store's listing beside ${L1.leader}'s, line by line (Google Maps tab): ratings, photos, review velocity, ways to shop, categories.` : 'Set the store beside number 1, line by line.', "Read the software's own factors for this market before changing anything: the only one that survives its control is the distance from the grid centre.", 'Change one thing at a time on the listing, and date each change.', 'Check both searches again in opening hours on the same grid every four weeks.'], done: L1 ? `Number 1 for "${L1.kw}", or the gap to ${L1.leader} halved, in a check taken in opening hours.` : 'Number 1 on the map for every search checked.' },
  'expected-search': { owner: 'us', group: 'first', service_only: true, title: missingSearches.length ? `Get the "${missingSearches[0]}" map check on file` : 'Get the missing map check on file', steps: [missingSearches.length ? `Find the "${missingSearches[0]}" scan the owner remembers: it is not in the software's records.` : 'Find the scan.', 'If it cannot be found, run one in opening hours on the same grid as the others (11 by 11, 2 miles).', 'Add it to the market file (sweeps-market --extra). The report picks it up with no change: the headline, the checks and the gap lines.'], done: missingSearches.length ? `A "${missingSearches[0]}" map check of this store is on file and in the report.` : 'The check is on file.' },
  'rescan-open-hours': { owner: 'us', group: 'first', title: 'Run the map checks again in opening hours', sales_title: 'Check the map while the store is open', benefit: 'Shows where the store appears around town while it is open.', steps: [`Run them between ${hours?.days[0]?.open || 'opening'} and ${hours?.days[0]?.close || 'closing'} store time.`, 'Hold every map number in this report until then.'], done: 'Every map check on file ran in opening hours.' },
  'client-questions': { owner: 'us', group: 'first', service_only: true, title: 'Send the client one email with three questions', steps: ['Who replies to Google reviews today?', 'Has anyone ordered links for the website in the last two months?', "Who holds the logins for the store's listings (Google, Weedmaps, Leafly, Yelp, Apple Maps)?"], done: 'All three answers are on file.' },
  'reply-reviews': { owner: 'us', group: 'reviews', title: 'Answer new Google reviews as they come in', sales_title: 'Answer every new review', benefit: `Shows customers the store reads what they write, and keeps the ${business.rating?.toFixed(1)} stars working for it.`,
    steps: [reviews?.windows?.d90 ? `Start with the ${reviews.windows.d90.n} reviews from the last 90 days: ${reviews.windows.d90.replied} have a reply.` : 'Start with the newest reviews.', 'Draft each reply plainly, in the store\'s voice, and thank the customer by what they mention.', 'Send the drafts to the store for approval, then post them.', 'Then reply within a week of each new review.'], done: 'Every review from the last 90 days has a reply, and new ones get one within a week.' },
  'low-star-subjects': { owner: 'us', group: 'reviews', title: 'Take the low-star subjects to the store manager', sales_title: 'Read the low-star reviews as a group, with your manager', benefit: 'Stops the same complaint from costing stars again.', steps: ['Read the low-star reviews and confirm the subjects by hand.', 'Agree one change in store for the top subject.'], done: 'One change is agreed.' },
  'reply-low-stars': { owner: 'us', group: 'reviews', title: `Draft replies to the ${reviews?.low_open || ''} low-star reviews that have none`, sales_title: 'Answer the open low-star reviews', benefit: `Protects the ${business.rating}.`, steps: ['Draft each reply plainly, with a way to reach the manager.', 'Send the drafts to the store for approval, then post them.'], done: 'Every 1 and 2 star review has a reply.' },
  'review-gap': { owner: 'client', group: 'reviews', title: 'Keep review velocity up with the rivals', sales_title: 'Keep new reviews coming as fast as your rivals', benefit: 'More recent reviews than the stores beside you.', steps: ['Put a card at checkout with a code that opens the Google review form.', 'Ask every customer, not only the happy ones.', 'No rewards for reviews: Google bans them.'], done: 'New reviews hold at the rivals\' pace for three months.' },
  'store-page-check': { owner: 'us', group: 'page', title: 'Check the store page by hand, as one ticket', sales_title: 'Make sure Google reads the store page', benefit: "Google reads the store's details and words from the page its listing sends people to.",
    steps: ["Run the page through Google's rich results test: does it read the store's name, address, phone and hours?", 'Open the page source: is the store-details code there once, and valid?', 'Fix the duplicate meta tags the software found, in the same ticket.'], done: "Google's rich results test reads the store's details." },
  'content-gap': { owner: 'us', group: 'content', blocked_by: ['rivals-searches', 'ranked-keywords'], title: 'Name the searches the rivals are found for and this website is not', sales_title: 'Name the searches your rivals win and you miss', benefit: 'Turns the gap in searches into a short list of pages worth building.', steps: ["Get this website's searches and the rivals' page 1 searches for Elizabeth and the towns around it. Neither is in this run.", 'Pick the ten with the most searches a month that this website misses.', 'Plan a page for a group of them only where there is something true and specific to say.'], done: 'Ten missed searches are named, with searches a month, and the first three pages are briefed.' },
  'listings-hand-check': { owner: 'us', group: 'links', title: 'Check the listings that matter by hand', sales_title: 'Check the listings that matter', benefit: "The store's name, address and phone read the same wherever a customer looks.",
    steps: [`Open each listing in the tables on the Links and listings tab${(listings?.matter || []).length ? `: ${(listings.matter || []).map(m => m.label).slice(0, 8).join(', ')}` : ''}.`, listings?.verdicts ? `Settle the ${listings.verdicts.undetermined} directories the software could not read either way, starting with the core and cannabis ones.` : 'Note the name, address, phone, hours and link on each.', listings?.phone_other ? `Look at the ${listings.phone_other} results where the store's phone number shows without its name.` : 'Fix or claim what is wrong.'], done: 'Each listing that matters is marked right, fixed or claimed.' },
  'link-list': { owner: 'us', group: 'links', title: "Ask the sites that link to the rivals' websites for a link to this one", sales_title: 'Get links from the sites that link to your rivals', benefit: "Relevant sites that already link to the other stores' websites.",
    steps: [worthCannabis.length ? `Start with the cannabis sites: ${worthCannabis.slice(0, 8).join(', ')}.` : 'Start with the cannabis directories on the list.', worthOther.length ? `Look at the others by hand before asking: ${worthOther.slice(0, 8).join(', ')}.` : 'Look at each site by hand before asking.', 'For each one, find how the rivals got listed and ask for the same.'], done: 'Listed on each named site, or a no is on file.' },
  'junk-links': { owner: 'us', group: 'links', title: 'Find out whether anyone bought links, then watch the wave', sales_title: 'Watch the wave of link-selling pages', benefit: "Keeps a market-wide wave of link-selling pages from becoming the store's problem.",
    steps: ['In Search Console, open Manual actions: is there one? (Search Console is not connected to the software yet.)', 'The client email asks whether anyone ordered links. Chase the answer.', 'Disavow only if there is a manual action or the links were bought. Otherwise note it and watch.', 'Count new link-selling pages each week for four weeks.'], done: 'We know who placed them, there is no manual action, and four weekly counts are on file.' },
  'speed': { owner: 'us', group: 'speed', title: 'Trim what slows the store page on a phone', sales_title: 'Speed up the store page on a phone', benefit: 'A faster first tap on the page Google sends customers to.',
    steps: [...fixSteps, 'Name the heaviest scripts from the test and which of them are ours to change.', 'Test again on a phone.'], done: 'The phone score is 90 or more, or main content shows in 2.5 s or less.' },
  'claim-listing': { owner: 'client', group: 'rank', title: 'Claim the Google listing', sales_title: 'Claim the Google listing', benefit: 'The store controls what Google shows.', steps: ['Claim the listing from the business Google account.', 'Add us as a manager.'], done: 'The listing reads as claimed.' },
  'fix-category': { owner: 'us', group: 'rank', title: 'Set the right main category', sales_title: 'Set the right main category', benefit: 'Google files the store under what it is.', steps: ['Change the main category on the listing.'], done: 'The listing shows the matching main category.' },
  'add-service-options': { owner: 'us', group: 'rank', title: 'List the ways to shop', sales_title: 'List the ways to shop', benefit: 'Customers see how they can buy.', steps: ['Tick every way to shop the store really offers on the listing.'], done: 'Two or more ways to shop show on the listing.' },
  'fix-hours': { owner: 'client', group: 'rank', title: 'List opening hours for every day', sales_title: 'List opening hours for every day', benefit: 'Customers and Google know when the store is open.', steps: ['Fill in the missing days on the listing.'], done: 'Seven days of hours show.' },
  'connect-google': { owner: 'client', group: 'rank', title: 'Connect Google Analytics and Search Console', sales_title: 'Connect Google Analytics and Search Console', benefit: 'Real clicks replace estimates.', steps: ['Grant access from the business Google account.'], done: 'We can see both connected on our side.' },
  'directory-work': { owner: 'us', group: 'ours', title: 'Review our directory work for this store', steps: ['List where our tagged links point.'], done: 'The list is on file.' },
  'scan-points': { owner: 'software', group: 'data', title: 'Hand back each map check whole, with readings that agree', steps: ["Check the store's rank field, its place in each point's list and the share against each other."], done: 'Every reading of the same points agrees.' },
  'scan-out-of-market': { owner: 'software', group: 'data', title: "Keep another area's businesses out of the map checks", steps: [`Find why ${SW.length ? sum(SW, s => s.far.over_150) : 'some'} business rows from about ${SW.find(s => s.far.miles)?.far.miles?.[0] ? n(SW.find(s => s.far.miles).far.miles[0]) : 'a thousand'} miles away show up in the lists${SW.find(s => s.far.towns.length) ? `, around ${listOf(SW.find(s => s.far.towns.length).far.towns)}` : ''}.`, 'Flag any point whose list carries them, and leave those points out of a check rather than mixing areas.'], done: 'Every business in a map check is in this market.' },
  'ranked-keywords': { owner: 'software', group: 'data', title: 'Turn on the ranked-searches read and the position checks for this store', steps: ['Run the next audit with the ranked-keywords part and the organic positions switched on.', "Read the rivals' ranked searches the same way."], done: 'The Google search tab names the searches the website ranks for, and the ones it misses.' },
  'rivals-searches': { owner: 'software', group: 'data', title: "Hand back the rivals' page 1 searches", steps: ["Include each rival's page 1 searches for the town and nearby towns."], done: 'The report names the searches this website misses.' },
  'collect-ai': { owner: 'software', group: 'data', title: 'Collect AI answers', steps: ['Ask ChatGPT, Perplexity and Google AI Mode the questions buyers ask.', 'Store which stores each answer names.'], done: 'The AI answers tab has numbers.' },
  'crawl-limit': { owner: 'software', group: 'data', title: 'Read the whole site, not the first 100 pages', steps: [website.sitemap_pages ? `The site's own sitemaps list ${n(website.sitemap_pages)} pages; raise the crawl limit above that.` : 'Raise the crawl limit above the site\'s page count.', 'Crawl the rivals\' sites the same way, or label their counts as the first 100 pages.'], done: 'The crawl reads every page the sitemaps list.' },
  'directory-sources': { owner: 'software', group: 'data', title: "Take the other market's sources out of this store's directory list", steps: [`Remove the ${listings?.verdicts?.other_market?.length || ''} ${listings?.verdicts?.other_market_label || 'out-of-market'} sources from the list the software checks for this store: ${(listings?.verdicts?.other_market || []).map(x => x.source).join(', ')}.`, 'Check that a new store\'s list is built from its own market, not copied from another store\'s.'], done: "The directory list holds this store's market only." },
  'directory-coverage': { owner: 'software', group: 'data', title: 'Search the directories for this store, not only test them', steps: ['Search every readable directory for the store itself.', 'Read the ones that came back empty a second way.'], done: 'Most directories on the list have an answer about this store.' },
  'answer-isolation': { owner: 'software', group: 'data', title: "Keep other accounts' readings out of this business's answers", steps: [otherAnalytics.length ? `Drop the ${otherAnalytics.length} analytics readings of ${[...new Set(otherAnalytics.map(r => host(r.target)))].join(', ')} from this business's full-audit answer: they are another account's own data.` : 'Drop readings about other accounts.', oldReads.length ? `Drop the ${oldReads.length} readings bought for other reports.` : 'Hand back only this run\'s readings and the store\'s own.'], done: "The answers carry only this store's, its rivals' and its market's readings." },
  'rival-rows': { owner: 'software', group: 'data', title: "Hand back the rivals' rows", steps: ["Include the rivals' readings in the record."], done: 'Every tab compares the store with its rivals.' },
  'store-findings': { owner: 'software', group: 'data', title: 'Store findings and tasks in the software', steps: ['Save each check and task with its evidence.'], done: 'Tasks live in the software.' },
};
// the software's own findings and tasks, one card per finding code, every run's ids kept
const seosCodes = [...new Set((t.tasks || []).map(x => x.finding_id && (t.findings || []).find(f => f.id === x.finding_id)?.code).filter(Boolean))];
const SEOS_DOOR = c => /^(PAGE_|SITE_)/.test(c) ? 'website' : /^CITATION|^LINKS/.test(c) ? 'links' : /^PROFILE_REVIEWS/.test(c) ? 'maps' : 'overview';
for (const code of seosCodes) {
  const fs2 = (t.findings || []).filter(f => f.code === code), ts = (t.tasks || []).filter(x => fs2.some(f => f.id === x.finding_id));
  const newest = [...ts].sort((a, b) => String(b.generated_at || b.id).localeCompare(String(a.generated_at || a.id)))[0];
  const brief = (t.task_briefs || []).find(b => b.code === code) || null, pm = (t.pm_tasks || []).find(p => p.code === code) || null;
  const ev = fs2.map(f => f.evidence_url).find(Boolean) || null;
  // the code is one long word (PAGE_CHECK_HAS_RENDER_BLOCKING_RESOURCES); a zero-width space after each underscore lets it wrap on a phone
  const shown = code.replace(/_/g, '_\u200b');
  const evShown = ev ? ev.replace(/^https?:\/\/(www\.)?/i, '').replace(/\//g, '/\u200b') : null;
  TASKS['seos-' + code.toLowerCase().replace(/_/g, '-')] = { owner: 'us', group: 'seos', service_only: true, door: SEOS_DOOR(code), seos: true,
    title: String(newest?.statement || code), seos_code: code,
    why: [`The software's own finding ${shown}, raised in ${plural(new Set(fs2.map(f => f.run_id)).size, 'run', 'runs')}: ${fs2.map(f => f.id).join(', ')}. Its tasks: ${ts.map(x => `${x.id} (${x.state})`).join(', ')}.`, brief ? `The software's brief: ${brief.what} ${brief.why}` : null, pm ? `Already sent to the task board as ${pm.public_key}, status "${pm.pm_status_label}".` : null, ev && !isOurs(ev) ? `Evidence: ${evShown}` : null].filter(Boolean),
    steps: brief ? [brief.fix] : [ev && !isOurs(ev) ? `Open the evidence: ${evShown}` : 'Open the finding in the software.', 'Fix it or mark it as will not do, with the reason.'], done: `The software's next run no longer raises ${shown}.` };
}
const GROUPS = [
  ['first', 'Before anything else', ['expected-search', 'rescan-open-hours', 'client-questions']],
  ['ours', 'Ours to put right', ['directory-work']],
  ['map', 'The map', ['map-gap']],
  ['rank', 'Listing basics', ['claim-listing', 'fix-category', 'add-service-options', 'fix-hours', 'connect-google']],
  ['reviews', 'Reviews', ['reply-reviews', 'low-star-subjects', 'reply-low-stars', 'review-gap']],
  ['page', 'The store page', ['store-page-check']],
  ['content', 'Pages and content', ['content-gap']],
  ['links', 'Listings and links', ['listings-hand-check', 'link-list', 'junk-links']],
  ['speed', 'Speed', ['speed']],
  ['account', 'For the account manager', []],
  ['seos', 'Found by the software, its own findings', []],
  ['data', 'For the software team', []],
];
const tasks = [];
const addTask = (id, c) => {
  const def = TASKS[id] || die(`check ${c?.id} names task ${id} and no such task is defined`);
  let tk = tasks.find(x => x.id === id);
  if (!tk) { tk = { id, door: c ? c.door : (def.door || 'overview'), owner: def.owner, group: def.group, internal: false, service_only: !!def.service_only, status: c ? c.status : 'watch', title: def.title, sales_title: def.sales_title || null, benefit: def.benefit || null, why: [...(def.why || [])], steps: def.steps, done_when: def.done, blocked_by: def.blocked_by || [], checks: [], ...(def.seos ? { seos: true, seos_code: def.seos_code } : {}) }; tasks.push(tk); }
  if (c) { tk.why.push(c.detail); tk.checks.push(c.id); if (c.status === 'fail') tk.status = 'fail'; if (c.internal) tk.internal = true; }
  return tk;
};
for (const c of checks.filter(c => c.task && c.status !== 'pass')) addTask(c.task, c);
if (reviews && links && listings) { const tk = addTask('client-questions', null); tk.why = [`${n(reviews.with_reply)} of ${n(reviews.collected)} Google reviews have an owner reply${reviews.windows?.d90 ? `, and ${reviews.windows.d90.replied} of the ${reviews.windows.d90.n} from the last 90 days` : ''}.`, `${n(links.fresh_sellers)} link-selling pages appeared in ${links.fresh_days} days.`, `${listings.verdicts ? `${listings.verdicts.undetermined} of the ${listings.verdicts.checked} directories the software checked could not be read` : `${listings.store_pages_empty} of the store's listing pages could not be read`}, so someone has to open them.`]; }
for (const id of Object.keys(TASKS).filter(k => k.startsWith('seos-'))) addTask(id, null);
for (const tk of tasks.filter(x => x.blocked_by.length)) for (const b of tk.blocked_by) if (!tasks.some(x => x.id === b)) addTask(b, null);
const gi = k => GROUPS.findIndex(g => g[0] === k);
for (const tk of tasks) { if (gi(tk.group) < 0) die(`task ${tk.id} is in no group`); tk.group_label = GROUPS[gi(tk.group)][1]; }
const within = tk => { const i = GROUPS[gi(tk.group)][2].indexOf(tk.id); return i < 0 ? 99 : i; };
const DOOR_ORDER = { maps: 0, search: 1, website: 2, links: 3, ai: 4, overview: 5 };
tasks.sort((a, b) => (gi(a.group) - gi(b.group)) || (within(a) - within(b)) || ((a.status === 'fail' ? 0 : 1) - (b.status === 'fail' ? 0 : 1)) || (DOOR_ORDER[a.door] - DOOR_ORDER[b.door]) || a.id.localeCompare(b.id));
tasks.forEach((tk, i) => { tk.n = i + 1; });
for (const tk of tasks) for (const b of tk.blocked_by) if (!tasks.some(x => x.id === b)) die(`task ${tk.id} is blocked by ${b}, which is not on the list`);
// the software's own task list: older copies of the latest run's tasks are still open there (one line for the team)
const seosLatest = [...(t.apex_runs || [])].sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))[0] || null;
const seosDupes = seosLatest ? (t.tasks || []).filter(x => x.run_id !== seosLatest.id && x.state === 'open' && (() => { const f = (t.findings || []).find(y => y.id === x.finding_id); return f && (t.findings || []).some(y => y.run_id === seosLatest.id && y.code === f.code); })()) : [];
const taskGroups = GROUPS.map(([key, label]) => ({ key, label, n: tasks.filter(x => x.group === key).length, ...(key === 'seos' && seosDupes.length ? { note: `${plural(seosDupes.length, 'older duplicate', 'older duplicates')} of these tasks ${seosDupes.length === 1 ? 'is' : 'are'} still open in the software: close ${seosDupes.length === 1 ? 'it' : 'them'} there.`, dupes: seosDupes.map(x => x.id) } : {}) })).filter(g => g.n);
// the sales plan, in the owner's order: where the store is losing first
const SALES_ORDER = ['rescan-open-hours', 'map-gap', 'reply-reviews', 'review-gap', 'store-page-check', 'speed', 'claim-listing', 'fix-category', 'add-service-options', 'fix-hours', 'reply-low-stars', 'low-star-subjects', 'content-gap', 'listings-hand-check', 'link-list', 'junk-links', 'connect-google'];
const plan = SALES_ORDER.map(id => tasks.find(x => x.id === id)).filter(tk => tk && !tk.internal && !tk.service_only && ['us', 'client'].includes(tk.owner)).map((tk, i) => ({ n: i + 1, id: tk.id, title: tk.sales_title || tk.title, benefit: tk.benefit, yours: tk.owner === 'client' }));
const missedInPlan = tasks.filter(tk => !tk.internal && !tk.service_only && ['us', 'client'].includes(tk.owner) && !plan.some(p => p.id === tk.id));
if (missedInPlan.length) die('tasks with no place in the sales plan: ' + missedInPlan.map(x => x.id).join(', '));

// ---------- numbers on hold: what the team must not quote yet, and who clears it ----------
// ONE rule: this table lists exactly the numbers the client copy never prints. Each entry carries `leak`, the patterns
// (regular expressions, matched without regard to case) a client copy must not contain; build-report.mjs refuses to
// write a client copy that holds one. A pattern is the number as the report prints it, with the words around it
// where the bare number is also a different, printable value (Zen Leaf's 3,259 linking sites and its 3,259 ratings).
const holds = [];
const reEsc = s => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const num = x => `(?<![\\d,.])${reEsc(n(x))}(?![\\d]|,\\d|\\.\\d)`;
for (const s of SEARCHES.filter(s => s.hold)) holds.push({ number: `"${s.kw}": ${s.you} of ${s.n} points`, where: 'Google Maps', why: (s.hold_reasons || []).join(' '), clears: 'Us: a clean check of the same search', leak: [`"${reEsc(s.kw)}"[^.]{0,80}${num(s.you)} of ${num(s.n)}`] });
for (const kw of missingSearches) holds.push({ number: `Any "${kw}" result`, where: 'Google Maps', why: `No "${kw}" map check of this store is on file. The report says nothing about it until one is.`, clears: 'Us: find or run the check', leak: [reEsc(kw)] });
{ const capped = rivals.filter(r => pulls[r.place_id]?.capped); if (capped.length) holds.push({ number: `${capped.map(r => r.short).join(' and ')}: review count from our pull (${capped.map(r => n(reviewNote(r.place_id).n)).join(', ')})`, where: 'Not printed in this report', why: `The pull stopped at the depth asked for, so it is not their count. Their ratings count on Google, and their review velocity over the windows the pull reaches back past, are printed.`, clears: 'Software team: pull every review', leak: capped.map(r => num(reviewNote(r.place_id).n)) }); }
{ const part = [...RV_PIDS].map(p => LK[p]).filter(k => k && !k.links_complete); if (part.length) holds.push({ number: `Link-seller counts for ${part.map(k => shortOf(k.pid)).join(' and ')} (at least ${part.map(k => n(k.sellers_floor)).join(', ')} among the links read)`, where: 'Links and listings', why: `${part.map(k => `${shortOf(k.pid)}: ${n(k.links)} of ${n(k.links_total)} links read`).join('; ')}. The pull stopped at its page limit, so sellers among the rest are unknown. Their linking-site totals are whole, and they are held with the other totals below.`, clears: 'Software team: read every link', leak: part.map(k => `${num(k.sellers_floor)}[^.]{0,40}(sell|scheme)`) }); }
if (links) { const tot = rivals.filter(r => r.linking_sites !== null);
  holds.push({ number: `Linking-site totals: ${n(links.sites)} here, ${tot.map(r => `${r.short} ${n(r.linking_sites)}`).join(', ')}`, where: 'Links and listings', why: `${n(links.sellers)} of this website's are link-selling or scheme pages, and the same wave reached the rivals, so the totals mostly compare junk. The report compares the classified counts.`, clears: 'Nobody: compare only the sites that are not link sellers',
    leak: [num(links.sites), ...tot.map(r => `${num(r.linking_sites)} (linking )?sites|linking sites[^.]{0,60}${num(r.linking_sites)}|${reEsc(r.short)}\\W{0,3}${num(r.linking_sites)}(?! ratings| stars)(?=[^.]{0,30}(sites|links|link))`)] }); }
if (links && links.gap_floor) holds.push({ number: `Sites that link to the rivals and not here: ${n(links.gap_left)} or more`, where: 'Links and listings', why: `${links.gap_parts.filter(p => p.total !== null && p.got < p.total).map(p => `${n(p.got)} of ${n(p.total)}`).join(' and ')} rows came back in two of the four parts: the vendor's limit. The total is a floor; the list of sites with some weight is read from the rows that came back.`, clears: 'Software team: raise the limit', leak: [num(links.gap_left)] });
// rule 7: the store's own search estimates are its one-store website's, printed with that label; a chain's are held
for (const r of chainRivals) { const st = r.domain ? rankOf(r.domain) : null;
  holds.push({ number: `${r.short}'s whole-website figures: ${n(r.keywords)} searches, ${n(r.visits)} visits a month${st !== null ? `, link strength ${st}` : ''}`, where: 'Google search, Links and listings', why: `${r.short}'s Google listing links to one store's page on ${r.domain}, a website for many stores. Its whole-website figures cover every store, so they are never set beside ${business.short}'s one-store website. The lines compare the best rival whose listing links to its own front page.`, clears: 'Nobody: compare one-store websites only',
    leak: [r.keywords !== null ? num(r.keywords) : null, r.visits !== null ? num(r.visits) : null].filter(Boolean) }); }
if (website.crawl?.at_limit) holds.push({ number: `Whole-site crawl counts and scores: ${website.crawl.duplicate_title} duplicate titles, ${website.crawl.duplicate_description} duplicate descriptions, score ${website.crawl.score}; ${website.rivals.filter(r => r.crawl).map(r => `${r.name} ${r.crawl.score}`).join(', ')}`, where: 'Website', why: `The crawl stopped at its ${website.crawl.max}-page limit${website.sitemap_pages ? ` of the ${n(website.sitemap_pages)} pages the sitemaps list` : ''}, and so did each rival's. They are counts within the first ${website.crawl.max} pages, so no whole website leads on them.`, clears: 'Software team: crawl past 100 pages',
  leak: [num(website.crawl.score), num(r1(website.crawl.score)), '\\d+ duplicate (titles|descriptions)', 'on-page score, whole website', 'whole site: score', ...website.rivals.filter(r => r.crawl).flatMap(r => [num(r.crawl.score), num(r1(r.crawl.score))])] });
{ const sw0 = SW.find(w => w.kw === mainSearch?.kw && w.n === mainSearch?.n); const unc = sw0 ? sw0.unconfirmed_not_found : [];
  if (unc.length) holds.push({ number: `"${sw0.kw}": not found at ${unc.length} of ${sw0.n} points`, where: 'Google Maps', why: `At each of those points the first 20 carries ${unc.every(x => x === unc[0]) ? unc[0] : listOf(unc.map(String))} businesses from another area, so the store may have been pushed out by them. The client copy says "at least ${sw0.you.found} of ${sw0.n}".`, clears: 'Software team: keep other areas out of the sweeps',
    leak: [`(?<!at least )${num(sw0.you.found)} of (the )?${num(sw0.n)}`, `not found at ${num(unc.length)}`] }); }
if (ownAccounts.length) holds.push({ number: `Our own accounts on this map: ${ownAccounts.map(a => `${a.name} (business ${a.business})`).join(', ')}`, where: 'Google Maps', why: 'They are tracked in our own software. A client hears of them only as businesses on the public map, like any rival.', clears: 'Nobody: never said to a client', leak: ['business [0-9]+', 'tracked in our own software', 'our own accounts?', '(also|one of) our (clients|accounts)'] });
// rule 9: two stores' phone-with-name counts rest on different numbers of answered searches, so the cross-store comparison
// is held; the store's own count is printed
if (listings && listings.rivals.some(r => typeof r.phone_named_outside === 'number')) holds.push({ number: `Phone shown with the name, store beside store: ${business.short} ${listings.phone_named_outside}, ${listings.rivals.filter(r => typeof r.phone_named_outside === 'number').map(r => `${r.name} ${r.phone_named_outside}`).join(', ')}`, where: 'Links and listings',
  why: `The same searches were not answered alike: ${[`${business.short} ${listings.searches_answered} of ${listings.searches}`, ...listings.rivals.filter(r => r.searches).map(r => `${r.name} ${r.searches_answered} of ${r.searches}`)].join(', ')}. A count over fewer answers is not a smaller footprint.`, clears: 'Software team: answer every search for every store', leak: ["outside sites where google shows the phone with the name"] });

// ---------- you, the gap, the yardstick (sales view) ----------
const ledger = [];
if (beside.length >= 3) ledger.push({ bucket: 'Google listing and reviews', measure: 'Google ratings', you: n(business.ratings), gap: { lead: business.ratings < Math.min(...beside) ? `${n(Math.min(...beside) - business.ratings)} to ${n(Math.max(...beside) - business.ratings)} fewer` : 'In the range' }, them: { lead: `The ${beside.length} stores Google lists beside it: ${n(Math.min(...beside))} to ${n(Math.max(...beside))}` } });
if (myPull?.d90) ledger.push({ bucket: 'Google listing and reviews', measure: 'Review velocity, new reviews a month over 90 days', you: n(Math.round(myPull.d90.per_month)), gap: { lead: '' }, them: { lead: velRows.filter(x => !x.me).map(x => `${x.short} ${n(Math.round(x.pull.d90.per_month))}`).join(', ') } });
if (website.phone) ledger.push({ bucket: 'Website', measure: 'Phone speed, lab test', you: `${website.phone.score} of 100`, gap: { lead: website.phone.score >= 90 ? 'In the good range' : `${90 - website.phone.score} points short of good` }, them: { lead: 'Good is 90 or more' } });
if (links) ledger.push({ bucket: 'Links and listings', measure: 'Linking sites that are not link sellers and carry some weight', you: n(links.clean_with_weight), gap: { lead: `${links.gap_worth.length} more link to the rivals and not here` }, them: { lead: links.gap_worth.length ? `Such as ${links.gap_worth.slice(0, 3).map(g => g.domain).join(', ')}` : '' } });

// ---------- compare: the store beside the competition, on every tab ----------
// Sets: map (the businesses at the top of the map in the run's own sweep, from their Google listings), rivals
// (the three stores the run names), nearby (the stores Google lists beside this one). A row reaches a client only
// when it is safe to quote; one on hold, or one resting on a count that stopped at a limit, stays with the team.
const cmpRows = [];
const cmpRow = (door, id, label, o, entries) => {
  const have = entries.filter(x => x.v !== null && x.v !== undefined);
  if (!have.some(x => x.is_you) || have.length < 2) return;
  const sorted = [...have].sort((a, b) => b.v - a.v || (a.is_you ? 1 : 0) - (b.is_you ? 1 : 0));
  const mine = have.find(x => x.is_you), whole = have.length === entries.length;
  const place = whole ? 1 + have.filter(x => x.v > mine.v).length : null;
  const tied = whole && have.filter(x => x.v === mine.v).length > 1;
  const top = sorted[0], showOf = x => x.show ?? n(x.v);
  const summary = o.set === 'map' && mine.v === 0 ? `${top.name} leads with ${showOf(top)}. ${business.short} is in Google's top 3 at none of the points.` : !whole ? `${business.short} has ${showOf(mine)}; ${top.is_you ? 'the most of those with a number' : `${top.name} leads with ${showOf(top)}`}.` : place === 1 ? `${business.short} ${tied ? 'shares the lead' : 'leads'}.` : `${top.name} leads with ${showOf(top)}. ${business.short} is ${tied ? 'tied for ' : ''}${nth(place)} of ${have.length}.`;
  cmpRows.push({ door, id, label, scope: o.scope, unit: o.unit || '', set: o.set, sales: !!o.sales && !o.hold, hold: !!o.hold, key: !!o.key, note: o.note || null, team_note: o.team_note || null,
    entries: [...sorted, ...entries.filter(x => x.v === null || x.v === undefined)].map(x => ({ id: x.id, name: x.name, is_you: !!x.is_you, v: x.v ?? null, show: x.v === null || x.v === undefined ? null : showOf(x), why: x.why || null })),
    place, of: have.length, tied, lead: top.id, summary, behind: whole ? place > 1 : null });
};
const youE = (v, show) => ({ id: you.id, name: business.short, is_you: true, v, ...(show ? { show } : {}) });
const rivE = f => rivals.map(r => { const x = f(r); return x !== null && typeof x === 'object' ? { id: r.id, name: r.short, ...x } : { id: r.id, name: r.short, v: x }; });
const nearby = business.also_viewed.filter(a => a.ratings !== null).map(a => ({ id: 'near-' + squash(a.short), name: a.short, full: a.name, rating: a.rating, ratings: a.ratings }));
// Google Maps: each search, the store beside the top of the field
const mkOnly = mk ? SEARCHES.filter(x => x.source === 'market' && !SW.some(w => w.kw === x.kw && day(w.finished) === x.date)) : [];
for (const ms of mkOnly) { const sc = market.scans.filter(x => String(x.kw).toLowerCase() === ms.kw).sort((a, b) => b.ts - a.ts)[0]; const MB = market.biz;
  cmpRow('maps', 'map-' + ms.key, `Points in Google's top 3 for "${ms.kw}"`, { scope: 'Map check', unit: `of ${ms.n} points`, set: 'map', hold: ms.hold, sales: true, note: `${ms.n} points, checked ${ms.when}.` },
    [youE(ms.you, `${ms.you} of ${ms.n}`), ...sc.field.filter(f => f[0] !== market.subject && !MB[f[0]].far).slice(0, 5).map(f => ({ id: 'map-' + MB[f[0]].pid, name: MB[f[0]].short, v: f[1], show: `${f[1]} of ${ms.n}` }))]); }
for (const s of SW.filter(x => x.n > 0)) cmpRow('maps', 'map-' + s.id, `Points in Google's top 3 for "${s.kw}"`, { scope: 'Map check', unit: `of ${s.n} points`, set: 'map', hold: s.hold, sales: true, key: s === mainSweep,
  note: `${s.n} points on an ${s.grid} by ${s.grid} grid, ${s.radius} ${s.unit} out, checked ${dayTime(s.finished)}${s.excluded ? `, ${s.excluded} points left out before it ran` : ''}.` },
  [youE(s.you.top3, `${s.you.top3} of ${s.n}`), ...s.field.filter(f => !f.is_you && !s.far_pids.includes(f.pid)).slice(0, 5).map(f => ({ id: 'map-' + f.pid, name: f.short, v: f.top3, show: `${f.top3} of ${s.n}` }))]);
const mapSet = topOfMap.filter(r => !r.me).slice(0, 6);
if (mapSet.length) {
  const noteL = `As each Google listing showed it when we read it: ${business.short}'s ${business.profile_read_at}, the others' ${[...new Set(mapSet.map(r => day(when(readingOf('business_info', r.pid)?.fetched_at))))].join(', ')}. The businesses with the most top-3 points for "${mainSweep.kw}".`;
  cmpRow('maps', 'ratings', 'Google ratings', { scope: 'This store', unit: 'ratings', set: 'map', sales: true, key: true, note: noteL }, [youE(business.ratings), ...mapSet.map(r => ({ id: 'map-' + r.pid, name: r.short, v: r.reviews }))]);
  cmpRow('maps', 'stars', 'Star rating', { scope: 'This store', unit: 'stars', set: 'map', sales: true, note: noteL }, [youE(business.rating, business.rating === null ? null : business.rating.toFixed(1)), ...mapSet.filter(r => r.rating !== null).map(r => ({ id: 'map-' + r.pid, name: r.short, v: r.rating, show: Number(r.rating).toFixed(1) }))]);
  cmpRow('maps', 'photos', 'Photos on the Google listing', { scope: 'This store', unit: 'photos', set: 'map', sales: true, note: noteL }, [youE(business.photos), ...mapSet.map(r => ({ id: 'map-' + r.pid, name: r.short, v: r.photos }))]);
}
if (velRows.length > 1) cmpRow('maps', 'velocity', 'Review velocity: new reviews a month', { scope: 'This store', unit: 'a month', set: 'rivals', sales: velocityOk, hold: !velocityOk,
  note: `Over the 90 days to ${myPull.collected_at}, from each store's own dated Google reviews.${rivals.some(r => pulls[r.place_id]?.capped) ? ` ${rivals.filter(r => pulls[r.place_id]?.capped).map(r => r.short).join(' and ')}'s review read stopped at the depth asked for, and still reaches back past the 90 days.` : ''}` },
  [youE(myPull.d90.per_month, n(Math.round(myPull.d90.per_month))), ...rivals.map(r => { const p = pulls[r.place_id]; return { id: r.id, name: r.short, v: p?.d90 ? p.d90.per_month : null, show: p?.d90 ? n(Math.round(p.d90.per_month)) : null, why: p ? null : 'Not read' }; })]);
if (myPull?.d90) cmpRow('maps', 'replies-90', 'Reviews from the last 90 days with an owner reply', { scope: 'This store', unit: '%', set: 'rivals', sales: true,
  note: `Of each store's reviews from the 90 days to ${myPull.collected_at}.` },
  [youE(r1(100 * myPull.d90.replied / Math.max(1, myPull.d90.n)), `${r1(100 * myPull.d90.replied / Math.max(1, myPull.d90.n))}%`), ...rivals.map(r => { const p = pulls[r.place_id]?.d90; return { id: r.id, name: r.short, v: p ? r1(100 * p.replied / Math.max(1, p.n)) : null, show: p ? `${r1(100 * p.replied / Math.max(1, p.n))}%` : null, why: p ? null : 'Not read' }; })]);
if (reviews) cmpRow('maps', 'reviews-pulled', 'Reviews our pull collected', { scope: 'This store', unit: 'reviews', set: 'rivals', hold: rivals.some(r => pulls[r.place_id]?.capped), sales: false, note: 'A store whose pull stopped at its limit has more reviews than it shows.' },
  [youE(reviews.collected), ...rivE(r => pulls[r.place_id]?.capped ? { v: null, why: "At the pull's limit" } : (pulls[r.place_id] ? pulls[r.place_id].count : null))]);
// Google search: whole websites. A chain's website (its listing links to one store's page on a website for many
// stores) is shown with the reason and no bar: it is never set beside a one-store website (rule 7)
const CHAIN_WHY = 'Not set beside yours: its listing links to one store\'s page on a website for many stores';
const rivWhole = f => rivals.map(r => isChain(r) ? { id: r.id, name: r.short, v: null, why: CHAIN_WHY } : { id: r.id, name: r.short, v: f(r) });
if (you.keywords !== null) cmpRow('search', 'searches', 'Searches the website shows up for', { scope: 'Whole website', unit: 'searches', set: 'rivals', sales: true, key: true, note: "Each bar is a whole website, every store it covers, in Google's first 100 results. An outside estimate." }, [youE(you.keywords), ...rivWhole(r => r.keywords)]);
if (you.visits !== null) cmpRow('search', 'visits', 'Estimated visits a month from search', { scope: 'Whole website', unit: 'visits a month', set: 'rivals', sales: true, key: true, note: 'An outside estimate for each whole website, every store it covers. Not real clicks.' }, [youE(you.visits), ...rivWhole(r => r.visits)]);
// Website: the store page beside each rival's (the page each Google listing links to), and whole-site crawls
const wpg = r => website.rivals.find(x => x.id === r.id)?.page || null;
const pageNote = `The page each Google listing links to, read the same way for every store on ${website.read_at}.`;
// rule 9, two readings: the full audit read each listing's own page; the website audit read each website's front page the
// night before. The full-audit read is the one used; the other is listed, and an order is only claimed if both give it.
const otherSpeed = r => { const x = readingOf('page_speed', 'site:' + r.domain)?.result; return x ? { phone: x.phone && x.phone.score != null ? Math.round(x.phone.score * 100) : null, desktop: x.desktop && x.desktop.score != null ? Math.round(x.desktop.score * 100) : null, url: readingOf('page_speed', 'site:' + r.domain)?.target || null } : null; };
const speedPlaces = dev => { const used = [website[dev]?.score ?? null, ...rivals.map(r => wpg(r)?.[dev]?.score ?? null)], alt = [website[dev]?.score ?? null, ...rivals.map(r => otherSpeed(r)?.[dev] ?? null)];
  const place = a => a.every(v => v !== null) ? 1 + a.slice(1).filter(v => v > a[0]).length : null; return { used: place(used), other: place(alt), of: used.length }; };
const speedNote = (() => { const ph = speedPlaces('phone'), dk = speedPlaces('desktop'), oth = rivals.map(r => ({ r, o: otherSpeed(r) })).filter(x => x.o);
  return `Which reading is used: each store's page is the one its Google listing links to, as the full audit read it on ${website.read_at}. The website audit also read each website's front page the night before: ${oth.map(x => `${x.r.short} ${x.o.phone} on a phone, ${x.o.desktop} on a desktop`).join('; ')} (the store's page is its front page, the same read). ${ph.used === ph.other && dk.used === dk.other ? `The store is ${nth(ph.used)} of ${ph.of} on a phone and ${nth(dk.used)} on a desktop on either reading, so the order is quoted.` : 'The two readings give a different order, so no order is quoted.'}`; })();
const speedOrderHolds = (() => { const ph = speedPlaces('phone'), dk = speedPlaces('desktop'); return ph.used === ph.other && dk.used === dk.other; })();
if (website.phone) cmpRow('website', 'speed-phone', 'Phone speed, lab test', { scope: 'Store page', unit: 'of 100', set: 'rivals', sales: true, key: true, note: `${pageNote} Google's lab test on a simulated slow phone. Good is 90 or more.`, team_note: speedNote }, [youE(website.phone.score), ...rivE(r => wpg(r)?.phone?.score ?? null)]);
if (website.desktop) cmpRow('website', 'speed-desktop', 'Desktop speed, lab test', { scope: 'Store page', unit: 'of 100', set: 'rivals', sales: true, note: pageNote }, [youE(website.desktop.score), ...rivE(r => wpg(r)?.desktop?.score ?? null)]);
if (website.crawler_words !== null) cmpRow('website', 'page-words', 'Words a crawler gets from the store page', { scope: 'Store page', unit: 'words', set: 'rivals', sales: true, note: `${pageNote} What our plain page reader got, with no browser.` }, [youE(website.crawler_words), ...rivE(r => wpg(r)?.crawler_words ?? null)]);
{ const share = p => p && p.crawler_words !== null && p.browser_words ? Math.min(100, Math.round(100 * p.crawler_words / p.browser_words)) : null; const mine = share({ crawler_words: website.crawler_words, browser_words: website.browser_words });
  if (mine !== null) cmpRow('website', 'crawler-share', "The browser's words a crawler also gets", { scope: 'Store page', unit: '%', set: 'rivals', sales: true, note: `${pageNote} 100% means a crawler reads everything a visitor's browser shows.` }, [youE(mine, `${mine}%`), ...rivE(r => { const x = share(wpg(r)); return x === null ? null : { v: x, show: `${x}%` }; })]); }
if (website.onpage !== null) cmpRow('website', 'onpage', 'On-page score of the store page', { scope: 'Store page', unit: 'of 100', set: 'rivals', sales: true, note: `${pageNote} The vendor's own score for the page's build.` }, [youE(r1(website.onpage)), ...rivE(r => { const p = wpg(r); if (p && p.onpage === null && p.onpage_reads?.[0] !== null && p.onpage_reads?.[1] !== null && p.onpage_reads?.[0] !== undefined) return { v: null, why: `Not confirmed: two reads of the page disagree (${r1(p.onpage_reads[0])} and ${r1(p.onpage_reads[1])})` }; return p?.onpage === null || p?.onpage === undefined ? null : r1(p.onpage); })]);
// rule 4: every crawl stopped at its page limit, so no website "leads" on its whole-site score: team only, with the reason
if (website.crawl) cmpRow('website', 'crawl-score', 'On-page score, whole website', { scope: 'Whole website', unit: 'of 100', set: 'rivals', sales: false, hold: !!website.crawl.at_limit, note: `The first ${website.crawl.max} pages of each whole website, crawled ${day(when(readingOf('site_crawl', subjectPid)?.fetched_at))}. Every crawl stopped at that limit.`,
  team_note: website.crawl.at_limit ? `On hold: each crawl stopped at ${website.crawl.max} pages${website.sitemap_pages ? ` (the store's sitemaps list ${n(website.sitemap_pages)})` : ''}, so these are scores of the first ${website.crawl.max} pages, not of whole websites. Broken links in those pages: ${[`${business.short} ${n(website.crawl.broken_links)}`, ...website.rivals.filter(r => r.crawl).map(r => `${r.name} ${n(r.crawl.broken_links)}`)].join(', ')}. Not for a client.` : null },
  [youE(r1(website.crawl.score)), ...rivE(r => { const c = website.rivals.find(x => x.id === r.id)?.crawl; return c ? r1(c.score) : null; })]);
// Links: whole websites, classified before counting
const lk = r => LK[r.place_id] || null;
if (rankOf(domain) !== null) cmpRow('links', 'strength', 'Link strength score', { scope: 'Whole website', unit: 'of 1,000', set: 'rivals', sales: true, key: true, note: "An outside score for the weight a whole website's links carry, on a scale to 1,000." }, [youE(rankOf(domain)), ...rivWhole(r => (r.domain ? rankOf(r.domain) : null))]);
if (links) {
  const qs = links.quality?.strict || {};
  cmpRow('links', 'clean-sites', 'Linking sites that are not link sellers', { scope: 'Whole website', unit: 'sites', set: 'rivals', sales: true, key: true, note: "Each website's linking sites, minus the link-selling and scheme pages, classified the same way for every website.",
    team_note: Object.values(qs).some(Boolean) ? `Checked again with the links' own fields: dropping every site with a spam score of 30 or more and every page title two or more linking hosts share leaves ${Object.entries(qs).filter(([, v]) => v).map(([k, v]) => `${k} ${n(v.not_sellers)}`).join(', ')}. ${(() => { const mine = qs[business.short], others = Object.entries(qs).filter(([k, v]) => k !== business.short && v); return mine && others.every(([, v]) => mine.not_sellers > v.not_sellers) ? 'The lead holds on that stricter count.' : 'The lead does not hold on that stricter count.'; })()}` : null },
    [youE(links.not_sellers), ...rivE(r => { const k = lk(r); return !k ? null : k.not_sellers === null ? { v: null, why: `Not counted: ${n(k.links)} of its ${n(k.links_total)} links were read` } : k.not_sellers; })]);
  cmpRow('links', 'clean-weight', 'Of those, sites that carry some weight', { scope: 'Whole website', unit: 'sites', set: 'rivals', sales: true, note: "Linking sites that are not link sellers and that the vendor scores above zero." },
    [youE(links.clean_with_weight), ...rivE(r => { const k = lk(r); return !k ? null : k.clean_with_weight === null ? { v: null, why: 'Not counted: part of its links were read' } : k.clean_with_weight; })]);
  cmpRow('links', 'sites', 'Sites that link to the website, all of them', { scope: 'Whole website', unit: 'sites', set: 'rivals', hold: true, sales: false, note: 'Totals with the link-selling pages left in. They mostly compare junk.' }, [youE(links.sites), ...rivE(r => lk(r)?.sites_complete ? lk(r).sites : null)]);
  cmpRow('links', 'wave', `Link-selling pages new in the last ${links.fresh_days} days`, { scope: 'Whole website', unit: 'sites', set: 'rivals', sales: false, note: 'The same wave reached every website in the market. A count to watch, not a strength.' },
    [youE(links.fresh_sellers), ...rivE(r => { const k = lk(r); return !k ? null : k.fresh_sellers === null ? { v: null, why: 'Not counted: part of its links were read' } : k.fresh_sellers; })]);
}
// Listings: the same three readings for every store
if (listings) {
  // rule 9: the searches behind each store's count were not answered alike, so the comparison stays with the team
  cmpRow('links', 'phone-named', "Outside sites where Google shows the phone with the name", { scope: 'This store', unit: 'sites', set: 'rivals', sales: false, hold: true, note: "From the same Google searches for each store's phone number, street address and name, made the same day for every store.",
    team_note: `On hold: the searches were not answered alike (${[`${business.short} ${listings.searches_answered} of ${listings.searches}`, ...listings.rivals.filter(r => r.searches).map(r => `${r.name} ${r.searches_answered} of ${r.searches}`)].join(', ')}), so a smaller count may be fewer answers, not fewer sites. The store's own count is printed; this side-by-side is not.` },
    [youE(listings.phone_named_outside), ...listings.rivals.map(r => ({ id: r.id, name: r.name, v: r.phone_named_outside ?? null }))]);
  cmpRow('links', 'dirs-showed', 'Directories that answered with the store on them', { scope: 'This store', unit: 'directories', set: 'rivals', sales: true, note: "Directories searched for each store, the same day for every store, that came back showing its phone or address. One that did not answer is not counted against anyone." },
    [youE(listings.directories_showed), ...listings.rivals.map(r => ({ id: r.id, name: r.name, v: r.directories_showed ?? null }))]);
}
// the websites this one meets most often in Google's results
const searchSites = cdItems.filter(i => i.domain !== domain).sort((a, b) => b.intersections - a.intersections).map(i => ({ domain: i.domain, shared: i.intersections, searches: i.full_domain_metrics?.organic?.count ?? null, visits: i.full_domain_metrics?.organic?.etv === undefined ? null : Math.round(i.full_domain_metrics.organic.etv), rival: rivals.find(r => r.domain === i.domain)?.short || null }));
const missing = {
  maps: missingSearches.map(kw => ({ what: `A map check of "${kw}" for this store`, state: 'Not on file', task: 'expected-search' })),
  search: [{ what: "The searches this website and each rival's website are found for", state: "Switched off in this run's settings", task: 'ranked-keywords' }],
  website: [],
  links: rivals.filter(r => lk(r) && !lk(r).links_complete).map(r => ({ what: `${r.short}'s links one by one, to sort the link sellers out`, state: `${n(lk(r).links)} of ${n(lk(r).links_total)} read`, task: null })),
  ai: [{ what: 'Which stores the AI assistants name', state: 'Not collected', task: 'collect-ai' }],
};
for (const list of Object.values(missing)) for (const m of list) if (m.task && !tasks.some(x => x.id === m.task)) m.task = null;
// the Google listings at the top of the map and the review velocity table, for the builder's v2 cards
const velocityTable = [subjectPid, ...RV_PIDS].map(p => ({ pid: p, name: shortOf(p), is_you: p === subjectPid, pull: pulls[p] })).filter(x => x.pull).map(x => ({ name: x.name, is_you: x.is_you, d30: x.pull.d30, d90: x.pull.d90, d365: x.pull.d365, total: x.pull.count, capped: x.pull.capped, oldest: x.pull.oldest, points: mainSweep?.field.find(f => f.pid === x.pid)?.top3 ?? null }));
const compare = { rivals: rivals.map(r => ({ id: r.id, name: r.short, full: r.name, domain: r.domain })), nearby, rows: cmpRows, search_sites: searchSites, missing,
  listings: topOfMap.map(r => ({ ...r, pid: undefined, miles: typeof r.km === 'number' ? r1(r.km / KM_PER_MI) : null, km: undefined })), listings_of: profilesRead, listings_kw: mainSweep?.kw || null, listings_n: mainSweep?.n || null,
  velocity: velocityTable, velocity_window: myPull ? { to: myPull.collected_at } : null, velocity_agrees: velocityOk, speed_order_holds: speedOrderHolds,
  website: [{ name: business.short, is_you: true, page: pageRead(subjectPid), crawl: website.crawl }, ...website.rivals.map(r => ({ name: r.name, is_you: false, domain: r.domain, page: r.page, crawl: r.crawl }))].map(x => ({ name: x.name, is_you: x.is_you, url: x.page?.url && !/utm_/i.test(x.page.url) ? x.page.url : (x.page?.url ? x.page.url.split('?')[0] : null), status: x.page?.status ?? null, words: x.page?.crawler_words ?? null, browser_words: x.page?.browser_words ?? null, onpage: x.page?.onpage === null && x.page?.onpage_reads?.[0] != null && x.page?.onpage_reads?.[1] != null ? 'Not confirmed' : x.page?.onpage === null || x.page?.onpage === undefined ? null : r1(x.page.onpage), phone: x.page?.phone?.score ?? null, desktop: x.page?.desktop?.score ?? null, lcp: x.page?.phone?.metrics?.lcp?.display ?? null, flags: x.page?.flags ?? null, gated: x.page?.gated ?? null, schema: x.page?.business_schema ?? null, crawl: x.crawl ? { pages: x.crawl.pages, max: x.crawl.max, score: r1(x.crawl.score), broken_links: x.crawl.broken_links, duplicate_title: x.crawl.duplicate_title } : null })),
  links: [{ pid: subjectPid, is_you: true }, ...rivals.map(r => ({ pid: r.place_id, is_you: false }))].map(x => { const k = LK[x.pid]; return k ? { name: shortOf(x.pid), is_you: x.is_you, sites: k.sites_complete ? k.sites : null, sites_total: k.sites_total, links_read: k.links, links_total: k.links_total, links_complete: k.links_complete, sellers: k.sellers, not_sellers: k.not_sellers, clean_with_weight: k.clean_with_weight, fresh: k.fresh, fresh_sellers: k.fresh_sellers, wave: k.wave, strength: rankOf(domainOf(x.pid)) } : { name: shortOf(x.pid), is_you: x.is_you }; }),
};

// ---------- the gap to number 1: each number, the store beside the best there is ----------
const gaps = [];
const gap = (door, id, label, mine, best, o) => {
  if (mine === null || mine === undefined || best === null || best === undefined) return;
  const show = o.show || n, lead = o.you_are_best ? true : mine >= best, level = !o.you_are_best && mine === best;
  const text = o.you_are_best ? (mine === best ? 'Level with number 2.' : `You lead by ${show(r2(mine - best))}.`) : level ? 'Level.' : lead ? 'You lead.'
    : o.diff === 'times' ? (mine === 0 ? `${show(best)} to none.` : mine <= 2 && best / mine >= 10 ? `${show(best)} to ${show(mine)}.` : best / mine >= 1.5 ? `${r1(best / mine)} times yours.` : `${n(r2(best - mine))} more than you.`)
      : o.diff === 'count' ? `${n(best - mine)} to go.` : o.diff === 'more' ? `${show(r2(best - mine))} more than yours.` : `${show(r2(best - mine))} ${o.unit} short.`;
  gaps.push({ door, id, label, you: mine, you_show: show(mine), best, best_show: show(best), best_name: o.name, who: o.who, lead, level, text: o.floor && !lead ? `At least ${text.charAt(0).toLowerCase()}${text.slice(1)}` : text, note: o.note || null, scope: o.scope || null, hold: !!o.hold, deficit: o.you_are_best || lead ? -Math.abs(mine - best) / Math.max(Math.abs(best), Math.abs(mine), 1) : (best - mine) / Math.max(Math.abs(best), 1) });
};
for (const s of SEARCHES.filter(x => !x.hold)) {
  if (s.you_lead) gap('maps', 'map-' + s.key, `Map points in Google's top 3 for "${s.kw}"`, s.you, s.second_points ?? 0, { name: s.second || 'nobody', who: 'Number 2 on the map', you_are_best: true, note: `Of ${s.n} points. You are number 1. Checked ${s.date}.` });
  else gap('maps', 'map-' + s.key, `Map points in Google's top 3 for "${s.kw}"`, s.you, s.leader_points, { name: s.leader, who: 'Number 1 on the map', diff: 'times', floor: !!s.leader_floor, note: `Of ${s.n} points. Checked ${s.date}.` });
}
if (L1 && L1prof) {
  const one = `Number 1 for "${L1.kw}"`, dated = `Yours as read ${business.profile_read_at}, ${L1.leader}'s on ${day(when(readingOf('business_info', L1.leader_pid)?.fetched_at))}.`;
  gap('maps', 'ratings-1', 'Google ratings', business.ratings, L1prof.reviews, { name: L1.leader, who: one, diff: 'times', note: dated });
  gap('maps', 'stars-1', 'Star rating', business.rating, L1prof.rating, { name: L1.leader, who: one, show: v => Number(v).toFixed(1), unit: 'of a star', note: dated });
  gap('maps', 'photos-1', 'Photos on the Google listing', business.photos, L1prof.photos, { name: L1.leader, who: one, diff: 'times', note: dated });
  gap('maps', 'ways-1', 'Ways to shop on the listing', business.service_options.length, L1prof.ways, { name: L1.leader, who: one, diff: 'times', note: dated });
  gap('maps', 'details-1', 'Details filled in on the listing', business.attributes.length, L1prof.attributes, { name: L1.leader, who: one, diff: 'times', note: dated });
  const lp = pulls[L1.leader_pid];
  if (velocityOk && myPull?.d90 && lp?.d90) gap('maps', 'velocity-1', 'Review velocity: new reviews a month', myPull.d90.per_month, lp.d90.per_month, { name: L1.leader, who: one, diff: 'times', show: v => n(Math.round(v)), note: `Over the 90 days to ${myPull.collected_at}, from each store's own dated reviews.` });
}
{ const best = f => { const r = [...rivals].filter(x => f(x) !== null && f(x) !== undefined).sort((a, b) => f(b) - f(a))[0]; return r ? { v: f(r), name: r.short } : null; };
  // whole-website lines (rule 7): the comparator is the best rival whose listing links to its own front page, never a
  // chain's website; the line says so on its face, and never in "times yours". With no fair comparator it leaves the list.
  const bestOne = f => best(r => (isChain(r) ? null : f(r)));
  const kw = bestOne(r => r.keywords), vi = bestOne(r => r.visits), st = bestOne(r => (r.domain ? rankOf(r.domain) : null)), cl = bestOne(r => lk(r)?.not_sellers ?? null), whole = 'Whole websites: this one-store website beside the rival one-store website with the most. An outside estimate.';
  if (kw) gap('search', 'searches', 'Searches the website shows up for', you.keywords, kw.v, { name: kw.name, who: 'Largest one-store rival website', diff: 'more', note: whole, scope: 'whole' });
  if (vi) gap('search', 'visits', 'Estimated visits a month from search', you.visits, vi.v, { name: vi.name, who: 'Largest one-store rival website', diff: 'more', note: whole, scope: 'whole' });
  if (st) gap('links', 'strength', 'Link strength score', rankOf(domain), st.v, { name: st.name, who: 'Strongest one-store rival website', unit: 'points', note: 'An outside score on a scale to 1,000, for each whole website.', scope: 'whole' });
  if (cl && links) gap('links', 'clean-sites', 'Linking sites that are not link sellers', links.not_sellers, cl.v, { name: cl.name, who: 'Rival with the most', diff: 'more', note: 'Classified the same way for every website. A rival whose links were not all read is left out.', scope: 'whole' });
  if (website.phone) gap('website', 'speed', 'Phone speed, lab test', website.phone.score, 90, { name: 'good is 90 or more', who: "Google's own mark", unit: 'points', note: 'Out of 100, on a simulated slow phone.' });
  if (reviews?.windows?.d90 && reviews.windows.d90.n) gap('maps', 'replies-90', 'Reviews from the last 90 days with a reply', reviews.windows.d90.replied, reviews.windows.d90.n, { name: 'every one of them', who: 'The target', diff: 'count', note: `Of the ${reviews.windows.d90.n} Google reviews from the 90 days to ${reviews.collected_at}.` });
  if (listings && listings.rivals.some(r => r.phone_named_outside !== null && r.phone_named_outside !== undefined)) { const b2 = [...listings.rivals].filter(r => typeof r.phone_named_outside === 'number').sort((a, b) => b.phone_named_outside - a.phone_named_outside)[0];
    gap('links', 'phone-named', "Outside sites where Google shows the phone with the name", listings.phone_named_outside, b2.phone_named_outside, { name: b2.name, who: 'Rival with the most', diff: 'times', note: "The same Google searches for each store's phone, street and name. On hold: the searches were not answered alike for every store.", hold: true }); } }

// ---------- the verdict (sales headline), in the owner's order: the biggest loss first, the win last ----------
const PLACE_WORD = ['', 'First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth', 'Ninth', 'Tenth', 'Eleventh', 'Twelfth'];
const verdict = (() => {
  const usable = SEARCHES.filter(s => !s.hold);
  const losses = usable.filter(s => !s.you_lead).sort((a, b) => (a.you === 0) !== (b.you === 0) ? (a.you === 0 ? -1 : 1) : (b.leader_points - b.you) / b.n - (a.leader_points - a.you) / a.n || b.leader_points / b.n - a.leader_points / a.n);
  const wins = usable.filter(s => s.you_lead).sort((a, b) => (b.you - (b.second_points || 0)) / b.n - (a.you - (a.second_points || 0)) / a.n);
  const lossHead = s => s.you === 0 ? (s.found === 0 ? `Nowhere for "${s.kw}".` : `Outside the top 3 for "${s.kw}".`) : `${PLACE_WORD[s.place] || `Number ${s.place}`} for "${s.kw}".`;
  const winHead = s => { const m = s.you - (s.second_points || 0); return `${m === 0 ? 'Tied first' : 'First'} for "${s.kw}"${m > 0 && m <= 2 ? `, by ${plural(m, 'point', 'points')}` : ''}.`; };
  const lossLine = s => s.you === 0 ? `For "${s.kw}" ${business.short} is not in Google's top 3 at any of the ${s.n} map points${s.found === 0 ? ', and not in the first 20 at any of them' : `, though Google lists it lower down at ${s.found}`}; ${s.leader}, at number 1, holds ${s.leader_floor ? 'at least ' : ''}${s.leader_points}.`
    : `For "${s.kw}" ${business.short} is ${s.tied ? 'tied ' : ''}${(PLACE_WORD[s.place] || nth(s.place)).toLowerCase()}, in Google's top 3 at ${s.you} of ${s.n} map points; ${s.leader}, at number 1, holds ${s.leader_points}.`;
  const winLine = (s, first) => `For "${s.kw}" ${first ? business.short : 'it'} is number 1, at ${s.you} of ${s.n} points${s.second ? `, ${s.you === s.second_points ? 'level with' : `${plural(s.you - s.second_points, 'point', 'points')} ahead of`} ${s.second} at ${s.second_points}` : ''}.`;
  const built = business.ratings !== null ? ` It has ${n(business.ratings)} Google ratings at ${business.rating.toFixed(1)} stars.` : '';
  if (!usable.length) return { a: `${n(business.ratings)} ratings at ${business.rating?.toFixed(1)} stars.`, b: 'The map check comes next.', lead: `What we read about ${business.short} in ${loc.city} on ${day(runStart)}.`, order: 'loss-first', losses: [], wins: [] };
  const a = losses.length ? lossHead(losses[0]) : winHead(wins[0]);
  const b = losses.length && wins.length ? winHead(wins[0]) : losses.length > 1 ? lossHead(losses[1]) : '';
  const lines = [...losses.map(lossLine), ...wins.map((s, i) => winLine(s, !losses.length && i === 0))];
  return { a, b, lead: lines.join(' ') + built, order: 'loss-first', losses: losses.map(s => s.kw), wins: wins.map(s => s.kw) };
})();

// ---------- counts for the tiles: what a client would see ----------
const doors = ['maps', 'search', 'ai', 'website', 'links'];
const counts = Object.fromEntries(doors.map(d => { const cs2 = checks.filter(c => c.door === d && c.weight !== 'data' && !c.internal); return [d, { pass: cs2.filter(c => c.status === 'pass').length, watch: cs2.filter(c => c.status === 'watch').length, fail: cs2.filter(c => c.status === 'fail').length, na: cs2.filter(c => c.status === 'na').length, total: cs2.length }]; }));

// ---------- what changed since the run before ----------
const prev = prevPath ? JSON.parse(fs.readFileSync(prevPath, 'utf8')) : null;
if (prev && prev.business?.id !== business.id) die('--prev is a report for a different business');
const prevStatus = id => prev?.checks.find(c => c.id === id)?.status ?? null;
const isOpen = s => s === 'fail' || s === 'watch';
const keyNumbers = [
  ['Google ratings', business.ratings], ['Star rating', business.rating], ['Reviews in the last 3 months', reviews?.last_3 ?? null], ['Reviews with an owner reply', reviews?.with_reply ?? null],
  ...SEARCHES.map(s => [`Map points in the top 3, "${s.kw}"`, s.you]),
  ['Searches the whole website shows up for', search.keywords_total], ['Searches on page 1', search.top10], ['Phone speed score', website.phone?.score ?? null],
  ['Linking sites that are not link sellers', links?.not_sellers ?? null], ['Link-selling pages among them', links?.sellers ?? null],
];
const changes = (() => {
  if (!prev) return { first_run: true, numbers: keyNumbers.map(([label, now]) => ({ label, now })) };
  const line = c => ({ id: c.id, door: c.door, title: c.title, value: c.value, was: prevStatus(c.id) });
  const before = Object.fromEntries((prev.changes?.numbers || []).map(x => [x.label, x.now]));
  return { first_run: false, since: prev.meta.run_started, since_date: prev.meta.report_date, same_run: prev.meta.run_id === run.id,
    new_problems: checks.filter(c => isOpen(c.status) && !isOpen(prevStatus(c.id))).map(line), fixed: checks.filter(c => c.status === 'pass' && isOpen(prevStatus(c.id))).map(line),
    still: checks.filter(c => isOpen(c.status) && isOpen(prevStatus(c.id))).length, numbers: keyNumbers.map(([label, now]) => ({ label, now, was: before[label] ?? null })) };
})();
for (const tk of tasks) tk.is_new = !prev || !(prev.tasks || []).some(x => x.id === tk.id);

// ---------- rule checks that can be made in code ----------
// rule 2: nothing a client can see carries our own tag
const salesText = JSON.stringify([checks.filter(c => !c.internal && c.weight !== 'data').map(c => [c.detail, c.value, c.sales]), cmpRows.filter(r => r.sales), plan, verdict, ledger, gaps]);
if (agency && new RegExp(`utm_[a-z]+=${agency}`, 'i').test(salesText)) die('a line a client can see carries our own tag');
// rule 6: every map count printed is a count of points, read from the cells, and agrees with the software's share
for (const s of SW) if (s.share_mismatches) console.warn(`note: "${s.kw}": the software's share disagrees with the points for ${s.share_mismatches} businesses`);
// rule 10: the verdict leads with a loss whenever there is one
if (SEARCHES.some(s => !s.hold && !s.you_lead) && verdict.losses.length && !verdict.a.includes(`"${verdict.losses[0]}"`)) die('the headline does not lead with the biggest loss');
// never claim a result for a search that is not on file
for (const kw of missingSearches) if (new RegExp(`"${kw}"`, 'i').test(JSON.stringify([verdict, gaps, cmpRows.filter(r => r.sales), checks.filter(c => c.weight !== 'data').map(c => [c.title, c.detail, c.value])]))) die(`the report claims a result for "${kw}", which has no map check on file`);

// ---------- --facts: every number this report shares with the independent facts file (gh-facts.mjs) must agree ----------
// The facts file is computed from the same raw answers by separate code. A disagreement stops the build (fail closed): the
// side that is wrong against the raw data gets fixed, never the comparison. Ids: the store is 'green-haven', each rival
// its own id, which is also the facts file's slug.
const factsPath = opt('facts');
let factsReport = null;
if (factsPath) {
  const FX = JSON.parse(fs.readFileSync(factsPath, 'utf8')).facts || die('the facts file has no facts');
  const pairs = [], gone = [];
  const has = k => Object.prototype.hasOwnProperty.call(FX, k);
  const eq = (what, mine, key, map = x => x) => { if (!has(key)) { gone.push(key); return; } pairs.push({ what, mine, theirs: map(FX[key]), key }); };
  const domOf = id => id === 'green-haven' ? business.domain : rivals.find(r => r.id === id)?.domain;
  const ids = ['green-haven', ...rivals.map(r => r.id)];
  // the Google listing
  eq('Google name', business.name, 'name.google_title'); eq('register name', business.register_name, 'name.register');
  for (const [k, v] of [['rating', business.rating], ['ratings_count', business.ratings], ['photos', business.photos], ['claimed', business.claimed], ['category', business.category], ['additional_categories', business.extra_categories], ['attributes', business.attributes.length], ['service_options', business.service_options.length], ['place_topics', business.topics.length]]) eq('listing ' + k, v, 'gbp.green-haven.' + k);
  eq('rating spread', JSON.stringify(Object.fromEntries(Object.entries(business.rating_dist).map(([a, b]) => [String(a), b]))), 'gbp.green-haven.rating_distribution', x => JSON.stringify(x));
  const hm = m => String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
  for (const d of business.hours.days) eq('hours ' + d.day, d.openMins === null || d.openMins === undefined ? null : hm(d.openMins) + '-' + hm(d.closeMins), 'gbp.green-haven.hours.' + d.day);
  // each sweep: points, the store by band, its place, number 1, the best rival, the far field
  for (const sw of SW) {
    const k = 'sweep.' + sw.id;
    eq(k + ' points', sw.n, k + '.points'); eq(k + ' store top 3', sw.you.top3, k + '.store.in_1_3'); eq(k + ' store found', sw.you.found, k + '.store.found');
    eq(k + ' store not found', sw.you.not_found_points, k + '.store.not_found'); if (sw.you.top3 > 0) eq(k + ' store place', sw.place, k + '.store.place_by_share'); // a store at no point in a top 3 has no place
    eq(k + ' number 1 points', sw.lead.top3, k + '.leader.top3_points'); eq(k + ' best rival points', sw.best ? sw.best.top3 : null, k + '.best_rival.top3_points');
    eq(k + ' number 1 is the store', sw.lead.is_you, k + '.leader.is_store'); eq(k + ' excluded points', sw.excluded, k + '.points_excluded');
    eq(k + ' far points in a first 20', sw.far.points, k + '.out_of_market.points_with_one_in_first_20'); eq(k + ' far in a top 3', sw.far.in_top3, k + '.out_of_market.top3_points');
    eq(k + ' far at not-found points', sw.far.not_found_with_far, k + '.out_of_market.not_found_points_with_one_in_first_20');
    eq(k + ' field seen in a first 20', sw.of_all - 1, k + '.field_in_a_first_20'); eq(k + ' finished in posted hours', sw.open, k + '.finished_within_posted_hours');
    eq(k + ' top 5 by points', JSON.stringify(sw.field.slice(0, 5).map(x => [x.is_you ? business.name : x.name, x.top3])), k + '.top5', x => JSON.stringify(x.map(y => [y.name, y.top3_points])));
    for (const r of rivals) { const fr = sw.field.find(x => x.pid === r.place_id); if (fr) eq(k + ' ' + r.id + ' top 3', fr.top3, k + '.vs.' + r.id + '.rival_top3_points'); }
  }
  const cmpVal = (id, eid) => (cmpRows.find(r => r.id === id) || { entries: [] }).entries.find(x => x.id === eid);
  // the listings beside the store (compare rows read from each Google listing)
  for (const r of rivals) for (const [row, key] of [['ratings', 'ratings_count'], ['stars', 'rating'], ['photos', 'photos']]) { const x = (cmpRows.find(c => c.id === row) || { entries: [] }).entries.find(y => y.name === r.short); if (x) eq(row + ' ' + r.id, x.v, 'gbp.' + r.id + '.' + key); }
  // review velocity and replies, every business the run pulled
  for (const id of ids) {
    const x = cmpVal('velocity', id); if (x) eq('velocity ' + id, x.v, 'rv.' + id + '.per_month_90d');
    const y = cmpVal('replies-90', id); if (y && has('rv.' + id + '.in_90d')) eq('replied 90 days ' + id, y.v, 'rv.' + id + '.replied_90d', v => FX['rv.' + id + '.in_90d'] ? Math.round(1000 * v / FX['rv.' + id + '.in_90d']) / 10 : null);
    const z = cmpVal('reviews-pulled', id); if (z) eq('reviews pulled ' + id, z.v, 'rv.' + id + '.collected', v => FX['rv.' + id + '.capped'] ? null : v);
    const vt = velocityTable.find(v => (v.is_you ? 'green-haven' : (rivals.find(r => r.short === v.name) || {}).id) === id);
    if (vt) for (const w of ['30', '90', '365']) { eq('velocity table ' + id + ' ' + w + ' days', vt['d' + w] ? vt['d' + w].n : null, 'rv.' + id + '.in_' + w + 'd'); eq('velocity table ' + id + ' ' + w + ' days a month', vt['d' + w] ? vt['d' + w].per_month : null, 'rv.' + id + '.per_month_' + w + 'd'); }
  }
  eq('reviews collected', reviews.collected, 'rv.green-haven.collected'); eq('reviews with a reply', reviews.with_reply, 'rv.green-haven.replied');
  for (const w of ['30', '90', '365']) { const x = reviews.windows ? reviews.windows['d' + w] : null; eq('store ' + w + ' days', x ? x.n : null, 'rv.green-haven.in_' + w + 'd'); eq('store ' + w + ' days replied', x ? x.replied : null, 'rv.green-haven.replied_' + w + 'd'); eq('store ' + w + ' days a month', x ? x.per_month : null, 'rv.green-haven.per_month_' + w + 'd'); }
  // search, whole websites
  for (const id of ids) { const dm = domOf(id);
    const a = cmpVal('searches', id), b = cmpVal('visits', id), c = cmpVal('strength', id);
    // a chain's whole-website figures are held off the cards (rule 7): its raw figures are compared instead
    const rv = rivals.find(r => r.id === id), ch = !!(rv && isChain(rv));
    if (a) eq('searches ' + id, ch ? rv.keywords : a.v, 'domain.' + dm + '.organic_keywords_whole_site'); if (b) eq('visits ' + id, ch ? rv.visits : b.v, 'domain.' + dm + '.organic_traffic_estimate_whole_site'); if (c) eq('link strength ' + id, ch ? rankOf(rv.domain) : c.v, 'domain.' + dm + '.rank'); }
  eq('store searches in the top 3', search.top3, 'domain.' + business.domain + '.positions_1_3');
  // the store pages and the crawls
  for (const id of ids) {
    const p = cmpVal('speed-phone', id), q = cmpVal('speed-desktop', id), w = cmpVal('page-words', id), o = cmpVal('onpage', id), c = cmpVal('crawl-score', id);
    if (p) eq('phone speed ' + id, p.v, 'speed.listing_page.' + id + '.phone.performance'); if (q) eq('desktop speed ' + id, q.v, 'speed.listing_page.' + id + '.desktop.performance');
    if (w) eq('crawler words ' + id, w.v, 'site.listing_page.' + id + '.words_crawler');
    if (o) eq('on-page score ' + id, o.v === null && /Not confirmed/.test(o.why || '') ? 'not confirmed' : o.v, 'site.listing_page.' + id + '.onpage_score', v => typeof v === 'number' ? r1(v) : v);
    if (c) eq('whole-site crawl score ' + id, c.v, 'crawl.' + id + '.onpage_score', v => r1(v));
  }
  eq('crawl pages', website.crawl ? website.crawl.pages : null, 'crawl.green-haven.pages_crawled'); eq('crawl stopped at its limit', website.crawl ? website.crawl.at_limit : null, 'crawl.green-haven.stopped_at_limit');
  // links, classified the same way for every website
  for (const id of ids) {
    const a = cmpVal('clean-sites', id), b = cmpVal('sites', id), c = cmpVal('wave', id);
    if (a) eq('not link sellers ' + id, a.v, 'links.' + id + '.referring_domains_not_sellers'); if (b) eq('linking sites ' + id, b.v, 'links.' + id + '.referring_domains');
    if (c) eq('new link sellers in 30 days ' + id, c.v, 'links.' + id + '.referring_domains_new_30d_sellers');
  }
  eq('store linking sites', links.sites, 'links.green-haven.referring_domains'); eq('store sellers', links.sellers, 'links.green-haven.referring_domains_sellers');
  eq('store links read', links.links, 'links.green-haven.links_held'); eq('store new linking sites in 30 days', links.fresh, 'links.green-haven.referring_domains_new_30d');
  // directories, the software's own verdicts
  eq('directory verdicts', listings.verdicts ? listings.verdicts.checked_all : null, 'cit.verdicts');
  eq('directory verdicts by kind', JSON.stringify(listings.verdicts ? listings.verdicts.all : null), 'cit.by_verdict', x => JSON.stringify([x.listed || 0, x['not-listed'] || 0, x.undetermined || 0]));
  // the one factor that survives the software's control, worked out again with and without another area's rows
  eq('distance fit, every row', distanceFit.all, 'seos.distance_rho_reproduced_all_rows'); eq('distance fit rows', distanceFit.rows, 'seos.distance_rho_rows');
  eq('distance fit without far rows', distanceFit.without_far, 'seos.distance_rho_without_out_of_market'); eq('distance fit rows without far', distanceFit.rows_without_far, 'seos.distance_rho_without_out_of_market_rows');
  // the search the owner expects and the record does not hold
  // whether the record this report reads holds the search (the facts' sweeps.*), not SEOS's own list of sweeps (seos.*): a scan
  // folded in from another tool is on file here and still absent from SEOS's list
  for (const kw of set.expect || []) if (kw === 'weed near me') eq('"weed near me" sweep on file for this report', !missingSearches.includes(kw), 'sweeps.weed_near_me_held');
  const differ = pairs.filter(p => JSON.stringify(p.mine) !== JSON.stringify(p.theirs));
  factsReport = { file: path.basename(factsPath), compared: pairs.length, differ: differ.length };
  if (gone.length) die('--facts: ' + gone.length + ' fact names are not in the facts file: ' + gone.slice(0, 8).join(', '));
  if (differ.length) die('--facts: ' + differ.length + ' of ' + pairs.length + ' shared numbers disagree:\n  ' + differ.slice(0, 30).map(p => p.what + ': report ' + JSON.stringify(p.mine) + ', facts ' + JSON.stringify(p.theirs) + ' [' + p.key + ']').join('\n  '));
  console.log('facts: ' + pairs.length + ' shared numbers compared with ' + path.basename(factsPath) + ', 0 disagree');
}

const out = {
  meta: {
    built_at: new Date().toISOString(), report_date: day(runStart), run_id: run.id, run_started: dayTime(runStart), run_finished: dayTime(runEnd),
    parts: Object.keys(parts).length, steps: run.steps.length, agency: set.agency || null, timezone: tz,
    record: { file: A.file, bytes: A.bytes, sha256: A.sha256 },
    sources: [A, FA, WA].map(x => ({ file: x.file, bytes: x.bytes, sha256: x.sha256, answer: x.json.audit || 'business' })),
    website_run: webRun ? { id: webRun.id, started: dayTime(when(webRun.started_at)), finished: dayTime(when(webRun.finished_at)), steps: webRun.steps?.length || 0 } : null,
    v2: true, order: 'loss-first', extractor: 'extract-v2.mjs', second_readings: secondReadings, facts_check: factsReport,
    expected_searches: set.expect || [], missing_searches: missingSearches,
  },
  business, stores, you, rivals, maps, reviews, search, website, links, listings,
  ai: { collected: false },
  checks, tasks, task_groups: taskGroups, plan, holds, ledger, compare, gaps, map: mk, market, verdict, counts, changes,
};
if (Object.keys(out).length !== 25) die(`the output has ${Object.keys(out).length} keys, the contract has 25`);
fs.writeFileSync(outPath, JSON.stringify(out, null, 1));

const st = s => checks.filter(c => c.status === s).length;
console.log(`wrote ${path.basename(outPath)} (${fs.statSync(outPath).size.toLocaleString('en-US')} bytes)`);
console.log(`${business.name} | run ${run.id} | report date ${out.meta.report_date} | ${SW.length} sweeps on file${mk ? `, market file with ${mk.searches.length} searches` : ', no market file'}`);
for (const s of SEARCHES) console.log(`  "${s.kw}": ${s.you} of ${s.n} points, ${s.place ? nth(s.place) : 'not placed'} of ${s.of}${s.you_lead ? `, number 1 (number 2 ${s.second} ${s.second_points})` : `, number 1 ${s.leader} ${s.leader_points}`}${s.hold ? ' [ON HOLD]' : ''} | ${s.when}, ${s.open ? 'open' : 'NOT OPEN'}`);
console.log(`checks ${checks.length}: pass ${st('pass')}, watch ${st('watch')}, fail ${st('fail')}, not measured or on hold ${st('na')} | ours only ${checks.filter(c => c.internal).length} | about the run ${checks.filter(c => c.weight === 'data').length}`);
console.log(`tasks ${tasks.length}: ${['us', 'client', 'account', 'software'].map(o => `${o} ${tasks.filter(x => x.owner === o).length}`).join(', ')} (software's own findings ${tasks.filter(x => x.seos).length}) | sales plan ${plan.length} | numbers on hold ${holds.length}`);
console.log(`verdict: ${verdict.a} ${verdict.b}`);
console.log(`compare rows ${cmpRows.length}: ${cmpRows.filter(r => r.sales).length} safe for a client, ${cmpRows.filter(r => !r.sales).length} team only | gap lines ${gaps.length}: ${gaps.filter(g => g.lead).length} level or ahead`);
console.log(`second readings: ${secondReadings.map(x => `${x.what} ${x.agree ? 'agree' : 'DISAGREE'} (${x.here.join('/')} vs ${x.seos.join('/')})`).join('; ') || 'none'}`);
if (missingSearches.length) console.log(`expected and not on file: ${missingSearches.map(k => `"${k}"`).join(', ')} -> task ${tasks.find(x => x.id === 'expected-search')?.n}`);
