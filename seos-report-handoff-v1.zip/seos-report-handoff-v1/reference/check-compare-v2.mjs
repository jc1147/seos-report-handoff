// check-compare-v2.mjs: a second, separately written reading of the raw SEOS answers for the Compare numbers of a v2
// report (extract-v2.mjs data). It shares no code with extract-v2.mjs: it goes back to the sweep cells, the Google
// listing readings, the page-speed readings and the whole-website signals, works each value out its own way, and fails
// if any store, value, the store's mark, the order of a card or a client-safe flag in report-data.json disagrees.
// It also holds the owner's rule that the comparison IS the product: every tab has a comparison a client can see, each
// with the store and at least one competitor that carry real numbers.
// usage: node check-compare-v2.mjs <business.json> <full-audit.json> <website-audit.json> <report-data.json>
import fs from 'node:fs';

const [bizPath, fullPath, webPath, dataPath] = process.argv.slice(2);
if (!bizPath || !fullPath || !webPath || !dataPath) { console.error('usage: node check-compare-v2.mjs <business.json> <full-audit.json> <website-audit.json> <report-data.json>'); process.exit(2); }
const J = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const T = J(bizPath).tables, FA = J(fullPath), WA = J(webPath), D = J(dataPath);
if (!D.meta || D.meta.v2 !== true) { console.error('not v2 data: use check-compare.mjs'); process.exit(2); }
const C = D.compare;
let bad = 0, checked = 0;
const fail = (what, detail) => { bad++; if (bad <= 40) console.log(`MISMATCH  ${what}${detail === undefined ? '' : '\n    ' + detail}`); };
const same = (what, got, want) => { checked++; if (JSON.stringify(got) !== JSON.stringify(want)) fail(what, `report: ${JSON.stringify(got)}  raw: ${JSON.stringify(want)}`); };
const ok = (what, cond, detail) => { checked++; if (!cond) fail(what, detail); };

// the readings, newest first per kind and place
const R = [...(FA.tables?.vendor_readings || []), ...(WA.tables?.vendor_readings || [])];
const latest = (kind, key) => R.filter(r => r.kind === kind && r.place_id === key).sort((a, b) => (Date.parse(b.fetched_at) || 0) - (Date.parse(a.fetched_at) || 0))[0] || null;
const store = T.locations[0].place_id;
const pidOf = id => id === D.you.id ? store : (D.rivals.find(r => r.id === id) || {}).place_id || (String(id).startsWith('map-') ? String(id).slice(4) : null);
const row = id => C.rows.find(r => r.id === id) || null;

// 1. map rows: each business's top-3 points, counted from the sweep's own cells (first 20 at each point)
for (const r of C.rows.filter(x => /^map-\d+$/.test(x.id))) {
  const scan = r.id.slice(4);
  const cells = (T.engine_sweep_cells || []).find(c => String(c.scan_id) === scan)?.cells || [];
  ok(`${r.id}: the sweep's cells are in the record`, cells.length > 0, `scan ${scan}`);
  const top3 = pid => cells.filter(c => (c.top || []).slice(0, 3).includes(pid)).length;
  for (const e of r.entries) { const pid = e.is_you ? store : pidOf(e.id); same(`${r.id}: ${e.name} top-3 points`, e.v, top3(pid)); }
  // the card lists the businesses with the most points first, and the store
  const vals = r.entries.filter(e => !e.is_you).map(e => e.v);
  ok(`${r.id}: businesses in order of points`, vals.every((v, i) => i === 0 || vals[i - 1] >= v), JSON.stringify(vals));
  const pids = new Set(cells.flatMap(c => (c.top || []).slice(0, 3)));
  const most = Math.max(...[...pids].filter(p => p !== store).map(top3));
  same(`${r.id}: the first competitor on the card has the most points of any`, vals[0], most);
}

// 2. the Google listing rows: ratings, stars, photos from each place's own listing reading
const LISTING = { ratings: it => it.rating?.votes_count ?? null, stars: it => it.rating?.value ?? null, photos: it => it.total_photos ?? null };
for (const [id, get] of Object.entries(LISTING)) {
  const r = row(id); if (!r) { fail(`${id}: the row is missing`); continue; }
  for (const e of r.entries) { const it = latest('business_info', e.is_you ? store : pidOf(e.id))?.result?.business_info?.items?.[0]; same(`${id}: ${e.name}`, e.v, it ? get(it) : null); }
}

// 3. the store pages' lab speed, phone and desktop, from each place's page-speed reading
for (const [id, dev] of [['speed-phone', 'phone'], ['speed-desktop', 'desktop']]) {
  const r = row(id); if (!r) { fail(`${id}: the row is missing`); continue; }
  for (const e of r.entries) { const x = latest('page_speed', e.is_you ? store : pidOf(e.id))?.result?.[dev]; same(`${id}: ${e.name}`, e.v, x && !x.error && x.score != null ? Math.round(x.score * 100) : null); }
}

// 4. whole-website signals (the store's own reading lists every website): searches, visits, link strength
const rs = latest('ranking_signals', store)?.result || {};
const domOf = e => e.is_you ? D.you.domain : (D.rivals.find(r => r.id === e.id) || {}).domain;
const traffic = d => (rs.traffic?.items || []).find(i => i.target === d)?.metrics?.organic || null;
// A rival whose own Google listing links to an inner page (one store's page on a website for many stores) is a chain:
// its whole-website figures may never stand beside the store's one-store website (rule 7). Its entry must carry no
// number and say why; every other entry must equal the raw figure. Read from the listing itself, not from the report.
const isChainRaw = e => { if (e.is_you) return false; const it = latest('business_info', pidOf(e.id))?.result?.business_info?.items?.[0]; try { const u = new URL(it?.url); return !(u.pathname === '/' || u.pathname === ''); } catch { return false; } };
for (const [id, get] of [['searches', d => traffic(d)?.count ?? null], ['visits', d => traffic(d)?.etv != null ? Math.round(traffic(d).etv) : null], ['strength', d => (rs.ranks?.items || []).find(i => i.target === d)?.rank ?? null]]) {
  const r = row(id); if (!r) { fail(`${id}: the row is missing`); continue; }
  for (const e of r.entries) {
    if (isChainRaw(e)) { same(`${id}: ${e.name} (${domOf(e)}) is a chain's website, so it carries no number`, e.v, null); ok(`${id}: ${e.name}'s missing number says it is a website for many stores`, /many stores/i.test(e.why || ''), JSON.stringify(e.why)); }
    else same(`${id}: ${e.name} (${domOf(e)})`, e.v, get(domOf(e)));
  }
}
// the gap lines for whole websites: never a chain as the comparator, never "times yours", and labelled whole
for (const g of (D.gaps || []).filter(x => ['searches', 'visits', 'strength'].includes(x.id))) {
  const rv = D.rivals.find(r => r.short === g.best_name || r.name === g.best_name);
  ok(`gap ${g.id}: the comparator is a rival's one-store website`, !!rv && !isChainRaw({ id: rv.id }), JSON.stringify(g.best_name));
  ok(`gap ${g.id}: no "times yours" on a whole-website line`, !/times yours/i.test(g.text), g.text);
  ok(`gap ${g.id}: marked as whole websites`, g.scope === 'whole', JSON.stringify(g.scope));
}

// 5. every row: the store once, values with a reason when missing, the client-safe flag
for (const r of C.rows) {
  ok(`${r.id}: the store is on the card exactly once`, r.entries.filter(e => e.is_you).length === 1, JSON.stringify(r.entries.map(e => e.name)));
  for (const e of r.entries.filter(x => x.v !== null && typeof x.v === 'number')) {
    // the first number printed is the value: '58 of 121' is 58, '97.1%' is 97.1, '268' is 267.85 rounded
    const first = String(e.show ?? '').match(/\d[\d,]*(\.\d+)?/); const shown = first ? parseFloat(first[0].replace(/,/g, '')) : NaN;
    ok(`${r.id}: ${e.name}'s printed value is its number`, Number.isFinite(shown) && Math.abs(shown - e.v) <= 0.5, JSON.stringify([e.show, e.v]));
  }
  ok(`${r.id}: every missing value says why`, r.entries.every(e => e.v !== null || (e.why && e.why.length > 3)), JSON.stringify(r.entries.filter(e => e.v === null)));
  ok(`${r.id}: a row on hold is never shown to a client`, !(r.hold && r.sales), JSON.stringify({ hold: r.hold, sales: r.sales }));
  if (r.sales) ok(`${r.id}: a row a client sees sets the store beside at least one competitor with a number`, r.entries.some(e => e.is_you && e.v !== null) && r.entries.some(e => !e.is_you && e.v !== null), JSON.stringify(r.entries.map(e => [e.name, e.v])));
}
// a capped review pull is never printed as a count (rule 4)
const pulled = row('reviews-pulled');
if (pulled) for (const e of pulled.entries) { const pid = e.is_you ? store : pidOf(e.id); const rv = latest('reviews', pid); const pull = rv?.result?.reviews || null, votes = latest('business_info', pid)?.result?.business_info?.items?.[0]?.rating?.votes_count ?? null; const depth = rv?.request?.reviews?.depth ?? rv?.result?.pull?.depth ?? null; const capped = pull ? pull.capped === true || (depth !== null && (pull.count ?? 0) >= depth && votes !== null && pull.count < votes) : null; // a pull that reached the depth it asked for and holds fewer than the listing's ratings stopped at its limit
  ok(`reviews-pulled: ${e.name}'s pull is in the record`, !!pull, pid); if (capped) same(`reviews-pulled: ${e.name}'s pull stopped at its limit, so it is not printed`, e.v, null); }
// 6. the comparison is the product: every tab of the Sales view has one with real competitor numbers
for (const door of ['maps', 'search', 'website', 'links']) ok(`${door}: a client sees at least one comparison with real competitor numbers`, C.rows.some(r => r.door === door && r.sales && r.entries.filter(e => !e.is_you && e.v !== null).length >= 1), door);

console.log(`${checked} checks, ${bad} disagreements`);
console.log(bad ? 'COMPARE CHECK V2: FAIL' : 'COMPARE CHECK V2: PASS');
process.exit(bad ? 1 : 0);
