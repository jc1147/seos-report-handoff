// merge-sweep.mjs: a data folder with one extra map sweep folded into the business answer, so the whole chain (the facts
// oracle included) reads it as if SEOS held it. The original answers are never edited: every top-level file of the data
// folder is copied as it is, and only the copy of business-<id>.json gets the sweep's engine_sweeps, engine_sweep_cells,
// engine_sweep_businesses, engine_sweep_fields and engine_actors rows appended. A sweep id the business answer already
// holds, or a sweep about another store, is refused. merged-from.json records what was folded in, with sha256s.
// usage: node merge-sweep.mjs <data folder> <sweep.seos.json> <new data folder>
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const [srcDir, sweepPath, outDir] = process.argv.slice(2);
if (!srcDir || !sweepPath || !outDir) { console.error('usage: node merge-sweep.mjs <data folder> <sweep.seos.json> <new data folder>'); process.exit(2); }
const die = m => { console.error('MERGE FAILED: ' + m); process.exit(1); };
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
if (path.resolve(srcDir) === path.resolve(outDir)) die('the new folder must not be the original');
const bizFile = fs.readdirSync(srcDir).find(f => /^business-\d+\.json$/.test(f)) || die('no business-<id>.json in ' + srcDir);
const bizRaw = fs.readFileSync(path.join(srcDir, bizFile)), biz = JSON.parse(bizRaw.toString('utf8'));
const T = biz.tables || die('the business answer has no tables');
const swRaw = fs.readFileSync(sweepPath), sw = JSON.parse(swRaw.toString('utf8'));
const store = T.locations?.[0]?.place_id || die('no location row');
const KINDS = ['engine_sweeps', 'engine_sweep_cells', 'engine_sweep_businesses', 'engine_sweep_fields', 'engine_actors'];
const ids = [...new Set((sw.engine_sweeps || []).map(s => String(s.scan_id)))];
if (!ids.length) die('the sweep file holds no engine_sweeps row');
for (const s of sw.engine_sweeps) if (s.subject !== store) die(`sweep ${s.scan_id} is about ${s.subject}, not ${store}`);
const held = new Set((T.engine_sweeps || []).map(s => String(s.scan_id)));
for (const id of ids) if (held.has(id)) die(`sweep ${id} is already in ${bizFile}`);
for (const k of KINDS) for (const r of sw[k] || []) if (r.scan_id !== undefined && !ids.includes(String(r.scan_id))) die(`a ${k} row names sweep ${r.scan_id}, not one of ${ids.join(', ')}`);

fs.mkdirSync(outDir, { recursive: true });
const copied = [];
for (const f of fs.readdirSync(srcDir)) { const p = path.join(srcDir, f); if (!fs.statSync(p).isFile() || f === bizFile) continue; fs.copyFileSync(p, path.join(outDir, f)); copied.push(f); }
const added = {};
for (const k of KINDS) { const rows = sw[k] || []; T[k] = [...(T[k] || []), ...rows]; added[k] = rows.length; }
const out = Buffer.from(JSON.stringify(biz));
fs.writeFileSync(path.join(outDir, bizFile), out);
fs.writeFileSync(path.join(outDir, 'merged-from.json'), JSON.stringify({ made_by: 'green-haven/merge-sweep.mjs', from: { folder: path.basename(path.resolve(srcDir)), business: bizFile, business_sha256: sha(bizRaw) },
  sweep: { file: path.basename(sweepPath), sha256: sha(swRaw), source: sw.source || null, scan_ids: ids }, rows_added: added, copied_unchanged: copied.sort(), business_out_sha256: sha(out) }, null, 1));
console.log(`merged sweep ${ids.join(', ')} into ${path.join(outDir, bizFile)}: ${KINDS.map(k => `${k} +${added[k]}`).join(', ')}; ${copied.length} other files copied unchanged`);
