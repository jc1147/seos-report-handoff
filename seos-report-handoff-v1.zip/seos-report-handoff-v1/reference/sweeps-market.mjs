// sweeps-market.mjs: the market around one store, built from SEOS's own map sweeps of it. It writes the same file
// market-facts.mjs writes from saved map reports, so mapview.js, build-report.mjs and extract.mjs read it unchanged.
// A sweep is a grid of points around the store; at every point SEOS kept the businesses Google listed, best first.
// Nothing is typed by hand and nothing is estimated: a share is a count of points, every count is checked against
// the share SEOS itself states, and where two fields of one reading disagree the file says so.
// Links are never copied (a listing link can carry tags): only where a link lands, the front page or a deeper page.
// usage: node sweeps-market.mjs <business-data.json> <full-audit.json> <store place id> <out market.json>
//          [--tz=America/New_York] [--extra=<file>[,<file>]] [--all-sweeps=<engine_sweeps-all.json>]
//          [--want=<search>[,<search>]] [--far-mi=150]
//   --extra       more sweeps in SEOS's own row shape: {engine_sweeps, engine_sweep_cells, engine_sweep_businesses
//                 [, engine_actors]} (or the API's {tables: {...}}). A sweep added this way needs no code change.
//   --all-sweeps  SEOS's list of every sweep: says which sweeps of this store exist but were not read here.
//   --want        searches someone asked for. One with no sweep on file is listed as missing, never as a result.
//   --far-mi      the distance past which a business is out of this market (default 150 miles, see far.why).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const argv = process.argv.slice(2);
const [bizPath, auditPath, SUBJECT, outPath] = argv.filter(a => !a.startsWith('--'));
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
if (!bizPath || !auditPath || !SUBJECT || !outPath) { console.error('usage: node sweeps-market.mjs <business-data.json> <full-audit.json> <store place id> <out market.json> [--tz=] [--extra=] [--all-sweeps=] [--want=] [--far-mi=]'); process.exit(2); }
const TZ = opt('tz') || 'America/New_York';
const die = m => { console.error('SWEEPS MARKET FAILED: ' + m); process.exit(1); };
const TOP = 20;                                    // every point is read to the same depth: Google's first 20
// One character names one business in a sweep. The first 64 are market-facts.mjs's; a SEOS sweep lists more
// businesses than that, so the alphabet runs on through Latin letters. Each is one UTF-16 unit, none is a dash the
// page's JSON step rewrites, none needs escaping. mapview.js reads the alphabet from the file.
const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_' +
  [...Array(0x180 - 0xC0).keys()].map(k => 0xC0 + k).filter(c => c !== 0xD7 && c !== 0xF7).map(c => String.fromCharCode(c)).join('');
const r1 = x => Math.round(x * 10) / 10, r2 = x => Math.round(x * 100) / 100;
const num = x => (x === null || x === undefined || x === '' ? null : Number(x));
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
// a time in the record: with its zone when it has one; the API's stamps without one are UTC (see source.notes)
const toMs = s => { if (s === null || s === undefined || s === '') return NaN; let x = String(s).trim().replace(' ', 'T').replace(/\s*([+-]\d\d:?\d\d|Z)$/i, '$1'); if (!/([+-]\d\d:?\d\d|Z)$/i.test(x)) x += 'Z'; return Date.parse(x); };
const sec = s => Math.floor(toMs(s) / 1000);
const parts = ts => Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: TZ, weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true }).formatToParts(new Date(ts * 1000)).map(p => [p.type, p.value]));
const dayKey = ts => new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(ts * 1000));
const clock = ts => { const p = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: TZ, weekday: 'long', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date(ts * 1000)).map(x => [x.type, x.value])); return { wd: p.weekday.toLowerCase(), m: (Number(p.hour) % 24) * 60 + Number(p.minute) }; };
const whenOf = ts => { const p = parts(ts); return `${p.weekday}, ${p.month} ${p.day}, ${p.year}, ${p.hour}:${p.minute} ${p.dayPeriod}`; };
const host = u => { try { return new URL(/^https?:/.test(u) ? u : 'https://' + u).hostname.replace(/^www\./, ''); } catch { return null; } };
const landsOn = u => { try { const p = new URL(u).pathname.replace(/\/+$/, ''); return p === '' ? 'home' : 'inner'; } catch { return null; } };
const KM_PER_MI = 1.609344;
const km = (a, b) => { const R = 6371.0088, rad = x => x * Math.PI / 180, dLat = rad(b[0] - a[0]), dLng = rad(b[1] - a[1]); const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dLng / 2) ** 2; return 2 * R * Math.asin(Math.min(1, Math.sqrt(h))); };

// ---------- the inputs ----------
const inputs = [];
const readJson = (p, role) => { const raw = fs.readFileSync(p); inputs.push({ file: path.basename(p), role, bytes: raw.length, sha256: sha(raw) }); return JSON.parse(raw.toString('utf8')); };
const BD = readJson(bizPath, 'business data');
const FA = readJson(auditPath, 'full audit');
const T = BD.tables || die('the business data has no tables');
const loc = (T.locations || []).find(l => l.place_id === SUBJECT) || die('the business data is about another store: no location row for ' + SUBJECT);
const register = (T.businesses || [])[0] || {};
const readings = (FA.tables && FA.tables.vendor_readings) || die('the full audit has no vendor_readings');
const BI = {};                                     // place id -> its Google listing as read, with when
for (const r of readings) if (r.kind === 'business_info') { const it = r.result && r.result.business_info && r.result.business_info.items && r.result.business_info.items[0]; if (it) BI[r.place_id] = { it, at: sec(r.fetched_at) }; }
const myBI = BI[SUBJECT] || null;
const STORE = [Number(loc.lat), Number(loc.lng)];
if (!Number.isFinite(STORE[0]) || !Number.isFinite(STORE[1])) die("the store's own location has no coordinates");

// every sweep to read: the business data's own, then any extra files
const sweeps = [], cellsBy = {}, rowsBy = {}, actorsBy = {}, skipped = [], notes = [];
const addSource = (tables, from) => {
  for (const s of tables.engine_sweeps || []) {
    const id = String(s.scan_id);
    if (s.subject !== SUBJECT) { skipped.push([`sweep ${id} (${from})`, 'about another store']); continue; }
    if (sweeps.some(x => x.id === id)) die(`sweep ${id} is in the input twice (${from})`);
    sweeps.push({ id, row: s, from });
  }
  for (const c of tables.engine_sweep_cells || []) { const id = String(c.scan_id); if (cellsBy[id] && from !== 'business data') die(`the points of sweep ${id} are in the input twice`); cellsBy[id] = c; }
  for (const b of tables.engine_sweep_businesses || []) { const id = String(b.scan_id); ((rowsBy[id] ||= {}))[b.place_id] && die(`sweep ${id} lists ${b.place_id} twice`); rowsBy[id][b.place_id] = b; }
  for (const a of tables.engine_actors || []) if (a.kind === 'scan') (actorsBy[String(a.ref)] ||= []).push(a);
};
addSource(T, 'business data');
for (const p of (opt('extra') || '').split(',').filter(Boolean)) { const j = readJson(p, 'extra sweeps'); addSource(j.tables || j, 'extra:' + path.basename(p)); }
if (!sweeps.length) die('no sweep of this store in the input');

// the store's posted hours, from its own Google listing
const HOURS = myBI && myBI.it.work_time && myBI.it.work_time.work_hours && myBI.it.work_time.work_hours.timetable || null;
const DAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
const spans = wd => (HOURS && HOURS[wd] || []).map(s => { const o = s.open.hour * 60 + s.open.minute; let c = s.close.hour * 60 + s.close.minute; if (c <= o) c += 1440; return [o, c]; });
const openAt = ts => { if (!HOURS) return null; const { wd, m } = clock(ts), prev = DAYS[(DAYS.indexOf(wd) + 6) % 7]; return spans(wd).some(([o, c]) => m >= o && m < c) || spans(prev).some(([, c]) => c > 1440 && m + 1440 < c); };
const hm12 = m => { const h = Math.floor(m / 60) % 24, mm = m % 60; return `${(h % 12) || 12}:${String(mm).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
const hoursOn = ts => { if (!HOURS) return null; const { wd } = clock(ts), s = spans(wd); return s.length ? s.map(([o, c]) => `${hm12(o)} to ${hm12(c % 1440)}`).join(', ') : 'closed'; };

// ---------- each sweep ----------
const biz = [], bizAt = new Map(), geoms = [], geomAt = new Map(), scans = [];
const latest = {};                                 // place id -> its row in the newest sweep that lists it
const addBiz = pid => { if (!bizAt.has(pid)) { bizAt.set(pid, biz.length); biz.push({ pid }); } return bizAt.get(pid); };
addBiz(SUBJECT);                                   // the store is business 0
const looksLikeStreet = s => /^\d+[A-Za-z]?\s+\S/.test(String(s || ''));
const seosRowsAddrInCat = new Set();

sweeps.sort((a, b) => toMs(a.row.finished_at) - toMs(b.row.finished_at) || a.id.localeCompare(b.id));
for (const sw of sweeps) {
  const id = sw.id, S = sw.row, CR = cellsBy[id], rows = rowsBy[id] || {};
  const kw = String(S.keyword || '').trim().toLowerCase();
  if (kw.length < 3) { skipped.push([`sweep ${id}`, `the search phrase is "${kw}"`]); continue; }
  if (!CR || !Array.isArray(CR.cells) || !CR.cells.length) { skipped.push([`sweep ${id}`, 'its points are not in the record']); continue; }
  const N = Number(S.grid_size), cs = CR.cells, n = cs.length;
  if (Number(S.total_points) !== n) die(`sweep ${id}: SEOS says ${S.total_points} points, the record holds ${n}`);
  // the points on a lattice: row 0 is the north edge, column 0 the west edge
  const seen = new Set(), latOf = new Map(), lngOf = new Map();
  for (const c of cs) {
    if (![c.row, c.col].every(v => Number.isInteger(v) && v >= 0 && v < N)) die(`sweep ${id}: a point sits outside the ${N} by ${N} grid`);
    const k = c.row + ',' + c.col; if (seen.has(k)) die(`sweep ${id}: two points at row ${c.row}, column ${c.col}`); seen.add(k);
    if (latOf.has(c.row) && latOf.get(c.row) !== Number(c.lat)) die(`sweep ${id}: row ${c.row} has two latitudes`); latOf.set(c.row, Number(c.lat));
    if (lngOf.has(c.col) && lngOf.get(c.col) !== Number(c.lng)) die(`sweep ${id}: column ${c.col} has two longitudes`); lngOf.set(c.col, Number(c.lng));
  }
  const rs = [...latOf.keys()].sort((a, b) => a - b), ks = [...lngOf.keys()].sort((a, b) => a - b), mid = (N - 1) / 2;
  if (rs.length < 2 || ks.length < 2) die(`sweep ${id}: too few rows or columns to place the grid`);
  const stepLat = (latOf.get(rs[0]) - latOf.get(rs[rs.length - 1])) / (rs[rs.length - 1] - rs[0]), stepLng = (lngOf.get(ks[ks.length - 1]) - lngOf.get(ks[0])) / (ks[ks.length - 1] - ks[0]);
  const cLat = latOf.get(rs[0]) - (mid - rs[0]) * stepLat, cLng = lngOf.get(ks[0]) - (ks[0] - mid) * stepLng;
  for (const r of rs) if (Math.abs(cLat + (mid - r) * stepLat - latOf.get(r)) > 1e-6) die(`sweep ${id}: the rows are not evenly spaced`);
  for (const k of ks) if (Math.abs(cLng + (k - mid) * stepLng - lngOf.get(k)) > 1e-6) die(`sweep ${id}: the columns are not evenly spaced`);
  const excluded = []; for (let r = 0; r < N; r++) for (let k = 0; k < N; k++) if (!seen.has(r + ',' + k)) excluded.push([r, k]);
  const stated = /(\d+) of the (\d+) grid points were excluded/.exec(String(S.exclusion_note || ''));
  if (stated && (Number(stated[1]) !== excluded.length || Number(stated[2]) !== N * N)) die(`sweep ${id}: the note says ${stated[1]} of ${stated[2]} points were left out, the grid is missing ${excluded.length} of ${N * N}`);
  if (!stated && excluded.length) notes.push(`sweep ${id}: ${excluded.length} of ${N * N} grid points are not in the record and no note says why`);
  const ordered = [...cs].sort((a, b) => a.row - b.row || a.col - b.col);
  const gKey = N + '|' + ordered.map(c => c.row + ',' + c.col).join(';') + '|' + cLat.toFixed(7) + ',' + cLng.toFixed(7);
  if (!geomAt.has(gKey)) { geomAt.set(gKey, geoms.length); geoms.push({ size: N, n, radius: num(S.radius), unit: S.unit || 'mi', centre: [cLat, cLng], step: [stepLat, stepLng], cells: ordered.map(c => [c.row, c.col]) }); }

  // each point's first 20, and the store's own rank field beside its place in the list
  const long = [], rankOff = [];
  const lists = ordered.map((c, gi) => {
    const all = Array.isArray(c.top) ? c.top : [], t20 = all.slice(0, TOP);
    if (new Set(t20).size !== t20.length) die(`sweep ${id}: the point at row ${c.row}, column ${c.col} lists one business twice`);
    if (all.length > TOP) long.push({ i: gi, row: c.row, col: c.col, listed: all.length });
    const field = c.rank === null || c.rank === undefined ? 0 : Number(c.rank), inList = all.indexOf(SUBJECT) + 1;
    if (field !== inList) rankOff.push({ i: gi, row: c.row, col: c.col, rank_field: field, in_list: inList });
    return { c, gi, all, t20 };
  });
  // the field: every business in some point's first 20, counted point by point. The store is always in it.
  const t3 = new Map(), found = new Map(), sum = new Map(), best = new Map();
  for (const L of lists) L.t20.forEach((pid, k) => { found.set(pid, (found.get(pid) || 0) + 1); sum.set(pid, (sum.get(pid) || 0) + k + 1); if (k < 3) t3.set(pid, (t3.get(pid) || 0) + 1); if (!best.has(pid) || k + 1 < best.get(pid)) best.set(pid, k + 1); });
  const pids = [...new Set([SUBJECT, ...found.keys()])];
  const disagree = { appearances: [], best_rank: [], arp: [] }, deep = [];
  for (const pid of pids) {
    const row = rows[pid]; if (!row) die(`sweep ${id}: a point lists ${pid}, which the sweep's own list of businesses does not`);
    const top3 = t3.get(pid) || 0, f = found.get(pid) || 0;
    if (row.top3_appearances !== null && row.top3_appearances !== undefined && Number(row.top3_appearances) !== top3) die(`sweep ${id}: ${row.name} is in the top 3 at ${top3} points, SEOS says ${row.top3_appearances}`);
    if (row.solv !== null && row.solv !== undefined && Math.abs(Number(row.solv) - r2(top3 * 100 / n)) > 0.006) die(`sweep ${id}: ${row.name} holds ${top3} of ${n} points (${r2(top3 * 100 / n)}%), SEOS states ${row.solv}%`);
    if (row.appearances !== null && row.appearances !== undefined && Number(row.appearances) !== f) {
      const whole = lists.filter(L => L.all.includes(pid)).length;
      disagree.appearances.push({ pid, name: row.name, seos: Number(row.appearances), first_20: f, whole_list: whole, explained: Number(row.appearances) === whole });
    }
    if (row.best_rank !== null && row.best_rank !== undefined && Number(row.best_rank) !== (best.get(pid) || null)) disagree.best_rank.push({ pid, seos: Number(row.best_rank), first_20: best.get(pid) || null });
    const avg = f ? r2(sum.get(pid) / f) : null;
    if (row.arp !== null && row.arp !== undefined && avg !== null && Math.abs(Number(row.arp) - avg) > 0.006) disagree.arp.push({ pid, seos: Number(row.arp), first_20: avg });
    if (!row.address && looksLikeStreet(row.category)) seosRowsAddrInCat.add(pid);
  }
  // the store's own figures in the sweep's header
  const meT3 = t3.get(SUBJECT) || 0, meF = found.get(SUBJECT) || 0;
  if (Math.abs(Number(S.solv) - r2(meT3 * 100 / n)) > 0.006) die(`sweep ${id}: the store holds ${meT3} of ${n} points, the sweep's header says ${S.solv}%`);
  if (num(S.found_points) !== null && Number(S.found_points) !== meF) die(`sweep ${id}: the store is listed at ${meF} points, the sweep's header says ${S.found_points}`);
  const meAvg = meF ? r2(sum.get(SUBJECT) / meF) : null;
  if (num(S.arp) !== null && meAvg !== null && Math.abs(Number(S.arp) - meAvg) > 0.006) disagree.arp.push({ pid: SUBJECT, seos: Number(S.arp), first_20: meAvg, from: 'header' });
  // businesses SEOS lists for the sweep that are in no point's first 20: they show up only past 20 in a longer list
  for (const [pid, row] of Object.entries(rows)) if (!found.has(pid) && pid !== SUBJECT) {
    const at = lists.map(L => [L.gi, L.all.indexOf(pid) + 1]).filter(x => x[1] > 0);
    deep.push({ pid, name: row.name, at, km: r1(km(STORE, [Number(row.lat), Number(row.lng)])) });
    if (!row.address && looksLikeStreet(row.category)) seosRowsAddrInCat.add(pid);
  }
  for (const pid of pids) { const prev = latest[pid]; if (!prev || toMs(S.finished_at) >= prev.t) latest[pid] = { t: toMs(S.finished_at), row: rows[pid] }; }

  // the ratings beside each business are SEOS's, read with the sweep; the store's own row leaves them out, so its
  // come from its Google listing as read (source.notes says when)
  const field = pids.map(pid => {
    const row = rows[pid], mine = pid === SUBJECT;
    const rating = mine ? (row.rating ?? (myBI ? num(myBI.it.rating && myBI.it.rating.value) : null)) : num(row.rating);
    const reviews = mine ? (row.reviews ?? (myBI ? num(myBI.it.rating && myBI.it.rating.votes_count) : null)) : num(row.reviews);
    return { pid, top3: t3.get(pid) || 0, found: found.get(pid) || 0, avg: (found.get(pid) ? r2(sum.get(pid) / found.get(pid)) : null), rating, reviews, name: row.name };
  }).sort((x, y) => y.top3 - x.top3 || y.found - x.found || (x.avg ?? 99) - (y.avg ?? 99) || String(x.name).localeCompare(String(y.name)) || x.pid.localeCompare(y.pid));
  for (const x of field) x.b = addBiz(x.pid);     // businesses are numbered in the order the sweeps rank them
  if (field.length > ALPHABET.length) die(`sweep ${id}: ${field.length} businesses, more than the ${ALPHABET.length} characters that can name them`);
  const at = Object.fromEntries(field.map((x, i) => [x.pid, i])), you = at[SUBJECT];
  const res = lists.map(L => L.t20.map(pid => ALPHABET[at[pid]]).join(''));
  // the store's rank as drawn is its place in each point's first 20; the rank field must say the same
  if (!lists.every((L, i) => res[i].indexOf(ALPHABET[you]) + 1 === (L.t20.indexOf(SUBJECT) + 1))) die(`sweep ${id}: the store's rank does not survive the encoding`);

  const ts = sec(S.finished_at), actors = actorsBy[id] || [], actor = actors.length === 1 ? actors[0] : null;
  if (actors.length > 1) notes.push(`sweep ${id}: ${actors.length} people are recorded as starting it; the first is not assumed`);
  const started = actor ? sec(actor.at) : null;
  if (started !== null && started > ts) die(`sweep ${id}: it is recorded as starting after it finished`);
  const openStart = started === null ? null : openAt(started), openEnd = openAt(ts);
  const p = parts(ts);
  scans.push({ key: 'seos-' + id, kw, ts, day: dayKey(ts), when: `${p.weekday}, ${p.month} ${p.day}, ${p.year}, ${p.hour}:${p.minute} ${p.dayPeriod}`, mins: clock(ts).m, geom: geomAt.get(gKey), n, full: true,
    field: field.map(x => [x.b, x.top3, x.found, x.avg, x.rating, x.reviews]), you, place: 1 + field.filter(x => x.top3 > field[you].top3).length, tied: field.filter(x => x.top3 === field[you].top3).length > 1, res, own: null,
    // what a reader needs before quoting this sweep: when it ran against the store's posted hours, how it was
    // started, the points left out, and what SEOS's own fields say that the points do not
    seos: { scan_id: id, from: sw.from, started_how: S.started_how ?? null, started, started_when: started === null ? null : whenOf(started), started_by_role: actor ? actor.role || null : null, by_person: actor ? !!actor.username : null,
      finished: ts, read_at: S.read_at ? sec(S.read_at) : null, hours_that_day: hoursOn(ts), open_at_start: openStart, open_at_finish: openEnd, in_hours: openEnd === null ? null : (openStart !== false && openEnd === true),
      exclusion_note: S.exclusion_note ?? null, excluded, points_kept: n, grid_points: N * N,
      long_lists: long, rank_field_disagrees: rankOff,
      centre_stated: [num(CR.centre_lat), num(CR.centre_lng)], centre_stated_off_m: Math.round(km([cLat, cLng], [Number(CR.centre_lat), Number(CR.centre_lng)]) * 1000),
      stated: { solv: num(S.solv), found_points: num(S.found_points), arp: num(S.arp), atrp: num(S.atrp) },
      disagree: { appearances: { n: disagree.appearances.length, explained: disagree.appearances.filter(x => x.explained).length, why: disagree.appearances.length ? `SEOS counts a business at a point when it is anywhere in that point's list. ${long.length === 1 ? 'One point keeps' : long.length + ' points keep'} more than ${TOP} (${long.map(l => `row ${l.row}, column ${l.col}: ${l.listed}`).join('; ')}), so a business listed there past ${TOP} counts once more in SEOS than in the first ${TOP}.` : null, rows: disagree.appearances.filter(x => !x.explained) },
        best_rank: disagree.best_rank, arp: disagree.arp },
      deep: { n: deep.length, rows: deep.map(d => [d.pid, d.name, Math.min(...d.at.map(x => x[1])), d.km]) } } });
}
if (!scans.length) die('no sweep of this store could be read');
scans.sort((a, b) => a.kw.localeCompare(b.kw) || a.ts - b.ts);

// ---------- the businesses: as each sweep named them, with the Google listing where it is richer ----------
const TOWN = String(loc.city || '').trim();
const KIND = [' Weed', ' Cannabis', ' Dispensary', ' Marijuana', ' Recreational', ' Provisioning'];
const reTown = TOWN ? new RegExp('[\\s-]+(of\\s+)?' + TOWN.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$', 'i') : null;
const noTown = s => (reTown ? s.replace(reTown, '') : s).trim();
const brandOf = name => { let x = noTown(String(name).split(' - ')[0].trim()); for (const w of KIND) { const i = x.indexOf(w); if (i >= 3) x = x.slice(0, i); } return noTown(x) || String(name); };
for (const b of biz) {
  const row = latest[b.pid] && latest[b.pid].row, bi = BI[b.pid] ? BI[b.pid].it : null, mine = b.pid === SUBJECT;
  // the store is named the way its Google listing names it; SEOS's own row for it carries the register name
  b.name = String(mine ? (bi && bi.title) || loc.name || row.name : (row && row.name) || (bi && bi.title));
  b.lat = mine ? STORE[0] : num(row && row.lat) ?? num(bi && bi.latitude);
  b.lng = mine ? STORE[1] : num(row && row.lng) ?? num(bi && bi.longitude);
  b.site = bi ? (bi.domain ? String(bi.domain).replace(/^www\./, '') : host(bi.url || '')) : null;
  b.cat = bi && Array.isArray(bi.category_ids) && bi.category_ids.length ? bi.category_ids[0] : null;
  b.cat_name = bi ? (bi.category || null) : (row && row.category && !looksLikeStreet(row.category) ? row.category : null);
  b.claimed = bi ? bi.is_claimed === true : null;
  b.lands = bi && bi.url ? landsOn(bi.url) : null;
  const regName = String(register.name || loc.name || '').trim();
  b.short = mine && regName && b.name.toLowerCase().startsWith(regName.toLowerCase()) ? regName : brandOf(b.name);
  b.km = b.lat === null || b.lng === null ? null : r1(km(STORE, [b.lat, b.lng]));
}
// two with the same brand: their full names, then the street, then a number
{ const street = b => { const row = latest[b.pid] && latest[b.pid].row; const s = row && (row.address || (looksLikeStreet(row.category) ? row.category : null)); return s ? String(s) : null; };
  const groups = {}; biz.forEach((b, i) => (groups[b.short.toLowerCase()] ||= []).push(i));
  for (const ids of Object.values(groups)) if (ids.length > 1) {
    const full = ids.map(i => biz[i].name);
    if (new Set(full.map(x => x.toLowerCase())).size === ids.length) { ids.forEach(i => { biz[i].short = biz[i].name; }); continue; }
    ids.forEach(i => { const s = street(biz[i]); biz[i].short = s ? `${biz[i].name}, ${s}` : biz[i].name; });
    const again = {}; ids.forEach(i => (again[biz[i].short.toLowerCase()] ||= []).push(i));
    for (const same of Object.values(again)) same.forEach((i, k) => { if (k > 0) biz[i].short = `${biz[i].short} (${k + 1})`; });
  }
  if (new Set(biz.map(b => b.short.toLowerCase())).size !== biz.length) die('two businesses still share a short name'); }

// ---------- out of market: how far each business sits from the store ----------
const FAR_MI = Number(opt('far-mi') || 150), FAR_KM = FAR_MI * KM_PER_MI;
for (const b of biz) b.far = b.km === null ? null : b.km > FAR_KM;
const allKm = [];                                  // every business any read sweep lists, near or far, once
{ const once = new Set(); for (const sw of sweeps) for (const [pid, row] of Object.entries(rowsBy[sw.id] || {})) if (!once.has(pid)) { once.add(pid); const d = pid === SUBJECT ? 0 : km(STORE, [Number(row.lat), Number(row.lng)]); allKm.push({ pid, d }); } }
const inside = allKm.filter(x => x.d <= FAR_KM).map(x => x.d), outside = allKm.filter(x => x.d > FAR_KM).map(x => x.d);
const farB = biz.map((b, i) => (b.far ? i : -1)).filter(i => i >= 0);
const far = { cutoff_mi: FAR_MI, cutoff_km: r1(FAR_KM),
  farthest_inside_km: inside.length ? r1(Math.max(...inside)) : null, nearest_outside_km: outside.length ? r1(Math.min(...outside)) : null, listed_outside: outside.length, listed_inside: inside.length,
  why: `${FAR_MI} miles is the line the template's own check draws between this market and another area's results (extract.mjs, check scan-market).` +
    (inside.length && outside.length ? ` Here no business the sweeps list sits between ${r1(Math.max(...inside))} km and ${r1(Math.min(...outside))} km from the store, so any line in that span marks the same ${outside.length} of ${allKm.length}.` : outside.length ? '' : ` No business the sweeps list sits past it.`),
  businesses: farB,
  cluster: farB.length ? { centre: [r2(farB.reduce((s, i) => s + biz[i].lat, 0) / farB.length), r2(farB.reduce((s, i) => s + biz[i].lng, 0) / farB.length)], km: [r1(Math.min(...farB.map(i => biz[i].km))), r1(Math.max(...farB.map(i => biz[i].km)))] } : null,
  scans: scans.map(s => { const A = ALPHABET, farLocal = new Set(s.field.map((f, i) => (biz[f[0]].far ? i : -1)).filter(i => i >= 0)); const g = geoms[s.geom];
    const pts = s.res.map((r, gi) => { const ks = r.split('').map((ch, k) => (farLocal.has(A.indexOf(ch)) ? k + 1 : 0)).filter(Boolean); return ks.length ? [gi, g.cells[gi][0], g.cells[gi][1], ks.length, Math.min(...ks)] : null; }).filter(Boolean);
    const sw = sweeps.find(x => 'seos-' + x.id === s.key), listedFar = Object.entries(rowsBy[sw.id] || {}).filter(([pid, row]) => pid !== SUBJECT && km(STORE, [Number(row.lat), Number(row.lng)]) > FAR_KM).length;
    return { key: s.key, field: farLocal.size, listed: listedFar, deep_only: listedFar - farLocal.size, points: pts, top3: pts.filter(p => p[4] <= 3).length, best: pts.length ? Math.min(...pts.map(p => p[4])) : null }; }) };

// ---------- review velocity, from each business's dated Google reviews ----------
// One reading per business, newest first. A reading that stopped at its collection limit holds only the newest
// reviews, so a window that starts before its oldest review is not measured. A pace is reviews in the window a
// month (30.44 days), as SEOS's own snapshots and the HS block count it.
const WINDOWS = [30, 90, 365], MAIN = 90;
const vRows = [], vLeft = [];
for (const r of readings.filter(x => x.kind === 'reviews')) {
  const pid = r.place_id, b = bizAt.has(pid) ? bizAt.get(pid) : -1, R = r.result && r.result.reviews, P = (r.result && r.result.pull) || {};
  const name = b >= 0 ? biz[b].short : pid;
  if (!R || !Array.isArray(R.items)) { vLeft.push({ pid, name, why: 'the reading holds no reviews: could not be read' }); continue; }
  if (b < 0) { vLeft.push({ pid, name, why: "not in any sweep's first 20" }); continue; }
  if (biz[b].far) { vLeft.push({ pid, b, name, why: `out of this market: ${biz[b].km} km from the store`, read: dayKey(sec(R.collected_at || r.fetched_at)) }); continue; }
  const end = toMs(R.collected_at || r.fetched_at), stamps = R.items.map(x => toMs(x.timestamp));
  if (!Number.isFinite(end) || stamps.some(x => !Number.isFinite(x))) { vLeft.push({ pid, b, name, why: 'a review or the reading has no readable date' }); continue; }
  const depth = num(P.depth), limited = R.capped === true || (depth !== null && R.items.length >= depth), oldest = Math.min(...stamps);
  const win = WINDOWS.map(days => { const start = end - days * 864e5, measured = !limited || start >= oldest, k = stamps.filter(t => t > start && t <= end).length;
    return { days, measured, n: measured ? k : null, per_month: measured ? r1(k / days * 30.44) : null, from: Math.floor(start / 1000) }; });
  const m = win.find(w => w.days === MAIN);
  if (!m.measured) { vLeft.push({ pid, b, name, why: `the reading stops at its collection limit (${R.items.length} reviews, the oldest ${dayKey(oldest / 1000)}), after the ${MAIN}-day window starts` }); continue; }
  const bi = BI[pid] ? BI[pid].it : null;
  vRows.push({ b, first: m.from, last: Math.floor(end / 1000), days: MAIN, from: null, to: bi ? num(bi.rating && bi.rating.votes_count) : null, gained: m.n, per_month: m.per_month, drops: null,
    built_from: 'reviews', read: dayKey(end / 1000), collected: R.items.length, limited, oldest: dayKey(oldest / 1000), windows: win.map(w => ({ days: w.days, measured: w.measured, n: w.n, per_month: w.per_month })) });
}
vRows.sort((x, y) => y.per_month - x.per_month || x.b - y.b);
// SEOS keeps its own snapshots of the store's pace: they are a second reading of the same reviews
const snaps = (T.review_velocity_snapshots || []).filter(s => s.place_id === SUBJECT);
const meV = vRows.find(x => x.b === 0);
const seosCheck = snaps.map(s => { const w = meV && meV.windows.find(x => x.days === Number(s.window_days)); return { days: Number(s.window_days), seos: Number(s.reviews_in_window), ours: w ? w.n : null, agree: !!w && w.n === Number(s.reviews_in_window) }; });
const velocity = vRows.length ? { built_from: 'dated Google reviews: the reviews readings in the full audit, one per business, newest first. Not the ratings counts at map checks (the HS block\'s source): SEOS has one day of sweeps for this store.',
  window_days: MAIN, window_why: `SEOS's own snapshots count 30, 90 and 365 days. ${MAIN} days is the middle one: long enough not to swing on one busy week, short enough to show the pace now. Every row carries all three.`,
  live_from: dayKey(Math.min(...vRows.map(x => x.first))), to: dayKey(Math.max(...vRows.map(x => x.last))), stale_days: 0, rows: vRows, left_out: vLeft, seos_check: seosCheck } : null;

// ---------- the Google listings at the top of each sweep ----------
// the store, and every business in the top 10 of any sweep by points in the top 3 (a tie at 10th is kept)
const topSet = new Set([0]);
for (const s of scans) { const cut = s.field.length > 10 ? s.field[9][1] : -1; s.field.forEach((f, i) => { if (f[0] !== 0 && (i < 10 || f[1] === cut) && f[1] > 0) topSet.add(f[0]); }); }
const lRows = [], lMissing = [];
for (const b of [...topSet].sort((x, y) => x - y)) {
  const rec = BI[biz[b].pid]; if (!rec) { lMissing.push(biz[b].short); continue; }
  const it = rec.it, avail = (it.attributes && it.attributes.available_attributes) || {};
  lRows.push({ b, name: String(it.title), rating: num(it.rating && it.rating.value), reviews: num(it.rating && it.rating.votes_count), photos: num(it.total_photos), claimed: it.is_claimed === true ? true : it.is_claimed === false ? false : null,
    category: it.category || null, extra_categories: it.additional_categories || [], ways: (avail.service_options || []).length, attributes: Object.values(avail).reduce((s2, l) => s2 + (Array.isArray(l) ? l.length : 0), 0),
    lands: it.url ? landsOn(it.url) : null, read: dayKey(rec.at) });
}
const readDays = [...new Set(lRows.map(r => r.read))].sort();
const listings = lRows.length ? { read: readDays[readDays.length - 1], read_from: readDays[0], rule: 'the store, and every business in the top 10 of any sweep by points in the top 3 (a tie at 10th is kept)', rows: lRows, not_read: lMissing } : null;

// ---------- directory listings: SEOS's own verdicts ----------
const cv = (T.citation_verdicts || []);
const dirsFor = pid => { const rows = cv.filter(r => r.place_id === pid); if (!rows.length) return null; const c = v => rows.filter(r => r.verdict === v).length;
  return { confirmed: c('listed'), not_listed: c('not-listed'), unknown: c('undetermined'), other: rows.length - c('listed') - c('not-listed') - c('undetermined'), sources: rows.length,
    nap_correct: rows.filter(r => r.verdict === 'listed' && r.nap_status === 'nap-correct').length, nap_incomplete: rows.filter(r => r.verdict === 'listed' && r.nap_status === 'nap-incomplete').length, contested: rows.filter(r => r.contested === true).length,
    read: dayKey(Math.max(...rows.map(r => sec(r.computed_at)))) }; };
const dRows = biz.map((x, b) => { const d = dirsFor(x.pid); return d ? { b, slug: b === 0 ? register.brand_slug || null : null, ...d } : null; }).filter(Boolean);
const rivalReads = readings.filter(r => /^cit_/.test(r.kind) && r.place_id !== SUBJECT).map(r => r.place_id);
const directories = dRows.length ? { read: dRows.find(r => r.b === 0)?.read || dRows[0].read, built_from: "SEOS citation_verdicts: listed = confirmed, not-listed = not listed, undetermined = could not be read",
  rows: dRows.map(({ read, ...r }) => r),
  rivals: dRows.some(r => r.b !== 0) ? null : `No verdict rows for any rival in the business data. The full audit holds raw directory searches (${[...new Set(readings.filter(r => /^cit_/.test(r.kind) && r.place_id !== SUBJECT).map(r => r.kind))].join(', ')}) for ${new Set(rivalReads).size} other businesses; those are searches, not verdicts, and are not turned into counts here.` } : null;
if (directories && !directories.rows.some(r => r.b === 0)) die('the directory verdicts do not cover the store');

// ---------- what was read, and what was not ----------
let allSweeps = null;
if (opt('all-sweeps')) {
  const j = readJson(opt('all-sweeps'), 'every SEOS sweep'), rows = j.rows || j;
  const complete = j.total === undefined || Number(j.total) === rows.length;
  const mineAll = rows.filter(r => r.subject === SUBJECT);
  allSweeps = { total: rows.length, complete, of_this_store: mineAll.map(r => String(r.scan_id)), not_read: mineAll.filter(r => !sweeps.some(x => x.id === String(r.scan_id))).map(r => ({ scan_id: String(r.scan_id), kw: r.keyword, finished: r.finished_at })) };
  if (!complete) notes.push(`SEOS's list of sweeps says ${j.total} and holds ${rows.length}: an absence in it is not proof`);
}
const wanted = (opt('want') || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);
const missing = wanted.filter(w => !scans.some(s => s.kw === w)).map(w => ({ kw: w, why: allSweeps ? (allSweeps.complete ? `no sweep of this store for it: none in the business data, none among the ${allSweeps.total} sweeps SEOS lists` : `no sweep of this store for it in what was read; SEOS's list of sweeps is incomplete, so this is not proof there is none`) : 'no sweep of this store for it in the business data or the extra files' }));
for (const s of scans) if (s.seos.rank_field_disagrees.length) notes.push(`${s.key}: the store's rank field and its place in the list disagree at ${s.seos.rank_field_disagrees.length} points`);
notes.push("Times in the record without a zone are read as UTC: sweep 352's start (its actor row) then falls 7 minutes before its stated finish, which carries +00:00; read any other way it would start after it finished.");
if (myBI) notes.push(`The store's stars and ratings count in each sweep's field come from its Google listing as read ${whenOf(myBI.at)}: SEOS's sweep row for the store leaves them empty.`);
if (seosRowsAddrInCat.size) notes.push(`${seosRowsAddrInCat.size} of SEOS's sweep rows carry a street address in the category column and no address: ${[...seosRowsAddrInCat].map(pid => (latest[pid] && latest[pid].row && latest[pid].row.name) || (bizAt.has(pid) ? biz[bizAt.get(pid)].name : pid)).join(', ')}. The category is taken as not known there.`);

const digest = crypto.createHash('sha256'); for (const f of inputs) digest.update(f.file + ':' + f.sha256 + '\n');
const out = { subject: 0, tz: TZ, alphabet: ALPHABET, velocity, directories,
  source: { built_by: 'sweeps-market.mjs', reports: scans.length, sweeps: scans.map(s => ({ key: s.key, scan_id: s.seos.scan_id, kw: s.kw, from: s.seos.from })), skipped, first: Math.min(...scans.map(s => s.ts)), last: Math.max(...scans.map(s => s.ts)),
    sha256: digest.digest('hex'), inputs, top: TOP, all_sweeps: allSweeps, missing, notes },
  biz, geoms, scans, listings, far };
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(out));

// ---------- what was written ----------
console.log(`wrote ${path.basename(outPath)} (${fs.statSync(outPath).size.toLocaleString('en-US')} bytes): ${scans.length} sweeps, ${biz.length} businesses, ${geoms.length} point layouts, alphabet of ${ALPHABET.length}`);
for (const s of scans) { const me = s.field[s.you], top = s.field[0], own = s.res.map(r => r.indexOf(ALPHABET[s.you]) + 1), band = (lo, hi) => own.filter(v => v >= lo && v <= hi).length;
  console.log(`  ${s.key} "${s.kw}" ${s.when} | ${s.n} of ${s.seos.grid_points} points (${s.seos.excluded.length} excluded) | you top 3 at ${me[1]}, place ${s.place}${s.tied ? ' (tied)' : ''} of ${s.field.length} | 1-3: ${band(1, 3)}, 4-10: ${band(4, 10)}, 11-20: ${band(11, 20)}, not in the first 20: ${own.filter(v => v === 0).length} | number 1 ${biz[top[0]].short} ${top[1]} | in hours: ${s.seos.in_hours} (${s.seos.hours_that_day})`);
  console.log(`      SEOS appearances differ for ${s.seos.disagree.appearances.n} (${s.seos.disagree.appearances.explained} explained by the long list), best rank ${s.seos.disagree.best_rank.length}, arp ${s.seos.disagree.arp.length}; rank field off at ${s.seos.rank_field_disagrees.length} points; deep-only ${s.seos.deep.n}; stated centre off by ${s.seos.centre_stated_off_m} m`); }
console.log(`  out of market: past ${FAR_MI} mi (${r1(FAR_KM)} km): ${farB.length} in the fields, ${outside.length} of ${allKm.length} listed; nothing between ${far.farthest_inside_km} and ${far.nearest_outside_km} km`);
for (const f of far.scans) console.log(`      ${f.key}: ${f.field} far in the field (${f.listed} listed, ${f.deep_only} only past 20), at ${f.points.length} points, best far rank ${f.best}, far in a top 3: ${f.top3}`);
if (velocity) for (const r of velocity.rows) console.log(`  velocity ${biz[r.b].short}: ${r.per_month} a month (${r.gained} in ${r.days} days) | ${r.windows.map(w => `${w.days}d ${w.measured ? w.n + ' = ' + w.per_month : 'not measured'}`).join(', ')} | ${r.collected} read${r.limited ? ', stopped at a limit' : ''}, oldest ${r.oldest}`);
if (velocity) for (const r of velocity.left_out) console.log(`  velocity left out ${r.name}: ${r.why}`);
if (velocity) console.log(`  SEOS snapshot check: ${velocity.seos_check.map(c => `${c.days}d ${c.seos} vs ${c.ours} ${c.agree ? 'ok' : 'DIFFERENT'}`).join(', ')}`);
if (listings) console.log(`  listings: ${listings.rows.length} read ${listings.read_from} to ${listings.read}${listings.not_read.length ? `, not read: ${listings.not_read.join(', ')}` : ''}`);
if (directories) console.log(`  directories: ${directories.rows.map(r => `${biz[r.b].short} ${r.confirmed} listed, ${r.not_listed} not, ${r.unknown} could not be read`).join('; ')}`);
for (const m of missing) console.log(`  MISSING "${m.kw}": ${m.why}`);
for (const [f, why] of skipped) console.log(`  left out ${f}: ${why}`);
for (const n2 of notes) console.log(`  note: ${n2}`);
