// ee-scan-to-seos.mjs: one Eagle Eyes scan export (the JSON the Eagle Eyes scan page saves) -> the same rows SEOS keeps
// for a sweep ({engine_sweeps, engine_sweep_cells, engine_sweep_businesses, engine_sweep_fields, engine_actors}), so
// sweeps-market.mjs --extra can take a scan that SEOS has not copied in yet. Nothing is estimated: every share, rank and
// count is computed from the export's own point results, and the export's own metrics must agree or the run stops.
// A scan where the store is found at no point is kept as a real result (Eagle Eyes marks it "failed: no point named this
// business" but still stores every point's listings); a scan whose points errored is refused.
// usage: node ee-scan-to-seos.mjs <eagleeyes-scan.json> <store place id> <out.json>
import fs from 'node:fs';

const [src, STORE, out] = process.argv.slice(2);
if (!src || !STORE || !out) { console.error('usage: node ee-scan-to-seos.mjs <eagleeyes-scan.json> <store place id> <out.json>'); process.exit(2); }
const die = m => { console.error('EE CONVERT FAILED: ' + m); process.exit(1); };
const j = JSON.parse(fs.readFileSync(src, 'utf8'));
const rq = j.request || die('no request block');
const pts = j.results || die('no results');
const M = j.metrics || {};
if (rq.place_id !== STORE) die(`the scan is about ${rq.place_id}, not ${STORE}`);
const errored = pts.filter(p => p.error);
if (errored.length) die(`${errored.length} of ${pts.length} points errored (a blocked or broken scan is not a result)`);
if (j.status === 'failed' && !/no point named this business/i.test(String(j.error || ''))) die('the scan failed for another reason: ' + j.error);
const excluded = new Set((rq.excluded_points || []).map(Number));
const live = pts.filter(p => !excluded.has(p.index));
const N = live.length;

const r2 = x => x === null ? null : Math.round(x * 100) / 100;
const km = (a, b) => { const R = 6371, t = Math.PI / 180, dLat = (b[0] - a[0]) * t, dLng = (b[1] - a[1]) * t;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a[0] * t) * Math.cos(b[0] * t) * Math.sin(dLng / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
const centre = [rq.center_lat, rq.center_lng];

// every business seen at any point, with its place at each point (positions as the export lists them, 1 = top)
const seen = new Map();
for (const p of live) {
  p.listings.forEach((l, k) => {
    const pos = l.position ?? k + 1;
    if (pos !== k + 1) die(`point ${p.index}: listing ${k} says position ${pos}`);
    const b = seen.get(l.place_id) || { place_id: l.place_id, name: l.name, address: l.address, category: l.category, rating: l.rating, reviews: l.reviews, lat: l.lat, lng: l.lng, ranks: new Map() };
    if (!b.ranks.has(p.index)) b.ranks.set(p.index, pos);
    for (const f of ['name', 'address', 'category', 'rating', 'reviews', 'lat', 'lng']) if (b[f] == null && l[f] != null) b[f] = l[f];
    seen.set(l.place_id, b);
  });
}
// the store's rank at each point: its position in that point's list, or none
const storeRank = p => { const k = p.listings.findIndex(l => l.place_id === STORE); return k < 0 ? null : k + 1; };
for (const p of live) if ((p.rank ?? null) !== storeRank(p)) die(`point ${p.index}: the export's rank ${p.rank} disagrees with the store's place in its own list (${storeRank(p)})`);

const stats = ranks => {        // ranks: Map point index -> position; only positions 1..20 count, as the export's metrics do
  const inTop = [...ranks.values()].filter(v => v <= 20), top3 = inTop.filter(v => v <= 3).length;
  const found = inTop.length, sum = inTop.reduce((s, v) => s + v, 0);
  return { appearances: ranks.size, found, top3, best: found ? Math.min(...inTop) : null, arp: found ? r2(sum / found) : null, atrp: r2((sum + 21 * (N - found)) / N), solv: r2(100 * top3 / N) };
};
const subj = stats(new Map(live.map(p => [p.index, storeRank(p)]).filter(([, v]) => v !== null)));
// the export's own metrics must agree with what its points say
const want = { found_points: subj.found, top3_points: subj.top3, solv: subj.solv, atrp: subj.atrp, arp: subj.arp, total_points: N };
for (const [k, v] of Object.entries(want)) if (M[k] !== undefined && M[k] !== null && Number(M[k]) !== Number(v)) die(`metrics.${k} is ${M[k]}, the points give ${v}`);
const listingsSeen = live.reduce((s, p) => s + p.listings.length, 0);
if (M.listings_seen !== undefined && M.listings_seen !== listingsSeen) die(`metrics.listings_seen is ${M.listings_seen}, the points hold ${listingsSeen}`);

const rows = [...seen.values()].filter(b => b.place_id !== STORE).map(b => ({ b, s: stats(b.ranks) }));
rows.sort((x, y) => y.s.solv - x.s.solv || (x.s.arp ?? 99) - (y.s.arp ?? 99) || x.b.name.localeCompare(y.b.name));
const solvRank = v => 1 + rows.filter(r => r.s.solv > v).length;
const scanId = String(j.id);
let rowId = 0;
const bizRows = [
  { id: `ee${scanId}-${rowId++}`, scan_id: scanId, place_id: STORE, is_subject: true, name: rq.business_name, address: null, category: null, rating: null, reviews: null,
    solv: subj.solv, arp: subj.arp, atrp: subj.atrp, appearances: null, top3_appearances: null, best_rank: null, rank_solv: solvRank(subj.solv), lat: centre[0], lng: centre[1], distance_km: 0 },
  ...rows.map(({ b, s }) => ({ id: `ee${scanId}-${rowId++}`, scan_id: scanId, place_id: b.place_id, is_subject: false, name: b.name, address: b.address ?? null, category: b.category ?? null,
    rating: b.rating ?? null, reviews: b.reviews ?? null, solv: s.solv, arp: s.arp, atrp: s.atrp, appearances: s.appearances, top3_appearances: s.top3, best_rank: s.best,
    rank_solv: solvRank(s.solv), lat: b.lat ?? null, lng: b.lng ?? null, distance_km: b.lat != null ? km(centre, [b.lat, b.lng]) : null })),
];
const readAt = fs.statSync(src).mtime.toISOString();
const result = {
  source: { file: src.split(/[\\/]/).pop(), eagle_eyes_scan: j.id, status: j.status, error: j.error, created_at: j.created_at, finished_at: j.finished_at,
    business_name: rq.business_name, keyword_as_typed: rq.keyword, feed_depth: rq.feed_depth, zoom: rq.zoom, vantage: rq.vantage?.label ?? null, listings_seen: listingsSeen },
  engine_sweeps: [{ scan_id: scanId, subject: STORE, keyword: String(rq.keyword).trim().toLowerCase(), grid_size: rq.grid_size, radius: rq.radius, unit: rq.unit,
    total_points: N, found_points: subj.found, arp: subj.arp, atrp: subj.atrp, solv: subj.solv,
    exclusion_note: excluded.size ? `${excluded.size} of the ${pts.length} grid points were excluded before this sweep ran, so every figure here is measured over the remaining ${N}.` : null,
    started_how: rq.feed_depth === 'centre_whole' ? 'whole_feed' : rq.feed_depth ?? null, finished_at: j.finished_at, read_at: readAt }],
  engine_sweep_cells: [{ scan_id: scanId, centre_lat: centre[0], centre_lng: centre[1],
    cells: live.map(p => ({ i: p.index, row: p.row, col: p.col, lat: p.lat, lng: p.lng, rank: storeRank(p), top: p.listings.map(l => l.place_id) })), read_at: readAt }],
  engine_sweep_businesses: bizRows,
  engine_sweep_fields: [{ scan_id: scanId, subject: STORE, finished_at: j.finished_at, competitors: rows.map(r => r.b.place_id), read_at: readAt }],
  engine_actors: [],
};
fs.writeFileSync(out, JSON.stringify(result, null, 1));
const far = rows.filter(r => r.b.lat != null && km(centre, [r.b.lat, r.b.lng]) > 40);
console.log(`scan #${scanId} "${result.engine_sweeps[0].keyword}": ${N} points, store found at ${subj.found} (top 3 at ${subj.top3}), share ${subj.solv}, atrp ${subj.atrp}; ` +
  `${rows.length} other businesses, ${far.length} more than 40 km away; ${listingsSeen} listings read; the export's own metrics agree.`);
console.log('top of the map by top-3 points: ' + rows.slice(0, 6).map(r => `${r.b.name} ${r.s.top3}/${N}`).join(' | '));
