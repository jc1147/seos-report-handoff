// check-sweeps-market.mjs: a second reading of a market file built from SEOS's sweeps, written apart from
// sweeps-market.mjs and sharing no code with it. It goes back to the raw sweep rows and works everything out its own
// way: each point's list is decoded from the file and set beside SEOS's own list for that point, the store's rank
// comes from each point's rank field (not from its list), counts are taken business by business, distances use
// another formula. Any disagreement fails the check.
// usage: node check-sweeps-market.mjs <business-data.json> <market.json> [--extra=<file>[,<file>]] [--audit=<full-audit.json>]
//   --extra  the same extra sweep files the market file was built with
//   --audit  the full audit: then the store's Google name, review velocity and the listings are checked as well
import fs from 'node:fs';

const args = process.argv.slice(2);
const [bizFile, marketFile] = args.filter(a => !a.startsWith('--'));
const flag = k => { const hit = args.find(a => a.startsWith(`--${k}=`)); return hit ? hit.split('=').slice(1).join('=') : null; };
if (!bizFile || !marketFile) { console.error('usage: node check-sweeps-market.mjs <business-data.json> <market.json> [--extra=] [--audit=]'); process.exit(2); }
const load = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const M = load(marketFile), raw = load(bizFile).tables;
let bad = 0, checked = 0;
const fail = (what, detail) => { bad++; if (bad <= 40) console.log(`MISMATCH  ${what}${detail === undefined ? '' : '\n    ' + detail}`); };
const same = (what, got, want) => { checked++; if (JSON.stringify(got) !== JSON.stringify(want)) fail(what, `file: ${JSON.stringify(got)}  raw: ${JSON.stringify(want)}`); };
const ok = (what, cond, detail) => { checked++; if (!cond) fail(what, detail); };

// the raw rows, sweep by sweep, from the business data and any extra files
const SW = {}, CELLS = {}, ROWS = {};
const take = t => {
  for (const s of t.engine_sweeps || []) SW[String(s.scan_id)] = s;
  for (const c of t.engine_sweep_cells || []) CELLS[String(c.scan_id)] = c.cells;
  for (const b of t.engine_sweep_businesses || []) (ROWS[String(b.scan_id)] = ROWS[String(b.scan_id)] || []).push(b);
};
take(raw);
for (const f of (flag('extra') || '').split(',').filter(Boolean)) { const j = load(f); take(j.tables || j); }
const AUDIT = flag('audit') ? load(flag('audit')).tables.vendor_readings : null;

// ---------- the store ----------
const store = raw.locations[0], PID = store.place_id;
ok('the file is about this store', M.biz[M.subject] && M.biz[M.subject].pid === PID, `file: ${M.biz[M.subject] && M.biz[M.subject].pid}, business data: ${PID}`);
const ME = M.subject, A = M.alphabet;
ok('the alphabet names each business once', typeof A === 'string' && new Set(A.split('')).size === A.length && [...A].length === A.length);

// ---------- every sweep of this store is in the file, once ----------
const mine = Object.values(SW).filter(s => s.subject === PID).map(s => String(s.scan_id)).sort();
same('the sweeps in the file', M.scans.map(s => s.seos && s.seos.scan_id).sort(), mine);

// newest raw row per business, for names and places
const newest = {};
for (const id of mine) for (const r of ROWS[id] || []) { const t = Date.parse(SW[id].finished_at); if (!newest[r.place_id] || t >= newest[r.place_id].t) newest[r.place_id] = { t, r }; }

for (const s of M.scans) {
  const id = s.seos && s.seos.scan_id, S = SW[id], cells = CELLS[id];
  if (!S || !cells) { fail(`scan ${s.key}: no raw sweep ${id}`); continue; }
  const tag = `sweep ${id} "${S.keyword}"`;
  same(`${tag}: search`, s.kw, String(S.keyword).trim().toLowerCase());
  same(`${tag}: finished`, s.ts, Math.floor(new Date(String(S.finished_at)).getTime() / 1000));
  same(`${tag}: points`, s.n, cells.length);
  same(`${tag}: points SEOS states`, s.n, Number(S.total_points));
  // the drawn points are exactly the points SEOS measured: an excluded point is never drawn or counted
  const g = M.geoms[s.geom];
  if (!g) { fail(`${tag}: no point layout ${s.geom}`); continue; }
  same(`${tag}: points in the layout`, g.cells.length, cells.length);
  same(`${tag}: grid size`, g.size, Number(S.grid_size));
  const rawAt = new Map(cells.map(c => [`${c.row}/${c.col}`, c]));
  const drawn = g.cells.map(([r, c]) => `${r}/${c}`);
  ok(`${tag}: no point is drawn twice`, new Set(drawn).size === drawn.length);
  const extra = drawn.filter(k => !rawAt.has(k)); ok(`${tag}: every drawn point was measured`, !extra.length, `drawn but not measured: ${extra.join(' ')}`);
  const lost = [...rawAt.keys()].filter(k => !drawn.includes(k)); ok(`${tag}: every measured point is drawn`, !lost.length, `measured but not drawn: ${lost.join(' ')}`);
  const holes = []; for (let r = 0; r < g.size; r++) for (let c = 0; c < g.size; c++) if (!rawAt.has(`${r}/${c}`)) holes.push([r, c]);
  same(`${tag}: the points left out`, (s.seos.excluded || []).map(x => x.join('/')).sort(), holes.map(x => x.join('/')).sort());
  // each drawn point sits where SEOS measured it
  const half = (g.size - 1) / 2; let off = 0;
  g.cells.forEach(([r, c]) => { const q = rawAt.get(`${r}/${c}`); if (!q) return; const lat = g.centre[0] + (half - r) * g.step[0], lng = g.centre[1] + (c - half) * g.step[1]; if (Math.abs(lat - q.lat) > 1e-6 || Math.abs(lng - q.lng) > 1e-6) off++; });
  ok(`${tag}: every point sits where SEOS measured it`, off === 0, `${off} points are placed elsewhere`);

  // each point's list, decoded from the file, against SEOS's own first 20 there
  ok(`${tag}: one list per point`, Array.isArray(s.res) && s.res.length === g.cells.length);
  const pidOfLocal = s.field.map(f => (M.biz[f[0]] || {}).pid);
  let listsOff = 0, rankOff = 0; const rankBad = [];
  g.cells.forEach(([r, c], i) => {
    const q = rawAt.get(`${r}/${c}`); if (!q || !s.res || typeof s.res[i] !== 'string') return;
    const decoded = [...s.res[i]].map(ch => pidOfLocal[A.indexOf(ch)]), want = (q.top || []).slice(0, 20);
    if (JSON.stringify(decoded) !== JSON.stringify(want)) listsOff++;
    // the store's rank from the point's own rank field; past 20 counts as not in the first 20
    const field = q.rank === null || q.rank === undefined ? 0 : Number(q.rank), expect = field >= 1 && field <= 20 ? field : 0;
    const shown = s.res[i].indexOf(A[s.you]) + 1;
    if (shown !== expect) { rankOff++; rankBad.push(`row ${r} col ${c}: file ${shown}, rank field ${field}`); }
  });
  ok(`${tag}: every point lists the businesses SEOS listed there, in its order`, listsOff === 0, `${listsOff} points differ`);
  ok(`${tag}: the store's rank at every point`, rankOff === 0, rankBad.slice(0, 5).join('; '));

  // counts, business by business, straight from the raw points
  const inField = new Set(); for (const q of cells) for (const p of (q.top || []).slice(0, 20)) inField.add(p); inField.add(PID);
  same(`${tag}: the businesses in the field`, [...new Set(pidOfLocal)].sort(), [...inField].sort());
  ok(`${tag}: no business twice in the field`, new Set(pidOfLocal).size === pidOfLocal.length);
  const rowsById = Object.fromEntries((ROWS[id] || []).map(r => [r.place_id, r]));
  for (const [k, f] of s.field.entries()) {
    const p = pidOfLocal[k]; let top3 = 0, listed = 0, rankSum = 0;
    for (const q of cells) { const pos = (q.top || []).slice(0, 20).indexOf(p); if (pos < 0) continue; listed++; rankSum += pos + 1; if (pos <= 2) top3++; }
    same(`${tag}: ${M.biz[f[0]].short} points in the top 3`, f[1], top3);
    same(`${tag}: ${M.biz[f[0]].short} points listed`, f[2], listed);
    ok(`${tag}: ${M.biz[f[0]].short} average rank`, listed ? Math.abs(f[3] - rankSum / listed) < 0.006 : f[3] === null, `file ${f[3]}, raw ${listed ? rankSum / listed : null}`);
    const R = rowsById[p];
    ok(`${tag}: ${M.biz[f[0]].short} is in SEOS's list of businesses for the sweep`, !!R);
    if (R && R.solv !== null && R.solv !== undefined) ok(`${tag}: ${M.biz[f[0]].short} share against SEOS's stated share`, Math.abs(Number(R.solv) - 100 * f[1] / s.n) < 0.006, `file ${f[1]} of ${s.n} = ${(100 * f[1] / s.n).toFixed(3)}%, SEOS ${R.solv}%`);
    if (R && p !== PID) { same(`${tag}: ${M.biz[f[0]].short} stars`, f[4], R.rating === null ? null : Number(R.rating)); same(`${tag}: ${M.biz[f[0]].short} ratings`, f[5], R.reviews === null ? null : Number(R.reviews)); }
  }
  ok(`${tag}: the field runs from most points in the top 3 down`, s.field.every((f, k) => k === 0 || s.field[k - 1][1] >= f[1]));
  // the store: its row, its share against the sweep's header, its place
  ok(`${tag}: the store's row`, s.field[s.you] && s.field[s.you][0] === ME, `row ${s.you} is business ${s.field[s.you] && s.field[s.you][0]}`);
  const myTop3 = cells.filter(q => { const rk = q.rank === null || q.rank === undefined ? 0 : Number(q.rank); return rk >= 1 && rk <= 3; }).length;
  same(`${tag}: the store's points in the top 3, from the rank field`, s.field[s.you] && s.field[s.you][1], myTop3);
  ok(`${tag}: the store's share against the header`, Math.abs(Number(S.solv) - 100 * myTop3 / s.n) < 0.006, `header ${S.solv}%, rank field ${myTop3} of ${s.n}`);
  if (S.found_points !== null && S.found_points !== undefined) same(`${tag}: the store's points listed, from the rank field`, cells.filter(q => q.rank !== null && q.rank !== undefined && Number(q.rank) >= 1 && Number(q.rank) <= 20).length, Number(S.found_points));
  const tops = s.field.map(f => f[1]).sort((a, b) => b - a);
  same(`${tag}: the store's place`, s.place, tops.indexOf(myTop3) + 1);
  same(`${tag}: the store tied`, s.tied, tops.filter(v => v === myTop3).length > 1);
}

// ---------- names, places and distances ----------
const shorts = M.biz.map(b => String(b.short).toLowerCase());
ok('every short name is different', new Set(shorts).size === shorts.length);
const register = String((raw.businesses && raw.businesses[0] && raw.businesses[0].name) || store.name);
for (const [i, b] of M.biz.entries()) {
  if (b.pid === PID) {
    same("the store's short name is its register name", b.short, register);
    ok("the store's name begins with its register name", String(b.name).toLowerCase().startsWith(register.toLowerCase()), b.name);
    same("the store's place", [b.lat, b.lng], [Number(store.lat), Number(store.lng)]);
    continue;
  }
  const n = newest[b.pid];
  if (!n) { fail(`business ${i} (${b.short}) is in no sweep of this store`); continue; }
  same(`business ${i} name`, b.name, n.r.name);
  same(`business ${i} place`, [b.lat, b.lng], [Number(n.r.lat), Number(n.r.lng)]);
}
// the spherical law of cosines, not the haversine the builder uses
const cosKm = (a, b) => { const d = Math.PI / 180, x = Math.sin(a[0] * d) * Math.sin(b[0] * d) + Math.cos(a[0] * d) * Math.cos(b[0] * d) * Math.cos((b[1] - a[1]) * d); return 6371.0088 * Math.acos(Math.max(-1, Math.min(1, x))); };
const cutKm = M.far.cutoff_mi * 1.609344;
for (const [i, b] of M.biz.entries()) {
  const d = b.pid === PID ? 0 : cosKm([Number(store.lat), Number(store.lng)], [b.lat, b.lng]);
  ok(`business ${i} (${b.short}) distance from the store`, Math.abs(b.km - d) <= 0.15, `file ${b.km} km, worked out ${d.toFixed(2)} km`);
  same(`business ${i} (${b.short}) out of market`, b.far, d > cutKm);
}
same('the businesses out of market', [...M.far.businesses].sort((a, b) => a - b), M.biz.map((b, i) => (b.far ? i : -1)).filter(i => i >= 0));
for (const fs2 of M.far.scans) {
  const s = M.scans.find(x => x.key === fs2.key); if (!s) { fail(`out of market: no scan ${fs2.key}`); continue; }
  const cells = CELLS[s.seos.scan_id], farP = new Set(M.biz.filter(b => b.far).map(b => b.pid));
  let pts = 0, top3 = 0, best = null;
  for (const q of cells) { const pos = (q.top || []).slice(0, 20).map((p, k) => (farP.has(p) ? k + 1 : 0)).filter(Boolean); if (pos.length) { pts++; const lo = Math.min(...pos); if (lo <= 3) top3++; best = best === null ? lo : Math.min(best, lo); } }
  same(`${fs2.key}: points with a far business in the first 20`, fs2.points.length, pts);
  same(`${fs2.key}: points with a far business in the top 3`, fs2.top3, top3);
  same(`${fs2.key}: best rank of a far business`, fs2.best, best);
  const listedFar = (ROWS[s.seos.scan_id] || []).filter(r => r.place_id !== PID && cosKm([Number(store.lat), Number(store.lng)], [Number(r.lat), Number(r.lng)]) > cutKm).length;
  same(`${fs2.key}: far businesses SEOS lists`, fs2.listed, listedFar);
}

// ---------- with the full audit: the store's Google name, review velocity, the listings ----------
if (AUDIT) {
  const info = {}; for (const r of AUDIT) if (r.kind === 'business_info' && r.result && r.result.business_info && r.result.business_info.items && r.result.business_info.items[0]) info[r.place_id] = r.result.business_info.items[0];
  if (info[PID]) same("the store's name is its Google listing's", M.biz[ME].name, info[PID].title);
  // a review's date written "2026-10-10 23:37:24 +00:00", read field by field
  const stamp = s => { const m = /^(\d{4})-(\d\d)-(\d\d)[ T](\d\d):(\d\d):(\d\d)(?:\.\d+)?\s*(?:\+00:?00|Z)?$/.exec(String(s).trim()); return m ? Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]) : NaN; };
  const V = M.velocity;
  if (V) for (const row of V.rows) {
    const b = M.biz[row.b], rd = AUDIT.find(r => r.kind === 'reviews' && r.place_id === b.pid);
    if (!rd) { fail(`velocity ${b.short}: no reviews reading`); continue; }
    const items = rd.result.reviews.items, times = items.map(x => stamp(x.timestamp));
    ok(`velocity ${b.short}: every review date reads`, times.every(Number.isFinite));
    const capped = rd.result.reviews.capped === true || items.length >= Number(rd.result.pull && rd.result.pull.depth);
    const oldest = Math.min(...times);
    for (const w of row.windows) {
      const from = row.last * 1000 - w.days * 86400000, count = times.filter(t => t > from && t <= row.last * 1000).length, measurable = !capped || from >= oldest;
      same(`velocity ${b.short}: ${w.days}-day window measured`, w.measured, measurable);
      if (measurable) { same(`velocity ${b.short}: reviews in ${w.days} days`, w.n, count); same(`velocity ${b.short}: a month over ${w.days} days`, w.per_month, Math.round(count / w.days * 30.44 * 10) / 10); }
      else same(`velocity ${b.short}: no count past the collection limit (${w.days} days)`, [w.n, w.per_month], [null, null]);
    }
    const main = row.windows.find(w => w.days === row.days);
    same(`velocity ${b.short}: the pace shown`, [row.gained, row.per_month], [main.n, main.per_month]);
    ok(`velocity ${b.short}: not out of market`, !b.far);
  }
  for (const snap of (raw.review_velocity_snapshots || []).filter(x => x.place_id === PID)) {
    const me = V && V.rows.find(r => r.b === ME), w = me && me.windows.find(x => x.days === Number(snap.window_days));
    same(`velocity of the store against SEOS's own ${snap.window_days}-day snapshot`, w ? w.n : null, Number(snap.reviews_in_window));
  }
  if (M.listings) for (const L of M.listings.rows) {
    const it = info[M.biz[L.b].pid]; if (!it) { fail(`listing ${L.name}: no Google listing read`); continue; }
    same(`listing ${L.name}: stars, ratings, photos, claimed`, [L.rating, L.reviews, L.photos, L.claimed], [it.rating ? it.rating.value : null, it.rating ? it.rating.votes_count : null, it.total_photos, it.is_claimed]);
    const av = (it.attributes && it.attributes.available_attributes) || {};
    same(`listing ${L.name}: ways to shop, details`, [L.ways, L.attributes], [(av.service_options || []).length, [].concat(...Object.values(av)).length]);
  }
}
// directory verdicts, recounted
if (M.directories) for (const d of M.directories.rows) {
  const rows = (raw.citation_verdicts || []).filter(r => r.place_id === M.biz[d.b].pid);
  same(`directories ${M.biz[d.b].short}: listed / not listed / could not be read`, [d.confirmed, d.not_listed, d.unknown], ['listed', 'not-listed', 'undetermined'].map(v => rows.filter(r => r.verdict === v).length));
}

console.log(`${checked} checks, ${bad} disagreements`);
console.log(bad ? 'SWEEPS MARKET CHECK: FAIL' : 'SWEEPS MARKET CHECK: PASS');
process.exit(bad ? 1 : 0);
