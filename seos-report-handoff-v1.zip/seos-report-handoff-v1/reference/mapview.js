// mapview.js: draws a map check from the market file. One copy of this code runs twice: build-report.mjs uses it
// to put the first view into the page, and the page uses it again when someone picks another search, date or
// business. That way what is printed and what is redrawn can never disagree. Plain script, no imports.
// Every name that reaches the page is escaped here.
var MapView = (function () {
  'use strict';
  function esc(s) { return String(s == null ? '' : s).replace(/[‒–—―−]/g, '-').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function n(x) { return Number(x).toLocaleString('en-US'); }
  function ord(k) { return k + (k % 100 >= 11 && k % 100 <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][k % 10] || 'th'); }
  function pct(a, b) { return b ? Math.round(1000 * a / b) / 10 : 0; }
  var CELL = 40, DOT = 16;

  function make(M) {
    var A = M.alphabet, B = M.biz, S = M.scans, ME = M.subject;
    var byKey = {}; S.forEach(function (s, i) { byKey[s.key] = i; });
    // the searches on file, each with its checks oldest first; the ones checked more than once come first
    var kws = [];
    S.forEach(function (s, i) { var k = null; for (var j = 0; j < kws.length; j++) if (kws[j].kw === s.kw) k = kws[j]; if (!k) { k = { kw: s.kw, ids: [] }; kws.push(k); } k.ids.push(i); });
    kws.forEach(function (k) { k.ids.sort(function (a, b) { return S[a].ts - S[b].ts; }); k.last = k.ids[k.ids.length - 1]; });
    kws.sort(function (a, b) { return (b.ids.length > 1) - (a.ids.length > 1) || b.ids.length - a.ids.length || S[b.last].ts - S[a.last].ts || a.kw.localeCompare(b.kw); });
    function kwOf(kw) { for (var j = 0; j < kws.length; j++) if (kws[j].kw === kw) return kws[j]; return null; }
    function localOf(s, b) { for (var i = 0; i < s.field.length; i++) if (s.field[i][0] === b) return i; return -1; }
    // a business the market file flags far (another area's results, past the cut-off sweeps-market states) is left out
    // of every field size, place, picker and list. The ranks at each point stay as the scan tool returned them.
    function far(b) { return !!(B[b] && B[b].far); }
    function inField(s, i) { return !far(s.field[i][0]); }
    function size(s) { var k = 0; for (var i = 0; i < s.field.length; i++) if (inField(s, i)) k++; return k; }
    function placeOf(s, local) { var t = s.field[local][1], k = 1; for (var i = 0; i < s.field.length; i++) if (inField(s, i) && s.field[i][1] > t) k++; return k; }
    function tiedAt(s, local) { var t = s.field[local][1], k = 0; for (var i = 0; i < s.field.length; i++) if (inField(s, i) && s.field[i][1] === t) k++; return k > 1; }
    // the place by share, or what stands in for it when the business is in no top 3 at any point
    var NONE = 'Not in the top 3 at any point';
    // the business to set beside the store when none is chosen: number 1, or number 2 when the store is number 1
    function defaultVs(si) { var s = S[si], rows = s.field.filter(function (f) { return !far(f[0]); }); return rows[0][0] !== ME ? rows[0][0] : (rows[1] ? rows[1][0] : ME); }
    function vsIn(si, vs) { return localOf(S[si], vs) >= 0 && vs !== ME && !far(vs) ? vs : defaultVs(si); }
    // the rank of one business at each point: 1 to 20, 0 = not in the results there, null = results not kept
    function ranks(s, local) { if (s.res) { var ch = A[local]; return s.res.map(function (r) { return r.indexOf(ch) + 1; }); } return local === s.you ? s.own : null; }
    function topAt(s, i, k) { return s.res ? s.res[i].slice(0, k).split('').map(function (c) { return B[s.field[A.indexOf(c)][0]].short; }) : []; }
    function band(v) { return v === 0 ? 'x' : v <= 3 ? 'a' : v <= 10 ? 'b' : 'c'; }

    // one grid: a dot at every point checked, coloured and numbered by the business's rank there
    function grid(si, b) {
      var s = S[si], g = M.geoms[s.geom], local = localOf(s, b), rk = local < 0 ? null : ranks(s, local), W = g.size * CELL, biz = B[b];
      var f = local < 0 ? null : s.field[local];
      var out = '<svg class="gg" viewBox="0 0 ' + W + ' ' + W + '" role="img" aria-label="' + esc(biz.short + (f ? ': in the top 3 at ' + f[1] + ' of ' + s.n + ' points' : '')) + '">';
      for (var i = 0; i < g.cells.length; i++) {
        var x = g.cells[i][1] * CELL + CELL / 2, y = g.cells[i][0] * CELL + CELL / 2;
        if (!rk) { out += '<circle class="g-n" cx="' + x + '" cy="' + y + '" r="' + DOT + '"/>'; continue; }
        var v = rk[i], top = topAt(s, i, 3);
        var tip = biz.short + ': ' + (v ? ord(v) : 'not in the top 20') + ' here.' + (top.length ? ' Top 3: ' + top.join(', ') + '.' : '');
        out += '<g class="gd g-' + band(v) + '" data-tip="' + esc(tip) + '"><circle cx="' + x + '" cy="' + y + '" r="' + DOT + '"/>' + (v ? '<text x="' + x + '" y="' + (y + 4.5) + '">' + v + '</text>' : '') + '</g>';
      }
      // where the business itself sits, when that is inside the area checked
      if (biz.lat !== null && biz.lng !== null) {
        var mid = (g.size - 1) / 2, px = (mid + (biz.lng - g.centre[1]) / g.step[1]) * CELL + CELL / 2, py = (mid - (biz.lat - g.centre[0]) / g.step[0]) * CELL + CELL / 2;
        if (px > 4 && py > 4 && px < W - 4 && py < W - 4) out += '<g class="g-pin" data-tip="' + esc(biz.short + ' is here.') + '"><path d="M' + px.toFixed(1) + ' ' + (py - 9).toFixed(1) + 'l9 9-9 9-9-9z"/></g>';
      }
      return out + '</svg>';
    }
    // the words under a grid
    // points where the business is not in the first 20 while another area's business is: not a confirmed "not there"
    function unconfirmed(s, local) {
      var rk = ranks(s, local); if (!rk || !s.res) return 0;
      var k = 0; for (var i = 0; i < rk.length; i++) { if (rk[i] !== 0) continue; var r = s.res[i]; for (var j = 0; j < r.length; j++) { var li = A.indexOf(r.charAt(j)); if (li >= 0 && s.field[li] && far(s.field[li][0])) { k++; break; } } }
      return k;
    }
    function facts(si, b) {
      var s = S[si], local = localOf(s, b);
      if (local < 0) return '<p class="mv-none">' + esc(B[b].short) + ' is not in this check.</p>';
      var f = s.field[local], place = placeOf(s, local), tied = tiedAt(s, local), unc = unconfirmed(s, local);
      return '<div class="mv-n"><span class="big">' + f[1] + ' <span class="unit">of ' + s.n + ' points in the top 3</span></span></div>' +
        '<p class="note">' + (f[1] > 0 ? (tied ? 'Tied for ' : '') + ord(place) + ' of ' + size(s) + ' businesses' : NONE) + '. ' + (f[2] > 0 ? (unc ? 'At least ' + f[2] + ' of the ' + s.n + ' points list it' : 'Listed at ' + f[2] + ' of the ' + s.n + ' points') : 'Not in the first 20 at any of the ' + s.n + ' points') + (f[4] !== null ? '. ' + Number(f[4]).toFixed(1) + ' stars' + (f[5] !== null && f[5] !== undefined ? ', ' + n(f[5]) + ' ratings' : '') : '') + '.' +
        (ranks(s, local) ? '' : ' This check did not keep the full results at every point, so only the store\'s own map can be drawn for it.') + '</p>';
    }
    function card(si, b, mine) {
      var biz = B[b];
      return '<p class="card-k">' + (mine ? 'You' : (placeLabel(si, b))) + '</p><p class="card-t">' + esc(biz.short) + '</p>' + grid(si, b) + facts(si, b);
    }
    function placeLabel(si, b) { var s = S[si], local = localOf(s, b); if (local < 0) return 'Not in this check'; if (!(s.field[local][1] > 0)) return NONE; var p = placeOf(s, local); return (tiedAt(s, local) ? 'Tied for number ' : 'Number ') + p; }
    // the businesses in a check, most points in the top 3 first. The store is always shown.
    function board(si, vs, all) {
      var s = S[si], rows = s.field.map(function (f, i) { return { i: i, f: f }; }).filter(function (r) { return !far(r.f[0]); }), max = Math.max(1, s.field[0][1]);
      var show = all ? rows : rows.filter(function (r, k) { return k < 10 || r.f[0] === ME || r.f[0] === vs; });
      var out = '<p class="card-k">The top of the map</p><div class="lb">';
      show.forEach(function (r) {
        var biz = B[r.f[0]], me = r.f[0] === ME;
        out += '<button type="button" class="lb-row' + (me ? ' lb-you' : '') + (r.f[0] === vs ? ' lb-on' : '') + '" data-vs="' + r.f[0] + '" data-tip="' + esc(biz.name + ': top 3 at ' + r.f[1] + ' of ' + s.n + ' points, listed at ' + r.f[2] + (r.f[4] !== null ? '. ' + Number(r.f[4]).toFixed(1) + ' stars' + (r.f[5] !== null && r.f[5] !== undefined ? ', ' + n(r.f[5]) + ' ratings' : '') : '')) + '">' +
          '<span class="lb-p">' + (r.f[1] > 0 ? placeOf(s, r.i) : '-') + '</span><span class="lb-n">' + esc(biz.short) + '</span><span class="b-track"><span class="b-fill" style="width:' + Math.max(1.5, pct(r.f[1], max)) + '%"></span></span><span class="lb-v">' + r.f[1] + '</span></button>';
      });
      out += '</div>';
      if (rows.length > show.length || all) out += '<p class="lb-more"><button type="button" class="btn btn-ghost" data-act="mv-all">' + (all ? 'Show the top 10' : 'Show all ' + rows.length) + '</button></p>';
      return out + '<p class="note">Points in Google\'s top 3, of ' + s.n + ' checked. Pick a business to see its map.</p>';
    }
    // the store's share across every check of one search, with number 1 at the time and the business chosen
    function trend(si, vs) {
      var s = S[si], k = kwOf(s.kw), ids = k.ids;
      if (ids.length < 2) return '<p class="mv-none">One check on file for this search, so there is no line to draw yet.</p>';
      var W = 1000, H = 220, L = 44, R = 16, T = 14, Bm = 30, t0 = S[ids[0]].ts, t1 = S[ids[ids.length - 1]].ts;
      var sh = function (i, local) { return local < 0 ? null : pct(S[i].field[local][1], S[i].n); };
      var lead = ids.map(function (i) { return sh(i, 0); }), you = ids.map(function (i) { return sh(i, S[i].you); }), them = ids.map(function (i) { return sh(i, localOf(S[i], vs)); });
      var top = Math.max.apply(null, lead.concat(you)), ymax = Math.max(20, Math.ceil(top / 20) * 20);
      var X = function (i) { return L + (W - L - R) * (t1 === t0 ? 0.5 : (S[i].ts - t0) / (t1 - t0)); }, Y = function (v) { return T + (H - T - Bm) * (1 - v / ymax); };
      var pathOf = function (vals) { var d = '', pen = false; ids.forEach(function (i, j) { if (vals[j] === null) { pen = false; return; } d += (pen ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(vals[j]).toFixed(1); pen = true; }); return d; };
      var out = '<svg class="tr" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc('Share of points in the top 3 for ' + s.kw + ', ' + ids.length + ' checks') + '">';
      for (var g = 0; g <= ymax; g += ymax / 4) out += '<line class="tr-g" x1="' + L + '" x2="' + (W - R) + '" y1="' + Y(g).toFixed(1) + '" y2="' + Y(g).toFixed(1) + '"/><text class="tr-a" x="' + (L - 8) + '" y="' + (Y(g) + 4).toFixed(1) + '" text-anchor="end">' + Math.round(g) + '%</text>';
      out += '<path class="tr-lead" d="' + pathOf(lead) + '"/>';
      if (vs !== ME && them.filter(function (v) { return v !== null; }).length > 1) out += '<path class="tr-vs" d="' + pathOf(them) + '"/>';
      out += '<path class="tr-you" d="' + pathOf(you) + '"/>';
      out += '<line class="tr-now" x1="' + X(si).toFixed(1) + '" x2="' + X(si).toFixed(1) + '" y1="' + T + '" y2="' + (H - Bm) + '"/>';
      ids.forEach(function (i, j) {
        var topB = B[S[i].field[0][0]].short;
        out += '<g class="tr-pt' + (i === si ? ' tr-on' : '') + '" data-scan="' + i + '" data-tip="' + esc(S[i].when + '. You: ' + S[i].field[S[i].you][1] + ' of ' + S[i].n + ' points. Number 1: ' + topB + ', ' + S[i].field[0][1] + '.') + '"><circle class="tr-hit" cx="' + X(i).toFixed(1) + '" cy="' + Y(you[j]).toFixed(1) + '" r="14"/><circle class="tr-dot" cx="' + X(i).toFixed(1) + '" cy="' + Y(you[j]).toFixed(1) + '" r="' + (i === si ? 6 : 4) + '"/></g>';
      });
      var lab = function (i, anchor) { return '<text class="tr-a" x="' + X(i).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="' + anchor + '">' + esc(S[i].when.split(', ').slice(1, 3).join(', ')) + '</text>'; };
      out += lab(ids[0], 'start') + lab(ids[ids.length - 1], 'end') + '</svg>';
      return out + '<div class="legend"><span class="lg-i"><span class="lg-s lg-you"></span>' + esc(B[ME].short) + '</span><span class="lg-i tr-k-lead"><span class="lg-s lg-lead"></span>Number 1 at each check</span>' +
        (vs !== ME && them.filter(function (v) { return v !== null; }).length > 1 ? '<span class="lg-i tr-k-vs"><span class="lg-s lg-vs"></span>' + esc(B[vs].short) + '</span>' : '') + '</div>';
    }
    // every search on file, at its latest check
    function searches(si) {
      var out = '<div class="tw"><table class="srt"><thead><tr><th>Search</th><th>Last checked</th><th class="num">You, top 3</th><th class="num">Your place</th><th data-cmp>Number 1</th><th class="num" data-cmp>Number 1, top 3</th><th class="num">Checks</th></tr></thead><tbody>';
      kws.forEach(function (k) {
        var s = S[k.last], me = s.field[s.you], top = s.field[0], place = placeOf(s, s.you), lead = top[0] === ME, none = !(me[1] > 0);
        out += '<tr class="sr-row' + (S[si].kw === k.kw ? ' sr-on' : '') + '" data-scan="' + k.last + '" tabindex="0"><td class="sr-kw">' + esc(k.kw) + '</td><td class="dim">' + esc(s.when.split(', ').slice(1, 3).join(', ')) + '</td>' +
          '<td class="num"><span class="sr-b sr-' + (!none && place <= 3 ? 'hi' : pct(me[1], top[1]) >= 50 ? 'mid' : 'lo') + '">' + me[1] + ' of ' + s.n + '</span></td><td class="num">' + (none ? 'Not in the top 3' : (tiedAt(s, s.you) ? 'Tied ' : '') + ord(place) + ' of ' + size(s)) + '</td>' +
          '<td data-cmp>' + esc(lead ? 'You' : B[top[0]].short) + '</td><td class="num" data-cmp>' + top[1] + ' of ' + s.n + '</td><td class="num dim">' + k.ids.length + '</td></tr>';
      });
      return out + '</tbody></table></div>';
    }
    function options(si, vs) {
      var s = S[si], tracked = kws.filter(function (k) { return k.ids.length > 1; }), once = kws.filter(function (k) { return k.ids.length === 1; });
      var opt = function (k) { return '<option value="' + k.last + '"' + (k.kw === s.kw ? ' selected' : '') + '>' + esc(k.kw) + '</option>'; };
      return { kw: (tracked.length ? '<optgroup label="Checked again and again">' + tracked.map(opt).join('') + '</optgroup>' : '') + (once.length ? '<optgroup label="Checked once">' + once.map(opt).join('') + '</optgroup>' : ''),
        vs: s.field.map(function (f, i) { return f[0] === ME || far(f[0]) ? '' : '<option value="' + f[0] + '"' + (f[0] === vs ? ' selected' : '') + '>' + (f[1] > 0 ? placeOf(s, i) + '. ' : '') + esc(B[f[0]].short) + '</option>'; }).join('') };
    }
    // the sentence over the two maps
    function line(si, vs) {
      var s = S[si], me = s.field[s.you], lv = localOf(s, vs), them = lv < 0 ? null : s.field[lv];
      if (!them || vs === ME) return 'In Google\'s top 3 at ' + me[1] + ' of ' + s.n + ' points.';
      if (me[1] === them[1]) return B[ME].short + ' and ' + B[vs].short + ' are level: top 3 at ' + me[1] + ' of ' + s.n + ' points each.';
      var ahead = me[1] > them[1], hi = ahead ? me : them, lo = ahead ? them : me, times = lo[1] ? Math.round(10 * hi[1] / lo[1]) / 10 : null;
      return (ahead ? B[ME].short + ' holds ' + me[1] + ' of ' + s.n + ' points. ' + B[vs].short + ' holds ' + them[1] + '.' : B[vs].short + ' holds ' + them[1] + ' of ' + s.n + ' points. ' + B[ME].short + ' holds ' + me[1] + '.') + (times && times >= 1.5 ? ' That is ' + times + ' times as many.' : '');
    }
    function render(st) {
      var si = st.si, vs = vsIn(si, st.vs), s = S[si], k = kwOf(s.kw), at = k.ids.indexOf(si);
      return { si: si, vs: vs, key: s.key, kw: s.kw, when: s.when, n: s.n, checks: k.ids.length, at: at, prev: at > 0 ? k.ids[at - 1] : -1, next: at < k.ids.length - 1 ? k.ids[at + 1] : -1,
        you: card(si, ME, true), them: card(si, vs, false), board: board(si, vs, !!st.all), trend: trend(si, vs), searches: searches(si), options: options(si, vs), line: line(si, vs) };
    }
    return { render: render, defaultVs: defaultVs, vsIn: vsIn, latest: function (kw) { var k = kwOf(kw); return k ? k.last : -1; }, byKey: function (key) { return byKey[key] === undefined ? -1 : byKey[key]; }, kws: kws, placeOf: placeOf, tiedAt: tiedAt, localOf: localOf, ranks: ranks, size: size, far: far, unconfirmed: unconfirmed };
  }
  return { make: make, esc: esc, ord: ord };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = MapView;
