// build-report.mjs: report-data.json -> one self-contained HTML page (styles, fonts, script and data inline;
// no network). Every string that reaches the page goes through e(): HTML-escaped, long dashes turned to hyphens.
// usage: node build-report.mjs <report-data.json> <out.html> [--audience=internal|client|service] [--doc="<document name>"]
//   internal (default): both views. Sales is what a client or prospect would see; Service is the team's.
//   client: the Sales view only. Nothing from the Service view is in the file: no team notes, no numbers on
//           hold, no tasks for the software team, no view switch. This is the copy that can be sent or shared.
//   service: the Service view only, as a document of its own (the "Action Plan"). Lines about our OTHER accounts
//           (which businesses on the map we also track, another account's readings in this answer) are left out of
//           the file: they are not about this store and stay in the internal copy.
//   --doc names the document in the title bar, the header and the first screen (e.g. "Competitor Analysis");
//           without it the page is named as before.
// The Compare switch sits at the end of the tab strip. Every block marked data-cmp is a comparison with the
// competition and is shown only while the switch is on: on by default in the Sales view, off in the Service view.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const [dataPath, outPath] = argv.filter(a => !a.startsWith('--'));
const AUD = (argv.find(a => a.startsWith('--audience=')) || '--audience=internal').slice(11);
if (!dataPath || !outPath || !['internal', 'client', 'service'].includes(AUD)) { console.error('usage: node build-report.mjs <report-data.json> <out.html> [--audience=internal|client|service] [--doc="<document name>"]'); process.exit(2); }
const CLIENT = AUD === 'client', SERVICE = AUD === 'service';
const DOC = (argv.find(a => a.startsWith('--doc=')) || '').slice(6).trim() || null;
const die = m => { console.error('BUILD FAILED: ' + m); process.exit(1); };
const d = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
// The service document leaves out every check, task and hold that speaks of our other accounts. Each one left out is
// printed below, and the finished file is read again for the same words (the gate at the end of this file).
const XACCT = /\bbusiness [0-9]+\b|tracked in our own software|\bour own accounts?\b|(also|one of) our (clients|accounts)|another account/i;
const omitted = [];
if (SERVICE) {
  const keep = kind => x => { if (!XACCT.test(JSON.stringify(x))) return true; omitted.push(`${kind} ${x.id || String(x.number).slice(0, 48)}`); return false; };
  const goneTasks = new Set((d.tasks || []).filter(t => XACCT.test(JSON.stringify(t))).map(t => t.id));
  const goneChecks = new Set((d.checks || []).filter(c => XACCT.test(JSON.stringify(c))).map(c => c.id));
  d.checks = d.checks.filter(keep('check'));
  d.tasks = d.tasks.filter(keep('task'));
  d.holds = (d.holds || []).filter(keep('hold'));
  const dangling = [...d.tasks.filter(t => (t.blocked_by || []).some(b => goneTasks.has(b)) || goneChecks.has(t.check)).map(t => 'task ' + t.id),
    ...d.checks.filter(c => goneTasks.has(c.task)).map(c => 'check ' + c.id), ...(d.plan || []).filter(p => goneTasks.has(p.task) || goneTasks.has(p.id)).map(p => 'plan ' + p.id)];
  if (dangling.length) die('leaving out the other-account lines would orphan: ' + dangling.join(', '));
  // the area counts leave out checks about the data itself; a check left out here must be one of those, or the counts would lie
  if (d.counts && omitted.some(o => o.startsWith('check ') && (() => { const c = JSON.parse(fs.readFileSync(dataPath, 'utf8')).checks.find(x => 'check ' + x.id === o); return c && c.weight !== 'data' && d.counts[c.door]; })())) die('a check left out is counted in the area totals');
  if (d.task_groups) d.task_groups = d.task_groups.map(g => ({ ...g, n: d.tasks.filter(t => t.group === g.key).length }));
}
const { business: B, you, rivals, maps, reviews: RV, search: S, website: W, links: L, listings: LS, checks, tasks, plan, holds, ledger, compare: C, verdict, counts, stores, meta } = d;
if (!C || !Array.isArray(C.rows)) die('report-data.json has no compare block: run extract.mjs again');
// the market: our own map checks, when the data carries them. mapview.js draws them here and again in the page.
const GAPS = d.gaps || [], MK = d.map || null, MARKET = d.market || null;
// Two flags in report-data.json, both absent from the HS data, so a page built without them is unchanged:
//   meta.order = 'loss-first' (the owner's ordering): the right/wrong board runs Wrong, To look at, Right; the gap
//     lines run biggest deficit first, level or ahead last; each tab's checks run fail, watch, not measured, pass.
//   meta.v2 = true (extract-v2.mjs, SEOS's three-answer API): the sections that read the new shape, where the HS
//     wording would claim something the new data does not say (the rivals' pages, the town searches, the map).
const LOSS = meta.order === 'loss-first', V2 = meta.v2 === true;
const STATUS_RANK = { fail: 0, watch: 1, na: 2, pass: 3 };
const lossSort = list => LOSS ? [...list].sort((a, b) => STATUS_RANK[a.status] - STATUS_RANK[b.status]) : list;
const mvSrc = fs.readFileSync(path.join(here, 'mapview.js'), 'utf8');
const MapView = new Function(mvSrc + '\nreturn MapView;')();
const MV = MARKET ? MapView.make(MARKET) : null;
if (MV && MV.byKey(MK.main.key) < 0) die('the main map check is not in the market data');

const e = s => String(s ?? '').replace(/[\u2012\u2013\u2014\u2015\u2212]/g, '-').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const n = x => x === null || x === undefined ? '' : (Number(x) === 0 ? 0 : Number(x)).toLocaleString('en-US');      // a rounded -0.2 prints as 0, never as -0
const pct = (v, max) => max ? Math.max(0.8, Math.round(1000 * v / max) / 10) : 0;
const STATUS = { pass: ['Good', '\u2713'], watch: ['Needs a look', '!'], fail: ['Needs fixing', '\u2715'], na: ['Not measured', '?'] };
const OWNER = { us: 'Us', client: 'The client', account: 'Account manager', software: 'Software team' };
const DOORS = { maps: 'Google Maps', search: 'Google search', ai: 'AI answers', website: 'Website', links: 'Links and listings', plan: 'Tasks', overview: 'Overview' };
const place = `${B.city}, ${B.state}`;
const phoneDigits = String(B.phone || '').replace(/[^0-9]/g, '').slice(-10);
const phone = phoneDigits.length === 10 ? `(${phoneDigits.slice(0, 3)}) ${phoneDigits.slice(3, 6)}-${phoneDigits.slice(6)}` : B.phone;
if (phoneDigits.length === 10 && phone.replace(/[^0-9]/g, '') !== phoneDigits) die('phone number was mangled while formatting');
const link = (url, text) => /^https?:\/\//.test(String(url)) ? `<a href="${e(url)}" target="_blank" rel="noopener noreferrer">${e(text ?? url)}</a>` : e(text ?? url);

// ---------- the find box: every fact, check and task, with where it lives. m = the view it belongs to ('' = both) ----------
const find = [];
const fact = (l, v, t, a, k = '', m = '') => { if (v !== null && v !== undefined && v !== '') find.push({ l: String(l), v: String(v), w: DOORS[t], t, a, k, m }); };

// ---------- pieces ----------
const chip = st => `<span class="chip chip-${st}">${STATUS[st][1]} ${STATUS[st][0]}</span>`;
const holdChip = '<span class="chip chip-hold" data-tip="Do not quote this number yet. The reason is on the Overview.">On hold</span>';
const meter = c => { const part = (k, v) => v ? `<span class="m-${k}" style="flex:${v}"></span>` : ''; return `<div class="meter" role="img" aria-label="${c.pass} good, ${c.watch} need a look, ${c.fail} need fixing${c.na ? `, ${c.na} not measured` : ''}">${part('pass', c.pass)}${part('watch', c.watch)}${part('fail', c.fail)}${part('na', c.na)}</div><div class="meter-l">${c.na === c.total ? 'Not measured yet' : `${c.pass} of ${c.total} checks good`}</div>`; };
const bars = (rows, unit = '') => { const max = Math.max(...rows.map(r => r.v)); return `<div class="bars">${rows.map(r => `<div class="b-row${r.you ? ' b-you' : ''}" data-tip="${e(r.tip || `${r.label}: ${n(r.v)}${unit ? ' ' + unit : ''}`)}"><div class="b-label">${e(r.label)}</div><div class="b-track"><div class="b-fill" style="width:${pct(r.v, max)}%"></div></div><div class="b-val">${e(r.show ?? n(r.v))}</div></div>`).join('')}</div>`; };
const RANK_NOTE = 'In our own study of cannabis map checks, stores with these in place ranked higher. A link, not proof of cause.';

// ---------- compare: one number, the store beside the competition. Shown only while the Compare switch is on ----------
// A row that is not safe for a client (a number on hold, a count that stopped at a limit) is marked for the team
// and is cut out of the client copy with the rest of the team's side.
const rowOf = id => C.rows.find(r => r.id === id) || null;
const cstat = (r, pre = 'cmp') => {
  if (!r) return '';
  const max = Math.max(...r.entries.filter(x => x.v !== null).map(x => x.v));
  const unit = x => /%$/.test(x.show) || !r.unit || (V2 && / of [0-9]/.test(x.show)) ? '' : ' ' + r.unit;
  const line = x => x.v === null
    ? `<div class="b-row b-none"><div class="b-label">${e(x.name)}</div><div class="b-miss">${e(x.why || 'Not in the record')}</div></div>`
    : `<div class="b-row${x.is_you ? ' b-you' : ''}" data-tip="${e(`${x.name}: ${x.show}${unit(x)}`)}"><div class="b-label">${e(x.name)}</div><div class="b-track"><div class="b-fill" style="width:${pct(x.v, max)}%"></div></div><div class="b-val">${e(x.show)}</div></div>`;
  return `<div class="card cstat" id="${pre}-${e(r.id)}"${r.sales ? '' : ' data-only="service" data-internal'}><p class="card-k">${e(r.label)}${r.hold ? ' ' + holdChip : ''}</p>${r.summary ? `<p class="cstat-s">${e(r.summary)}</p>` : ''}<div class="bars">${r.entries.map(line).join('')}</div><p class="note"><span class="chip chip-plain">${e(r.scope)}</span> ${e(r.note || '')}</p>${V2 && r.team_note ? `<p class="note" data-only="service" data-internal>${e(r.team_note)}</p>` : ''}</div>`;
};
// v2, loss-first: the cards of a group run where the store is behind first (furthest back first), where it leads last
const standing = h => { const m = /id="cmp-([^"]+)"/.exec(h), r = m ? rowOf(m[1]) : null; if (!r) return 1; const have = r.entries.filter(x => x.v !== null), me = have.find(x => x.is_you); if (!me || have.length < 2) return 1; const above = have.filter(x => !x.is_you && x.v > me.v).length; return above ? -above / 100 : 2; };
const cmpGrid = cards => { const list = V2 && LOSS ? cards.filter(Boolean).map((h, i) => [h, i]).sort((a, b) => standing(a[0]) - standing(b[0]) || a[1] - b[1]).map(x => x[0]) : cards.filter(Boolean); return list.length > 1 ? `<div class="${list.length === 3 ? 'grid3' : 'grid2'} cmp-grid">${list.join('')}</div>` : list.join(''); };
// what the run read about the rivals and the record does not hand back: the team's list, never a blank for a client
const cmpMissing = door => { const list = C.missing[door] || []; return list.length ? `<div class="card" data-only="service" data-internal id="cmp-missing-${door}"><p class="card-k">Not compared yet</p><div class="tw"><table class="stack-sm"><thead><tr><th>What</th><th>Where it stands</th><th>Task</th></tr></thead><tbody>${list.map(m => { const tk = m.task ? tasks.find(x => x.id === m.task) : null; return `<tr><td>${e(m.what)}</td><td class="dim">${e(m.state || '')}</td><td class="dim">${tk ? `Task ${tk.n}: ${e(tk.title)}` : ''}</td></tr>`; }).join('')}</tbody></table></div></div>` : ''; };
const cmpPanel = (id, sub, body, only = null) => `<div class="sec cmp-sec" data-cmp id="${id}"${only ? ` data-only="${only}"` : ''}><h3 class="h2">You and the competition</h3>${sub}${body}</div>`;
const besideNote = maps.hold ? ' That check ran after closing time, so a check in opening hours comes before any map number.' : '';
// ---------- the map, point by point: any search, any date, any business beside the store ----------
// Drawn here for the main search at its latest check; the page redraws it with the same code on every pick.
const mapPortal = (() => {
  if (!MV) return '';
  const firstLoss = V2 && LOSS ? (maps.searches || []).find(x => !x.hold && !x.you_lead && MV.byKey(x.key) >= 0) : null;
  const si = firstLoss ? MV.byKey(firstLoss.key) : MV.byKey(MK.main.key), st = MV.render({ si, vs: MV.defaultVs(si), all: false });
  for (const s of MK.searches) fact(`On the map: ${s.kw}`, `${s.you} of ${s.n} points, ${s.tied ? 'tied ' : ''}${MapView.ord(s.place)} of ${s.of}`, 'overview', 'map-view', `map grid points geogrid local pack dots number 1 ${s.leader} top 3`);
  fact('Number 1 on the map', `${MK.main.leader}, ${MK.main.leader_points} of ${MK.main.n} points for "${MK.main.kw}"`, 'overview', 'map-view', 'leader number one who is first top of the map competitor rival winner');
  return `<div class="sec mv" id="map-view" data-scan="${si}" data-vs="${st.vs}" data-prev="${st.prev}" data-next="${st.next}">
  <h2 class="h2">The map, point by point</h2>
  <p class="sub">Each dot is a spot around town where we searched Google Maps, and the number is the place Google gave the store there. ${n(MK.reports)} checks of ${MK.searches.length} searches since ${e(MK.first)}, ${V2 && MK.outside_hours ? `${n(MK.outside_hours)} of them outside opening hours` : 'every one taken in opening hours'}.</p>
  <div class="mv-bar">
    <label class="mv-f"><span>Search</span><select id="mv-kw" class="sel">${st.options.kw}</select></label>
    <div class="mv-f"><span>Checked</span><div class="mv-date"><button class="icon-b" type="button" data-act="mv-prev" aria-label="The check before"${st.prev < 0 ? ' disabled' : ''}>‹</button><span id="mv-when">${e(st.when)}</span><button class="icon-b" type="button" data-act="mv-next" aria-label="The check after"${st.next < 0 ? ' disabled' : ''}>›</button></div></div>
    <label class="mv-f" data-cmp><span>Beside</span><select id="mv-vs" class="sel">${st.options.vs}</select></label>
  </div>
  <p class="mv-line" id="mv-line" data-cmp>${e(st.line)}</p>
  <div class="mv-grids">
    <div class="card mv-card mv-me" id="mv-you">${st.you}</div>
    <div class="card mv-card" id="mv-them" data-cmp>${st.them}</div>
    <div class="card mv-card" id="mv-board" data-cmp>${st.board}</div>
  <div class="legend mv-key"><span class="lg-i"><span class="lg-s g-ka"></span>1st to 3rd</span><span class="lg-i"><span class="lg-s g-kb"></span>4th to 10th</span><span class="lg-i"><span class="lg-s g-kc"></span>11th to 20th</span><span class="lg-i"><span class="lg-s g-kx"></span>Not in the first 20</span><span class="lg-i"><span class="lg-s g-kp"></span>Where the business is</span><span class="lg-i">Blank spots were left out of the check.</span></div>
    <div class="card mv-trend" id="mv-trend"><p class="card-k">Share of the points in Google's top 3, check by check</p><div id="mv-trend-b">${st.trend}</div></div>
  </div>
  <div class="card" id="mv-all"><p class="card-k">Every search we have checked on the map</p><div id="mv-searches">${st.searches}</div><p class="note">Pick a row to see its map.</p></div>
</div>`;
})();

// ---------- the gap to number 1: every number, the store beside the best there is ----------
const gapOrder = V2 && LOSS && GAPS.every(g => typeof g.deficit === 'number') ? [...GAPS].sort((a, b) => (a.lead - b.lead) || ((a.scope === 'whole') - (b.scope === 'whole')) || (b.deficit - a.deficit))
  : LOSS && GAPS.every(g => typeof g.deficit === 'number') ? [...GAPS].sort((a, b) => (a.lead - b.lead) || (b.deficit - a.deficit)) : [...GAPS].sort((a, b) => (a.lead - b.lead) || (a.you / (a.best || 1)) - (b.you / (b.best || 1)));
const gapLine = g => { const max = Math.max(g.you, g.best) || 1, a = Math.round(1000 * g.you / max) / 10, b = Math.round(1000 * g.best / max) / 10, lo = Math.min(a, b), hi = Math.max(a, b);
  fact(`Against number 1: ${g.label}`, `${g.you_show} to ${g.best_show}. ${g.text}`, 'overview', `gap-${g.id}`, `gap number 1 best leader versus compare competition rival ${g.who} ${g.best_name || ''}`, V2 && g.hold ? 'service' : '');
  return `<button type="button" class="gp${g.lead ? ' gp-ok' : ''}" id="gap-${e(g.id)}" data-tab-set="${g.door}" data-tip="${e(g.note || '')}"${V2 && g.hold ? ' data-only="service" data-internal' : ''}>
    <span class="gp-l"><span class="gp-t">${e(g.label)}</span><span class="gp-w">${V2 && g.hold ? holdChip + ' ' : ''}${V2 && g.scope === 'whole' ? '<span class="chip chip-plain">Whole websites</span> ' : ''}${e(g.who)}${g.best_name && g.best_name !== 'You' ? ': ' + e(g.best_name) : ''}</span></span>
    <span class="gp-tr"><span class="gp-bar" style="left:${lo}%;width:${Math.max(0, hi - lo)}%"></span>${g.level ? '' : `<span class="gp-d gp-best" style="left:${b}%"></span>`}<span class="gp-d gp-you" style="left:${a}%"></span></span>
    <span class="gp-n gp-ny">${e(g.you_show)}</span><span class="gp-n gp-nb">${e(g.best_show)}</span><span class="gp-x">${e(g.text)}</span></button>`; };
const gapSection = GAPS.length ? `<div class="sec" data-cmp id="gaps"><h2 class="h2">The gap to number 1</h2><p class="sub">Each line sets ${e(B.short)} beside the best there is and names it. Biggest gaps first, and the lines where the store is level or ahead are at the end.</p>
  <div class="gps"><div class="gp-h"><span></span><span></span><span class="gp-n">You</span><span class="gp-n">The best</span><span></span></div>${gapOrder.map(gapLine).join('')}</div></div>` : '';

// ---------- everything right, everything wrong: every check on one screen ----------
const RW = LOSS ? [['fail', 'Wrong'], ['watch', 'To look at'], ['pass', 'Right']] : [['pass', 'Right'], ['watch', 'To look at'], ['fail', 'Wrong']];
const rwItem = (c, sales) => `<button type="button" class="rw-i" data-goto="${sales ? 'cks' : 'ck'}-${e(c.id)}" data-goto-tab="${c.door}"><span class="rw-d">${e(DOORS[c.door] || '')}</span><span class="rw-t">${e(c.title)}</span><span class="rw-v">${e(sales && c.hold ? 'Check to come' : c.value)}</span></button>`;
const rwBoard = sales => { const list = checks.filter(c => c.door !== 'overview' && (sales ? c.weight !== 'data' && !c.internal && c.door !== 'ai' : true));
  const na = list.filter(c => c.status === 'na');
  return `<div class="rw"${sales ? ' data-only="sales"' : ' data-only="service"'}>${RW.map(([st, label]) => { const items = list.filter(c => c.status === st); return `<div class="card rw-c rw-${st}"><p class="rw-h"><span class="rw-k">${items.length}</span>${label}</p><div class="rw-l">${items.map(c => rwItem(c, sales)).join('')}</div></div>`; }).join('')}</div>${na.length ? `<p class="note"${sales ? ' data-only="sales"' : ' data-only="service"'}>Not measured yet: ${na.map(c => e(c.title)).join(', ')}.</p>` : ''}`; };
const rwSection = `<div class="sec" id="right-wrong"><h2 class="h2">Everything right, everything wrong</h2><p class="sub">Every check in this report on one screen. Pick a line to see what was found.</p>${rwBoard(true)}${rwBoard(false)}</div>`;
fact('Everything right, everything wrong', `${checks.filter(c => c.status === 'pass').length} right`, 'overview', 'right-wrong', 'what is right what is wrong all checks health list summary problems wins');

// the map shares are drawn as the board inside the map check card, not as a small chart
for (const r of C.rows) fact(`Compared: ${r.label}`, r.summary || `${r.entries.filter(x => x.v !== null).length} stores`, r.door, r.id === 'map-share' ? 'board' : `cmp-${r.id}`, `compare competition rivals rival versus vs against beside side by side ${r.scope} ${r.entries.map(x => x.name).join(' ')}`, r.sales ? '' : 'service');
// a check as the team reads it, and as a client reads it (no run problems, none of our own slips, client wording)
const checkRow = (c, sales) => `<div class="ck ck-${c.status}" id="${sales ? 'cks' : 'ck'}-${c.id}"><div class="ck-ic" aria-hidden="true">${STATUS[c.status][1]}</div><div class="ck-t">${e(c.title)}${c.weight === 'rank' && !V2 ? ' <span class="chip chip-rank">Tied to map rank</span>' : ''}${!sales && c.internal ? ' <span class="chip chip-ours">Ours</span>' : ''}${!sales && c.hold ? ' ' + holdChip : ''}</div><div class="ck-v">${e(sales && c.hold ? 'Check to come' : c.value)}</div><div class="ck-d">${e(sales && c.sales ? c.sales : c.detail)}</div></div>`;
const doorChecks = door => checks.filter(c => c.door === door && c.weight !== 'data');
const dataChecks = door => checks.filter(c => c.door === door && c.weight === 'data');
const checkBlock = door => {
  const forSales = lossSort(doorChecks(door).filter(c => !c.internal)), forTeam = lossSort(doorChecks(door)), rankNote = !V2 && forTeam.some(c => c.weight === 'rank') ? `<p class="note">${RANK_NOTE}${forTeam.filter(c => c.weight === 'rank').every(c => c.status === 'pass') ? (V2 ? ' All of them are in place here.' : ' All of them are in place here, so whatever holds the store back on the map is somewhere else.') : ''}</p>` : '';
  return `<div class="sec"><h3 class="h2">Health checks</h3><p class="sub">Each line is one thing we looked at and what we found.</p>
  <div data-only="sales"><div class="checks">${forSales.map(c => checkRow(c, true)).join('')}</div>${rankNote}</div>
  <div data-only="service"><div class="checks">${forTeam.map(c => checkRow(c, false)).join('')}</div>${rankNote}</div></div>`;
};
const ours = tasks.filter(t => ['us', 'client'].includes(t.owner));
const soft = tasks.filter(t => t.owner === 'software');
const acct = tasks.filter(t => t.owner === 'account');
const taskById = id => tasks.find(t => t.id === id);
const taskCard = (t, opt = {}) => `<details class="tk" data-task="${e(t.id)}" data-owner="${t.owner}"${t.internal || t.owner === 'software' || t.owner === 'account' || t.service_only ? ' data-internal' : ''}${opt.id ? ` id="tk-${e(t.id)}"` : ''}${opt.open ? ' open' : ''}><summary><span class="tk-n">${t.n}</span><span><span class="tk-t">${e(t.title)}</span><span class="tk-m"><span class="chip chip-plain">${e(OWNER[t.owner])}</span><span class="chip chip-plain">${e(t.group_label)}</span>${chip(t.status)}${t.internal ? '<span class="chip chip-ours">Ours</span>' : ''}${t.blocked_by.length ? `<span class="chip chip-hold">Blocked by task ${t.blocked_by.map(b => taskById(b).n).join(', ')}</span>` : ''}${t.is_new && !d.changes.first_run ? '<span class="chip chip-rank">New this run</span>' : ''}</span></span><span class="tk-side"><select class="sel" aria-label="Status of task ${t.n}"><option value="new">New</option><option value="assigned">Assigned</option><option value="doing">In progress</option><option value="waiting">Waiting on client</option><option value="blocked">Blocked</option><option value="done">Done</option><option value="wontdo">Will not do</option></select><button class="btn btn-ghost" type="button" data-copy="${e(t.id)}">Copy</button></span></summary>
<div class="tk-body"><div><p class="tk-h">Why</p>${t.why.map(w => `<p>${e(w)}</p>`).join('')}</div><div><p class="tk-h">Steps</p><ol>${t.steps.map(s => `<li>${e(s)}</li>`).join('')}</ol></div><div><p class="tk-h">Done when</p><p>${e(t.done_when)}</p></div>${t.blocked_by.length ? `<div><p class="tk-h">Blocked by</p>${t.blocked_by.map(b => `<p>Task ${taskById(b).n}: ${e(taskById(b).title)} (${e(OWNER[taskById(b).owner])})</p>`).join('')}</div>` : ''}
<div class="tk-f"><label>Who<input type="text" data-f="who" placeholder="Name" autocomplete="off"></label><label>Due<input type="date" data-f="due"></label><label class="tk-f-w">Note<input type="text" data-f="note" placeholder="One line" autocomplete="off"></label></div></div></details>`;
const planItem = p => `<div class="plan-i"><div class="plan-n">${String(p.n).padStart(2, '0')}</div><div><p class="plan-t">${e(p.title)}${p.yours ? ' <span class="chip chip-plain">With your team</span>' : ''}</p><p class="plan-w">${e(p.benefit || '')}</p></div></div>`;
const doorPlan = door => plan.filter(p => taskById(p.id).door === door);
const doorWork = door => { const mine = ours.filter(t => t.door === door), sw = [...soft, ...acct].filter(t => t.door === door), dc = lossSort(dataChecks(door)), sales = doorPlan(door);
  return `${sales.length ? `<div class="sec" data-only="sales"><h3 class="h2">What we would do here</h3><div>${sales.map(planItem).join('')}</div></div>` : ''}
  ${mine.length ? `<div class="sec" data-only="service"><h3 class="h2">Tasks here</h3><div class="tasks">${mine.map(t => taskCard(t)).join('')}</div></div>` : ''}
  ${dc.length ? `<div class="sec" data-only="service" data-internal><details class="more" open><summary>Checks on the data itself (${dc.length})</summary><div class="more-b"><p class="sub">Problems with this run, not with the store. They go to the software team.</p><div class="checks">${dc.map(c => checkRow(c, false)).join('')}</div>${sw.length ? `<div class="tasks" style="margin-top:14px">${sw.map(t => taskCard(t)).join('')}</div>` : ''}</div></details></div>` : ''}`; };
// a door's heading: one for a client, one for the team, when they differ
const head = (eyebrow, a, b, lead, only = null) => `<div class="hero"${only ? ` data-only="${only}"` : ''}><p class="eyebrow">${e(eyebrow)}</p><h2 class="h1 door-h">${e(a)} <span class="h1-a">${e(b)}</span></h2><p class="lead">${e(lead)}</p></div>`;
const kv = rows => `<dl class="kv">${rows.filter(r => r[1] !== null && r[1] !== undefined && r[1] !== '').map(([k, v, id, only, raw]) => `<dt${only ? ` data-only="${only}"` : ''}>${e(k)}</dt><dd${id ? ` id="${id}"` : ''}${only ? ` data-only="${only}"` : ''}>${raw ? v : e(v)}</dd>`).join('')}</dl>`;

// ---------- overview: sales ----------
const beside = B.also_viewed.filter(a => a.ratings !== null);
// v2: every search on file, losing first (extract-v2.mjs orders maps.searches that way)
const V2S = V2 ? (maps.searches || []).filter(s => !s.hold) : [];
const v2MapTile = (s, lead) => `<button class="tile${lead ? ' tile-lead' : ''}" type="button" ${MV ? 'data-goto="map-view" data-goto-tab="overview"' : 'data-tab-set="maps"'}><span class="card-k">Google Maps · "${e(s.kw)}"</span><span class="big">${s.you} <span class="unit">of ${s.n}</span></span><span class="tile-u">map points in Google's top 3${s.you_lead ? ', number 1' : s.place ? `, ${ordinalOf(s.place)} place` : ''}</span><span class="tile-s">${s.you_lead ? (s.second ? `Number 2 is ${e(s.second)}, at ${s.second_points}. ` : '') : `Number 1 is ${e(s.leader)}, at ${s.leader_floor ? `${s.leader_points} or more` : s.leader_points}. `}${e(s.date)}.</span></button>`;
const v2Tiles = () => { const map = V2S.slice(0, 3).map((s, i) => v2MapTile(s, i === 0)), w90 = RV && RV.windows && RV.windows.d90;
  const rest = [`<button class="tile" type="button" data-tab-set="maps"><span class="card-k">Reviews</span><span class="big">${n(B.ratings)}</span><span class="tile-u">Google ratings at ${Number(B.rating).toFixed(1)} stars</span><span class="tile-s">${w90 ? `${n(w90.replied)} of the ${n(w90.n)} from the last 90 days answered.` : RV ? `${n(RV.with_reply)} of ${n(RV.collected)} answered.` : ''}</span></button>`,
    `<button class="tile" type="button" data-tab-set="website"><span class="card-k">Website</span><span class="big">${W.phone ? W.phone.score : ''}</span><span class="tile-u">of 100 on a phone, lab test</span><span class="tile-s">Our page reader got ${n(W.words)} words from the store page.</span></button>`,
    `<button class="tile" type="button" data-tab-set="links"><span class="card-k">Links</span><span class="big">${n(L.not_sellers)}</span><span class="tile-u">linking sites that are not link sellers</span><span class="tile-s">${n(L.clean_with_weight)} of them carry some weight.</span></button>`];
  return `<div class="grid5">${[...map, ...rest].slice(0, 5).join('\n')}</div>`; };
const salesTiles = V2 ? v2Tiles() : `<div class="grid5">
<button class="tile tile-lead" type="button" data-tab-set="search"><span class="card-k">Searched by town</span><span class="big">${S.town_page1 ? n(S.town_page1) : 'None'}</span><span class="tile-u">of ${n(S.top10)} page 1 searches is a ${e(B.city)} dispensary search</span><span class="tile-s">${S.sister_town_page1.length ? `The brand's other stores hold ${S.sister_town_page1_n}.` : ''}</span></button>
<button class="tile" type="button" data-tab-set="search"><span class="card-k">Searched by name</span><span class="big">${S.name_town ? 'No. ' + S.name_town.rank : ''}</span><span class="tile-u">for "${e(S.name_town?.kw || '')}"</span><span class="tile-s">${S.name_town ? `${n(S.name_town.volume)} searches a month.` : ''}</span></button>
<button class="tile" type="button" data-tab-set="maps"><span class="card-k">Reviews</span><span class="big">${n(B.ratings)}</span><span class="tile-u">Google ratings at ${B.rating} stars</span><span class="tile-s">${RV ? `${n(RV.with_reply)} of ${n(RV.collected)} answered.` : ''}</span></button>
<button class="tile" type="button" data-tab-set="website"><span class="card-k">Website</span><span class="big">${W.phone ? W.phone.score : ''}</span><span class="tile-u">of 100 on a phone, lab test</span><span class="tile-s">Our page reader got ${n(W.words)} words from the store page.</span></button>
${MK ? `<button class="tile" type="button" data-goto="map-view" data-goto-tab="overview"><span class="card-k">Google Maps</span><span class="big">${MK.main.you} <span class="unit">of ${MK.main.n}</span></span><span class="tile-u">map points in Google's top 3</span><span class="tile-s">${MK.main.you_lead ? '' : `${e(MK.main.leader)} holds ${MK.main.leader_points}. `}"${e(MK.main.kw)}", ${e(MK.main.date)}.</span></button>`
  : `<button class="tile" type="button" data-tab-set="maps"><span class="card-k">Google Maps</span><span class="big">${maps.hold ? 'Next' : e(maps.board.find(b => b.is_you)?.in100 || '')}</span><span class="tile-u">${maps.hold ? 'a map check in opening hours' : 'of every 100 map points, top 3'}</span><span class="tile-s">${maps.hold ? 'The check on file ran after closing, so it is not quoted.' : ''}</span></button>`}
</div>`;
// what is missing, in the buckets the work is sold and done in
const BOARD = V2 ? [['The map', ['rescan-open-hours', 'map-gap']], ['Reviews', ['reply-reviews', 'reply-low-stars', 'low-star-subjects', 'review-gap']], ['The store page', ['store-page-check', 'town-page']], ['Speed', ['speed']], ['Pages and content', ['content-gap']], ['Listings and links', ['listings-hand-check', 'link-list', 'junk-links']], ['Google Analytics and Search Console', ['connect-google']]]
  : [['The map', ['rescan-open-hours']], ['The store page', ['store-page-check', 'town-page']], ['Reviews', ['reply-low-stars', 'low-star-subjects', 'review-gap']], ['Pages and content', ['content-gap']], ['Listings and links', ['listings-hand-check', 'link-list', 'junk-links']], ['Speed', ['speed']]];
const boardRows = BOARD.map(([label, ids]) => ({ label, items: plan.filter(p => ids.includes(p.id)) })).filter(b => b.items.length);
const leftOut = plan.filter(p => !BOARD.some(([, ids]) => ids.includes(p.id)));
if (leftOut.length) boardRows.push({ label: 'The Google listing', items: leftOut });
const missing = `<div class="grid3">${boardRows.map(b => `<div class="card"><p class="card-k">${e(b.label)}</p><div class="big">${b.items.length}<span class="unit">${b.items.length === 1 ? 'piece of work' : 'pieces of work'}</span></div><ul class="miss">${b.items.map(p => `<li>${e(p.title)}</li>`).join('')}</ul></div>`).join('')}</div>`;
// who the competition is: found from the find box on the tab that sets the store beside them
for (const r of C.rivals) fact(r.full, r.domain, 'search', 'cmp-searches', `${r.name} rival competitor who up against competitors`, 'sales');
for (const a of C.nearby) fact(a.full, `${a.rating} stars, ${n(a.ratings)} ratings`, 'maps', 'cmp-ratings', 'nearby store competitor beside competitors who up against', 'sales');
const listingRows = sales => [
  ['Name', B.name, sales ? null : 'fact-name'], ['Address', `${B.street}, ${B.city}, ${B.state} ${B.zip}`, sales ? null : 'fact-address'], ['Phone', phone, sales ? null : 'fact-phone'], ['Hours', B.hours?.summary, sales ? null : 'fact-hours'],
  ['Category', B.category, sales ? null : 'fact-category'], ['Rating', `${B.rating} stars from ${n(B.ratings)} ratings`, sales ? null : 'fact-rating'], ['Photos', n(B.photos), sales ? null : 'fact-photos'],
  ['Ways to shop', B.service_options.join(', '), sales ? null : 'fact-shop'], ['Link on the listing', link(B.listing_link), sales ? null : 'fact-link', null, true],
];
const SAID = { Phone: 'number call telephone contact', Address: 'location where street directions', Hours: 'opening closing time when', Rating: 'stars score', Category: 'type kind gbp', Photos: 'pictures images', 'Link on the listing': 'website url link', 'Ways to shop': 'pickup delivery curbside service options', Name: 'business name gbp listing' };
// in the find box the hours line says what it answers, so 'when do they close' finds it first
for (const [k, v, id] of listingRows(false)) fact(k === 'Hours' ? 'Hours: open and close' : k, k === 'Link on the listing' ? B.listing_link : v, 'maps', id, 'listing google profile ' + (SAID[k] || ''));
fact('Full link on the listing, with its tags', B.listing_full_link, 'maps', 'fact-full-link', 'utm tag tracking label campaign charlotte', 'service');
for (const a of beside) fact(a.name, `${a.rating} stars, ${n(a.ratings)} ratings`, 'maps', 'cmp-ratings', 'nearby store competitor beside competitors');
const chainOf = r => V2 && !!rowOf('searches') && rowOf('searches').entries.some(x => x.id === r.id && x.v === null);
for (const r of rivals) { fact(`${r.short}: searches, whole website`, n(r.keywords), 'search', 'cmp-searches', `${r.name} ${r.domain} rival competitor keywords competitors`, chainOf(r) ? 'service' : ''); fact(`${r.short}: estimated visits from search, whole website`, n(r.visits), 'search', 'cmp-visits', `${r.name} ${r.domain} rival competitor traffic`, chainOf(r) ? 'service' : ''); }
const dossier = `<div class="grid2"><div class="card"><p class="card-k">On Google</p>${kv(listingRows(true))}</div>
<div class="card"><p class="card-k">What customers mention in reviews</p><div class="chips">${B.topics.slice(0, 10).map(t => `<span class="chip chip-plain">${e(t.label)} · ${n(t.n)}</span>`).join('')}</div><p class="note">The words Google pulls out of the store's reviews, and how often each comes up.</p></div></div>`;
// The first screen, in the order a reader needs it: the verdict, the map, the gap to number 1, then every check
// as right or wrong. The map, the gap and the checks are the same for a client and for the team; what sits above
// and below them differs.
const v2Sweeps = V2 ? (maps.sweeps || []) : [];
const sourceLine = V2 && !MK && v2Sweeps.length ? `The store: read ${e(meta.report_date)}. The map: ${v2Sweeps.length} ${v2Sweeps.length === 1 ? 'check' : 'checks'}, ${e([...new Set(v2Sweeps.map(s => String(s.finished).replace(/, \d+:\d+ [AP]M$/, '')))].join(' and '))}${v2Sweeps.every(s => s.open === true) ? ', in opening hours' : ''}.`
  : MK ? `The store: read ${e(meta.report_date)}. The map: our own checks, ${V2 && MK.first === MK.last ? e(MK.first) : `${e(MK.first)} to ${e(MK.last)}`}.` : `Read ${e(meta.report_date)}.`;
const overviewSalesTop = `<div data-only="sales">
  <div class="hero"><p class="eyebrow">${DOC ? e(DOC) : 'SEO and competition report'} · ${e(place)} · ${e(meta.report_date)}</p>
  <h1 class="h1${(verdict.a + verdict.b).length > 44 ? ' h1-long' : ''}">${e(verdict.a || '')} <span class="h1-a">${e(verdict.b || '')}</span></h1><p class="lead">${e(verdict.lead)}</p><p class="src">${sourceLine}</p></div>
  ${salesTiles}
</div>`;
const overviewSalesRest = `<div data-only="sales">
  <div class="sec"><h2 class="h2">What is missing</h2><p class="sub">Each line is a piece of work. The checks behind it are on the tabs.</p>${missing}<p style="margin-top:22px"><button class="btn" type="button" data-tab-set="plan">See the plan, in order</button></p></div>
  <div class="sec"><h2 class="h2">What we already know about the store</h2><p class="sub">Read from Google and from the website on ${e(meta.report_date)}.</p>${dossier}</div>
</div>`;

// v2, no market file: every search on file, losing first, and the top of the map for each (the map itself is drawn when the market file is in)
const v2Home = (() => { if (!V2 || MV || !V2S.length) return '';
  for (const s of V2S) fact(`On the map: ${s.kw}`, `${s.you} of ${s.n} points, ${s.place ? `${s.tied ? 'tied ' : ''}${ordinalOf(s.place)}` : 'not placed'}`, 'overview', 'v2-searches', `map grid points geogrid local pack number 1 ${s.leader} top 3`);
  const boards = [...v2Sweeps].sort((a, b) => V2S.findIndex(x => x.kw === a.kw) - V2S.findIndex(x => x.kw === b.kw)).map(sw => `<div class="card"><p class="card-k">The top of the map for "${e(sw.kw)}"</p><div class="board">${sw.top.map(b => `<div class="board-row${b.is_you ? ' board-you' : ''}" data-tip="${e(`${b.name}: in Google's top 3 at ${b.points} of ${sw.n} points`)}"><div class="board-n">${e(b.short)}</div><div class="b-track"><div class="b-fill" style="width:${pct(b.points, sw.n)}%"></div></div><div class="board-v">${b.points}<span class="unit"> of ${sw.n}</span></div></div>`).join('')}</div><p class="note">Points in Google's top 3, of ${sw.n}, ${e(sw.finished)}.</p></div>`);
  return `<div class="sec" id="v2-searches"><h2 class="h2">Every search checked on the map</h2><p class="sub">Where the store is losing first, where it is winning last. Each check covers ${e([...new Set(v2Sweeps.map(s => `an ${s.grid} by ${s.grid} grid, ${s.radius} ${s.unit} out`))].join('; '))}.</p>
  <div class="tw"><table><thead><tr><th>Search</th><th>Checked</th><th class="num">Your points, top 3</th><th class="num">Your place</th><th>Number 1</th><th class="num">Number 1's points</th></tr></thead><tbody>${V2S.map(s => `<tr><td>${e(s.kw)}</td><td class="dim">${e(s.when)}</td><td class="num">${s.you} of ${s.n}</td><td class="num">${s.place ? `${s.tied ? 'Tied ' : ''}${ordinalOf(s.place)}` : 'Not placed'}</td><td>${s.you_lead ? 'You' : e(s.leader)}</td><td class="num">${s.leader_points} of ${s.n}</td></tr>`).join('')}</tbody></table></div>
  <div class="${boards.length === 3 ? 'grid3' : 'grid2'} cmp-grid" data-cmp style="margin-top:16px">${boards.join('')}</div></div>`; })();

// ---------- overview: service ----------
const CH = d.changes;
const chList = rows => rows.length ? `<ul class="miss">${rows.map(c => `<li>${e(c.title)} · ${e(c.value)}</li>`).join('')}</ul>` : '<p class="note">None.</p>';
const moved = CH.first_run ? [] : CH.numbers.filter(x => x.was !== null && x.now !== null && x.was !== x.now);
const changesHtml = CH.first_run
  ? `<div class="sec"><div class="card" id="since"><p class="card-k">Since the last report</p><p class="card-t">This is the first report for this store, so every task is new.</p><p class="note">Once a second report exists, this block lists what broke, what got fixed and which numbers moved.</p></div></div>`
  : `<div class="sec" id="since"><h2 class="h2">Since the last report</h2><p class="sub">Compared with the run of ${e(CH.since)}.</p><div class="grid3">
    <div class="card"><p class="card-k">New problems</p><div class="big">${CH.new_problems.length}</div>${chList(CH.new_problems)}</div>
    <div class="card"><p class="card-k">Fixed</p><div class="big">${CH.fixed.length}</div>${chList(CH.fixed)}</div>
    <div class="card"><p class="card-k">Still open</p><div class="big">${CH.still}</div><p class="note">Checks that needed work last time and still do.</p></div></div>
    ${moved.length ? `<div class="tw" style="margin-top:16px"><table><thead><tr><th>Number</th><th class="num">Last report</th><th class="num">This report</th><th class="num">Change</th></tr></thead><tbody>${moved.map(x => `<tr><td>${e(x.label)}</td><td class="num">${n(x.was)}</td><td class="num">${n(x.now)}</td><td class="num">${x.now > x.was ? 'up ' : 'down '}${n(Math.round(Math.abs(x.now - x.was) * 100) / 100)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="note">No headline number moved.</p>'}</div>`;
const holdsHtml = holds.length ? `<div class="sec" data-internal id="holds"><h2 class="h2">Not safe to quote yet</h2><p class="sub">Numbers the team holds back, why, and who clears each one.</p><div class="tw"><table class="stack-sm"><thead><tr><th>Number</th><th>Why it is on hold</th><th>Who clears it</th></tr></thead><tbody>${holds.map(h => `<tr><td><strong>${e(h.number)}</strong><br><span class="dim">${e(h.where)}</span></td><td>${e(h.why)}</td><td>${e(h.clears)}</td></tr>`).join('')}</tbody></table></div></div>` : '';
const doorTiles = V2 ? `<div class="grid5">
<button class="tile" type="button" data-tab-set="maps"><span class="card-k">Google Maps</span>${V2S[0] ? `<span class="big">${V2S[0].you}<span class="unit">of ${V2S[0].n}</span></span><span class="tile-u">map points in the top 3, "${e(V2S[0].kw)}"</span>` : '<span class="big">No check</span><span class="tile-u">no map check on file</span>'}${meter(counts.maps)}</button>
<button class="tile" type="button" data-tab-set="search"><span class="card-k">Google search</span><span class="big">${n(S.keywords_total)}</span><span class="tile-u">searches the whole website shows up for</span>${meter(counts.search)}</button>
<button class="tile" type="button" data-tab-set="ai"><span class="card-k">AI answers</span><span class="big">No data</span><span class="tile-u">not collected yet</span>${meter(counts.ai)}</button>
<button class="tile" type="button" data-tab-set="website"><span class="card-k">Website</span><span class="big">${W.phone ? W.phone.score : ''}</span><span class="tile-u">of 100 on a phone, lab test</span>${meter(counts.website)}</button>
<button class="tile" type="button" data-tab-set="links"><span class="card-k">Links and listings</span><span class="big">${n(L.not_sellers)}</span><span class="tile-u">linking sites that are not link sellers, of ${n(L.sites)}</span>${meter(counts.links)}</button>
</div>` : `<div class="grid5">
<button class="tile" type="button" data-tab-set="maps"><span class="card-k">Google Maps</span>${MK ? `<span class="big">${MK.main.you}<span class="unit">of ${MK.main.n}</span></span><span class="tile-u">map points in the top 3, "${e(MK.main.kw)}"</span>` : `<span class="big">${maps.hold ? 'Hold' : e(maps.board.find(b => b.is_you)?.in100 || '')}</span><span class="tile-u">${maps.hold ? 'map numbers, until a check in opening hours' : 'of every 100 map points'}</span>`}${meter(counts.maps)}</button>
<button class="tile" type="button" data-tab-set="search"><span class="card-k">Google search</span><span class="big">${S.town_page1 ? n(S.town_page1) : 'None'}</span><span class="tile-u">page 1 town searches without the name</span>${meter(counts.search)}</button>
<button class="tile" type="button" data-tab-set="ai"><span class="card-k">AI answers</span><span class="big">No data</span><span class="tile-u">not collected yet</span>${meter(counts.ai)}</button>
<button class="tile" type="button" data-tab-set="website"><span class="card-k">Website</span><span class="big">${W.phone ? W.phone.score : ''}</span><span class="tile-u">of 100 on a phone, lab test</span>${meter(counts.website)}</button>
<button class="tile" type="button" data-tab-set="links"><span class="card-k">Links and listings</span><span class="big">${n(L.with_weight)}</span><span class="tile-u">linking sites that carry weight, of ${n(L.sites)}</span>${meter(counts.links)}</button>
</div>`;
const firstOurs = tasks.filter(t => t.owner === 'us').slice(0, 3), clientTasks = tasks.filter(t => t.owner === 'client');
const cnt = { us: tasks.filter(t => t.owner === 'us').length, client: clientTasks.length, account: acct.length, software: soft.length };
const overviewServiceTop = `<div data-only="service">
  <div class="hero"><p class="eyebrow">${DOC ? e(DOC) : 'Service view'} · ${e(B.short)}, ${e(B.city)} · report of ${e(meta.report_date)}</p>
  <h1 class="h1"><span data-count="open">${ours.length}</span> things to do. <span class="h1-a">Start with these.</span></h1>
  <p class="lead"><span data-count="us">${cnt.us}</span> ours, <span data-count="client">${cnt.client}</span> the client's, <span data-count="done">0</span> done. <span data-internal>${cnt.software} more are for the software team and ${cnt.account} for the account manager.</span></p><p class="src">${sourceLine}</p></div>
  <div class="sec" id="do-first" style="padding-top:0"><div class="grid2"><div><p class="grp" style="margin-top:0">Ours today</p><div class="tasks">${firstOurs.map((t, i) => taskCard(t, { open: i === 0 })).join('')}</div></div>
    <div><p class="grp" style="margin-top:0">Ask the client</p><div class="tasks">${clientTasks.map(t => taskCard(t)).join('') || '<p class="note">Nothing for the client in this report.</p>'}</div><p class="note">Copy puts a task on your clipboard, ready to paste to whoever does it. The Tasks tab has all ${tasks.length}.</p><p style="margin-top:14px"><button class="btn" type="button" data-tab-set="plan">All tasks</button></p></div></div></div>
</div>`;
const overviewServiceRest = `<div data-only="service">
  ${holdsHtml}
  ${changesHtml}
  <div class="sec"><h2 class="h2">Health by area</h2><p class="sub">Open an area for its numbers, its checks and its tasks.</p>${doorTiles}</div>
</div>`;
fact('Do first', `${firstOurs.length} tasks to start with`, 'overview', 'do-first', 'what do i do first top 3 three tasks today start priority quick wins next steps tell the client first', 'service');
fact('Not safe to quote yet', `${holds.length} numbers on hold`, 'overview', 'holds', 'what can i not quote show client hold trust safe numbers data problems can i trust the map number', 'service');
fact('What changed since the last report', CH.first_run ? 'First report' : `${CH.new_problems.length} new, ${CH.fixed.length} fixed, ${CH.still} still open`, 'overview', 'since', 'changed change new fixed yesterday last run difference', 'service');

// ---------- Google Maps ----------
const maxMonth = RV ? Math.max(...RV.monthly.map(m => m.n)) : 0;
const reviewCols = RV ? `<div class="cols" role="img" aria-label="Reviews received each month">${RV.monthly.map(m => `<div class="col" data-tip="${e(`${m.label}: ${m.n} ${m.n === 1 ? 'review' : 'reviews'}, average ${m.avg}`)}"><div class="col-bar" style="height:${pct(m.n, maxMonth)}%"></div></div>`).join('')}</div><div class="axis"><span>${e(RV.monthly[0].label)}</span><span>${e(RV.monthly[RV.monthly.length - 1].label)}</span></div>` : '';
const dist = B.rating_dist ? bars([5, 4, 3, 2, 1].map(s => ({ label: `${s} star${s === 1 ? '' : 's'}`, v: B.rating_dist[s] || 0 })), 'ratings') : '';
fact('Reviews', `${n(B.ratings)} Google ratings, ${B.rating} stars`, 'maps', 'reviews', 'how many review count rating stars total reviews do we need');
if (RV) { if (V2 && RV.last_90 !== undefined) { fact('Reviews in the last 90 days', n(RV.last_90), 'maps', 'reviews', 'review pace velocity new reviews 3 months'); fact('Reviews in the last 365 days', n(RV.last_365), 'maps', 'reviews', 'review pace 12 months year'); } else { fact('Reviews in the last 3 months', n(RV.last_3), 'maps', 'reviews', 'review pace velocity new reviews'); fact('Reviews in the last 12 months', n(RV.last_12), 'maps', 'reviews', 'review pace'); } fact('Reviews with an owner reply', `${n(RV.with_reply)} of ${n(RV.collected)}`, 'maps', 'reviews', 'reply response answered');
  if (!V2 || RV.low_open_list.length) fact('Low-star reviews with no reply', `${n(RV.low_open)}, ${n(RV.low_open_12)} from the last 12 months`, 'maps', 'low-open', 'unanswered 1 star 2 star complaint bad reviews how many bad', 'service'); fact('What the low-star reviews are about', RV.low_subjects.filter(s => s.n).map(s => `${s.n} ${s.label}`).join('; '), 'maps', 'subjects', 'complaint complaints discount price staff what do customers say bad reviews', 'service'); }
for (const t of B.topics.slice(0, 10)) fact(`Customers mention: ${t.label}`, `${n(t.n)} times`, 'maps', 'topics', 'what do customers say reviews topics mention');
const board = `<div class="board" id="board">${maps.board.map(b => `<div class="board-row${b.is_you ? ' board-you' : ''}" data-tip="${e(`${b.name}: in Google's top 3 at ${b.share}% of the points checked`)}"><div class="board-n">${e(b.short)}</div><div class="b-track"><div class="b-fill" style="width:${pct(b.share, 100)}%"></div></div><div class="board-v">${e(String(b.share))}<span class="unit">%</span></div></div>`).join('')}</div>`;
if (!V2) {
fact('Map shares on file (on hold)', maps.board.map(b => `${b.short} ${b.share}%`).join(', '), 'maps', 'board', 'map rank share points why is the map low solv local pack competitors', 'service');
fact('When the map check ran', `${maps.scanned}; the store closes at ${maps.close}`, 'maps', 'board', 'when was the scan scan time closed after hours', 'service');
}
const mapsSalesHead = head(`Google Maps · ${place}`, 'A strong listing.', 'The map check comes next.', `The basics Google asks of a listing are in place: ${n(B.ratings)} ratings at ${B.rating} stars, the right category, hours and ways to shop. The one map check on file ran after closing time, so its numbers are not quoted here.`, 'sales');
const mapsTeamHead = head(`Google Maps · ${place}`, 'Map numbers are on hold.', 'Check again in opening hours.', maps.hold_reasons.join(' '), 'service');
// with our own checks on file the team reads what they show; without them, what is still unknown
const leadersInTurn = MK ? MK.series.map(s => s.leader).filter((x, i, a) => i === 0 || x !== a[i - 1]) : [];
const basics = GAPS.filter(g => /-1$/.test(g.id));
// v2: what the software's own fit over this store's checks says, factor by factor (escaped here: the list below is inserted as HTML)
const v2Factors = V2 ? (maps.factors || []) : [];
const v2Why = () => { const held = v2Factors.filter(f => f.survives), ns = v2Factors.filter(f => !f.survives && f.n >= 30), few = v2Factors.filter(f => !f.survives && f.n < 30 && f.n > 0);
  return [...V2S.map(s => e(s.you_lead ? `For "${s.kw}" the store is number 1 at ${s.you} of ${s.n} points${s.second ? `; ${s.second} is next with ${s.second_points}` : ''}.` : `For "${s.kw}" it is ${s.place ? ordinalOf(s.place) : 'in the top 3 at none'} at ${s.you} of ${s.n} points; ${s.leader} is number 1 with ${s.leader_floor ? 'at least ' : ''}${s.leader_points}.`)),
    ...held.map(f => e(`${f.factor} holds up after the software's control: rank correlation ${f.rho}, ${f.partial} with the control, over ${f.n} rows.${f.refit && f.refit.far_rows ? ` That includes ${f.refit.far_rows} out-of-market rows; ${Number(f.refit.without_far).toFixed(2)} without them.` : ''}`)),
    ns.length ? e(`No link the software can stand behind for ${ns.map(f => `${f.factor.toLowerCase()} (${f.rho})`).join(', ')}: not significant over ${ns[0].n === ns[ns.length - 1].n ? ns[0].n : 'their'} rows.`) : null,
    few.length ? e(`Too few rows to test: ${few.map(f => `${f.factor.toLowerCase()} (${f.n})`).join(', ')}.`) : null,
    maps.model && maps.model.notes ? e(`The fit: ${maps.model.notes}`) : null].filter(Boolean); };
const whyShown = V2 ? v2Why() : MK ? [`For "${e(MK.main.kw)}" the store held ${MK.middle} of ${MK.main.n} points at the middle one of its ${MK.prior} earlier checks. It holds ${MK.main.you} now.`,
  leadersInTurn.length > 1 ? `Number 1 changed hands ${leadersInTurn.length - 1} times in ${MK.series.length} checks: ${leadersInTurn.map(e).join(', then ')}.` : null,
  basics.length ? `On ${basics.filter(g => g.lead).length} of the ${basics.length} listing lines set beside number 1, the store is level or ahead.` : null,
  MK.town ? `For searches that name the town it holds ${MK.town.you} of ${MK.town.n} points.` : null].filter(Boolean)
  : ['How the store shows in a check taken while it is open', "The rivals' listings and hours: not in the record", 'The result at each map point, and how far each store sits from it', "Whether some points returned another area's results"];
const whyLow = `<div class="sec" data-only="service" data-internal><div class="card" id="why-low"><p class="card-k">${V2 ? "Why the map looks the way it does: what is in place, what the software's own fit for this market says" : MK ? 'Why the map is low: what is ruled out, what the checks show' : 'Why the map may be low: what is ruled out, what is not known'}</p><div class="grid2"><div><p class="tk-h">In place</p><ul class="miss">${checks.filter(c => c.door === 'maps' && c.weight === 'rank' && c.status === 'pass').map(c => `<li>${e(c.title)}</li>`).join('')}</ul></div><div><p class="tk-h">${V2 ? "What the checks and the software's fit show" : MK ? 'What our own checks show' : 'Not known yet'}</p><ul class="miss">${whyShown.map(x => `<li>${x}</li>`).join('')}</ul></div></div></div></div>`;
fact('Why the map may be low', 'What is ruled out and what is not known', 'maps', 'why-low', 'why is the map low reason rank drop map rank', 'service');
// the map check as the scan tool handed it to the software: who led, what it saw, and every check on file
const band = maps.far ? [['Within 25 miles', maps.far.within_25], ['25 to 150 miles', maps.far.mid], ['More than 150 miles away', maps.far.over_150]] : [];
const bandCls = ['st-3', 'st-2', 'st-far'];
const seenStrip = band.length ? `<p class="card-k" style="margin-top:26px">The ${n(maps.far.seen)} businesses the check listed, by distance from the store${maps.far.seen > maps.far.placed ? ` (${n(maps.far.seen - maps.far.placed)} could not be placed)` : ''}</p><div class="stack" role="img" aria-label="${e(band.map(([k, v]) => `${k}: ${v}`).join(', '))}">${band.map(([k, v], i) => `<div class="st-seg ${bandCls[i]}" style="flex:${v}" data-tip="${e(`${k}: ${n(v)} businesses`)}">${n(v)}</div>`).join('')}</div><div class="legend">${band.map(([k, v], i) => `<span class="lg-i"><span class="lg-s ${bandCls[i]}"></span>${e(k)}: ${n(v)}</span>`).join('')}</div>` : '';
const yn = v => v === true ? 'Open' : v === false ? 'Closed' : 'Not known';
const scanTable = maps.scans.length ? `<details class="more" id="scans"><summary>All ${maps.scans.length} map checks on file for this store</summary><div class="more-b"><div class="tw"><table><thead><tr><th>Check</th><th>Finished</th><th>Store was</th><th class="num">Listed</th><th class="num">Nearby</th><th class="num">Far away</th>${C.rivals.map(r => `<th class="num">${e(r.name)}</th>`).join('')}</tr></thead><tbody>${maps.scans.map(s => `<tr><td>${e(s.id)}${s.used ? ' <span class="chip chip-plain">Used here</span>' : ''}</td><td>${e(s.when)}</td><td class="dim">${yn(s.open)}</td><td class="num">${n(s.seen)}</td><td class="num">${s.within_25 === null ? '' : n(s.within_25)}</td><td class="num">${s.far === null ? '' : n(s.far)}</td>${C.rivals.map(r => `<td class="num">${s.places[r.id] ? ordinalOf(s.places[r.id]) : '<span class="dim">Not listed</span>'}</td>`).join('')}</tr>`).join('')}</tbody></table></div><p class="note">Times are the store's own. Listed is how many businesses the check saw; nearby is within 25 miles of the store, far away is more than 150. The last columns give each store's place in the check's list.${maps.list_runs_by_score ? ' In the check used here the list runs in score order, so the place reads as a rank. That is an inference for the other checks: their scores and their search phrases are not in the record.' : ' The record does not say what order the list is in.'}</p></div></details>` : '';
function ordinalOf(k) { return `${k}${k % 100 >= 11 && k % 100 <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][k % 10] || 'th'}`; }
const scanCard = `<div class="card scan" id="scan"${maps.hold ? ' data-only="service" data-internal' : ''}><p class="card-k">${MK ? "The software's own map check" : 'The map check on file'}${maps.hold ? ' ' + holdChip : ''}</p>${MK ? `<p class="note" style="margin:0 0 16px">The map on the Overview comes from our own checks. This is the one check the software ran for its report.</p>` : ''}
  <div class="chips scan-meta"><span class="chip chip-plain">Search: ${e(maps.phrase)}</span><span class="chip chip-plain">${e(maps.scanned)}</span>${maps.in_hours === false ? `<span class="chip chip-hold">After the ${e(maps.close)} close</span>` : ''}<span class="chip chip-plain" data-only="service">${maps.started_by_hand ? 'Started by hand' : 'Started on a schedule'}</span>${maps.seen ? `<span class="chip chip-plain" data-only="service">${n(maps.seen)} businesses listed</span>` : ''}</div>
  ${board}<p class="note">Share of the points checked where each store was in Google's top 3. <span data-only="service">The record does not say how many points were checked.</span></p>
  <div data-only="service" data-internal>${seenStrip}${scanTable}
  <div class="empty scan-gap" id="scan-gap"><p class="empty-t">The map itself is not in the record</p><p>Where the store ranks at each point around town, and a score and a name for each of the ${n(maps.seen)} businesses, stay in the scan tool. The record hands back the list each check saw and a score for ${maps.board.length} stores in one check.</p></div></div></div>`;
if (!V2) {
fact('Every map check on file', `${maps.scans.length} checks, ${maps.scans.filter(s => s.open === true).length} finished while the store was open`, 'maps', 'scans', 'scan history earlier scans eagle eyes geogrid grid map checks list', 'service');
fact('The map, point by point', 'Not in the record', 'maps', 'scan-gap', 'grid dots map points geogrid heat map embed scan picture', 'service');
}
// the Google listings at the top of the map, side by side: the store's from the software's read, the others' from our own
const listingsCard = (() => {
  if (V2) return '';
  const LL = MARKET && MARKET.listings; if (!LL || !LL.rows.length || !MV) return '';
  const main = MARKET.scans[MV.byKey(MK.main.key)], ptsOf = b => { const f = main.field.find(x => x[0] === b); return f ? f[1] : null; };
  const paceOf = b2 => { const v = MARKET.velocity && MARKET.velocity.rows.find(x => x.b === b2); return v ? v.per_month : null; };
  const mine = { me: true, short: B.short, pts: MK.main.you, rating: B.rating, reviews: B.ratings, photos: B.photos, ways: B.service_options.length, attributes: B.attributes.length, claimed: B.claimed, category: B.category, pace: MK.velocity ? MK.velocity.you.per_month : null, lands: B.listing_is_homepage === null ? null : B.listing_is_homepage ? 'home' : 'inner' };
  const list = [mine, ...LL.rows.filter(r => r.b !== MARKET.subject).map(r => ({ ...r, short: MARKET.biz[r.b].short, pts: ptsOf(r.b), pace: paceOf(r.b), lands: MARKET.biz[r.b].lands || null }))].sort((a, b) => (b.pts ?? -1) - (a.pts ?? -1));
  const others = list.filter(r => !r.me && r.pts !== null && r.reviews !== null), top3 = [...others].sort((a, b) => b.pts - a.pts).slice(0, 3);
  const lean = [...top3].sort((a, b) => a.reviews - b.reviews)[0], heavy = [...others].sort((a, b) => b.reviews - a.reviews)[0];
  const contrast = lean && heavy && heavy.pts < lean.pts && heavy.reviews > lean.reviews * 5 ? ` More ratings do not line up with more of the map here: ${e(lean.short)} holds ${lean.pts} points with ${n(lean.reviews)} ratings, and ${e(heavy.short)} has ${n(heavy.reviews)} ratings and holds ${heavy.pts}.` : '';
  const sameCat = list.every(r => r.category === B.category);
  fact('The Google listings at the top of the map', `${list.length} listings side by side`, 'maps', 'cmp-listings', 'compare competition rivals listing gbp profile photos stars ratings ways to shop number 1 versus side by side');
  return `<div class="card" id="cmp-listings"><p class="card-k">The Google listings at the top of the map</p><div class="tw"><table><thead><tr><th>Business</th><th class="num">Map points</th><th class="num">Stars</th><th class="num">Ratings</th><th class="num">New a month</th><th class="num">Photos</th><th class="num">Ways to shop</th><th class="num">Details</th><th>Link goes to</th><th>Claimed</th></tr></thead><tbody>${list.map(r => `<tr${r.me ? ' class="row-you"' : ''}><td class="nw">${e(r.short)}</td><td class="num">${r.pts === null ? '' : r.pts}</td><td class="num">${r.rating === null ? '' : Number(r.rating).toFixed(1)}</td><td class="num">${n(r.reviews)}</td><td class="num">${r.pace === null ? '' : n(Math.round(r.pace))}</td><td class="num">${n(r.photos)}</td><td class="num">${n(r.ways)}</td><td class="num">${n(r.attributes)}</td><td class="dim">${r.lands === 'home' ? 'Front page' : r.lands === 'inner' ? 'Store page' : 'Not known'}</td><td>${r.claimed ? 'Yes' : 'No'}</td></tr>`).join('')}</tbody></table></div><p class="note">Map points are the points in Google's top 3 for "${e(MK.main.kw)}", ${e(MK.main.date)}, of ${MK.main.n}. Details counts the extra fields filled in on the listing, and the link is where the listing's website button leads. ${e(B.short)}'s listing as read ${e(B.profile_read_at)}, the others' on ${e(MK.listings_read || '')}.${MK.velocity ? ` New a month is review velocity, the Google ratings each business added a month, counted at our map checks, ${e(MK.velocity.live_from)} to ${e(MK.velocity.to)}.` : ''}${sameCat ? ` All ${list.length} have the same main category, ${e(B.category)}.` : ''}${contrast}</p></div>`;
})();
const paceTable = (() => {
  if (V2) return '';
  const VV = MARKET && MARKET.velocity; if (!VV || !MK || !MK.velocity || !MV) return '';
  const main = MARKET.scans[MV.byKey(MK.main.key)], ptsOf = b2 => { const f = main.field.find(x => x[0] === b2); return f ? f[1] : null; };
  // a business whose count fell sharply between two checks is listed without a pace and without a place
  const paced = VV.rows.filter(x => x.per_month !== null);
  const rows = VV.rows.map(r => ({ ...r, place: r.per_month === null ? null : 1 + paced.filter(x => x.per_month > r.per_month).length, short: MARKET.biz[r.b].short, me: r.b === MARKET.subject, pts: ptsOf(r.b) }));
  for (const r of rows) fact(`Review velocity: ${r.short}`, r.per_month === null ? 'No pace, its count fell between two checks' : `${n(Math.round(r.per_month))} new a month`, 'maps', 'pace-all', 'review velocity pace reviews per month new ratings how fast speed competitor');
  const resetNote = (MK.velocity.resets || []).map(x => ` ${e(x.name)} has no pace: its count fell from ${n(x.before)} on ${e(x.before_on)} to ${n(x.after)} on ${e(x.after_on)}.`).join('');
  fact('Review velocity', `${n(Math.round(MK.velocity.you.per_month))} new ratings a month, ${MapView.ord(MK.velocity.you.place)} fastest of ${MK.velocity.you.of}`, 'maps', 'cmp-velocity', 'review velocity pace reviews per month new ratings how fast speed momentum');
  // a faster pace and more of the map do not go hand in hand here: say so with the two plainest cases
  const top = rows.filter(r => r.pts !== null && !r.me && r.per_month !== null).sort((x, y) => y.pts - x.pts).slice(0, 5), slow = [...top].sort((x, y) => x.per_month - y.per_month)[0];
  const fast = rows.filter(r => r.pts !== null && !r.me && r.per_month !== null && slow && r.pts < slow.pts).sort((x, y) => y.per_month - x.per_month)[0];
  const contrast = slow && fast && fast.per_month > slow.per_month * 3 ? ` A faster pace does not line up neatly with more of the map: ${e(slow.short)} holds ${slow.pts} points while adding ${n(Math.round(slow.per_month))} a month, and ${e(fast.short)} adds ${n(Math.round(fast.per_month))} a month and holds ${fast.pts}.` : '';
  return `<details class="more" id="pace-all"><summary>Review velocity of the ${rows.length} businesses our map checks followed</summary><div class="more-b"><div class="tw"><table><thead><tr><th class="num">Place</th><th>Business</th><th class="num">New ratings a month</th><th class="num">Ratings at the start</th><th class="num">Ratings at the end</th><th class="num">Days counted</th><th class="num">Map points, top 3</th></tr></thead><tbody>${rows.map(r => `<tr${r.me ? ' class="row-you"' : ''}><td class="num">${r.place === null ? '' : r.place}</td><td class="nw">${e(r.short)}</td><td class="num">${r.per_month === null ? 'Count fell' : n(Math.round(r.per_month))}</td><td class="num">${n(r.from)}</td><td class="num">${n(r.to)}</td><td class="num">${Math.round(r.days)}</td><td class="num">${r.pts === null ? 'Not in this check' : r.pts}</td></tr>`).join('')}</tbody></table></div><p class="note">Review velocity is the number of new Google ratings a business adds in a month, less any that were removed. Counted from the ratings our map checks recorded, ${e(MK.velocity.live_from)} to ${e(MK.velocity.to)}. A business is listed when our checks recorded its ratings over three weeks or more, and one that first appeared later is counted from its first check.${resetNote} Map points are for "${e(MK.main.kw)}", ${e(MK.main.date)}.${contrast}</p></div></details>`;
})();
// ---------- v2: the Google Maps comparisons from the new data ----------
const v2Listings = () => { const rows = C.listings || []; if (!rows.length) return '';
  const none = v => v === null || v === undefined ? '<span class="dim">None</span>' : n(v);
  const row = r => `<tr${r.me ? ' class="row-you"' : ''}><td class="nw">${e(r.short)}</td><td class="num">${r.pts === null || r.pts === undefined ? '' : r.pts}</td><td class="num">${r.rating === null || r.rating === undefined ? '<span class="dim">None</span>' : Number(r.rating).toFixed(1)}</td><td class="num">${none(r.reviews)}</td><td class="num">${none(r.photos)}</td><td class="num">${n(r.ways)}</td><td class="num">${n(r.attributes)}</td><td class="dim">${r.lands === 'home' ? 'Front page' : r.lands === 'inner' ? 'Store page' : 'Not known'}</td><td>${r.claimed ? 'Yes' : 'No'}</td><td class="num">${r.me || r.miles === null || r.miles === undefined ? '' : Number(r.miles).toFixed(1)}</td></tr>`;
  const head2 = '<thead><tr><th>Business</th><th class="num">Top 3 points</th><th class="num">Stars</th><th class="num">Ratings</th><th class="num">Photos</th><th class="num">Ways to shop</th><th class="num">Details</th><th>Link to</th><th>Claimed</th><th class="num">Miles</th></tr></thead>';
  const top = rows.slice(0, 12), rest = rows.slice(12), sameCat = top.every(r => r.category === B.category);
  fact('The Google listings at the top of the map', `${rows.length} listings side by side`, 'maps', 'cmp-listings', 'compare competition rivals listing gbp profile photos stars ratings ways to shop number 1 versus side by side');
  return `<div class="card" id="cmp-listings"><p class="card-k">The Google listings at the top of the map</p><div class="tw"><table class="fit">${head2}<tbody>${top.map(row).join('')}</tbody></table></div>${rest.length ? `<details class="more"><summary>The other ${rest.length} businesses in the check with a Google listing read</summary><div class="more-b"><div class="tw"><table class="fit">${head2}<tbody>${rest.map(row).join('')}</tbody></table></div></div></details>` : ''}<p class="note">Map points are the points in Google's top 3 for "${e(C.listings_kw)}", of ${n(C.listings_n)}. Details counts the extra fields filled in on the listing, and the link is where the listing's website button leads. Every listing as read for this report, ${e(B.profile_read_at === meta.report_date ? meta.report_date : `${B.profile_read_at} and ${meta.report_date}`)}.${sameCat ? ` The first ${top.length} have the same main category, ${e(B.category)}.` : ''}</p></div>`; };
const v2Pace = () => { const rows = C.velocity || []; if (rows.length < 2) return ''; const me = rows.find(r => r.is_you);
  const pm = w => w ? n(Math.round(w.per_month)) : 'Not whole';
  for (const r of rows) fact(`Review velocity: ${r.name}`, r.d90 ? `${n(Math.round(r.d90.per_month))} new reviews a month over 90 days` : 'Not counted', 'maps', 'pace-all', 'review velocity pace reviews per month new ratings how fast speed competitor');
  const capped = rows.filter(r => r.capped);
  return `<details class="more" id="pace-all"><summary>Review velocity of the store and the ${rows.length - 1} rivals, window by window</summary><div class="more-b"><div class="tw"><table class="fit"><thead><tr><th>Business</th><th class="num">A month, last 30 days</th><th class="num">A month, last 90 days</th><th class="num">A month, last 365 days</th><th class="num">Last 90 days answered</th><th class="num">Map points, top 3</th></tr></thead><tbody>${rows.map(r => `<tr${r.is_you ? ' class="row-you"' : ''}><td class="nw">${e(r.name)}</td><td class="num">${pm(r.d30)}</td><td class="num">${pm(r.d90)}</td><td class="num">${pm(r.d365)}</td><td class="num">${r.d90 ? `${n(r.d90.replied)} of ${n(r.d90.n)}` : ''}</td><td class="num">${r.points === null ? '' : r.points}</td></tr>`).join('')}</tbody></table></div><p class="note">Review velocity is the number of new Google reviews a store gets in a month, counted from its own dated reviews over the 30, 90 and 365 days to ${e(C.velocity_window ? C.velocity_window.to : meta.report_date)}.${capped.length ? ` ${e(capped.map(r => r.name).join(' and '))}: the read stopped at the depth asked for, so the store's total is not counted; it reaches back past a year, so every window is whole.` : ''}${C.velocity_agrees ? ` ${e(B.short)}'s counts agree with the software's own.` : ''} Map points are for "${e(C.listings_kw || '')}".</p></div></details>`; };
const v2Scans = () => { const list = v2Sweeps; if (!list.length) return '';
  fact('The map checks on file', `${list.length} checks, ${list.filter(s => s.open === true).length} in opening hours`, 'maps', 'scans', 'scan history scans geogrid grid map checks list when was the scan after hours far away out of market', 'service');
  return `<div class="card scan" id="scans" data-only="service" data-internal><p class="card-k">The map checks the software ran for this store</p><div class="tw"><table class="stack-sm"><thead><tr><th>Search</th><th>Finished</th><th>Store hours that day</th><th class="num">Points</th><th>How it was started</th><th>Far-away businesses</th></tr></thead><tbody>${list.map(s => `<tr><td>${e(s.kw)}</td><td>${e(s.finished)}${s.open === false ? ' <span class="chip chip-hold">Closed</span>' : ''}</td><td class="dim">${e(s.store_day_hours || 'Not listed')}</td><td class="num">${s.n}${s.excluded ? ` <span class="dim">(${s.excluded} left out)</span>` : ''}</td><td class="dim">${s.started_by_hand ? `Started by ${e(s.starter_role === 'admin' ? 'an admin' : 'a user')}` : 'No record of who started it or when'}${s.started_how ? ` (${e(String(s.started_how).replace(/_/g, ' '))})` : ''}</td><td class="dim">${s.far.over_150 ? `${n(s.far.over_150)} of ${n(s.far.of)} rows, about ${n(s.far.miles[0])} miles away; in the first 20 at ${n(s.far.points)} points, in a top 3 at ${n(s.far.in_top3)}` : 'None'}</td></tr>`).join('')}</tbody></table></div><p class="note">Times are the store's own. A far-away business in a point's top 3 would put that check on hold; lower in the list it is a note for the software team. The store's place at each point, its place in each point's list and the software's share agree for every check.</p></div>`; };
const v2MapsCmp = () => cmpPanel('cmp-maps', `<p class="sub" data-only="sales">The businesses at the top of the map, by what Google shows on each listing, and the three stores this report follows.</p><p class="sub" data-only="service">Two sets: the top of the map in the software's own checks, with the Google listing the run read for each, and the three rivals the run names, with their reviews read the same way as the store's.</p>`,
  `${cmpGrid(C.rows.filter(r => r.door === 'maps' && /^map-/.test(r.id)).sort((a, b) => (a.place === 1) - (b.place === 1) || (b.place || 99) - (a.place || 99)).map(r => cstat(r)))}<div class="cmp-gap"></div>${v2Listings()}<div class="cmp-gap"></div>${cmpGrid([cstat(rowOf('ratings')), cstat(rowOf('stars')), cstat(rowOf('photos'))])}<div class="cmp-gap"></div>${cmpGrid([cstat(rowOf('velocity')), cstat(rowOf('replies-90'))])}${v2Pace()}<div class="cmp-gap" data-only="service"></div>${v2Scans()}<div class="cmp-gap" data-only="service"></div>${cmpGrid([cstat(rowOf('reviews-pulled')), cmpMissing('maps')])}`);
const v2MapsHead = () => head(`Google Maps · ${place}`, verdict.a || '', verdict.b || '', `${V2S.map((s, i) => { const who = i === 0 ? B.short : 'it'; return s.you_lead ? `For "${s.kw}" ${who} is number 1, at ${s.you} of ${s.n} points${s.second ? `; ${s.second} is next with ${s.second_points}` : ''}.` : `For "${s.kw}" ${who} is ${s.place ? ordinalOf(s.place) : 'in the top 3 at none'}, at ${s.you} of ${s.n} points; ${s.leader} is number 1 with ${s.leader_floor ? 'at least ' : ''}${s.leader_points}.`; }).join(' ')} Checked ${[...new Set(V2S.map(s => s.date))].join(' and ')}.`);
const mapsCmp = V2 ? v2MapsCmp() : cmpPanel('cmp-maps',`<p class="sub" data-only="sales">${MK ? `The businesses at the top of the map, and the ${C.nearby.length} stores Google lists beside ${e(B.short)}.` : `The ${C.nearby.length} stores Google lists beside ${e(B.short)}, by what Google shows on each listing.`}</p><p class="sub" data-only="service">${MK ? `Three sets: the top of the map from our own checks, the ${C.nearby.length} stores Google lists beside this one, and the ${C.rivals.length} stores with a score in the software's own check.` : `Two sets, from two readings: the ${C.rivals.length} stores with a score in the map check on file, and the ${C.nearby.length} stores Google lists beside this one.`}</p>`,
  `${MK ? `${listingsCard}<div class="cmp-gap"></div>` : ''}${cmpGrid([cstat(rowOf('ratings')), cstat(rowOf('stars')), cstat(rowOf('velocity'))])}${paceTable}<div class="cmp-gap" data-only="service"></div>${scanCard}<div class="cmp-gap" data-only="service"></div>${cmpGrid([cstat(rowOf('reviews-pulled')), cmpMissing('maps')])}`);
const mapsHead = V2 ? v2MapsHead() : MK ? head(`Google Maps · ${place}`, `Top 3 at ${MK.main.you} of ${MK.main.n} points.`, MK.main.you_lead ? 'Number 1 on the map.' : `Number 1 holds ${MK.main.leader_points}.`, `For "${MK.main.kw}", checked ${MK.main.when}.${MK.main.you_lead ? '' : ` ${MK.main.leader} is number 1.`}${MK.won.length && MK.word ? ` For searches with "${MK.word}" in them the store is in the top 3 at every point.` : ''}${MK.town ? ` For searches that name the town it holds ${MK.town.you} of ${MK.town.n}.` : ''}`)
  : maps.hold ? mapsSalesHead + mapsTeamHead : head(`Google Maps · ${place}`, `In Google's top 3 at ${maps.board.find(b => b.is_you)?.in100} of every 100 points.`, '', `Checked ${maps.scanned} for "${maps.phrase}".`);
const mapsTab = `${mapsHead}
<div id="map-slot"></div>
${mapsCmp}
<div class="sec"><div class="grid2">
  <div class="card" id="reviews"><p class="card-k">Reviews</p><div class="row"><div class="big">${n(B.ratings)}<span class="unit">ratings</span></div><div class="big">${B.rating}<span class="unit">stars</span></div></div>${reviewCols}<p class="note">${RV ? (V2 && RV.last_90 !== undefined ? `Reviews received each month. The first ${n(RV.opening_n)} reviews came within 10 weeks, from ${e(RV.first)}. The last 90 days brought ${n(RV.last_90)}, ${RV.pace_90} a month (a month is 30.4 days).` : `Reviews received each month. ${n(RV.opening_n)} came in the 10 weeks after the first one (${e(RV.first)}). The last 3 months brought ${n(RV.last_3)}, about ${n(Math.round(RV.pace_recent))} a month.`) : ''}</p></div>
  <div class="card"><p class="card-k">How the ratings split</p>${dist}</div>
</div></div>
<div class="sec"><div class="grid2">
  <div class="card"><p class="card-k">The Google listing</p>${kv([...listingRows(false), ['Full link, with its tags', B.listing_full_link, 'fact-full-link', 'service']])}</div>
  <div class="card" id="topics"><p class="card-k">What customers mention in reviews</p><div class="chips">${B.topics.slice(0, 10).map(t => `<span class="chip chip-plain">${e(t.label)} · ${n(t.n)}</span>`).join('')}</div><p class="note">The words Google pulls out of the store's reviews, and how often each comes up.</p></div>
</div></div>
${checkBlock('maps')}
${whyLow}
${RV && RV.low_12 ? `<div class="sec" data-only="service" data-internal><div class="card" id="subjects"><p class="card-k">What the ${RV.low_12} low-star reviews of the last 12 months are about, by word match</p>${bars(RV.low_subjects.map(s => ({ label: cap1(s.label), v: s.n })), 'reviews')}<p class="note">A review can count under more than one subject. ${RV.low_12 - RV.low_12_with_text} of the ${RV.low_12} have no text. Confirm by reading them before taking this to the store.</p></div></div>` : ''}
${doorWork('maps')}
${RV && RV.low_open_list.length ? `<div class="sec" data-only="service" data-internal><details class="more" id="low-open"><summary>Low-star reviews with no reply (${RV.low_open}): ${RV.low_open_12} from the last 12 months, ${RV.low_open - RV.low_open_12} older</summary><div class="more-b">${RV.low_open_list.map(r => `<blockquote class="quote" data-quote>${e(r.text)}<span class="quote-m">${r.rating} star${r.rating === 1 ? '' : 's'} · ${e(r.date)}${r.recent ? '' : ' · older than 12 months'}</span></blockquote>`).join('')}<p class="note">The record carries no reviewer name or link. Find each one by its date on the listing.</p></div></details></div>` : ''}`;
function cap1(s) { return String(s).replace(/^\w/, c => c.toUpperCase()); }

// ---------- Google search ----------
const stack = S.buckets ? `<div class="stack" role="img" aria-label="Where the website's searches rank">${S.buckets.map((b, i) => `<div class="st-seg st-${i}" style="flex:${b.n}" data-tip="${e(`${b.label}: ${n(b.n)} searches`)}">${b.n / S.keywords_total > 0.045 ? n(b.n) : ''}</div>`).join('')}</div><div class="legend">${S.buckets.map((b, i) => `<span class="lg-i"><span class="lg-s st-${i}"></span>${e(b.label)}: ${n(b.n)}</span>`).join('')}</div>` : '';
const kwTable = rows => `<div class="tw"><table><thead><tr><th>Search</th><th class="num">Searches a month</th><th class="num">Rank</th><th>Page it lands on</th></tr></thead><tbody>${rows.map(k => `<tr><td>${e(k.kw)}</td><td class="num">${n(k.volume)}</td><td class="num">${k.rank}</td><td class="dim">${e(k.page)}</td></tr>`).join('')}</tbody></table></div>`;
for (const k of [...S.top_brand, ...S.top_plain]) fact(`Search: ${k.kw}`, `rank ${k.rank}`, 'search', 'kw-all', `keyword keywords ${k.page}`);
if (!V2) fact(`Page 1 for "${B.city} dispensary" searches`, S.town_page1 ? n(S.town_page1) : 'None', 'search', 'town', `${B.city.toLowerCase()} dispensary rank town search content gap`);
fact('Searches the whole website shows up for', n(S.keywords_total), 'search', 'positions', 'keywords ranking footprint seo'); fact('Searches on page 1', n(S.top10), 'search', 'positions', 'top 10 keywords');
for (const s of C.search_sites) fact(`Meets you in search: ${s.domain}`, `${n(s.shared)} shared searches`, 'search', 'cmp-search-sites', 'compare competition search competitors who ranks same keywords overlap directories');
const meet = C.search_sites[0] || null;
const sitesCard = C.search_sites.length ? `<div class="card" id="cmp-search-sites"><p class="card-k">The websites you meet most in Google's results</p><div class="tw"><table><thead><tr><th>Website</th><th class="num">Searches shared with yours</th><th class="num">Their searches in all</th><th class="num">Their estimated visits a month</th></tr></thead><tbody>${C.search_sites.map(s => `<tr><td>${e(s.domain)}${s.rival ? ` <span class="chip chip-plain">${e(s.rival)}</span>` : ''}</td><td class="num">${n(s.shared)}</td><td class="num">${n(s.searches)}</td><td class="num">${n(s.visits)}</td></tr>`).join('')}</tbody></table></div><p class="note">Shared means both websites show up in Google's first 100 results for the same search. ${e(meet.domain)} is there for ${n(meet.shared)} of the ${n(S.keywords_total)} searches this website shows up for. Outside estimates for whole websites.</p></div>` : '';
const searchCmp = cmpPanel('cmp-search', `<p class="sub">${V2 ? `The websites of the ${C.rivals.length} stores this report follows, and the websites that show up for the same searches as yours.` : `The websites of the ${C.rivals.length} stores that led the one map check on file, and the websites that show up for the same searches as yours.`}</p>`,
  `${cmpGrid([cstat(rowOf('searches')), cstat(rowOf('visits'))])}<div class="cmp-gap"></div>${sitesCard}<div class="cmp-gap" data-only="service"></div>${cmpMissing('search')}`);
if (!V2) { fact("Estimated visits a month to this store's pages", n(S.store_visits), 'search', 'byname', 'traffic organic visits'); fact('Visits that come from the brand name, whole website, estimated', `${S.brand_visit_share}%`, 'search', 'byname', 'brand branded non-brand name'); }
if (S.other_store_page) fact(`The second ${B.city} page`, S.other_store_page, 'search', 'two-pages', 'dispensary-locations page two pages which page');
const v2SearchTab = () => { const row = rowOf('searches'), b = row && row.place ? (row.place === row.of ? `The fewest of the ${row.of} websites.` : `${cap1(ordinalOf(row.place))} of ${row.of} websites.`) : '';
  fact('Which searches the website shows up for', 'Not read for this report', 'search', 'search-unread', 'which keywords searches ranking list top searches', '');
  return `${head(`Google search · ${B.domain}`, `${n(S.keywords_total)} searches for the whole website.`, b || 'An outside estimate.', "Where the whole website shows up in Google's regular results, beside the rivals' one-store websites. Every figure here is an outside estimate for a whole website; a website for many stores is not set beside this one.")}
${searchCmp}
<div class="grid2">
  <div class="card" id="positions"><p class="card-k">Where the website's ${n(S.keywords_total)} searches rank</p>${stack}<p class="note">${n(S.top10)} are on page 1. ${n(S.keywords_total - S.top10)} sit on page 2 or deeper. Outside estimates for the whole website.</p></div>
  <div class="card" id="search-unread"><p class="card-k">Which searches they are</p><p class="card-t">Not part of this report</p><p class="note">The counts on this tab say how many searches each website shows up for. Which searches they are, for this website and for the rivals', comes next: that is where the missed searches will show.</p></div>
</div>
${checkBlock('search')}
${doorWork('search')}`; };
const searchTab = V2 ? v2SearchTab() : `${head(`Google search · ${B.domain}`, S.name_town ? `Number ${S.name_town.rank} for its name.` : 'Found by name.', S.town_page1 ? 'On page 1 by town.' : 'Not found by town yet.', "Where the website shows up in Google's regular results, and who finds it there. Search figures here are outside estimates for the whole website, every store.")}
${searchCmp}
<div class="grid2">
  <div class="card" id="town"><p class="card-k">"${e(B.city)} dispensary" searches, without the store's name</p><div class="big">${S.town_page1 ? n(S.town_page1) : 'None'}<span class="unit">on page 1</span></div><p class="note">${S.town_page1 ? '' : `None of the website's ${S.top10} page 1 searches is a ${e(B.city)} search without the store's name in it.`}${S.sister_town_page1_n ? ` The brand's other stores hold ${S.sister_town_page1_n}:` : ''}</p>${S.sister_town_page1.length ? `<div class="chips" style="margin-top:12px">${S.sister_town_page1.map(k => `<span class="chip chip-plain">${e(k.kw)} · ${k.rank}</span>`).join('')}</div>` : ''}</div>
  <div class="card" id="two-pages"><p class="card-k">The ${e(B.city)} pages</p>${S.other_store_page ? `<p class="card-t">Two pages, one job</p>${kv([['The listing links to', S.store_page], ['The other one', S.other_store_page], ['Its title', S.other_store_page_title], ['Links pointing at it', n(S.other_store_page_links)]])}<p class="note">The brand's other stores are found for town searches with both kinds of page: ${Object.entries(S.sister_town_by_kind).map(([k, v]) => `${v} with ${k === 'shop' ? '/shop' : k === 'locations' ? '/dispensary-locations' : 'other'} pages`).join(', ')}. Only ${e(S.store_page)} was read for this report.</p>` : `<p class="card-t">${e(S.store_page)}</p>`}</div>
</div>
<div class="sec"><div class="grid2">
  <div class="card" id="byname"><p class="card-k">Found by name, or found by need</p><div class="big">${n(S.store_visits)}<span class="unit">estimated visits a month to the ${e(B.city)} pages</span></div><p class="note">${n(S.store_name_visits)} of them come from ${S.store_name_searches} searches that contain the store's name. Across the whole website, ${S.brand_visit_share}% of the estimated visits from its ${S.stored} best-ranked searches come from the brand name or a close spelling${S.top_search ? `, and one search, "${e(S.top_search.kw)}", brings ${S.top_search.share}% on its own` : ''}.</p></div>
  <div class="card" id="positions"><p class="card-k">Where the website's ${n(S.keywords_total)} searches rank</p>${stack}<p class="note">${n(S.top10)} are on page 1. ${n(S.keywords_total - S.top10)} sit on page 2 or deeper. Every store's pages are counted.</p></div>
</div></div>
${checkBlock('search')}
${doorWork('search')}
<div class="sec"><details class="more" id="kw-all"><summary>The website's strongest searches</summary><div class="more-b"><p class="card-k">With the brand name</p>${kwTable(S.top_brand)}<p class="card-k" style="margin-top:20px">Without the brand name</p>${kwTable(S.top_plain)}<p class="note">Sites that show up for the same searches most often: ${S.others.slice(0, 5).map(o => `${e(o.domain)} (${n(o.shared)})`).join(', ')}. Directories hold many of the page 1 places for town searches, so a store page has to earn its own.</p></div></details></div>`;

// ---------- AI answers (team only until there is data) ----------
const aiTask = taskById('collect-ai');
const aiTab = `<div data-only="service">${head('AI answers', 'Who do the AI assistants recommend?', 'Not collected yet.', 'This tab will show which stores ChatGPT, Perplexity and Google AI Mode name when buyers ask where to shop. It is planned, and nothing was collected for this report.')}
${cmpPanel('cmp-ai', '<p class="sub">Nothing to set side by side until the answers are collected.</p>', cmpMissing('ai'))}
<div class="empty"><p class="empty-t">No AI answers in this report</p><p>It stays out of the client view until there is data.</p></div>
<div class="sec"><h3 class="h2">Health checks</h3><div class="checks">${doorChecks('ai').map(c => checkRow(c, false)).join('')}</div></div>
${aiTask ? `<div class="sec" data-internal><h3 class="h2">Tasks here</h3><div class="tasks">${taskCard(aiTask)}</div></div>` : ''}</div>`;

// ---------- website ----------
const dial = (label, sp) => sp ? `<svg class="dial" viewBox="0 0 120 120" role="img" aria-label="${label}: ${sp.score} of 100"><circle class="dial-track" cx="60" cy="60" r="50"/><circle class="dial-arc dial-${sp.band}" cx="60" cy="60" r="50" stroke-dasharray="${(314.16 * sp.score / 100).toFixed(1)} 314.16"/><text class="dial-n" x="60" y="66">${sp.score}</text><text class="dial-l" x="60" y="84">${label}</text></svg>` : '';
const METRIC = { lcp: 'Main content shows', fcp: 'First content shows', tbt: 'Page is blocked for', cls: 'Layout shift', si: 'Page looks complete', tti: 'Page fully settles' };
const metricRows = sp => sp ? Object.entries(sp.metrics).map(([k, m]) => `<tr><td>${METRIC[k] || k}</td><td class="num">${e(m.display)}</td><td>${chip(m.band)}</td></tr>`).join('') : '';
if (W.phone) { fact('Phone speed score', `${W.phone.score} of 100, lab test`, 'website', 'speed', 'page speed mobile is the site slow fast load lighthouse'); fact('Desktop speed score', W.desktop ? `${W.desktop.score} of 100` : null, 'website', 'speed', 'page speed'); for (const [k, m] of Object.entries(W.phone.metrics)) fact(`On a phone: ${METRIC[k] || k}`, m.display, 'website', 'speed-detail', `speed metric ${k}`); }
fact('Words our page reader got from the store page', n(W.words), 'website', 'reader', 'content text thin'); fact('Page title', W.title, 'website', 'reader', 'title tag');
fact('Main heading on the store page', W.main_heading_in_list ? 'Present' : 'Not confirmed', 'website', 'reader', 'h1 heading'); if (W.gate_heading) fact('Age check', 'It is what our page reader met on the store page', 'website', 'reader', 'age gate verification 21 popup blocked crawler iframe frame');
// ---------- v2: the store page beside each rival's, read the same way in the same run ----------
const v2Sites = () => { const rows = C.website || []; if (rows.length < 2) return '';
  const page = u => { try { const x = new URL(u); return x.hostname.replace(/^www\./, '') + (x.pathname === '/' ? '' : x.pathname.replace(/\/$/, '')); } catch { return String(u || ''); } };
  fact('The store pages side by side', `${rows.length} pages`, 'website', 'cmp-pages', 'compare competition rivals website page speed words crawler on-page score crawl broken links side by side');
  return `<div class="card" id="cmp-pages"><p class="card-k">The store pages side by side</p><div class="tw"><table class="fit"><thead><tr><th>Store</th><th>Page the listing links to</th><th class="num">Phone speed</th><th class="num">Main content shows</th><th class="num">Words, crawler</th><th class="num">On-page score</th></tr></thead><tbody>${rows.map(r => `<tr${r.is_you ? ' class="row-you"' : ''}><td class="nw">${e(r.name)}</td><td class="dim">${e(page(r.url))}</td><td class="num">${r.phone === null ? '' : r.phone}</td><td class="num">${e(r.lcp || '')}</td><td class="num">${n(r.words)}</td><td class="num">${r.onpage === null ? '' : r.onpage}</td></tr>`).join('')}</tbody></table></div><p class="note">Each store's own page, the one its Google listing links to, read on ${e(W.read_at)}: Google's lab speed test on a phone, then what our plain page reader got from it. An on-page score reads Not confirmed when two reads of the same page disagree.</p></div>`; };
const v2WebsiteCmp = () => cmpPanel('cmp-website', `<p class="sub">The store page beside the page each rival's Google listing links to, read the same way on the same day.</p>`,
  `${cmpGrid([cstat(rowOf('speed-phone')), cstat(rowOf('speed-desktop'))])}<div class="cmp-gap"></div>${cmpGrid([cstat(rowOf('page-words')), cstat(rowOf('crawler-share')), cstat(rowOf('onpage'))])}<div class="cmp-gap"></div>${v2Sites()}<div class="cmp-gap" data-only="service"></div>${cmpGrid([cstat(rowOf('crawl-score'))])}${cmpMissing('website')}`);
const v2WebsiteTab = () => { const row = rowOf('speed-phone'), b = row && row.place && C.speed_order_holds !== false ? (row.place === 1 ? 'The fastest of the store pages on a phone.' : `${cap1(ordinalOf(row.place))} of ${row.of} store pages on a phone.`) : '';
  const ageLine = W.age_gate === true ? (W.thin_to_crawler ? 'On the page, and a crawler gets far less text than a browser' : 'On the page; the text still reaches a crawler') : W.age_gate === false ? 'None found' : 'Not read';
  const sd = checks.find(c => c.id === 'store-details');
  return `${head(`Website · ${B.domain}`, `${W.phone ? W.phone.score : ''} of 100 on a phone.`, b, "How fast the store page is in Google's lab test and what a crawler gets from it, beside the rivals' store pages read the same way.")}
${websiteCmp}
<div class="grid2">
  <div class="card" id="reader"><p class="card-k">What our page reader got from the store page</p><div class="reader"><span class="reader-k">Title</span><span>${e(W.title)}</span><span class="reader-k">Main heading</span><span>${W.main_heading ? e(W.main_heading) : 'Not confirmed'}</span><span class="reader-k">Words</span><span>${n(W.crawler_words ?? W.words)} as a crawler${W.browser_words !== null ? `, ${n(W.browser_words)} in a browser` : ''}</span><span class="reader-k">Age check</span><span>${e(ageLine)}</span><span class="reader-k">Store details</span><span>${e(sd ? sd.value : 'Not read')}</span></div><p class="note">Our reader is not Google. Google's own rich results test settles what Google reads from the page.</p></div>
  <div class="card" id="speed"><p class="card-k">Speed, by Google's lab test</p><div class="row">${dial('Phone', W.phone)}${dial('Desktop', W.desktop)}</div>${W.phone?.fixes.length ? `<p class="card-k" style="margin-top:22px">Where time can be saved on a phone</p><div class="tw"><table><tbody>${W.phone.fixes.map(f => `<tr><td>${e(f.title)}</td><td class="num">about ${f.saves_s} s</td></tr>`).join('')}</tbody></table></div>` : ''}<p class="note">A lab test on a simulated slow phone, not a measure of real visitors.</p></div>
</div>
${checkBlock('website')}
${doorWork('website')}
<div class="sec"><details class="more" id="speed-detail"><summary>Speed test, measure by measure</summary><div class="more-b"><p class="card-k">On a phone</p><div class="tw"><table><tbody>${metricRows(W.phone)}</tbody></table></div><p class="card-k" style="margin-top:20px">On a desktop</p><div class="tw"><table><tbody>${metricRows(W.desktop)}</tbody></table></div></div></details></div>`; };
const websiteCmp = V2 ? v2WebsiteCmp() : cmpPanel('cmp-website', '',`<div class="card" data-only="sales" id="cmp-website-none"><p class="card-t">No rival pages in this report</p><p class="note">The numbers on this tab set the store page against Google's marks for a fast page. The rivals' store pages and their speed are not part of this report.</p></div>${cmpMissing('website')}`);
if (!V2) {
fact("Compared: the rivals' store pages and speed", 'Not part of this report', 'website', 'cmp-website-none', 'compare competition competitors rivals versus speed page', 'sales');
fact("Compared: the rivals' store pages and speed", 'Read in this run, not in the record', 'website', 'cmp-missing-website', 'compare competition competitors rivals versus speed page', 'service');
}
const websiteTab = V2 ? v2WebsiteTab() : `${head(`Website · ${B.domain}${W.url ? new URL(W.url).pathname : ''}`, `${W.phone ? W.phone.score : ''} of 100 on a phone.`, 'The store page needs a look by hand.', "How fast the store page is in Google's lab test, and what our page reader got from it.")}
${websiteCmp}
<div class="grid2">
  <div class="card" id="reader"><p class="card-k">What our page reader got from the store page</p><div class="reader"><span class="reader-k">Title</span><span>${e(W.title)}</span><span class="reader-k">Headings</span><span>${W.headings} in all: ${W.gate_headings} ${W.gate_headings === 1 ? 'is' : 'are'} the age check${W.sample_headings[0] ? ` ("${e(W.sample_headings[0])}")` : ''}, ${W.label_headings} are pop-up or widget labels</span><span class="reader-k">Main heading</span><span>${W.main_heading_in_list ? 'Present' : 'Not confirmed'}</span><span class="reader-k">Words</span><span>${n(W.words)}</span></div><p class="note">Our reader is not Google. Google already ranks this page number ${S.name_town ? S.name_town.rank : 1} for the store's name, so the next step is to look at what Google itself reads.</p></div>
  <div class="card" id="speed"><p class="card-k">Speed, by Google's lab test</p><div class="row">${dial('Phone', W.phone)}${dial('Desktop', W.desktop)}</div>${W.phone?.fixes.length ? `<p class="card-k" style="margin-top:22px">Where time can be saved on a phone</p><div class="tw"><table><tbody>${W.phone.fixes.map(f => `<tr><td>${e(f.title)}</td><td class="num">about ${f.saves_s} s</td></tr>`).join('')}</tbody></table></div>` : ''}<p class="note">A lab test on a simulated slow phone, not a measure of real visitors.</p></div>
</div>
${checkBlock('website')}
${doorWork('website')}
<div class="sec"><details class="more" id="speed-detail"><summary>Speed test, measure by measure</summary><div class="more-b"><p class="card-k">On a phone</p><div class="tw"><table><tbody>${metricRows(W.phone)}</tbody></table></div><p class="card-k" style="margin-top:20px">On a desktop</p><div class="tw"><table><tbody>${metricRows(W.desktop)}</tbody></table></div></div></details></div>`;

// ---------- links and listings ----------
const dailyCols = `<div class="cols" role="img" aria-label="New linking sites each day">${L.daily.map(x => `<div class="col${x.n >= 10 ? ' col-hot' : ''}" data-tip="${e(`${x.label}: ${x.n} new linking ${x.n === 1 ? 'site' : 'sites'}`)}"><div class="col-bar" style="height:${pct(x.n, L.daily_peak)}%"></div></div>`).join('')}</div><div class="axis"><span>${e(L.daily[0].label)}</span><span>${e(L.daily[L.daily.length - 1].label)}</span></div>`;
const fieldMax = Math.max(...L.field.map(f => f.sites));
const fieldCols = `<div class="cols" role="img" aria-label="Linking sites for each dispensary website from the map check's list">${L.field.map(f => `<div class="col${f.is_you ? ' col-hot' : f.rival ? ' col-rv' : ''}" data-tip="${e(`${f.domain}: ${n(f.sites)} linking sites`)}"><div class="col-bar" style="height:${pct(f.sites, fieldMax)}%"></div></div>`).join('')}</div><div class="legend"><span class="lg-i"><span class="lg-s" style="background:var(--accent)"></span>${e(B.short)}: ${n(L.sites)}</span>${rivals.filter(r => r.linking_sites !== null).map(r => `<span class="lg-i"><span class="lg-s" style="background:var(--rival-hi)"></span>${e(r.short)}: ${n(r.linking_sites)}</span>`).join('')}<span class="lg-i"><span class="lg-s" style="background:var(--rival)"></span>Other websites</span></div>`;
const seen = v => v ? '<span class="yes">\u2713 Seen</span>' : '<span class="dim">Not seen</span>';
fact('Sites that link to the website', `${n(L.sites)}, of which at least ${n(L.sellers)} sell links`, 'links', 'wave', 'backlinks referring domains website links', V2 ? 'service' : ''); fact('Linking sites that carry weight', n(L.with_weight), 'links', 'worth', 'backlinks authority quality', V2 ? 'service' : '');
if (V2) fact('Linking sites that are not link sellers', `${n(L.not_sellers)}, ${n(L.clean_with_weight)} of them with some weight`, 'links', 'wave', 'backlinks referring domains website links quality clean', 'sales');
fact(`Link-selling pages that appeared in ${L.fresh_days} days`, n(L.fresh_sellers), 'links', 'wave', 'spam junk toxic backlinks new wave pbn');
fact(V2 ? "Sites with some weight that link to the rivals' websites and not to yours" : 'Sites worth a look that list the rivals and not this store', n(L.gap_worth.length), 'links', 'worth', 'link gap who links to competitors rivals opportunities'); for (const g of L.gap_worth) fact(V2 ? `Links to the rivals: ${g.domain}` : `Lists the rivals: ${g.domain}`, `links to ${g.rivals.join(', ')}`, 'links', 'worth', 'link gap opportunity who links to competitors rivals');
if (LS) { fact("Outside sites showing the store's phone with its name", n(LS.phone_named_outside), 'links', 'details', 'citation citations nap phone directory directories listings'); fact("Sites showing the store's address with its name", n(LS.street_named_sites), 'links', 'details', 'citation nap address directory');
  for (const r of LS.table) fact(`Listing: ${r.host}`, `phone ${r.phone ? 'seen' : 'not seen'}, address ${r.street ? 'seen' : 'not seen'}`, 'links', 'dirs', `citation listing directory which directories ${r.host.split('.')[0]}`, 'service');
  fact('Directories: what was read', `${LS.table.length} listings tied to the store`, 'links', 'dirs', 'which directories listings are wrong checked', 'service');
  for (const m of LS.matter) fact(`Listing that matters: ${m.label}`, m.seen, 'links', 'matter', `listing directory ${m.label.toLowerCase()} ${m.id}`); }
const v2Wave = V2 ? (C.links || []).filter(x => !x.is_you && x.fresh_sellers !== null && x.fresh_sellers !== undefined) : [];
const linksSalesHead = V2 ? head(`Links and listings · ${B.domain}`, `${n(L.not_sellers)} linking sites are not link sellers.`, `${L.gap_worth.length} ${L.gap_worth.length === 1 ? 'site' : 'sites'} with some weight link to two or more rivals' websites and not to yours.`, `Who links to the website once the link-selling pages are taken out, and where the store is listed. A wave of link-selling pages reached this website and its rivals' in the last ${L.fresh_days} days: ${n(L.fresh_sellers)} here${v2Wave.length ? `, ${v2Wave.map(x => `${x.name} ${n(x.fresh_sellers)}`).join(', ')}` : ''}. It is something to watch, not a fault of the store.`, 'sales') : head(`Links and listings · ${B.domain}`, `${n(L.with_weight)} linking sites carry weight.`, `${L.gap_worth.length} more list your rivals, not you.`, `Who links to the website, which of those links count, and where the store is listed. A wave of link-selling pages reached stores across this market in the last ${L.fresh_days} days. It is something to watch, not a fault of the store.`, 'sales');
const linksTeamHead = V2 ? head(`Links and listings · ${B.domain}`, `${n(L.sellers)} of ${n(L.sites)} linking sites are link sellers or scheme pages.`, `${n(L.clean_with_weight)} of the rest carry weight.`, `Totals with the sellers left in mostly compare junk, here and for the rivals. Work from the ${n(L.not_sellers)} that are not sellers and the ${L.gap_worth.length} worth a look that list the rivals.`, 'service') : head(`Links and listings · ${B.domain}`, `At least ${n(L.sellers)} of ${n(L.sites)} linking sites sell links.`, `${n(L.with_weight)} carry weight.`, `Linking-site totals mostly compare junk, here and for the rivals. Work from the ${n(L.with_weight)} that carry weight and the ${L.gap_worth.length} worth a look that list the rivals.`, 'service');
const worthCard = `<div class="card" id="worth"><p class="card-k">${V2 ? "Sites with some weight that link to two or more rivals' websites and not to yours" : 'Sites worth a look that list the rivals and not this store'}</p><div class="tw"><table class="stack-sm"><thead><tr><th>Site</th><th>${V2 ? 'Links to' : 'Lists'}</th><th class="num" data-only="service">Score</th></tr></thead><tbody>${L.gap_worth.map(g => `<tr><td>${e(g.domain)}${g.cannabis ? ' <span class="chip chip-plain">Cannabis directory</span>' : ''}</td><td class="dim">${e(g.rivals.join(', '))}</td><td class="num" data-only="service">${g.score}</td></tr>`).join('')}</tbody></table></div><p class="note">${V2 ? `Each links to the websites of at least two of the three stores this report follows. <span data-only="service">Score is the vendor's weight for the site, on a scale to 1,000. The other ${n(L.gap_left - L.gap_worth.length)}${L.gap_floor ? ' or more' : ''} sites on the raw list carry little or none, or sell links.</span>` : `They link to at least two of the three stores from the map check on file. <span data-only="service">Score is the vendor's weight for the site, on a scale to 1,000. The other ${n(L.gap_left - L.gap_worth.length)} sites on the raw list carry little or none.</span>`}</p></div>`;
const fieldCard = V2 ? '' : `<div class="card" id="field" data-only="service" data-internal><p class="card-k">Linking sites, website by website from the map check's list ${holdChip}</p>${fieldCols}<p class="note">${L.field_size} websites${L.field_dropped_far ? `, after leaving out ${L.field_dropped_far} that belong to businesses the check placed far away` : ''}. Every total includes link-selling pages, so the order says little.</p></div>`;
const dirCard = !V2 && MK && MK.directories ? (() => { const rows = [...MK.directories.rows].sort((x, y) => y.confirmed - x.confirmed);
  fact('Directory listings, store by store', `${rows.filter(r => r.is_you)[0].confirmed} confirmed for the store`, 'links', 'cmp-dirs', 'citations citation directories listings compare competition rivals versus nap side by side');
  return `<div class="card" id="cmp-dirs"><p class="card-k">Directory listings, store by store</p><div class="tw"><table><thead><tr><th>Business</th><th class="num">Listings confirmed</th><th class="num">Confirmed not listed</th><th class="num">Could not be read</th></tr></thead><tbody>${rows.map(r => `<tr${r.is_you ? ' class="row-you"' : ''}><td class="nw">${e(r.name)}</td><td class="num">${n(r.confirmed)}</td><td class="num">${n(r.not_listed)}</td><td class="num">${n(r.unknown)}</td></tr>`).join('')}</tbody></table></div><p class="note">Our own check of the directories, ${e(MK.directories.read)}. A listing counts when the directory's own page for the store was found. "Could not be read" are directories the check could not settle either way, so they count for nobody.</p></div>`; })() : '';
const v2LinksTable = () => { const rows = C.links || []; if (rows.length < 2) return '';
  const cell = v => v === null || v === undefined ? '<span class="dim">Not counted</span>' : n(v);
  fact('Linking sites, website by website, classified', `${rows.length} websites`, 'links', 'cmp-link-table', 'compare competition rivals backlinks referring domains link sellers spam scheme wave side by side', 'service');
  return `<div class="card" id="cmp-link-table" data-only="service" data-internal><p class="card-k">Linking sites, website by website, classified the same way</p><div class="tw"><table class="fit"><thead><tr><th>Website</th><th class="num">Linking sites</th><th class="num">Link sellers and scheme pages</th><th class="num">Not sellers</th><th class="num">Of those, with weight</th><th class="num">New in ${L.fresh_days} days</th><th class="num">Sellers among the new</th><th class="num">Links read</th></tr></thead><tbody>${rows.map(r => `<tr${r.is_you ? ' class="row-you"' : ''}><td class="nw">${e(r.name)}</td><td class="num">${cell(r.sites)}</td><td class="num">${cell(r.sellers)}</td><td class="num">${cell(r.not_sellers)}</td><td class="num">${cell(r.clean_with_weight)}</td><td class="num">${cell(r.fresh)}</td><td class="num">${cell(r.fresh_sellers)}</td><td class="num">${n(r.links_read)} of ${n(r.links_total)}</td></tr>`).join('')}</tbody></table></div><p class="note">A linking site is a seller when the page its link sits on is titled as one, or the software's link ledger flags its host as a scheme. A website whose links were not all read gets no seller count: the sellers among the rest are unknown. ${rows.filter(r => r.wave).map(r => `${e(r.name)}: ${n(r.wave.hosts)} pages share the title "${e(r.wave.title)}", first seen ${e(r.wave.from)} to ${e(r.wave.to)}.`).join(' ')}</p></div>`; };
const linksCmp = V2 ? cmpPanel('cmp-links', `<p class="sub">The websites of the ${C.rivals.length} stores this report follows, link-selling and scheme pages taken out the same way for each, and where Google shows each store's details.</p>`,
  `${cmpGrid([cstat(rowOf('strength')), cstat(rowOf('clean-sites')), cstat(rowOf('clean-weight'))])}<div class="cmp-gap"></div>${cmpGrid([cstat(rowOf('dirs-showed')), worthCard])}<div class="cmp-gap" data-only="service"></div>${v2LinksTable()}<div class="cmp-gap" data-only="service"></div>${cmpGrid([cstat(rowOf('phone-named')), cstat(rowOf('sites')), cstat(rowOf('wave'))])}<div class="cmp-gap" data-only="service"></div>${cmpMissing('links')}`) : cmpPanel('cmp-links', `<p class="sub">The websites of the ${C.rivals.length} stores that led the one map check on file.</p>`,
  `${cmpGrid([cstat(rowOf('strength')), worthCard])}${dirCard ? '<div class="cmp-gap"></div>' + dirCard : ''}<div class="cmp-gap" data-only="service"></div>${cmpGrid([cstat(rowOf('sites')), fieldCard])}<div class="cmp-gap" data-only="service"></div>${cmpMissing('links')}`);
const waveCard = `<div class="card" id="wave"><p class="card-k">New linking sites, day by day</p>${dailyCols}<p class="note">${n(L.fresh_sellers)} link-selling pages appeared in the last ${L.fresh_days} days. ${V2 ? `${n(L.fresh_sellers_also_rivals)} of them also link to two or more of the three rivals. ${L.fresh_sellers_with_weight ? `${n(L.fresh_sellers_with_weight)} of them carry any weight.` : 'None carries any weight.'}` : `At least ${n(L.fresh_sellers_also_rivals)} of them also link to two or more of the three rivals. None carries any weight.`}</p><p data-only="service" data-internal style="margin-top:14px"><button class="btn btn-ghost" type="button" data-act="sellers">Save the list of ${n(L.sellers)} link-selling sites</button></p></div>`;
const linksTab = `${linksSalesHead}${linksTeamHead}
${linksCmp}
${LS ? `<div class="grid2">
  <div class="colstack">${waveCard}
  <div class="card" id="details"><p class="card-k">Where Google shows the store's details</p><div class="row"><div><div class="big">${n(LS.phone_named_outside)}</div><p class="note">outside sites show the phone number with the store's name</p></div><div><div class="big">${n(LS.street_named_sites)}</div><p class="note">sites show the street address with it</p></div></div><div class="chips" style="margin-top:16px">${LS.named_site_list.slice(0, 16).map(h => `<span class="chip chip-plain">${e(h)}</span>`).join('')}</div><p class="note">From ${LS.searches} Google searches for the store's phone number, street address and name.</p>
    <div data-only="service" data-internal style="margin-top:18px"><p class="card-k">${V2 ? `The phone number shown without the name ${e(B.short)}, off the store's own website (${LS.phone_other} results on ${LS.phone_other_sites.length} sites)` : `The phone number shown without the store's name (${LS.phone_other} results)`}</p><div class="chips">${LS.phone_other_sites.map(h => `<span class="chip chip-plain">${e(h)}</span>`).join('')}</div><p class="note">${V2 ? 'Phone-lookup and people-search pages, and the other sites named here. Open them before telling the client anything.' : 'Other businesses, people-search pages and list pages. Open them before telling the client anything.'}</p></div></div></div>
  <div class="card" id="matter"><p class="card-k">The listings that matter</p><div class="tw"><table class="stack-sm"><thead><tr><th>Listing</th><th>What this report saw</th></tr></thead><tbody>${LS.matter.map(m => `<tr><td>${e(m.label)}</td><td class="dim">${e(m.seen)}</td></tr>`).join('')}</tbody></table></div><p class="note">Seen in Google's results is a start. Each one gets opened and checked by hand.</p></div>
</div>
<div class="sec" data-only="service"><div class="card" id="dirs"><p class="card-k">Listing pages this report could tie to the store ${holdChip}</p><div class="tw"><table class="stack-sm"><thead><tr><th>Listing</th><th>Phone</th><th>Address</th><th>Seen on</th></tr></thead><tbody>${LS.table.map(r => `<tr><td>${link(r.url, r.host)}${r.pages > 1 ? ` <span class="dim">(${r.pages} pages)</span>` : ''}</td><td>${seen(r.phone)}</td><td>${seen(r.street)}</td><td class="dim">${e(cap1(r.source))}</td></tr>`).join('')}</tbody></table></div><p class="note">Not seen does not mean not there: ${LS.store_pages_empty} of the store's ${LS.store_pages} listing pages came back empty${LS.store_empty_by_site[0] ? `, ${LS.store_empty_by_site[0].n} of them on ${e(LS.store_empty_by_site[0].host)}` : ''}.</p></div></div>` : waveCard}
${V2 && LS && LS.verdicts ? (() => { const v = LS.verdicts; fact('Directories the software checked', `${v.listed} list the store, ${v.not_listed} ${v.not_listed === 1 ? 'does' : 'do'} not, ${v.undetermined} could not be read`, 'links', 'verdicts', 'citations directories listed not listed nap which directories checked');
  return `<div class="sec"><div class="card" id="verdicts"><p class="card-k">Directories the software checked for this store</p><div class="row"><div><div class="big">${n(v.listed)}</div><p class="note">list the store</p></div><div><div class="big">${n(v.not_listed)}</div><p class="note">${v.not_listed === 1 ? 'does not' : 'do not'}</p></div><div><div class="big">${n(v.undetermined)}</div><p class="note">could not be read either way</p></div></div><p class="note">Of ${n(v.checked)} directories, checked ${e(v.computed)}. Could not be read is not "not listed": walled directories, or listings the search did not find.</p>${(v.other_market || []).length ? `<p class="note" data-only="service" data-internal>Left out of every count: ${n(v.other_market.length)} sources in the software's list for this store that name ${e(v.other_market_label || "another market's")} places (${e(v.other_market.map(x => x.domain).join(', '))}), a defect in its source list for this store. With them it would read ${n(v.checked_all)} checked.</p>` : ''}<div data-only="service" data-internal style="margin-top:14px"><div class="tw"><table class="stack-sm"><thead><tr><th>Directory</th><th>Verdict</th><th>Name, address, phone</th></tr></thead><tbody>${v.rows.map(r => `<tr><td>${link(r.url, r.domain)}</td><td>${e(r.verdict)}</td><td class="dim">${e(r.nap || 'Not read')}</td></tr>`).join('')}</tbody></table></div></div></div></div>`; })() : ''}${checkBlock('links')}
${doorWork('links')}
<div class="sec"><details class="more"><summary>Linking sites that carry weight (${V2 ? `${n(L.clean_with_weight)} that are not link sellers` : L.with_weight})</summary><div class="more-b"><div class="tw"><table><thead><tr><th>Site</th><th class="num">Links</th></tr></thead><tbody>${L.top_sites.map(s => `<tr><td>${e(s.domain)}</td><td class="num">${n(s.links)}</td></tr>`).join('')}</tbody></table></div><p class="note">The strongest ${L.top_sites.length} of ${V2 ? n(L.clean_with_weight) : L.with_weight} are shown.</p></div></details></div>`;

// ---------- the plan / all tasks ----------
const groups = d.task_groups;
const planService = groups.map(g => `<div class="grp-b"${['data', 'account', 'ours', 'seos'].includes(g.key) ? ' data-internal' : ''}><p class="grp">${e(g.label)}</p>${V2 && g.note ? `<p class="note" data-internal>${e(g.note)}</p>` : ''}<div class="tasks">${tasks.filter(t => t.group === g.key).map(t => taskCard(t, { id: true })).join('')}</div></div>`).join('');
for (const t of tasks) fact(`Task ${t.n}: ${t.title}`, OWNER[t.owner], 'plan', `tk-${t.id}`, `${t.group_label} ${t.why.join(' ')} ${t.steps.join(' ')} ${t.done_when} ${t.owner === 'client' ? 'which task is the clients who do i chase what is the client waiting' : ''} ${t.owner === 'software' ? 'data problems software' : ''}`, 'service');
for (const c of checks) { const team = c.weight === 'data' || c.internal || c.hold; fact(c.title, team || !c.sales ? c.value : 'Check to come', c.door === 'overview' ? 'plan' : c.door, c.door === 'overview' ? `tk-${c.task}` : `ck-${c.id}`, `${STATUS[c.status][0]} check ${team ? c.detail : (c.sales || c.detail)}`, 'service'); }
for (const c of checks.filter(c => c.weight !== 'data' && !c.internal && c.door !== 'ai')) fact(c.title, c.hold ? 'Check to come' : c.value, c.door, `cks-${c.id}`, `${STATUS[c.status][0]} check ${c.sales || c.detail}`, 'sales');
for (const p of plan) fact(`Plan ${String(p.n).padStart(2, '0')}: ${p.title}`, p.benefit || '', 'plan', 'plan-list', 'plan what we do next steps', 'sales');
const planTab = `
<div data-only="sales">${V2 ? head('The plan', `${plan.length} pieces of work,`, 'in this order.', `Where the store is losing first: ${(() => { const seen = []; for (const p of plan) { const lb = (BOARD.find(([, ids]) => ids.includes(p.id)) || ['Other'])[0]; if (!seen.includes(lb)) seen.push(lb); } return seen.map(x => /^Google/.test(x) ? x : x.toLowerCase()).join(', '); })()}. This list becomes the task board our team works from on day one.`) : head('The plan', `${plan.length} pieces of work,`, 'in this order.', `The map check first, because it decides what can be said about the map. Then the store page, the ${B.city} page, reviews, pages, listings and links. This list becomes the task board our team works from on day one.`)}<div id="plan-list">${plan.map(planItem).join('')}</div></div>
<div data-only="service"><div class="hero"><p class="eyebrow">All tasks · ${e(B.short)}, ${e(B.city)}</p><h2 class="h1 door-h"><span data-count="open">${ours.length}</span> open for us and the client. <span class="h1-a"><span data-count="done">0</span> done.</span></h2><p class="lead">Set a status, a name, a date and a note as work moves. They are saved in this browser only, and they carry over to the next report for this store.</p></div>
<div class="tools"><button class="own-b" type="button" data-owner-set="all">All</button><button class="own-b" type="button" data-owner-set="us">Ours</button><button class="own-b" type="button" data-owner-set="client">The client's</button><button class="own-b" type="button" data-owner-set="account" data-internal>Account manager</button><button class="own-b" type="button" data-owner-set="software" data-internal>Software team</button>
<label class="sr" for="st-filter">Show status</label><select id="st-filter" class="sel"><option value="">Any status</option><option value="new">New</option><option value="assigned">Assigned</option><option value="doing">In progress</option><option value="waiting">Waiting on client</option><option value="blocked">Blocked</option><option value="done">Done</option><option value="wontdo">Will not do</option></select>
<span class="tools-gap"></span><button class="btn btn-ghost" type="button" data-act="copy-open">Copy open tasks</button><button class="btn btn-ghost" type="button" data-act="copy-client">Copy the client's list as an email</button><button class="btn btn-ghost" type="button" data-act="csv">Save as a spreadsheet</button></div>
${planService}</div>`;

// ---------- page ----------
const tabTasks = door => ours.filter(t => t.door === door).length;
const TABS = [['overview', 'Overview'], ['maps', 'Google Maps'], ['search', 'Google search'], ['ai', 'AI answers'], ['website', 'Website'], ['links', 'Links and listings']];
const font = (file, name, weight) => { const p = path.join(here, 'fonts', file); if (!fs.existsSync(p)) die(`font file missing: fonts/${file}`); return `@font-face{font-family:"${name}";src:url(data:font/woff2;base64,${fs.readFileSync(p).toString('base64')}) format("woff2");font-weight:${weight};font-style:normal;font-display:swap}`; };
const css = fs.readFileSync(path.join(here, 'report.css'), 'utf8');
const js = fs.readFileSync(path.join(here, 'client.js'), 'utf8');
const json = o => JSON.stringify(o).replace(/</g, '\\u003c').replace(/[\u2012\u2013\u2014\u2015\u2212]/g, '-');
const fileSlug = `${B.short} ${B.city}`.toLowerCase().replace(/[^a-z0-9]+/g, '-');
const sources = V2 ? [['Google listing', B.profile_read_at], ['Map checks', [...new Set(v2Sweeps.map(x => String(x.finished).replace(/, d+:d+ [AP]M$/, '')))].join(', ') || null], ['Reviews, the store and the rivals', RV?.collected_at], ['Search estimates, whole websites', S.read_at], ['Store pages, speed tests and site crawls', W.read_at], ['Links', L.read_at], ['Listings', LS?.read_at]].filter(r => r[1]) : [['Google listing', B.profile_read_at], ['Reviews', RV?.collected_at], ['Search estimates', S.read_at], ['Store page and speed test', W.read_at], ['Links', L.read_at], ['Listings', LS?.read_at]].filter(r => r[1]);
fact('When this report was run', `${meta.run_started}`, 'overview', 'foot-run', 'when run date how old is this data report date', 'service');
let html = `<!doctype html>
<html lang="en" data-theme="dark" data-mode="${SERVICE ? 'service' : 'sales'}" data-tab="overview" data-compare="on" data-owner="all" data-present="off" data-audience="${AUD}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>${e(B.short)} ${e(B.city)} · ${DOC ? e(DOC) : 'SEO health report'}</title>
<style>${font('Montserrat-Variable.woff2', 'Montserrat', '100 900')}${font('DMSans-1.woff2', 'DM Sans', '100 1000')}
${css}</style>
</head>
<body>
<header class="bar"><div class="bar-in">
  <div class="brand"><span class="brand-mark">${e(meta.agency || 'SEO')}</span><span class="brand-sub">${DOC ? e(DOC) : 'SEO health report'}<span data-only="sales"> · ${e(B.short)}, ${e(B.city)}</span></span></div>
  <label class="pick" data-only="service" data-internal><span class="sr">Store</span><select id="store" data-current="${B.id}">${stores.map(s => `<option value="${s.id}"${s.current ? ' selected' : ''}>${e(s.label)}${s.has_run ? '' : ' (no report yet)'}</option>`).join('')}</select></label>
  <div class="find"><label class="sr" for="q">Find anything in this report</label><input id="q" class="find-in" type="search" placeholder="Find anything: reviews, speed, phone, a rival" autocomplete="off"><div id="find-list" class="find-list" hidden></div></div>
  <button class="own-b" type="button" data-act="present" data-only="service" data-tip="Hide team notes, numbers on hold and software-team work while a client can see the screen">Present</button>
  <div class="seg" aria-label="View" data-team><button class="seg-b" type="button" data-mode-set="sales">Sales</button><button class="seg-b" type="button" data-mode-set="service">Service</button></div>
  <button class="icon-b" type="button" data-act="theme" aria-label="Switch between dark and light">\u25D0</button>
</div></header>
<nav class="tabs" aria-label="Sections"><div class="tabs-in">
${TABS.map(([k, label]) => `<button class="tab-b" type="button" data-tab-set="${k}"${k === 'ai' ? ' data-only="service"' : ''}>${label}${k !== 'overview' && tabTasks(k) ? `<span class="tab-n" data-only="service" data-tip="${tabTasks(k)} ${tabTasks(k) === 1 ? 'task' : 'tasks'} here">${tabTasks(k)}</span>` : ''}</button>`).join('')}
<button class="tab-b" type="button" data-tab-set="plan"><span data-only="sales">The plan</span><span data-only="service">Tasks</span><span class="tab-n" data-only="service" data-count="open" data-tip="Open tasks for us and the client">${ours.length}</span></button>
<button class="cmp-t" type="button" role="switch" aria-checked="true" data-act="compare" data-tip="Set each number beside the competition. Press C to switch."><span class="cmp-t-d" aria-hidden="true"></span>Compare</button>
</div></nav>
<main class="wrap">
<section class="tab" id="tab-overview">${overviewSalesTop}${overviewServiceTop}<div id="map-home">${mapPortal}</div>${v2Home}${gapSection}${rwSection}${overviewSalesRest}${overviewServiceRest}</section>
<section class="tab" id="tab-maps">${mapsTab}</section>
<section class="tab" id="tab-search">${searchTab}</section>
<section class="tab" id="tab-ai">${aiTab}</section>
<section class="tab" id="tab-website">${websiteTab}</section>
<section class="tab" id="tab-links">${linksTab}</section>
<section class="tab" id="tab-plan">${planTab}</section>
<footer class="foot">
  <p data-only="sales">Prepared by ${e(meta.agency || 'us')} for ${e(B.short)} · ${e(meta.report_date)}</p>
  <p data-only="service" data-internal id="foot-run">Run ${e(meta.run_id)} · started ${e(meta.run_started)}, finished ${e(meta.run_finished)} · ${meta.parts} parts, ${meta.steps} steps · ${checks.length} checks, ${tasks.length} tasks</p>
  <details class="more"><summary>What was read, and when</summary><div class="more-b"><div class="tw"><table><tbody>${sources.map(([k, v]) => `<tr><td>${e(k)}</td><td class="dim">${e(v)}</td></tr>`).join('')}</tbody></table></div></div></details>
</footer>
</main>
<div id="tip" role="tooltip"></div><div id="toast" role="status"></div>
<script type="application/json" id="report-find">__FIND__</script>
<script type="application/json" id="report-tasks">__TASKS__</script>
<script type="application/json" id="report-sellers">__SELLERS__</script>
<script type="application/json" id="report-market">__MARKET__</script>
<script>${mvSrc}
${js}</script>
</body>
</html>
`;

// ---------- the client copy: cut everything that is not the sales view out of the file itself ----------
// Removes each element marked data-only="service" (or data-team) through its matching close tag.
function cut(src, attr) {
  const open = new RegExp(`<([a-z0-9]+)\\b[^>]*\\s${attr}(?:="[^"]*")?[^>]*>`);
  for (let guard = 0; guard < 5000; guard++) {
    const m = open.exec(src); if (!m) return src;
    const tag = m[1], re = new RegExp(`<${tag}\\b[^>]*>|</${tag}>`, 'g'); re.lastIndex = m.index + m[0].length;
    let depth = 1, end = -1, x;
    while ((x = re.exec(src))) { if (x[0][1] === '/') { if (--depth === 0) { end = re.lastIndex; break; } } else if (!x[0].endsWith('/>')) depth++; }
    if (end < 0) die(`could not find the end of a <${tag}> marked ${attr}`);
    src = src.slice(0, m.index) + src.slice(end);
  }
  die('too many service blocks to cut');
}
let findOut = find, tasksOut = tasks.map(t => ({ id: t.id, n: t.n, title: t.title, owner: t.owner, owner_label: OWNER[t.owner], group_label: t.group_label, internal: !!t.internal, why: t.why, steps: t.steps, done_when: t.done_when, blocked_by: t.blocked_by.map(b => `Task ${taskById(b).n}: ${taskById(b).title}`), client_line: t.sales_title || t.title, benefit: t.benefit || '' }));
if (CLIENT) {
  html = cut(cut(html, 'data-only="service"'), 'data-team');
  html = html.replace(/<section class="tab" id="tab-ai"><\/section>\n?/, '');
  findOut = find.filter(f => f.m !== 'service');
  tasksOut = [];
}
if (SERVICE) {
  // the Service view alone: every Sales-only block and the view switch come out of the file itself
  html = cut(cut(html, 'data-only="sales"'), 'data-team');
  findOut = find.filter(f => f.m !== 'sales');
}
html = html.replace('__FIND__', () => json({ key: `${B.id}`, ...(CLIENT ? {} : { run: meta.run_id }), store: `${B.short}, ${B.city}`, date: meta.report_date, file: fileSlug, audience: AUD, tabs: CLIENT ? ['overview', 'maps', 'search', 'website', 'links', 'plan'] : ['overview', 'maps', 'search', 'ai', 'website', 'links', 'plan'], items: findOut }))
  .replace('__TASKS__', () => json(tasksOut)).replace('__SELLERS__', () => json(CLIENT ? [] : L.seller_list))
  // what the page needs to redraw the map: names, positions and who stood where. No link, no report id.
  .replace('__MARKET__', () => json(MARKET ? { subject: MARKET.subject, alphabet: MARKET.alphabet, biz: MARKET.biz.map(b => ({ name: b.name, short: b.short, lat: b.lat, lng: b.lng, far: b.far === true ? true : undefined })),
    geoms: MARKET.geoms.map(g => ({ size: g.size, n: g.n, centre: g.centre, step: g.step, cells: g.cells })),
    scans: MARKET.scans.map(s => ({ kw: s.kw, ts: s.ts, when: s.when, geom: s.geom, n: s.n, field: s.field, you: s.you, res: s.res, own: s.own })) } : null));
// every place the find box can send someone must exist on the page
const ids = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]));
const lost = findOut.filter(f => !ids.has(f.a));
if (lost.length) die('the find box points at places that are not on the page: ' + [...new Set(lost.map(f => f.a))].join(', '));
if (CLIENT) {
  // nothing from the team's side may be left in the file a client gets
  const body = html.replace(/<style>[\s\S]*?<\/style>/, '').replace(/<script>[\s\S]*?<\/script>\s*<\/body>/, '</body>');
  // a map share may reach a client only when the map check is not on hold
  const leaks = [['a service block', /data-only="service"/], ['a team-only block', /data-internal/], ['the view switch', /data-mode-set/], ['software team', /software team/i], ['on hold', /on hold/i],
    ...(maps.hold ? [['a map share', new RegExp(maps.board.map(b => String(b.share).replace('.', '\\.') + '%').join('|'))], ['the map check card', /id="scan"/]] : []),
    ['the name of a tool we use', /local ?falcon|localrankingtracker|lf-static|dataforseo|eagle ?eyes/i],
    ['a comparison kept for the team', new RegExp(C.rows.filter(r => !r.sales).map(r => `id="cmp[ov]?-${r.id}"`).join('|') || 'zzzz')], ['the list of what was not handed back', /id="cmp-missing-/], ['a collection limit', /pull's limit|the pull stops/i],
    ['our own tag', new RegExp(`utm_|${(B.listing_tag || 'zzzz').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'i')], ['a run id', new RegExp(meta.run_id)], ['a low-star quote', /data-quote/], ['task internals', /"steps"|done_when/]].filter(([, re]) => re.test(body)).map(([name]) => name);
  if (leaks.length) die('the client copy still carries: ' + leaks.join(', '));
  // v2, ONE rule: the team's "Not safe to quote yet" table lists exactly the numbers the client copy never prints. Every
  // hold names the patterns it would be printed as (report-data.json holds[].leak); the client copy is read the way a
  // reader meets it (text, tooltips and labels, and the find box), and one hit stops the build.
  if (V2) {
    const ent = { amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", nbsp: ' ' };
    const readable = html.replace(/<style>[\s\S]*?<\/style>/, '').replace(/<script>[\s\S]*?<\/script>/g, '')
      .replace(/<[^>]*>/g, tag => ' ' + [...tag.matchAll(/\s(?:data-tip|aria-label|title|placeholder|alt)="([^"]*)"/g)].map(m => m[1]).join(' ') + ' ')
      .replace(/&(amp|lt|gt|quot|#39|nbsp);/g, (m, k) => ent[k]).replace(/\\u003c/g, '<').replace(/\s+/g, ' ');
    const held = [];
    for (const h of holds) for (const src of h.leak || []) { const m = new RegExp(src, 'i').exec(readable); if (m) held.push(`${h.number} [${src}]: "...${readable.slice(Math.max(0, m.index - 60), m.index + m[0].length + 40).trim()}..."`); }
    if (holds.some(h => !Array.isArray(h.leak) || !h.leak.length)) die('a number on hold names no pattern to keep it out of the client copy: ' + holds.filter(h => !Array.isArray(h.leak) || !h.leak.length).map(h => h.number).join('; '));
    if (held.length) die('the client copy prints a number on hold:\n  ' + held.join('\n  '));
  }
}
if (SERVICE) {
  // nothing of the Sales view and no line about our other accounts may be left in the service document, read the way a
  // reader meets it (text, tooltips, labels, and the find box and task data the page carries)
  const ent = { amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", nbsp: ' ' };
  const markup = html.replace(/<style>[\s\S]*?<\/style>/, '').replace(/<script>[\s\S]*?<\/script>/g, '');
  const readable = markup.replace(/<[^>]*>/g, tag => ' ' + [...tag.matchAll(/\s(?:data-tip|aria-label|title|placeholder|alt)="([^"]*)"/g)].map(m => m[1]).join(' ') + ' ')
    .replace(/&(amp|lt|gt|quot|#39|nbsp);/g, (m, k) => ent[k]).replace(/\\u003c/g, '<').replace(/\s+/g, ' ');
  const left = [['a Sales-only block', /data-only="sales"/.test(markup)], ['the view switch', /data-mode-set/.test(markup)],
    ['a line about our other accounts', XACCT.test(readable)]].filter(([, hit]) => hit).map(([name]) => name);
  if (left.length) die('the service document still carries: ' + left.join(', ') + (XACCT.test(readable) ? ` ("...${readable.slice(Math.max(0, readable.search(XACCT) - 60), readable.search(XACCT) + 60)}...")` : ''));
}
fs.writeFileSync(outPath, html);
if (omitted.length) console.log(`left out of the service document (about our other accounts): ${omitted.join('; ')}`);
console.log(`wrote ${path.basename(outPath)} (${AUD}, ${fs.statSync(outPath).size.toLocaleString('en-US')} bytes) | ${findOut.length} things in the find box | ${checks.length} checks, ${tasks.length} tasks, ${plan.length} plan items, ${ledger.length} gap rows`);
