// Every class used in the page's markup must have a CSS rule. A dropped rule renders as unstyled markup with no
// overflow and no console error, so the use test cannot see it.
// The page carries its own drawing code (mapview.js), which holds markup inside strings; script blocks are left
// out of the scan, and the classes that code writes are checked through what the builder printed with it.
// usage: node verify-classes.mjs <page.html>
import fs from 'node:fs';

const html = fs.readFileSync(process.argv[2], 'utf8');
const css = (html.match(/<style>([\s\S]*?)<\/style>/) || [, ''])[1];
const body = html.slice(html.indexOf('</style>')).replace(/<script[\s\S]*?<\/script>/g, '');
const used = new Set();
for (const m of body.matchAll(/class="([^"]+)"/g)) for (const c of m[1].split(/\s+/)) if (c) used.add(c);
const defined = new Set();
for (const m of css.matchAll(/\.([a-zA-Z][\w-]*)/g)) defined.add(m[1]);
const missing = [...used].filter(c => !defined.has(c)).sort();
const unused = [...defined].filter(c => !used.has(c)).sort();
console.log(`classes in markup ${used.size}, classes with a rule ${defined.size}`);
console.log(`in markup with no rule: ${missing.length ? missing.join(', ') : 'none'}`);
console.log(`rules never used (informational): ${unused.join(', ') || 'none'}`);
const text = body.replace(/<[^>]+>/g, ' ');
const odd = [['long dash or minus sign', /[‒–—―−]/g], ['undefined/null/NaN in text', /\b(undefined|NaN|null)\b/g], ['unfilled template', /\$\{[^}]*\}/g], ['empty table cell pair', /<td[^>]*><\/td><td[^>]*><\/td>/g]];
let bad = missing.length > 0;
for (const [name, re] of odd) { const src = name.startsWith('empty') ? body : text; const hits = src.match(re) || []; console.log(`${name}: ${hits.length}${hits.length ? ' e.g. ' + JSON.stringify(hits.slice(0, 3)) : ''}`); if (hits.length) bad = true; }
console.log(bad ? 'CLASS CHECK: FAIL' : 'CLASS CHECK: PASS');
process.exit(bad ? 1 : 0);
