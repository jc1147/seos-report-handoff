// client.js: the controls of the SEO health report. No network, no libraries. The page reads with this
// script off (everything is in the markup); the script switches what is shown and remembers task status.
// In the client copy of the report there is no Service view, no task data and no way to reach either.
(function () {
  var root = document.documentElement;
  var DATA = JSON.parse(document.getElementById('report-find').textContent);
  var TASKS = JSON.parse(document.getElementById('report-tasks').textContent);
  var CLIENT = DATA.audience === 'client', SERVICE = DATA.audience === 'service';   // a one-view document stays in its view
  var KEY = 'seo-report:' + DATA.key;                // by store, not by run, so status carries over to the next report
  var ALL_TABS = DATA.tabs;
  var STATES = { 'new': 'New', assigned: 'Assigned', doing: 'In progress', waiting: 'Waiting on client', blocked: 'Blocked', done: 'Done', wontdo: 'Will not do' };
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var tabsNow = function () { return ALL_TABS.filter(function (t) { return t !== 'ai' || root.dataset.mode === 'service'; }); };

  // ---------- state lives in the address, so a link opens the same view ----------
  function readHash() { var out = {}; location.hash.replace(/^#/, '').split('&').forEach(function (p) { var kv = p.split('='); if (kv[0]) out[kv[0]] = decodeURIComponent(kv[1] || ''); }); return out; }
  function writeHash() {
    var s = (CLIENT || SERVICE ? '' : 'mode=' + root.dataset.mode + '&') + 'tab=' + root.dataset.tab;
    if (cmpChosen) s += '&cmp=' + (root.dataset.compare === 'on' ? '1' : '0');
    var mv = document.getElementById('map-view'); if (mv && mv.dataset.touched === '1') s += '&map=' + mv.dataset.scan + '.' + mv.dataset.vs;
    if (root.dataset.theme !== 'dark') s += '&theme=' + root.dataset.theme;
    if (root.dataset.present === 'on') s += '&present=1';
    try { history.replaceState(null, '', '#' + s); } catch (e) { /* a file page may refuse; the view still works */ }
  }
  function replay(el) { $$('.b-fill, .col-bar', el).forEach(function (n) { n.style.animation = 'none'; void n.offsetWidth; n.style.animation = ''; }); }
  // The map view is one thing shown in two places: the Overview and the Google Maps tab. It is moved to the
  // tab that is open, so a search, a date or a business picked in one place is the same in the other.
  function placeMap() {
    var mv = document.getElementById('map-view'); if (!mv) return;
    var slot = document.getElementById(root.dataset.tab === 'maps' ? 'map-slot' : 'map-home');
    if (slot && mv.parentNode !== slot) slot.appendChild(mv);
  }
  function setTab(t, keepScroll) {
    if (tabsNow().indexOf(t) < 0) t = 'overview';
    root.dataset.tab = t;
    placeMap();
    var pane = document.getElementById('tab-' + t); if (pane) replay(pane);
    if (!keepScroll) window.scrollTo(0, 0);
    writeHash();
  }
  function setMode(m) {
    root.dataset.mode = SERVICE || (!CLIENT && m === 'service') ? 'service' : 'sales';
    if (root.dataset.mode === 'sales') root.dataset.present = 'off';
    if (tabsNow().indexOf(root.dataset.tab) < 0) root.dataset.tab = 'overview';
    if (!cmpChosen) root.dataset.compare = compareDefault();
    paintCompare(); writeHash();
  }
  // ---------- compare: each number beside the competition, on every tab at once ----------
  // The page opens with it on, in both views: the gap to number 1 is the point of the first screen. Someone
  // can switch it off for a view of the store alone, and the choice then holds across tabs, views and links.
  var cmpChosen = false;
  function compareDefault() { return 'on'; }
  function paintCompare() { var on = root.dataset.compare === 'on'; $$('[data-act="compare"]').forEach(function (b) { b.setAttribute('aria-checked', on ? 'true' : 'false'); }); }
  function setCompare(on) {
    root.dataset.compare = on ? 'on' : 'off'; cmpChosen = true; paintCompare();
    var pane = document.getElementById('tab-' + root.dataset.tab); if (on && pane) replay(pane);
    writeHash();
  }
  function setTheme(t) { root.dataset.theme = t === 'light' ? 'light' : 'dark'; writeHash(); }
  function setPresent(on) { root.dataset.present = on && root.dataset.mode === 'service' ? 'on' : 'off'; if (root.dataset.present === 'on' && ['software', 'account'].indexOf(root.dataset.owner) >= 0) setOwner('all'); writeHash(); }
  function applyHash() {
    var h = readHash();
    if (h.theme) root.dataset.theme = h.theme === 'light' ? 'light' : 'dark';
    if (h.mode && !CLIENT && !SERVICE) root.dataset.mode = h.mode === 'service' ? 'service' : 'sales';
    if (h.cmp === '1' || h.cmp === '0') { root.dataset.compare = h.cmp === '1' ? 'on' : 'off'; cmpChosen = true; }
    else if (!cmpChosen) root.dataset.compare = compareDefault();
    paintCompare();
    if (h.tab && tabsNow().indexOf(h.tab) >= 0) root.dataset.tab = h.tab;
    root.dataset.present = h.present === '1' && root.dataset.mode === 'service' ? 'on' : 'off';
    placeMap();
    if (h.map && MVW) { var mp = h.map.split('.'); drawMap({ si: Number(mp[0]), vs: Number(mp[1]), all: false }, true); mapEl.dataset.touched = '1'; }
    if (h.task && !CLIENT) openTask(h.task);
  }
  function openTask(id) {
    var el = document.getElementById('tk-' + id); if (!el) return;
    root.dataset.mode = 'service'; root.dataset.tab = 'plan'; setOwner('all');
    if (!cmpChosen) root.dataset.compare = compareDefault();
    paintCompare();
    el.open = true; setTimeout(function () { el.scrollIntoView({ block: 'center' }); flash(el); }, 60);
  }
  function flash(el) { el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash'); }
  // open a tab and land on one thing in it: unfold what hides it, switch Compare on when it is a comparison
  function goTo(tab, id) {
    setTab(tab, true);
    var el = document.getElementById(id); if (!el) { window.scrollTo(0, 0); return; }
    if (el.closest('[data-cmp]') && root.dataset.compare !== 'on') setCompare(true);
    var dd = el.closest('details'); while (dd) { dd.open = true; dd = dd.parentElement && dd.parentElement.closest('details'); }
    el.scrollIntoView({ block: el.getBoundingClientRect().height > window.innerHeight * 0.7 ? 'start' : 'center' }); flash(el);
  }

  // ---------- the map: any search, any date, any business beside the store ----------
  // mapview.js drew the first view into the page; the same code redraws it here on every pick.
  var mapEl = document.getElementById('map-view'), MVW = null, MKT = null;
  if (mapEl && typeof MapView !== 'undefined') { try { MKT = JSON.parse(document.getElementById('report-market').textContent); if (MKT) MVW = MapView.make(MKT); } catch (e) { MVW = null; } }
  function mapState() { return { si: Number(mapEl.dataset.scan), vs: Number(mapEl.dataset.vs), all: mapEl.dataset.all === '1' }; }
  function drawMap(st, quiet) {
    if (!MVW || !(st.si >= 0 && st.si < MKT.scans.length)) return;
    var r = MVW.render(st);
    mapEl.dataset.scan = r.si; mapEl.dataset.vs = r.vs; mapEl.dataset.all = st.all ? '1' : ''; mapEl.dataset.prev = r.prev; mapEl.dataset.next = r.next;
    $('#mv-you').innerHTML = r.you; $('#mv-them').innerHTML = r.them; $('#mv-board').innerHTML = r.board; $('#mv-trend-b').innerHTML = r.trend; $('#mv-searches').innerHTML = r.searches;
    $('#mv-kw').innerHTML = r.options.kw; $('#mv-vs').innerHTML = r.options.vs; $('#mv-when').textContent = r.when; $('#mv-line').textContent = r.line;
    $('[data-act="mv-prev"]').disabled = r.prev < 0; $('[data-act="mv-next"]').disabled = r.next < 0;
    if (!quiet) { mapEl.dataset.touched = '1'; writeHash(); }
  }
  document.addEventListener('change', function (ev) {
    if (!MVW) return;
    if (ev.target.id === 'mv-kw') drawMap({ si: Number(ev.target.value), vs: mapState().vs, all: false });
    else if (ev.target.id === 'mv-vs') { var st = mapState(); st.vs = Number(ev.target.value); drawMap(st); }
  });

  document.addEventListener('click', function (ev) {
    var m = MVW && ev.target.closest('.lb-row[data-vs], .tr-pt[data-scan], .sr-row[data-scan]');
    if (m) { var ms = mapState(); if (m.dataset.vs !== undefined) ms.vs = Number(m.dataset.vs); else { ms.si = Number(m.dataset.scan); ms.all = false; } drawMap(ms); if (m.classList.contains('sr-row')) mapEl.scrollIntoView({ block: 'start' }); return; }
    var b = ev.target.closest('[data-tab-set],[data-mode-set],[data-owner-set],[data-copy],[data-act],[data-goto]');
    if (!b) return;
    if (b.dataset.goto) { goTo(b.dataset.gotoTab, b.dataset.goto); return; }
    if (b.dataset.act === 'mv-prev' || b.dataset.act === 'mv-next') { var to = Number(mapEl.dataset[b.dataset.act === 'mv-prev' ? 'prev' : 'next']); if (to >= 0) { var s2 = mapState(); s2.si = to; drawMap(s2); } return; }
    if (b.dataset.act === 'mv-all') { var s3 = mapState(); s3.all = !s3.all; drawMap(s3, true); return; }
    if (b.dataset.tabSet) { setTab(b.dataset.tabSet); return; }
    if (b.dataset.modeSet) { setMode(b.dataset.modeSet); return; }
    if (b.dataset.act === 'compare') { setCompare(root.dataset.compare !== 'on'); return; }
    if (b.dataset.ownerSet) { setOwner(b.dataset.ownerSet); return; }
    if (b.dataset.copy) { ev.preventDefault(); copy(brief(b.dataset.copy), 'Task copied'); return; }
    if (b.dataset.act === 'theme') { setTheme(root.dataset.theme === 'dark' ? 'light' : 'dark'); return; }
    if (b.dataset.act === 'present') { setPresent(root.dataset.present !== 'on'); return; }
    if (b.dataset.act === 'sellers') { sellers(); return; }
    if (b.dataset.act === 'copy-open') { var ids = shownTasks(true); copy(ids.map(brief).join('\n\n----------\n\n'), ids.length + ' open tasks copied'); return; }
    if (b.dataset.act === 'copy-client') { copy(clientEmail(), "The client's list copied"); return; }
    if (b.dataset.act === 'csv') { csv(); return; }
  });

  // ---------- tasks: status, a name, a date and a note, kept in this browser ----------
  var saved = {};
  try { saved = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { saved = {}; }
  var rec = function (id) { return saved[id] || (saved[id] = { s: 'new', who: '', due: '', note: '' }); };
  var stateOf = function (id) { return (saved[id] && saved[id].s) || 'new'; };
  var closed = function (id) { var s = stateOf(id); return s === 'done' || s === 'wontdo'; };
  function save() { try { localStorage.setItem(KEY, JSON.stringify(saved)); } catch (e) { /* private window: kept until the page closes */ } }
  function setOwner(o) { root.dataset.owner = ['us', 'client', 'account', 'software'].indexOf(o) < 0 ? 'all' : o; filterList(); }
  // the owner and status filters act on the Tasks tab only, and a group with nothing showing is hidden
  function filterList() {
    var owner = root.dataset.owner, st = ($('#st-filter') || {}).value || '';
    $$('#tab-plan .tk').forEach(function (el) { var hide = (owner !== 'all' && el.dataset.owner !== owner) || (st && stateOf(el.dataset.task) !== st); el.hidden = !!hide; });
    $$('#tab-plan .grp-b').forEach(function (g) { g.hidden = !$$('.tk', g).some(function (el) { return !el.hidden; }); });
  }
  function paint() {
    $$('.tk').forEach(function (el) {
      var r = saved[el.dataset.task] || {}, st = r.s || 'new';
      el.classList.toggle('is-done', st === 'done' || st === 'wontdo');
      var sel = $('.sel', el); if (sel && sel.value !== st) sel.value = st;
      $$('[data-f]', el).forEach(function (inp) { var v = r[inp.dataset.f] || ''; if (inp.value !== v && document.activeElement !== inp) inp.value = v; });
    });
    var mine = function (t) { return t.owner === 'us' || t.owner === 'client'; };
    var count = function (f) { return TASKS.filter(function (t) { return !closed(t.id) && f(t); }).length; };
    var set = function (id, v) { $$('[data-count="' + id + '"]').forEach(function (n) { n.textContent = v; }); };
    set('open', count(mine)); set('us', count(function (t) { return t.owner === 'us'; })); set('client', count(function (t) { return t.owner === 'client'; }));
    set('software', count(function (t) { return t.owner === 'software'; })); set('account', count(function (t) { return t.owner === 'account'; }));
    set('done', TASKS.filter(function (t) { return mine(t) && stateOf(t.id) === 'done'; }).length);
    filterList();
  }
  document.addEventListener('change', function (ev) {
    if (ev.target.id === 'st-filter') { filterList(); return; }
    var card = ev.target.closest('.tk'); if (!card) return;
    if (ev.target.classList.contains('sel')) rec(card.dataset.task).s = STATES[ev.target.value] ? ev.target.value : 'new';
    else if (ev.target.dataset.f) rec(card.dataset.task)[ev.target.dataset.f] = ev.target.value.slice(0, 200);
    else return;
    save(); paint();
  });
  // choosing a status must not fold or unfold the task it sits on
  document.addEventListener('click', function (ev) { if (ev.target.closest('summary .sel')) ev.preventDefault(); });
  // what "Copy open tasks" and the spreadsheet cover: the owner chosen, or us and the client when none is
  function shownTasks(openOnly) {
    var owner = root.dataset.owner, present = root.dataset.present === 'on';
    return TASKS.filter(function (t) { return (owner === 'all' ? (t.owner === 'us' || t.owner === 'client') : t.owner === owner) && !(present && t.internal) && (!openOnly || !closed(t.id)); }).map(function (t) { return t.id; });
  }
  var byId = function (id) { return TASKS.filter(function (x) { return x.id === id; })[0]; };
  function brief(id) {
    var t = byId(id); if (!t) return ''; var r = saved[id] || {};
    var lines = ['TASK ' + t.n + ': ' + t.title, 'Store: ' + DATA.store + '   Report of ' + DATA.date, 'For: ' + t.owner_label + '   Area: ' + t.group_label + (r.who ? '   Who: ' + r.who : '') + (r.due ? '   Due: ' + r.due : ''), '', 'Why', t.why.map(function (w) { return '- ' + w; }).join('\n'), '',
      'Steps', t.steps.map(function (s, i) { return (i + 1) + '. ' + s; }).join('\n'), '', 'Done when: ' + t.done_when];
    if (t.blocked_by.length) lines.push('Blocked by: ' + t.blocked_by.join('; '));
    if (r.note) lines.push('Note: ' + r.note);
    return lines.join('\n');
  }
  function clientEmail() {
    var list = TASKS.filter(function (t) { return t.owner === 'client' && !closed(t.id); });
    var out = ['Subject: ' + DATA.store + ': ' + (list.length === 1 ? 'one thing' : list.length + ' things') + ' we need from the store', '', 'Hi,', '', 'From the report of ' + DATA.date + ', here is what we need from the store:', ''];
    list.forEach(function (t, i) { out.push((i + 1) + '. ' + t.client_line); if (t.benefit) out.push('   Why it matters: ' + t.benefit); t.steps.forEach(function (s) { out.push('   - ' + s); }); out.push('   Done when: ' + t.done_when); out.push(''); });
    if (!list.length) out.push('Nothing is waiting on the store right now.', '');
    out.push('Thank you.');
    return out.join('\n');
  }
  function toast(msg) { var n = document.getElementById('toast'); n.textContent = msg; n.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(function () { n.classList.remove('on'); }, 1700); }
  function copy(text, msg) {
    var done = function () { toast(msg); };
    var old = function () { var ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); done(); } catch (e) { toast('Copy did not work here'); } ta.remove(); };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(done, old); else old();
    window.__lastCopy = text;
  }
  function csv() {
    var q = function (s) { return '"' + String(s == null ? '' : s).replace(/"/g, '""') + '"'; };
    var rows = [['Store', 'Report date', 'No', 'Task', 'For', 'Area', 'Status', 'Who', 'Due', 'Note', 'Why', 'Steps', 'Done when', 'Blocked by']].concat(shownTasks(false).map(byId).map(function (t) { var r = saved[t.id] || {}; return [DATA.store, DATA.date, t.n, t.title, t.owner_label, t.group_label, STATES[r.s || 'new'], r.who || '', r.due || '', r.note || '', t.why.join(' '), t.steps.join(' | '), t.done_when, t.blocked_by.join('; ')]; }));
    var blob = new Blob(['\ufeff' + rows.map(function (r) { return r.map(q).join(','); }).join('\r\n')], { type: 'text/csv' });
    save_file(DATA.file + '-tasks.csv', blob);
    window.__lastCsv = rows; toast(rows.length - 1 + ' tasks saved');
  }
  function save_file(name, blob) { var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); }
  // the list of link-selling sites, one a line, for whoever looks into them
  function sellers() { var sl = JSON.parse(document.getElementById('report-sellers').textContent); save_file(DATA.file + '-link-selling-sites.txt', new Blob([sl.join('\r\n')], { type: 'text/plain' })); window.__lastSellers = sl.length; toast(sl.length + ' sites saved'); }
  window.addEventListener('beforeprint', function () { $$('details').forEach(function (dd) { if (!dd.open) { dd.open = true; dd.dataset.printOpened = '1'; } }); });
  window.addEventListener('afterprint', function () { $$('details[data-print-opened]').forEach(function (dd) { dd.open = false; delete dd.dataset.printOpened; }); });

  // ---------- find the answer ----------
  // People type questions, not keywords: small words are dropped; an answer that holds every remaining word
  // wins; when none does, the answers holding the most are shown; one wrong letter is forgiven when nothing
  // else matches. Only answers from the view on screen are offered, and picking one never changes the view.
  var q = document.getElementById('q'), list = document.getElementById('find-list'), hits = [], at = -1;
  var SMALL = ' a an the is are was were be do does did of for to in on at by with and or my our their its it they we you i me us what whats which who whom how many much why when where there this that these those have has had can could should would about from as so any some than then ';
  var starts = function (hay, stem) { var p = hay.indexOf(stem); while (p > 0 && /[a-z0-9]/.test(hay.charAt(p - 1))) p = hay.indexOf(stem, p + 1); return p; };
  var oneOff = function (a, b) { if (Math.abs(a.length - b.length) > 1) return false; if (a.length === b.length) { var d = []; for (var x = 0; x < a.length; x++) if (a[x] !== b[x]) d.push(x); if (d.length === 2 && d[1] === d[0] + 1 && a[d[0]] === b[d[1]] && a[d[1]] === b[d[0]]) return true; } var i = 0, j = 0, miss = 0; while (i < a.length && j < b.length) { if (a[i] === b[j]) { i++; j++; } else { if (++miss > 1) return false; if (a.length > b.length) i++; else if (b.length > a.length) j++; else { i++; j++; } } } return miss + (a.length - i) + (b.length - j) <= 1; };
  function pool() { var m = root.dataset.mode; return DATA.items.filter(function (it) { return !it.m || it.m === m; }); }
  function run(words, loose) {
    var phrase = words.join(' ');
    return pool().map(function (it) {
      var label = it.l.toLowerCase(), hay = (it.l + ' ' + it.v + ' ' + (it.k || '')).toLowerCase(), hit = 0, score = 0, hayWords = loose ? hay.split(/[^a-z0-9]+/) : null;
      for (var i = 0; i < words.length; i++) {
        var w = words[i], stem = w.length > 4 && w.charAt(w.length - 1) === 's' ? w.slice(0, -1) : w, inLabel = starts(label, stem), found = starts(hay, stem) >= 0;
        if (!found && loose && w.length >= 5) found = hayWords.some(function (x) { return x.length >= 4 && oneOff(x, w); });
        if (!found) continue;
        hit++; score += (label === w || label === stem) ? -6 : inLabel === 0 ? -3 : inLabel > 0 ? 0 : 4;
      }
      // the words side by side, as typed, beat the same words scattered
      if (hit > 1 && phrase) score += label.indexOf(phrase) >= 0 ? -2 : hay.indexOf(phrase) >= 0 ? -1 : 0;
      return hit ? { it: it, hit: hit, score: score + label.length / 200 } : null;
    }).filter(Boolean);
  }
  function search(text) {
    var all = text.toLowerCase().replace(/[^a-z0-9.\s-]/g, ' ').split(/\s+/).filter(Boolean);
    var words = all.filter(function (w) { return SMALL.indexOf(' ' + w + ' ') < 0; });
    if (!words.length) words = all;
    if (!words.length) return [];
    var scored = run(words, false); if (!scored.length) scored = run(words, true);
    var most = Math.max.apply(null, scored.map(function (x) { return x.hit; }).concat([0]));
    return scored.filter(function (x) { return x.hit === most; }).sort(function (a, b) { return a.score - b.score; }).slice(0, 12).map(function (x) { return x.it; });
  }
  function show() {
    hits = search(q.value); at = hits.length ? 0 : -1;
    list.innerHTML = '';
    if (!q.value.trim()) { list.hidden = true; return; }
    if (!hits.length) { var none = document.createElement('div'); none.className = 'find-none'; none.textContent = 'Nothing in this report matches that.'; list.appendChild(none); list.hidden = false; return; }
    hits.forEach(function (it, i) {
      var b = document.createElement('button'); b.type = 'button'; b.className = 'find-item' + (i === at ? ' on' : ''); b.dataset.i = i;
      var l = document.createElement('span'); l.className = 'find-l'; l.textContent = it.l;
      var v = document.createElement('span'); v.className = 'find-v'; v.textContent = it.v;
      var w = document.createElement('span'); w.className = 'find-w'; w.textContent = it.w;
      b.appendChild(l); b.appendChild(v); b.appendChild(w); list.appendChild(b);
    });
    list.hidden = false;
  }
  function go(it) {
    if (!it || (it.m && it.m !== root.dataset.mode)) return;      // never cross from one view to the other
    setTab(it.t, true);
    list.hidden = true; q.blur();
    var el = document.getElementById(it.a);
    if (!el) { window.scrollTo(0, 0); return; }
    if (it.t === 'plan') { setOwner('all'); var f = $('#st-filter'); if (f) { f.value = ''; filterList(); } }
    if (el.closest('[data-cmp]') && root.dataset.compare !== 'on') setCompare(true);   // an answer that sits in a comparison turns Compare on
    var dd = el.closest('details'); while (dd) { dd.open = true; dd = dd.parentElement && dd.parentElement.closest('details'); }
    if (el.tagName === 'DETAILS') el.open = true;
    el.scrollIntoView({ block: 'center' }); flash(el);
    window.__lastFind = it.a;
  }
  q.addEventListener('input', show);
  q.addEventListener('focus', show);
  q.addEventListener('keydown', function (ev) {
    if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') { ev.preventDefault(); if (!hits.length) return; at = (at + (ev.key === 'ArrowDown' ? 1 : hits.length - 1)) % hits.length; $$('.find-item', list).forEach(function (n, i) { n.classList.toggle('on', i === at); }); }
    else if (ev.key === 'Enter') { ev.preventDefault(); go(hits[at]); }
    else if (ev.key === 'Escape') { list.hidden = true; q.blur(); }
  });
  list.addEventListener('mousedown', function (ev) { var b = ev.target.closest('.find-item'); if (b) { ev.preventDefault(); go(hits[Number(b.dataset.i)]); } });
  document.addEventListener('click', function (ev) { if (!ev.target.closest('.find')) list.hidden = true; });
  document.addEventListener('keydown', function (ev) {
    var typing = /INPUT|SELECT|TEXTAREA/.test((ev.target && ev.target.tagName) || '');
    if (ev.key === 'Enter' && ev.target && ev.target.classList && ev.target.classList.contains('sr-row')) { ev.target.click(); return; }
    if ((ev.key === '/' && !typing) || (String(ev.key).toLowerCase() === 'k' && (ev.ctrlKey || ev.metaKey))) { ev.preventDefault(); q.focus(); q.select(); return; }
    if (typing || ev.ctrlKey || ev.metaKey || ev.altKey) return;
    if (String(ev.key).toLowerCase() === 'c' && root.dataset.tab !== 'plan') { setCompare(root.dataset.compare !== 'on'); return; }
    var n = Number(ev.key), tabs = tabsNow(); if (n >= 1 && n <= tabs.length) setTab(tabs[n - 1]);
  });

  // ---------- small hover labels on chart marks ----------
  var tip = document.getElementById('tip');
  document.addEventListener('mousemove', function (ev) {
    var m = ev.target.closest && ev.target.closest('[data-tip]');
    if (!m) { tip.style.opacity = 0; return; }
    tip.textContent = m.dataset.tip; tip.style.opacity = 1;
    var x = Math.min(window.innerWidth - tip.offsetWidth - 12, ev.clientX + 14), y = ev.clientY - tip.offsetHeight - 12;
    tip.style.left = Math.max(8, x) + 'px'; tip.style.top = (y < 8 ? ev.clientY + 18 : y) + 'px';
  });
  var store = document.getElementById('store');
  if (store) store.addEventListener('change', function () { store.value = store.dataset.current; toast('That store has no report yet'); });

  root.dataset.owner = 'all';
  applyHash();
  window.addEventListener('hashchange', applyHash);
  paint(); writeHash();
  window.__report = { setTab: setTab, setMode: setMode, setCompare: setCompare, drawMap: drawMap, mapState: function () { return mapEl ? mapState() : null; }, mapView: function () { return MVW; }, goTo: goTo, setTheme: setTheme, setPresent: setPresent, setOwner: setOwner, search: search, go: go, brief: brief, clientEmail: clientEmail, shownTasks: shownTasks, saved: saved, paint: paint, client: CLIENT };
})();
