// run-report.mjs: one command from SEOS's answers to the two documents, on the reference code in reference/.
// Every stage is a child process on a reference script; the first stage that exits non-zero stops the run.
//
// usage: node run-report.mjs --data=<folder> --settings=<file> --out=<folder> [--extra-sweep=<Eagle Eyes export>]...
//          [--facts=<file>] [--no-browser]
//   --data         the answers of SEOS's GETs: business-<id>.json (/businesses/{id}), full-audit-<id>.json
//                  (/businesses/{id}/full-audit-result), website-audit-<id>.json (/businesses/{id}/website-audit-result) and,
//                  when present, engine_sweeps-all.json (/tables/engine_sweeps) and locations-all.json (/tables/locations).
//                  Never written to.
//   --settings     the business settings (extract-v2.mjs --settings): business_id is required and names the answers.
//   --out          an empty or new folder. Gets market.json, report-data.json, competitor-analysis.html,
//                  action-plan.html, SHA256SUMS, run-log.txt, logs/ (each stage's output) and, with an extra sweep,
//                  data/ (the answers with the sweep folded in) and extra/ (the converted sweep).
//   --extra-sweep  an Eagle Eyes scan export of the store: converted to SEOS's sweep rows (ee-scan-to-seos.mjs) and folded
//                  into a copy of the answers (merge-sweep.mjs). Repeatable. Note: the converter stamps the rows' read_at
//                  with the export's file time, which reaches market.json and report-data.json (run-log.txt records it).
//   --facts        the independent facts file for this business (extract-v2.mjs --facts); Green Haven only today.
//   --no-browser   skip conformance/check-documents.mjs (headless Chrome).
// Read from the answers, not typed: the store's place id and state (the business answer's first location row). The time
// zone is settings.timezone, else the state table read out of reference/extract-v2.mjs (one table, never a second copy).
// The searches the owner expects (sweeps-market --want) are settings.expected_searches.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REF = path.join(HERE, 'reference');
const CHECK_DOCS = path.join(HERE, 'conformance', 'check-documents.mjs');
const USAGE = 'usage: node run-report.mjs --data=<folder> --settings=<file> --out=<folder> [--extra-sweep=<Eagle Eyes export>]... [--facts=<file>] [--no-browser]';
const argv = process.argv.slice(2);
const KNOWN = ['--data=', '--settings=', '--out=', '--extra-sweep=', '--facts=', '--no-browser'];
const stop = (m, code = 1) => { console.error('RUN STOPPED: ' + m); process.exit(code); };
const unknown = argv.filter(a => !KNOWN.some(k => k.endsWith('=') ? a.startsWith(k) : a === k));
if (unknown.length) stop(`unknown argument${unknown.length > 1 ? 's' : ''}: ${unknown.join(' ')}\n${USAGE}`, 2);
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
const many = k => argv.filter(v => v.startsWith('--' + k + '=')).map(v => v.slice(k.length + 3));
if (!opt('data') || !opt('settings') || !opt('out')) stop(USAGE, 2);
const DATA = path.resolve(opt('data')), SETTINGS = path.resolve(opt('settings')), OUT = path.resolve(opt('out'));
const EXTRA = many('extra-sweep').map(p => path.resolve(p)), FACTS = opt('facts') ? path.resolve(opt('facts')) : null, BROWSER = !argv.includes('--no-browser');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');

// ---------- the inputs ----------
if (!fs.existsSync(DATA) || !fs.statSync(DATA).isDirectory()) stop('no data folder at ' + DATA);
for (const [p, what] of [[SETTINGS, 'settings file'], ...EXTRA.map(p => [p, 'Eagle Eyes export']), ...(FACTS ? [[FACTS, 'facts file']] : [])]) if (!fs.existsSync(p) || !fs.statSync(p).isFile()) stop(`no ${what} at ${p}`);
let settings; try { settings = JSON.parse(fs.readFileSync(SETTINGS, 'utf8')); } catch (e) { stop(`the settings file is not JSON: ${e.message}`); }
const ID = settings.business_id;
if (!Number.isInteger(ID)) stop('settings.business_id is required (the SEOS business id the answers are about)');
const FILES = { biz: `business-${ID}.json`, full: `full-audit-${ID}.json`, web: `website-audit-${ID}.json` };
const GETS = { biz: `/businesses/${ID}`, full: `/businesses/${ID}/full-audit-result`, web: `/businesses/${ID}/website-audit-result` };
for (const k of Object.keys(FILES)) if (!fs.existsSync(path.join(DATA, FILES[k]))) stop(`missing ${FILES[k]} in ${DATA} (SEOS's answer to GET ${GETS[k]})`);
let biz; try { biz = JSON.parse(fs.readFileSync(path.join(DATA, FILES.biz), 'utf8')); } catch (e) { stop(`${FILES.biz} is not JSON: ${e.message}`); }
if ((biz.business_id ?? biz.tables?.businesses?.[0]?.id) !== ID) stop(`${FILES.biz} is about business ${biz.business_id ?? biz.tables?.businesses?.[0]?.id}, the settings about ${ID}`);
const loc = biz.tables?.locations?.[0] || stop(`${FILES.biz} has no location row`);
const PID = loc.place_id || stop(`the location row in ${FILES.biz} has no place id`);
// the state table, read out of the extractor itself so the two can never drift apart
const tzTable = () => {
  const src = fs.readFileSync(path.join(REF, 'extract-v2.mjs'), 'utf8');
  const m = /const TZ = \{([^}]*)\};/.exec(src) || stop('could not find the state table (const TZ = {...};) in reference/extract-v2.mjs');
  const pairs = [...m[1].matchAll(/([A-Z]{2}): '([^']+)'/g)], items = m[1].split(',').map(s => s.trim()).filter(Boolean);
  if (pairs.length !== items.length) stop(`the state table in reference/extract-v2.mjs has ${items.length} entries and ${pairs.length} read as STATE: 'Zone'`);
  return Object.fromEntries(pairs.map(p => [p[1], p[2]]));
};
const TZ = settings.timezone || tzTable()[loc.state] || stop(`no time zone for state ${loc.state}: give settings.timezone`);
try { new Intl.DateTimeFormat('en-US', { timeZone: TZ }); } catch { stop(`${settings.timezone ? 'settings.timezone' : 'the state table'} gives "${TZ}", which is not a time zone`); }
const want = Array.isArray(settings.expected_searches) ? settings.expected_searches.map(s => String(s).trim()).filter(Boolean) : [];
if (want.some(s => s.includes(','))) stop('an expected search holds a comma, which sweeps-market.mjs --want reads as a separator');

if (fs.existsSync(OUT) && fs.readdirSync(OUT).length) stop('the out folder is not empty: ' + OUT);
fs.mkdirSync(path.join(OUT, 'logs'), { recursive: true });

// ---------- the stages ----------
const log = [], started = Date.now();
const header = [`run-report.mjs`, `data: ${DATA}`, `settings: ${SETTINGS} (sha256 ${sha(fs.readFileSync(SETTINGS))})`, `business ${ID}, store place id ${PID}, state ${loc.state}, time zone ${TZ}${settings.timezone ? ' (settings)' : ' (state table in reference/extract-v2.mjs)'}`,
  `expected searches: ${want.length ? want.map(s => `"${s}"`).join(', ') : 'none'}`, ...EXTRA.map(p => `extra sweep: ${p} (sha256 ${sha(fs.readFileSync(p))}, file time ${fs.statSync(p).mtime.toISOString()}: ee-scan-to-seos.mjs stamps read_at with it)`),
  `facts: ${FACTS ? `${FACTS} (sha256 ${sha(fs.readFileSync(FACTS))})` : 'none'}`, `browser check: ${BROWSER ? 'yes' : 'no (--no-browser)'}`, ''];
const writeLog = status => fs.writeFileSync(path.join(OUT, 'run-log.txt'), [...header, 'stage\texit\tseconds\tcommand', ...log.map(r => `${r.stage}\t${r.exit}\t${r.seconds}\t${r.command}`), '', status, ''].join('\n'));
const run = (stage, script, args) => {
  const t0 = Date.now();
  const r = spawnSync(process.execPath, [script, ...args], { cwd: OUT, encoding: 'utf8', maxBuffer: 1 << 28 });
  const seconds = ((Date.now() - t0) / 1000).toFixed(1), exit = r.status === null ? `signal ${r.signal}` : r.status;
  const quote = a => (/[\s"]/.test(a) ? JSON.stringify(a) : a);
  log.push({ stage, exit, seconds, command: ['node', script, ...args].map(quote).join(' ') });
  fs.writeFileSync(path.join(OUT, 'logs', `${String(log.length).padStart(2, '0')}-${stage.replace(/[^a-z0-9]+/gi, '-')}.log`), `$ ${log[log.length - 1].command}\n--- stdout\n${r.stdout || ''}\n--- stderr\n${r.stderr || ''}\n--- exit ${exit}\n`);
  if (r.error) { writeLog(`STOPPED at ${stage}: ${r.error.message}`); stop(`${stage} could not start: ${r.error.message}`); }
  if (r.status !== 0) {
    const tail = (r.stderr || '').trim() || (r.stdout || '').trim();
    writeLog(`STOPPED at ${stage} (exit ${exit})`);
    console.error(`RUN STOPPED at ${stage} (exit ${exit})\n` + tail.split('\n').slice(-15).map(l => '  ' + l).join('\n'));
    process.exit(1);
  }
  console.log(`${stage.padEnd(24)} ok  ${seconds}s`);
  return r.stdout;
};
const ref = f => path.join(REF, f);

// 1. each Eagle Eyes export: converted, then folded into a copy of the answers (the last copy is <out>/data)
let D = DATA;
EXTRA.forEach((x, i) => {
  const n = EXTRA.length > 1 ? `[${i + 1}]` : '';
  fs.mkdirSync(path.join(OUT, 'extra'), { recursive: true });
  const conv = path.join(OUT, 'extra', path.basename(x).replace(/\.json$/i, '') + '.seos.json');
  run('ee-scan-to-seos' + n, ref('ee-scan-to-seos.mjs'), [x, PID, conv]);
  const next = i === EXTRA.length - 1 ? path.join(OUT, 'data') : path.join(OUT, `data-merge-${i + 1}`);
  run('merge-sweep' + n, ref('merge-sweep.mjs'), [D, conv, next]);
  D = next;
});
const IN = k => path.join(D, FILES[k]);
const ALL_SWEEPS = path.join(D, 'engine_sweeps-all.json'), LOCATIONS = path.join(D, 'locations-all.json');
const hasAll = fs.existsSync(ALL_SWEEPS), hasLoc = fs.existsSync(LOCATIONS);
const O = f => path.join(OUT, f);

// 2. the market file from the store's sweeps, and its second reading
run('sweeps-market', ref('sweeps-market.mjs'), [IN('biz'), IN('full'), PID, O('market.json'), `--tz=${TZ}`, ...(hasAll ? [`--all-sweeps=${ALL_SWEEPS}`] : []), ...(want.length ? [`--want=${want.join(',')}`] : [])]);
run('check-sweeps-market', ref('check-sweeps-market.mjs'), [IN('biz'), O('market.json'), `--audit=${IN('full')}`]);

// 3. the report model, and its second reading
run('extract-v2', ref('extract-v2.mjs'), [IN('biz'), IN('full'), IN('web'), O('report-data.json'), `--settings=${SETTINGS}`, `--market=${O('market.json')}`,
  ...(hasAll ? [`--all-sweeps=${ALL_SWEEPS}`] : []), ...(hasLoc ? [`--locations=${LOCATIONS}`] : []), ...(FACTS ? [`--facts=${FACTS}`] : [])]);
{ const m = JSON.parse(fs.readFileSync(O('market.json'), 'utf8')), d = JSON.parse(fs.readFileSync(O('report-data.json'), 'utf8'));
  if (d.meta?.v2 !== true) { writeLog('STOPPED: report-data.json is not v2 data'); stop('report-data.json is not v2 data (meta.v2)'); }
  if (m.tz !== TZ || d.meta.timezone !== TZ) { writeLog('STOPPED: two time zones'); stop(`two time zones in one report: the market file ${m.tz}, the model ${d.meta.timezone}, the run ${TZ}`); } }
run('check-compare-v2', ref('check-compare-v2.mjs'), [IN('biz'), IN('full'), IN('web'), O('report-data.json')]);

// 4. the two documents, and their checks
run('build-report client', ref('build-report.mjs'), [O('report-data.json'), O('competitor-analysis.html'), '--audience=client', '--doc=Competitor Analysis']);
run('build-report service', ref('build-report.mjs'), [O('report-data.json'), O('action-plan.html'), '--audience=service', '--doc=Action Plan']);
run('verify-classes client', ref('verify-classes.mjs'), [O('competitor-analysis.html')]);
run('verify-classes service', ref('verify-classes.mjs'), [O('action-plan.html')]);
if (BROWSER) run('check-documents', CHECK_DOCS, [O('report-data.json'), O('competitor-analysis.html'), O('action-plan.html'), O('screenshots')]);

// 5. the record
const OUTPUTS = ['market.json', 'report-data.json', 'competitor-analysis.html', 'action-plan.html'];
fs.writeFileSync(O('SHA256SUMS'), OUTPUTS.map(f => `${sha(fs.readFileSync(O(f)))}  ${f}`).join('\n') + '\n');
writeLog(`DONE in ${((Date.now() - started) / 1000).toFixed(1)}s: ${OUTPUTS.join(', ')}`);
console.log(`DONE: ${OUTPUTS.map(f => path.join(OUT, f)).join(', ')}`);
