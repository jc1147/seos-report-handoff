// check-documents.mjs: the two documents used in headless Chrome over the DevTools protocol, opened straight from disk
// (file://). Every expectation comes from the report model (report-data.json) or from the reference code; nothing here
// is about one business. Modelled on check-preview.mjs sections 2 and 3 (the open page and the Action Plan).
//
// usage: node check-documents.mjs <report-data.json> <competitor-analysis.html> <action-plan.html> <screenshot folder> [--chrome=<path>]
//   Chrome: --chrome, else the CHROME_PATH environment variable, else the usual install places on Windows, macOS and Linux.
// What it checks:
//   Competitor Analysis  title "<business.short> <business.city> · Competitor Analysis"; the h1 starts with verdict.a;
//                        the Sales view, no view switch, no AI tab; every tab opens with content; the Compare switch
//                        flips; no sideways scroll at 1440 and 390; the console stays clean.
//   Action Plan          title "... · Action Plan"; the Service view, no view switch, and it stays in the Service view when
//                        the address asks for mode=sales; no text matching XACCT (the other-accounts pattern, read out of
//                        reference/build-report.mjs); every tab opens with content; one task card for each task of the
//                        model that XACCT does not match, and none for those it does; the Compare switch flips; no
//                        sideways scroll at 1440 and 390; the console stays clean.
// The only network traffic is to Chrome's own DevTools port on 127.0.0.1.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const [DATA, CA, AP, SHOTS] = argv.filter(a => !a.startsWith('--'));
if (!DATA || !CA || !AP || !SHOTS) { console.error('usage: node check-documents.mjs <report-data.json> <competitor-analysis.html> <action-plan.html> <screenshot folder> [--chrome=<path>]'); process.exit(2); }
const die = m => { console.error('DOCUMENT CHECK FAILED TO RUN: ' + m); process.exit(2); };
for (const p of [DATA, CA, AP]) if (!fs.existsSync(p)) die('no file at ' + p);
fs.mkdirSync(SHOTS, { recursive: true });

// ---------- the expectations ----------
const d = JSON.parse(fs.readFileSync(DATA, 'utf8'));
if (d.meta?.v2 !== true) die('report-data.json is not v2 data (meta.v2)');
const builder = fs.readFileSync(path.join(HERE, '..', 'reference', 'build-report.mjs'), 'utf8');
const xm = /^const XACCT = \/(.+)\/([a-z]*);$/m.exec(builder) || die('could not read XACCT out of reference/build-report.mjs');
const XACCT = new RegExp(xm[1], xm[2]);
const dash = s => String(s ?? '').replace(/[\u2012\u2013\u2014\u2015\u2212]/g, '-');      // build-report.mjs e() turns long dashes into hyphens
const squeeze = s => dash(s).replace(/\s+/g, ' ').trim();
const TITLE_CA = `${dash(d.business.short)} ${dash(d.business.city)} · Competitor Analysis`;
const TITLE_AP = `${dash(d.business.short)} ${dash(d.business.city)} · Action Plan`;
const HEAD = squeeze(d.verdict?.a);
if (!HEAD) die('report-data.json has no verdict.a');
const groups = new Set((d.task_groups || []).map(g => g.key));
const cardsWanted = (d.tasks || []).filter(t => !XACCT.test(JSON.stringify(t)) && groups.has(t.group)).map(t => t.id);
const cardsGone = (d.tasks || []).filter(t => XACCT.test(JSON.stringify(t))).map(t => t.id);

// ---------- Chrome ----------
const CANDIDATES = ['C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser'];
const chromeArg = argv.find(a => a.startsWith('--chrome='));
const CH = chromeArg ? chromeArg.slice(9) : process.env.CHROME_PATH || CANDIDATES.find(p => fs.existsSync(p)) || die('no Chrome found: pass --chrome=<path> or set CHROME_PATH');
const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'check-documents-'));
const proc = spawn(CH, ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check', '--disable-extensions', '--remote-debugging-port=0', '--user-data-dir=' + profile, 'about:blank'], { stdio: 'ignore' });
proc.on('error', e => { try { fs.rmSync(profile, { recursive: true, force: true }); } catch {} die(`Chrome did not start (${CH}): ${e.message}`); });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let ws = null, port = null;
const cleanup = async () => { try { ws?.close(); } catch {} proc.kill(); for (let i = 0; i < 10; i++) { try { fs.rmSync(profile, { recursive: true, force: true }); return; } catch { await sleep(300); } } };
for (let i = 0; i < 100 && !port; i++) { try { port = Number(fs.readFileSync(path.join(profile, 'DevToolsActivePort'), 'utf8').split('\n')[0]) || null; } catch { await sleep(150); } }
if (!port) { await cleanup(); die('Chrome did not open its DevTools port'); }
const target = await (await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' })).json();
ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.addEventListener('open', res, { once: true }); ws.addEventListener('error', rej, { once: true }); });
let id = 0; const pend = new Map(); const bad = []; const errs = [];
ws.addEventListener('message', ev => {
  const m = JSON.parse(ev.data);
  if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); return; }
  if (m.method === 'Network.responseReceived' && m.params.response.status >= 400) bad.push(`${m.params.response.status} ${m.params.response.url}`);
  if (m.method === 'Network.loadingFailed' && !m.params.canceled) bad.push(`failed ${m.params.errorText}`);
  if (m.method === 'Runtime.exceptionThrown') errs.push(m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text);
  if (m.method === 'Runtime.consoleAPICalled' && ['error', 'assert'].includes(m.params.type)) errs.push('console.' + m.params.type + ': ' + (m.params.args || []).map(a => a.value ?? a.description ?? '').join(' '));
  if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') errs.push(m.params.entry.text + ' ' + (m.params.entry.url || ''));
});
const send = (method, params = {}) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
const ev = async expr => { const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }); if (r.result?.exceptionDetails) throw new Error('page script failed: ' + expr.slice(0, 80)); return r.result?.result?.value; };
const waitFor = async (expr, ms = 20000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await ev(expr)) return true; await sleep(150); } return false; };
await send('Page.enable'); await send('Network.enable'); await send('Runtime.enable'); await send('Log.enable');
let n = 0, failed = 0;
const ok = (cond, msg) => { n++; console.log((cond ? 'PASS ' : 'FAIL ') + msg); if (!cond) failed++; };
// a fresh load every time (a change of #hash alone would not reload the page)
const go = async (url, w = 1440, h = 1000) => {
  await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: w < 600 });
  await send('Page.navigate', { url: 'about:blank' }); await waitFor('location.href === "about:blank" && document.readyState === "complete"');
  bad.length = 0; errs.length = 0;
  await send('Page.navigate', { url }); await waitFor('location.protocol === "file:" && document.readyState === "complete"'); await sleep(900);
};
const shot = async name => { const r = await send('Page.captureScreenshot', { format: 'png' }); fs.writeFileSync(path.join(SHOTS, name), Buffer.from(r.result.data, 'base64')); };
const clean = () => !bad.length && !errs.length;
const why = () => (bad.length || errs.length ? ': ' + [...bad, ...errs].slice(0, 3).join(' | ') : '');
const noSideways = 'document.documentElement.scrollWidth <= window.innerWidth + 1';
const tabsOf = () => ev('[...document.querySelectorAll(".tab-b")].map(b => b.dataset.tabSet)');
const openTabs = async (label, min) => {
  const tabs = await tabsOf();
  ok(tabs.length > 0, `${label}: the tab strip has tabs (${tabs.join(', ')})`);
  for (const k of tabs) { await ev(`document.querySelector('.tab-b[data-tab-set="${k}"]').click()`); await sleep(250); ok(await ev(`document.documentElement.dataset.tab === "${k}" && !!document.getElementById("tab-${k}") && document.getElementById("tab-${k}").innerText.trim().length > ${min}`), `${label}: tab ${k} opens with content`); }
  await ev('document.querySelector(\'.tab-b[data-tab-set="overview"]\')?.click()'); await sleep(250);
  return tabs;
};
const flipCompare = async label => {
  const has = await ev('!!document.querySelector("[data-act=compare]")');
  ok(has, `${label}: the Compare switch is on the page`); if (!has) return;
  const c0 = await ev('document.documentElement.dataset.compare');
  await ev('document.querySelector("[data-act=compare]").click()'); await sleep(200); const c1 = await ev('document.documentElement.dataset.compare');
  await ev('document.querySelector("[data-act=compare]").click()'); await sleep(200); const c2 = await ev('document.documentElement.dataset.compare');
  ok(c1 !== c0 && c2 === c0, `${label}: the Compare switch flips (${c0} -> ${c1} -> ${c2})`);
};
const caUrl = pathToFileURL(path.resolve(CA)).href, apUrl = pathToFileURL(path.resolve(AP)).href;

try {
  // ---------- the Competitor Analysis ----------
  for (const [w, h] of [[1440, 1000], [390, 860]]) {
    await go(caUrl, w, h);
    ok(clean(), `competitor analysis at ${w}: loads clean${why()}`);
    ok(await ev('document.title') === TITLE_CA, `competitor analysis at ${w}: titled "${TITLE_CA}"`);
    ok(await ev(noSideways), `competitor analysis at ${w}: no sideways scroll`);
    await shot(`competitor-analysis-${w}-top.png`);
  }
  await go(caUrl);
  const h1 = squeeze(await ev('document.querySelector("h1") ? document.querySelector("h1").innerText : ""'));
  ok(h1.startsWith(HEAD), `competitor analysis: the h1 starts with verdict.a ("${HEAD}")`);
  ok(await ev('document.documentElement.dataset.mode === "sales" && document.documentElement.dataset.audience === "client"'), 'competitor analysis: the Sales view (client copy)');
  ok(await ev('!document.querySelector("[data-mode-set]")'), 'competitor analysis: no view switch');
  ok(await ev('!document.querySelector("[data-tab-set=ai]") && !document.getElementById("tab-ai")'), 'competitor analysis: no AI tab');
  await openTabs('competitor analysis', 100);
  await flipCompare('competitor analysis');
  ok(clean(), 'competitor analysis: the console stayed clean while it was used' + why());

  // ---------- the Action Plan ----------
  for (const [w, h] of [[1440, 1000], [390, 860]]) {
    await go(apUrl + '#mode=sales&tab=overview', w, h);
    ok(clean(), `action plan at ${w}: loads clean${why()}`);
    ok(await ev('document.title') === TITLE_AP, `action plan at ${w}: titled "${TITLE_AP}"`);
    ok(await ev('document.documentElement.dataset.mode === "service"'), `action plan at ${w}: opened with #mode=sales in the address, it shows the Service view`);
    ok(await ev(noSideways), `action plan at ${w}: no sideways scroll`);
    await shot(`action-plan-${w}-top.png`);
  }
  await go(apUrl);
  ok(await ev('document.documentElement.dataset.mode === "service" && document.documentElement.dataset.audience === "service"'), 'action plan: the Service view (service copy)');
  ok(await ev('!document.querySelector("[data-mode-set]")'), 'action plan: no view switch');
  await ev('location.hash = "#mode=sales&tab=overview"'); await sleep(400);
  ok(await ev('document.documentElement.dataset.mode === "service"'), 'action plan: an address that asks for mode=sales after loading still shows the Service view');
  const markup = await ev('document.documentElement.outerHTML.replace(/<script>[\\s\\S]*?<\\/script>/g, "")');   // code out; the page's JSON data blocks stay in
  const text = await ev('document.body.innerText');
  const hitAt = s => { const i = s.search(XACCT); return i < 0 ? '' : `: "...${s.slice(Math.max(0, i - 50), i + 50)}..."`; };
  ok(!XACCT.test(markup) && !XACCT.test(text), `action plan: no text about our other accounts (XACCT, ${XACCT.source.length} characters, from reference/build-report.mjs)${hitAt(markup) || hitAt(text)}`);
  const tabs = await openTabs('action plan', 100);
  ok(tabs.includes('plan'), 'action plan: the tasks tab is on the page');
  await ev('document.querySelector(\'.tab-b[data-tab-set="plan"]\')?.click()'); await sleep(300);
  const cards = await ev('[...document.querySelectorAll("#tab-plan .tk")].map(x => x.dataset.task)');
  const missing = cardsWanted.filter(i => !cards.includes(i)), extra = cards.filter(i => !cardsWanted.includes(i)), stray = cardsGone.filter(i => cards.includes(i));
  ok(cards.length === cardsWanted.length && !missing.length && !extra.length, `action plan: the tasks tab shows ${cards.length} task cards, one for each of the ${cardsWanted.length} tasks of the model not about other accounts${missing.length ? '; missing ' + missing.join(', ') : ''}${extra.length ? '; not in the model ' + extra.join(', ') : ''}`);
  ok(!stray.length, `action plan: no card for the ${cardsGone.length} task${cardsGone.length === 1 ? '' : 's'} about other accounts${cardsGone.length ? ' (' + cardsGone.join(', ') + ')' : ''}`);
  await shot('action-plan-1440-tasks.png');
  await ev('document.querySelector(\'.tab-b[data-tab-set="overview"]\')?.click()'); await sleep(250);
  await flipCompare('action plan');
  ok(clean(), 'action plan: the console stayed clean while it was used' + why());
} catch (e) {
  ok(false, 'the check could not finish: ' + e.message);
} finally {
  await cleanup();
}
console.log(failed ? `DOCUMENT CHECK: FAIL (${failed} of ${n} failed)` : `DOCUMENT CHECK: PASS (${n} of ${n})`);
process.exitCode = failed ? 1 : 0;
