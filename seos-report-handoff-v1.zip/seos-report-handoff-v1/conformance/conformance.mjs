// conformance.mjs: same SEOS data in, same two documents out. Checks the reference chain (or a port of it) against the
// Green Haven fixture's expected outputs (fixtures/green-haven-48/expected/).
//
// usage:
//   node conformance.mjs [--no-browser] [--keep]
//       runs run-report.mjs on fixtures/green-haven-48 (scrubbed input, settings.json, the Eagle Eyes export as
//       --extra-sweep, --facts=oracle/gh-facts.json) into a fresh folder under the system temp folder, then compares:
//       market.json and both documents byte for byte, report-data.json deep-equal apart from meta.built_at.
//       Exit 0 only when all of it holds. The temp folder is removed on a pass (kept with --keep, always kept on a fail).
//   node conformance.mjs --model=<report-data.json>
//       a port's model against expected/report-data.json, deep-equal apart from meta.built_at and meta.facts_check (the
//       record of the Green Haven facts check, which only extract-v2.mjs --facts writes; a port need not port that check);
//       prints every differing path.
//   node conformance.mjs --documents=<folder>
//       a port's competitor-analysis.html and action-plan.html against expected/, byte for byte; on a difference prints
//       the first differing offset with 120 characters of context.
//   node conformance.mjs --write-expected
//       (owner only, after a reviewed change to reference/) writes expected/ from a fresh run. Refuses when expected/
//       already holds files: delete them first, on purpose.
// The Eagle Eyes export's file time is pinned from fixture.json before the run: ee-scan-to-seos.mjs stamps the sweep's
// read_at with it, and market.json and report-data.json carry read_at, so an unpinned copy would fail on another machine.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PKG = path.resolve(HERE, '..');
const FX = path.join(PKG, 'fixtures', 'green-haven-48');
const EXP = path.join(FX, 'expected');
const OUTPUTS = ['market.json', 'report-data.json', 'competitor-analysis.html', 'action-plan.html'];
const DOCS = ['competitor-analysis.html', 'action-plan.html'];
const argv = process.argv.slice(2);
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
const flag = k => argv.includes('--' + k);
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const stop = m => { console.error('CONFORMANCE STOPPED: ' + m); process.exit(2); };

// ---------- comparisons ----------
// every path where two JSON values differ, meta.built_at left out (the one clock read of the extraction); with --model also
// meta.facts_check (the fixture run writes it with --facts; a port's model has no reason to)
const SKIP = new Set(['meta.built_at', ...(opt('model') ? ['meta.facts_check'] : [])]);
const jsonDiff = (want, got) => {
  const out = [];
  const show = v => { const s = JSON.stringify(v); return s === undefined ? '(absent)' : s.length > 160 ? s.slice(0, 160) + '...' : s; };
  const walk = (a, b, p) => {
    if (SKIP.has(p)) return;
    if (a && b && typeof a === 'object' && typeof b === 'object' && Array.isArray(a) === Array.isArray(b)) {
      if (Array.isArray(a)) { if (a.length !== b.length) out.push(`${p}: ${a.length} items expected, ${b.length} found`); for (let i = 0; i < Math.max(a.length, b.length); i++) walk(a[i], b[i], `${p}[${i}]`); }
      else for (const k of [...new Set([...Object.keys(a), ...Object.keys(b)])]) walk(a[k], b[k], p ? `${p}.${k}` : k);
      return;
    }
    if (JSON.stringify(a) !== JSON.stringify(b)) out.push(`${p || '(root)'}: expected ${show(a)}, found ${show(b)}`);
  };
  walk(want, got, '');
  return out;
};
const firstDiff = (want, got) => { const n = Math.min(want.length, got.length); let i = 0; while (i < n && want[i] === got[i]) i++; return i === n && want.length === got.length ? -1 : i; };
const context = (buf, i) => JSON.stringify(buf.subarray(Math.max(0, i - 60), i + 60).toString('utf8'));
const compareBytes = (name, wantPath, gotPath) => {
  if (!fs.existsSync(gotPath)) return [`${name}: not found at ${gotPath}`];
  const want = fs.readFileSync(wantPath), got = fs.readFileSync(gotPath);
  if (want.equals(got)) return [];
  const i = firstDiff(want, got);
  return [`${name}: differs (${want.length} bytes expected, ${got.length} found); first difference at byte ${i}\n    expected ${context(want, i)}\n    found    ${context(got, i)}`];
};
const compareModel = gotPath => {
  if (!fs.existsSync(gotPath)) return [`report-data.json: not found at ${gotPath}`];
  let got; try { got = JSON.parse(fs.readFileSync(gotPath, 'utf8')); } catch (e) { return [`report-data.json: not JSON (${e.message})`]; }
  return jsonDiff(JSON.parse(fs.readFileSync(path.join(EXP, 'report-data.json'), 'utf8')), got).map(d => 'report-data.json ' + d);
};
const expectedIntact = () => {
  const sums = path.join(EXP, 'SHA256SUMS'); if (!fs.existsSync(sums)) stop('expected/SHA256SUMS is missing');
  const bad = fs.readFileSync(sums, 'utf8').trim().split('\n').map(l => l.split(/\s+/)).filter(([h, f]) => !fs.existsSync(path.join(EXP, f)) || sha(fs.readFileSync(path.join(EXP, f))) !== h).map(([, f]) => f);
  if (bad.length) stop('expected/ does not match its SHA256SUMS: ' + bad.join(', '));
};
const report = (problems, label, t0) => {
  for (const p of problems) console.log('  ' + p);
  const secs = t0 ? ` in ${((Date.now() - t0) / 1000).toFixed(1)}s` : '';
  console.log(problems.length ? `CONFORMANCE: FAIL (${label}: ${problems.length} difference${problems.length === 1 ? '' : 's'})${secs}` : `CONFORMANCE: PASS (${label})${secs}`);
  return problems.length ? 1 : 0;
};

// ---------- a port's model or documents ----------
if (opt('model')) { expectedIntact(); process.exit(report(compareModel(path.resolve(opt('model'))), 'model against expected/report-data.json, apart from meta.built_at and meta.facts_check')); }
if (opt('documents')) { expectedIntact(); const dir = path.resolve(opt('documents')); process.exit(report(DOCS.flatMap(f => compareBytes(f, path.join(EXP, f), path.join(dir, f))), 'documents against expected/, byte for byte')); }

// ---------- the reference chain on the fixture ----------
const WRITE = flag('write-expected');
if (WRITE && fs.existsSync(EXP) && fs.readdirSync(EXP).length) stop('expected/ already holds files; delete them first if the reference really changed');
if (!WRITE) expectedIntact();
const fixture = JSON.parse(fs.readFileSync(path.join(FX, 'fixture.json'), 'utf8'));
const t0 = Date.now();
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'seos-conformance-'));
const extras = (fixture.extra_sweeps || []).map(x => {
  const src = path.join(FX, x.file), dst = path.join(tmp, 'extra', path.basename(x.file));
  fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.copyFileSync(src, dst);
  if (sha(fs.readFileSync(dst)) !== x.sha256) stop(`${x.file} is not the file fixture.json records`);
  const t = new Date(x.mtime); fs.utimesSync(dst, t, t);
  if (fs.statSync(dst).mtime.toISOString() !== x.mtime) stop(`this file system cannot hold the export's file time ${x.mtime} (it reads back ${fs.statSync(dst).mtime.toISOString()})`);
  return dst;
});
const args = [path.join(PKG, 'run-report.mjs'), `--data=${path.join(FX, 'input')}`, `--settings=${path.join(FX, 'settings.json')}`, `--out=${path.join(tmp, 'out')}`,
  ...extras.map(x => `--extra-sweep=${x}`), `--facts=${path.join(FX, 'oracle', 'gh-facts.json')}`, ...(flag('no-browser') ? ['--no-browser'] : [])];
console.log(`conformance: run-report.mjs on fixtures/green-haven-48 into ${tmp}`);
const r = spawnSync(process.execPath, args, { stdio: 'inherit' });
const OUT = path.join(tmp, 'out');
if (r.status !== 0) { console.log(`  run-report.mjs exited ${r.status}; the run is kept in ${tmp}`); process.exit(report(['run-report.mjs did not finish'], 'the fixture run', t0)); }
if (WRITE) {
  fs.mkdirSync(EXP, { recursive: true });
  for (const f of OUTPUTS) fs.copyFileSync(path.join(OUT, f), path.join(EXP, f));
  fs.writeFileSync(path.join(EXP, 'SHA256SUMS'), OUTPUTS.map(f => `${sha(fs.readFileSync(path.join(EXP, f)))}  ${f}`).join('\n') + '\n');
  console.log(`wrote expected/ (${OUTPUTS.join(', ')}, SHA256SUMS) from ${OUT}`);
  if (!flag('keep')) fs.rmSync(tmp, { recursive: true, force: true });
  process.exit(0);
}
const problems = [
  ...compareBytes('market.json', path.join(EXP, 'market.json'), path.join(OUT, 'market.json')),
  ...DOCS.flatMap(f => compareBytes(f, path.join(EXP, f), path.join(OUT, f))),
  ...compareModel(path.join(OUT, 'report-data.json')),
];
const code = report(problems, 'the fixture run: market.json and both documents byte for byte, report-data.json apart from meta.built_at', t0);
if (code || flag('keep')) console.log(`  the run is kept in ${tmp}`); else fs.rmSync(tmp, { recursive: true, force: true });
process.exit(code);
