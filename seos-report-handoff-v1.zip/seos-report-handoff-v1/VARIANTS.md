# Variable data: what the report does when the data changes

Green Haven fixture (SEOS business 48). Each variant is one scripted change of the scrubbed fixture (`fixtures/green-haven-48/variants/make-variants.mjs`), run through `run-report.mjs --no-browser` and compared with **base**, the fixture run the same way (no `--facts`, like every variant). Rebuild this file with `node fixtures/green-haven-48/variants/run-variants.mjs`. Every number and quote below comes from those runs; `fixtures/green-haven-48/variants/results.json` holds all of it, the full sentence lists included.

Control: base's documents are byte-identical to `fixtures/green-haven-48/expected/`: competitor-analysis.html yes, action-plan.html yes.

| variant | what changed | outcome | verdict.a | verdict.b | checks | tasks | holds | plan items |
|---|---|---|---|---|---|---|---|---|
| base | Control: the fixture as it is (scan 320 folded in), run without --facts like every variant | built | "Nowhere for "weed near me"." | "First for "dispensary near me", by 1 point." | 43 | 34 | 9 | 10 |
| no-weed-scan | SEOS's answers alone: no Eagle Eyes export, so no "weed near me" sweep | built | "Third for "cannabis near me"." | "First for "dispensary near me", by 1 point." | 43 | 35 | 10 | 10 |
| one-search | Only the "dispensary near me" sweep (352): sweep 353's rows removed from every engine_* table of the business answer, no export | built | "First for "dispensary near me", by 1 point." | (empty) | 42 | 34 | 10 | 9 |
| no-expected-search | As no-weed-scan, and expected_searches removed from the settings | built | "Third for "cannabis near me"." | "First for "dispensary near me", by 1 point." | 42 | 34 | 9 | 10 |
| other-vertical | settings.vertical = "Dental" (the record's own vertical is empty, so the settings decide); scan 320 kept | built | "Nowhere for "weed near me"." | "First for "dispensary near me", by 1 point." | 43 | 35 | 9 | 11 |
| no-store-reviews | The store's own Google reviews reading (kind reviews) removed from the full-audit answer; scan 320 kept | stopped at check-sweeps-market |  |  |  |  |  |  |
| no-rival-pages | The rivals' readings removed from the website-audit answer (every reading not about the store); scan 320 kept | built | "Nowhere for "weed near me"." | "First for "dispensary near me", by 1 point." | 43 | 34 | 9 | 10 |

## no-weed-scan

Changed: SEOS's answers alone: no Eagle Eyes export, so no "weed near me" sweep.

Outcome: built. Searches in the model: cannabis near me: 37 of 111; dispensary near me: 58 of 121. Expected searches: weed near me; expected and not on file: weed near me.

The Competitor Analysis opens with: "Third for "cannabis near me". First for "dispensary near me", by 1 point.", then: "For "cannabis near me" Green Haven is third, in Google's top 3 at 37 of 111 map points; Zen Leaf, at number 1, holds 88. For "dispensary near me" it is number 1, at 58 of 121 points, 1 point ahead of Zen Leaf at 57. It has 434 Google rating..."

Against base:

- checks added: map-missing-weednearme; removed: map-seos-320; status changed: scan-market (The map checks' business lists are this market) fail -> watch
- tasks added: expected-search; removed: none
- holds added: "Any "weed near me" result"; "Our own accounts on this map: Joyleaf Weed Dispensary (business 29), Noire Dispensary Maplewood (business 38)"; removed: "Our own accounts on this map: Hudsonica Weed Dispensary & Delivery (business 28), Joyleaf Weed Dispensary (business 29), Noire Dispensary Maplewood (business 38)"
- plan items added: none; removed: none
- documents identical to base: Competitor Analysis no, Action Plan no

Competitor Analysis: 161 sentences not in base, 135 of base's gone. Sentences matching /weed near me/: 0 (base 17).

New: none matching.

Gone (17, first 3):
- "Nowhere for "weed near me"."
- "For "weed near me" Green Haven is not in Google's top 3 at any of the 121 map points, and not in the first 20 at any of them; Joyleaf, at number 1, holds at least 117."
- "Google Maps · "weed near me" 0 of 121 map points in Google's top 3 Number 1 is Joyleaf, at 117 or more."

Action Plan: 232 sentences not in base, 193 of base's gone. Sentences matching /weed near me/: 12 (base 20).

New:
- "1 Get the "weed near me" map check on file Us Before anything else ?"
- "No map check of "weed near me" for this store is in the record: it holds 2 sweeps for this store, "dispensary near me" and "cannabis near me"."
- "None of the 166 sweeps in the software is a "weed near me" check of this store."
- "Nothing about "weed near me" is said in this report until one is run."
- "Find the "weed near me" scan the owner remembers: it is not in the software's records."

Gone (20, first 3):
- "2 Close the gap to Joyleaf for "weed near me" Us The map ✕ Needs fixing"
- "Not in the first 20 at any of the 121 points for "weed near me"."
- "Number 1 for "weed near me", or the gap to Joyleaf halved, in a check taken in opening hours."

## one-search

Changed: Only the "dispensary near me" sweep (352): sweep 353's rows removed from every engine_* table of the business answer, no export. business-48.json: 128 rows removed.

Outcome: built. Searches in the model: dispensary near me: 58 of 121. Expected searches: weed near me; expected and not on file: weed near me.

The Competitor Analysis opens with: "First for "dispensary near me", by 1 point.", then: "For "dispensary near me" Green Haven is number 1, at 58 of 121 points, 1 point ahead of Zen Leaf at 57. It has 434 Google ratings at 5.0 stars."

Against base:

- checks added: map-missing-weednearme; removed: map-seos-353, map-seos-320; status changed: scan-market (The map checks' business lists are this market) fail -> watch, scan-setup (How the map checks were run) watch -> pass
- tasks added: expected-search; removed: map-gap
- holds added: "Any "weed near me" result"; "Our own accounts on this map: Joyleaf Weed Dispensary (business 29), Noire Dispensary Maplewood (business 38)"; removed: "Our own accounts on this map: Hudsonica Weed Dispensary & Delivery (business 28), Joyleaf Weed Dispensary (business 29), Noire Dispensary Maplewood (business 38)"
- plan items added: none; removed: map-gap
- documents identical to base: Competitor Analysis no, Action Plan no

Competitor Analysis: 180 sentences not in base, 168 of base's gone. Sentences matching /near me|map check/: 16 (base 44).

New:
- "For "dispensary near me" Green Haven is number 1, at 58 of 121 points, 1 point ahead of Zen Leaf at 57."
- "For "dispensary near me" Green Haven is number 1, at 58 of 121 points; Zen Leaf is next with 57."

Gone (30, first 3):
- "Nowhere for "weed near me"."
- "For "weed near me" Green Haven is not in Google's top 3 at any of the 121 map points, and not in the first 20 at any of them; Joyleaf, at number 1, holds at least 117."
- "For "cannabis near me" Green Haven is third, in Google's top 3 at 37 of 111 map points; Zen Leaf, at number 1, holds 88."

Action Plan: 223 sentences not in base, 209 of base's gone. Sentences matching /near me|map check/: 43 (base 60).

New:
- "1 Get the "weed near me" map check on file Us Before anything else ?"
- "No map check of "weed near me" for this store is in the record: it holds 1 sweep for this store, "dispensary near me"."
- "None of the 166 sweeps in the software is a "weed near me" check of this store."
- "Nothing about "weed near me" is said in this report until one is run."
- "Find the "weed near me" scan the owner remembers: it is not in the software's records."

Gone (37, first 3):
- "2 Close the gap to Joyleaf for "weed near me" Us The map ✕ Needs fixing"
- "3rd on the map for "cannabis near me": in Google's top 3 at 37 of 111 points."
- "Not in the first 20 at any of the 121 points for "weed near me"."

## no-expected-search

Changed: As no-weed-scan, and expected_searches removed from the settings.

Outcome: built. Searches in the model: cannabis near me: 37 of 111; dispensary near me: 58 of 121. Expected searches: none; expected and not on file: none.

The Competitor Analysis opens with: "Third for "cannabis near me". First for "dispensary near me", by 1 point.", then: "For "cannabis near me" Green Haven is third, in Google's top 3 at 37 of 111 map points; Zen Leaf, at number 1, holds 88. For "dispensary near me" it is number 1, at 58 of 121 points, 1 point ahead of Zen Leaf at 57. It has 434 Google rating..."

Against base:

- checks added: none; removed: map-seos-320; status changed: scan-market (The map checks' business lists are this market) fail -> watch
- tasks added: none; removed: none
- holds added: "Our own accounts on this map: Joyleaf Weed Dispensary (business 29), Noire Dispensary Maplewood (business 38)"; removed: "Our own accounts on this map: Hudsonica Weed Dispensary & Delivery (business 28), Joyleaf Weed Dispensary (business 29), Noire Dispensary Maplewood (business 38)"
- plan items added: none; removed: none
- documents identical to base: Competitor Analysis no, Action Plan no

Competitor Analysis: 161 sentences not in base, 135 of base's gone. Sentences matching /weed near me/: 0 (base 17).

New: none matching.

Gone (17, first 3):
- "Nowhere for "weed near me"."
- "For "weed near me" Green Haven is not in Google's top 3 at any of the 121 map points, and not in the first 20 at any of them; Joyleaf, at number 1, holds at least 117."
- "Google Maps · "weed near me" 0 of 121 map points in Google's top 3 Number 1 is Joyleaf, at 117 or more."

Action Plan: 188 sentences not in base, 167 of base's gone. Sentences matching /weed near me/: 0 (base 20).

New: none matching.

Gone (20, first 3):
- "2 Close the gap to Joyleaf for "weed near me" Us The map ✕ Needs fixing"
- "Not in the first 20 at any of the 121 points for "weed near me"."
- "Number 1 for "weed near me", or the gap to Joyleaf halved, in a check taken in opening hours."

## other-vertical

Changed: settings.vertical = "Dental" (the record's own vertical is empty, so the settings decide); scan 320 kept.

Outcome: built. Searches in the model: weed near me: 0 of 121; cannabis near me: 37 of 111; dispensary near me: 58 of 121. Expected searches: weed near me; expected and not on file: none.

The Competitor Analysis opens with: "Nowhere for "weed near me". First for "dispensary near me", by 1 point.", then: "For "weed near me" Green Haven is not in Google's top 3 at any of the 121 map points, and not in the first 20 at any of them; Joyleaf, at number 1, holds at least 117. For "cannabis near me" Green Haven is third, in Google's top 3 at 37 of ..."

Against base:

- checks added: none; removed: none; status changed: category (Main category fits the store) pass -> na
- tasks added: fix-category; removed: none
- holds added: none; removed: none
- plan items added: fix-category; removed: none
- documents identical to base: Competitor Analysis no, Action Plan no

How the words below are counted (a heuristic): a word is "in the data" when it sits inside a short string of the model's data blocks (names, searches, categories, page titles; explanations and whole sentences left out), inside a web address, or inside a name the page shortened with "…". Everything else is "in the wording", with the reference code line that holds the wording when a phrase of 18 or more characters around the word is found there.

The Competitor Analysis still says cannabis / dispensary / weed / marijuana 130 times (weed 52, dispensary 43, cannabis 34, dispensaries 1) in 102 sentences: 100 have it only in the data, 2 in the wording. The wording ones:

- "weedmaps.com Cannabis directory" (reference/build-report.mjs:515)
- "Weedmaps" (no code line found)

<details><summary>Every sentence of the Competitor Analysis that holds one of the words (102; words in it, and how many sit in the data)</summary>

- "Nowhere for "weed near me"." [1 word, 1 in the data]
- "First for "dispensary near me", by 1 point." [1 word, 1 in the data]
- "For "weed near me" Green Haven is not in Google's top 3 at any of the 121 map points, and not in the first 20 at any of them; Joyleaf, at number 1, holds at least 117." [1 word, 1 in the data]
- "For "cannabis near me" Green Haven is third, in Google's top 3 at 37 of 111 map points; Zen Leaf, at number 1, holds 88." [1 word, 1 in the data]
- "For "dispensary near me" it is number 1, at 58 of 121 points, 1 point ahead of Zen Leaf at 57." [1 word, 1 in the data]
- "Google Maps · "weed near me" 0 of 121 map points in Google's top 3 Number 1 is Joyleaf, at 117 or more." [1 word, 1 in the data]
- "Google Maps · "cannabis near me" 37 of 111 map points in Google's top 3, 3rd place Number 1 is Zen Leaf, at 88." [1 word, 1 in the data]
- "Google Maps · "dispensary near me" 58 of 121 map points in Google's top 3, number 1 Number 2 is Zen Leaf, at 57." [1 word, 1 in the data]
- "weed near me" [1 word, 1 in the data]
- "cannabis near me" [1 word, 1 in the data]
- "dispensary near me" [1 word, 1 in the data]
- "The Cannabis Place Dispensary Weed Delivery Jersey City" [3 words, 3 in the data]
- "Cannabis World" [1 word, 1 in the data]
- "Uber weed delivery service LLC" [1 word, 1 in the data]
- "The Weed Shoppe" [1 word, 1 in the data]
- "Weed Land" [1 word, 1 in the data]
- "Ｗeed And De𝗅ivery Dispensary, 160 Polk St" [1 word, 1 in the data]
- "Top 3: Budzooka, Joyleaf, Greenhouse Canna store, Exotic weed and THC Dispo." [1 word, 1 in the data]
- "Top 3: Budzooka, Joyleaf, The Cannabis Place Dispensary Weed Delivery Jersey City." [3 words, 3 in the data]
- "Top 3: Budzooka, The Cannabis Place Dispensary Weed Delivery Jersey City, Joyleaf." [3 words, 3 in the data]
- "Top 3: Budzooka, The Cannabis Place Dispensary Weed Delivery Jersey City, Greenhouse Canna store, Exotic weed and THC Dispo." [4 words, 4 in the data]
- "Top 3: Joyleaf, Budzooka, Greenhouse Canna store, Exotic weed and THC Dispo." [1 word, 1 in the data]
- "Top 3: Budzooka, ZenZest, The Cannabis Place Dispensary Weed Delivery Jersey City." [3 words, 3 in the data]
- "Top 3: ZenZest, Budzooka, Greenhouse Canna store, Exotic weed and THC Dispo." [1 word, 1 in the data]
- "Top 3: ZenZest, Joyleaf, Greenhouse Canna store, Exotic weed and THC Dispo." [1 word, 1 in the data]
- "Top 3: ZenZest, Greenhouse Canna store, Exotic weed and THC Dispo, Joyleaf." [1 word, 1 in the data]
- "Top 3: Joyleaf, Greenhouse Canna store, Exotic weed and THC Dispo, Budzooka." [1 word, 1 in the data]
- "Top 3: Joyleaf, ZenZest, Greenhouse Canna store, Exotic weed and THC Dispo." [1 word, 1 in the data]
- "Joyleaf Weed Dispensary: top 3 at 117 of 121 points, listed at 121." [2 words, 2 in the data]
- "Budzooka Weed Dispensary: top 3 at 103 of 121 points, listed at 121." [2 words, 2 in the data]
- "ZenZest Weed Dispensary Staten Island & Cannabis Delivery: top 3 at 67 of 121 points, listed at 121." [3 words, 3 in the data]
- "The Cannabis Place Dispensary Weed Delivery Jersey City: top 3 at 10 of 121 points, listed at 121." [3 words, 3 in the data]
- "4 The Cannabis Place Dispensary Weed Delivery Jersey City 10" [3 words, 3 in the data]
- "Cannabis World Weed Delivery New York: top 3 at 0 of 121 points, listed at 121." [2 words, 2 in the data]
- "- Cannabis World 0" [1 word, 1 in the data]
- "TerpTaxi Weed Delivery NJ: top 3 at 0 of 121 points, listed at 121." [1 word, 1 in the data]
- "Noire Weed Dispensary Maplewood: top 3 at 0 of 121 points, listed at 121." [2 words, 2 in the data]
- "Battery Weed: top 3 at 0 of 121 points, listed at 121." [1 word, 1 in the data]
- "Uber weed delivery service LLC: top 3 at 0 of 121 points, listed at 121." [1 word, 1 in the data]
- "- Uber weed delivery service LLC 0" [1 word, 1 in the data]
- "The Weed Shoppe: top 3 at 0 of 121 points, listed at 121." [1 word, 1 in the data]
- "- The Weed Shoppe 0" [1 word, 1 in the data]
- "Map points in Google's top 3 for "weed near me" Number 1 on the map: Joyleaf" [1 word, 1 in the data]
- "Google ratings Number 1 for "weed near me": Joyleaf" [1 word, 1 in the data]
- "Photos on the Google listing Number 1 for "weed near me": Joyleaf" [1 word, 1 in the data]
- "Map points in Google's top 3 for "cannabis near me" Number 1 on the map: Zen Leaf" [1 word, 1 in the data]
- "Ways to shop on the listing Number 1 for "weed near me": Joyleaf" [1 word, 1 in the data]
- "Map points in Google's top 3 for "dispensary near me" Number 2 on the map: Zen Leaf" [1 word, 1 in the data]
- "Star rating Number 1 for "weed near me": Joyleaf" [1 word, 1 in the data]
- "Details filled in on the listing Number 1 for "weed near me": Joyleaf" [1 word, 1 in the data]
- "Google Maps Number 1 on the map for "cannabis near me" 37 of 111 points" [1 word, 1 in the data]
- "Google Maps Number 1 on the map for "weed near me" Not found" [1 word, 1 in the data]
- "Google Maps Number 1 on the map for "dispensary near me" 58 of 121 points" [1 word, 1 in the data]
- "Win "weed near me" on the map" [1 word, 1 in the data]
- "Name Green Haven Industries Address 402 Elizabeth Ave, Elizabeth, NJ 07206 Phone (908) 242-5119 Hours Mon to Fri 10 AM to 10 PM, Sat 10 AM to 9 PM, Sun 11 AM to 9 PM Category Cannabis store Rating 5 s..." [1 word, 1 in the data]
- "For "weed near me" Green Haven is in the top 3 at none, at 0 of 121 points; Joyleaf is number 1 with at least 117." [1 word, 1 in the data]
- "For "cannabis near me" it is 3rd, at 37 of 111 points; Zen Leaf is number 1 with 88." [1 word, 1 in the data]
- "For "dispensary near me" it is number 1, at 58 of 121 points; Zen Leaf is next with 57." [1 word, 1 in the data]
- "Points in Google's top 3 for "weed near me"" [1 word, 1 in the data]
- "The Cannabis Place Dispensary Wee…: 10 of 121" [2 words, 2 in the data]
- "The Cannabis Place Dispensary Wee…" [2 words, 2 in the data]
- "Points in Google's top 3 for "cannabis near me"" [1 word, 1 in the data]
- "Oz Dispensary: 20 of 111" [1 word, 1 in the data]
- "Oz Dispensary" [1 word, 1 in the data]
- "Points in Google's top 3 for "dispensary near me"" [1 word, 1 in the data]
- "Green Leaf Dispensary: 44 of 121" [1 word, 1 in the data]
- "Green Leaf Dispensary" [1 word, 1 in the data]
- "The Flowery Dispensary Richmond A…" [1 word, 1 in the data]
- "Green Leaf Cannabis LLC" [1 word, 1 in the data]
- "The Dispensary of Union" [1 word, 1 in the data]
- "FlynnStoned Cannabis Dispensary -…" [2 words, 2 in the data]
- "The Flowery Dispensary Staten Isl…" [1 word, 1 in the data]
- "Ｗeed And De𝗅ivery Dispensary" [1 word, 1 in the data]
- "Map points are the points in Google's top 3 for "dispensary near me", of 121." [1 word, 1 in the data]
- "Green Leaf Dispensary: 6 ratings" [1 word, 1 in the data]
- "The businesses with the most top-3 points for "dispensary near me"." [1 word, 1 in the data]
- "Green Leaf Dispensary: 1 photos" [1 word, 1 in the data]
- "Green Leaf Dispensary: 4.7 stars" [1 word, 1 in the data]
- "Map points are for "dispensary near me"." [1 word, 1 in the data]
- "Number 1 on the map for "cannabis near me"" [1 word, 1 in the data]
- "3rd on the map for "cannabis near me": in Google's top 3 at 37 of 111 points." [1 word, 1 in the data]
- "Number 1 on the map for "weed near me"" [1 word, 1 in the data]
- "Not in the first 20 at any of the 121 points for "weed near me"." [1 word, 1 in the data]
- "Cannabis store" [1 word, 1 in the data]
- "The main category is Cannabis store." [1 word, 1 in the data]
- "Number 1 on the map for "dispensary near me"" [1 word, 1 in the data]
- "Number 1 for "dispensary near me": in Google's top 3 at 58 of 121 points, 1 point ahead of Zen Leaf (57)." [1 word, 1 in the data]
- "At least 119 of the 121 points list the store in Google's first 20 results for "dispensary near me"." [1 word, 1 in the data]
- "Number 1 for "weed near me" holds at least 117 of 121 points; the store holds 0." [1 word, 1 in the data]
- "weedmaps.com" [1 word, 1 in the data]
- "cannabispromotions.com" [1 word, 1 in the data]
- "freshcannabis.co" [1 word, 1 in the data]
- "Shared means both websites show up in Google's first 100 results for the same search. weedmaps.com is there for 96 of the 122 searches this website shows up for." [1 word, 1 in the data]
- "zenleafdispensaries.com/locations/elizabeth" [1 word, 1 in the data]
- "zenzestweeddispensary.com" [1 word, 1 in the data]
- "Title Green Haven Industries: Cannabis Dispensary in Elizabeth, NJ Main heading Premium Weed in Elizabeth, NJ Words 2,393 as a crawler, 2,404 in a browser Age check On the page; the text still reaches..." [3 words, 3 in the data]
- "The page has a main heading: "Premium Weed in Elizabeth, NJ"." [1 word, 1 in the data]
- "Title: "Green Haven Industries: Cannabis Dispensary in Elizabeth, NJ"." [2 words, 2 in the data]
- "weedmaps.com Cannabis directory" [2 words, 1 in the data]
- "blackherb.org blissco.life bn.toponavi.com bt.toponavi.com cannabispromotions.com cannawayz.com jointcommerce.com manta.com mapquest.com smokeshops.com yelp.com" [1 word, 1 in the data]
- "Weedmaps" [1 word, 0 in the data]
- "cannabisforthailand.com" [1 word, 1 in the data]

</details>

The Action Plan still says cannabis / dispensary / weed / marijuana 158 times (weed 58, cannabis 46, dispensary 49, dispensaries 4, marijuana 1) in 121 sentences: 114 have it only in the data, 7 in the wording. The wording ones:

- "Who holds the logins for the store's listings (Google, Weedmaps, Leafly, Yelp, Apple Maps)?" (reference/extract-v2.mjs:918)
- "weedmaps.com Cannabis directory" (reference/build-report.mjs:515)
- "Weedmaps" (no code line found)
- "What the 22 with weight are, by their pages' titles: 9 carry the store's name in the page title, directory pages and articles (blackherb.org, activeplayhub.net, whatnetworksph.com, pressloaded.net, jointcommerce.com, can..." (no code line found)
- "Open each listing in the tables on the Links and listings tab: Google Business Profile, Apple Maps, Bing Places, Yelp, Facebook, Weedmaps, Leafly, Dutchie." (no code line found)
- "Settle the 120 directories the software could not read either way, starting with the core and cannabis ones." (reference/extract-v2.mjs:928)
- "Start with the cannabis sites: weedmaps.com." (reference/extract-v2.mjs:930)

<details><summary>Every sentence of the Action Plan that holds one of the words (121; words in it, and how many sit in the data)</summary>

- "Who holds the logins for the store's listings (Google, Weedmaps, Leafly, Yelp, Apple Maps)?" [1 word, 0 in the data]
- "2 Close the gap to Joyleaf for "weed near me" Us The map ✕ Needs fixing" [1 word, 1 in the data]
- "3rd on the map for "cannabis near me": in Google's top 3 at 37 of 111 points." [1 word, 1 in the data]
- "Not in the first 20 at any of the 121 points for "weed near me"." [1 word, 1 in the data]
- "Number 1 for "weed near me", or the gap to Joyleaf halved, in a check taken in opening hours." [1 word, 1 in the data]
- "The main category is Cannabis store." [1 word, 1 in the data]
- "weed near me" [1 word, 1 in the data]
- "cannabis near me" [1 word, 1 in the data]
- "dispensary near me" [1 word, 1 in the data]
- "The Cannabis Place Dispensary Weed Delivery Jersey City" [3 words, 3 in the data]
- "Cannabis World" [1 word, 1 in the data]
- "Uber weed delivery service LLC" [1 word, 1 in the data]
- "The Weed Shoppe" [1 word, 1 in the data]
- "Weed Land" [1 word, 1 in the data]
- "Ｗeed And De𝗅ivery Dispensary, 160 Polk St" [1 word, 1 in the data]
- "Top 3: Budzooka, Joyleaf, Greenhouse Canna store, Exotic weed and THC Dispo." [1 word, 1 in the data]
- "Top 3: Budzooka, Joyleaf, The Cannabis Place Dispensary Weed Delivery Jersey City." [3 words, 3 in the data]
- "Top 3: Budzooka, The Cannabis Place Dispensary Weed Delivery Jersey City, Joyleaf." [3 words, 3 in the data]
- "Top 3: Budzooka, The Cannabis Place Dispensary Weed Delivery Jersey City, Greenhouse Canna store, Exotic weed and THC Dispo." [4 words, 4 in the data]
- "Top 3: Joyleaf, Budzooka, Greenhouse Canna store, Exotic weed and THC Dispo." [1 word, 1 in the data]
- "Top 3: Budzooka, ZenZest, The Cannabis Place Dispensary Weed Delivery Jersey City." [3 words, 3 in the data]
- "Top 3: ZenZest, Budzooka, Greenhouse Canna store, Exotic weed and THC Dispo." [1 word, 1 in the data]
- "Top 3: ZenZest, Joyleaf, Greenhouse Canna store, Exotic weed and THC Dispo." [1 word, 1 in the data]
- "Top 3: ZenZest, Greenhouse Canna store, Exotic weed and THC Dispo, Joyleaf." [1 word, 1 in the data]
- "Top 3: Joyleaf, Greenhouse Canna store, Exotic weed and THC Dispo, Budzooka." [1 word, 1 in the data]
- "Top 3: Joyleaf, ZenZest, Greenhouse Canna store, Exotic weed and THC Dispo." [1 word, 1 in the data]
- "Joyleaf Weed Dispensary: top 3 at 117 of 121 points, listed at 121." [2 words, 2 in the data]
- "Budzooka Weed Dispensary: top 3 at 103 of 121 points, listed at 121." [2 words, 2 in the data]
- "ZenZest Weed Dispensary Staten Island & Cannabis Delivery: top 3 at 67 of 121 points, listed at 121." [3 words, 3 in the data]
- "The Cannabis Place Dispensary Weed Delivery Jersey City: top 3 at 10 of 121 points, listed at 121." [3 words, 3 in the data]
- "4 The Cannabis Place Dispensary Weed Delivery Jersey City 10" [3 words, 3 in the data]
- "Cannabis World Weed Delivery New York: top 3 at 0 of 121 points, listed at 121." [2 words, 2 in the data]
- "- Cannabis World 0" [1 word, 1 in the data]
- "TerpTaxi Weed Delivery NJ: top 3 at 0 of 121 points, listed at 121." [1 word, 1 in the data]
- "Noire Weed Dispensary Maplewood: top 3 at 0 of 121 points, listed at 121." [2 words, 2 in the data]
- "Battery Weed: top 3 at 0 of 121 points, listed at 121." [1 word, 1 in the data]
- "Uber weed delivery service LLC: top 3 at 0 of 121 points, listed at 121." [1 word, 1 in the data]
- "- Uber weed delivery service LLC 0" [1 word, 1 in the data]
- "The Weed Shoppe: top 3 at 0 of 121 points, listed at 121." [1 word, 1 in the data]
- "- The Weed Shoppe 0" [1 word, 1 in the data]
- "Map points in Google's top 3 for "weed near me" Number 1 on the map: Joyleaf" [1 word, 1 in the data]
- "Google ratings Number 1 for "weed near me": Joyleaf" [1 word, 1 in the data]
- "Photos on the Google listing Number 1 for "weed near me": Joyleaf" [1 word, 1 in the data]
- "Map points in Google's top 3 for "cannabis near me" Number 1 on the map: Zen Leaf" [1 word, 1 in the data]
- "Ways to shop on the listing Number 1 for "weed near me": Joyleaf" [1 word, 1 in the data]
- "Map points in Google's top 3 for "dispensary near me" Number 2 on the map: Zen Leaf" [1 word, 1 in the data]
- "Star rating Number 1 for "weed near me": Joyleaf" [1 word, 1 in the data]
- "Details filled in on the listing Number 1 for "weed near me": Joyleaf" [1 word, 1 in the data]
- "Google Maps Number 1 on the map for "cannabis near me" 37 of 111 points" [1 word, 1 in the data]
- "Google Maps Number 1 on the map for "weed near me" Not found" [1 word, 1 in the data]
- "Google Maps Number 1 on the map for "dispensary near me" 58 of 121 points" [1 word, 1 in the data]
- "Zen Leaf's Google listing links to one store's page on zenleafdispensaries.com, a website for many stores." [1 word, 1 in the data]
- ""dispensary near me": not found at 2 of 121 points" [1 word, 1 in the data]
- "Google Maps 0 of 121 map points in the top 3, "weed near me"" [1 word, 1 in the data]
- "Nowhere for "weed near me"." [1 word, 1 in the data]
- "First for "dispensary near me", by 1 point." [1 word, 1 in the data]
- "For "weed near me" Green Haven is in the top 3 at none, at 0 of 121 points; Joyleaf is number 1 with at least 117." [1 word, 1 in the data]
- "For "cannabis near me" it is 3rd, at 37 of 111 points; Zen Leaf is number 1 with 88." [1 word, 1 in the data]
- "For "dispensary near me" it is number 1, at 58 of 121 points; Zen Leaf is next with 57." [1 word, 1 in the data]
- "Points in Google's top 3 for "weed near me"" [1 word, 1 in the data]
- "The Cannabis Place Dispensary Wee…: 10 of 121" [2 words, 2 in the data]
- "The Cannabis Place Dispensary Wee…" [2 words, 2 in the data]
- "Points in Google's top 3 for "cannabis near me"" [1 word, 1 in the data]
- "Oz Dispensary: 20 of 111" [1 word, 1 in the data]
- "Oz Dispensary" [1 word, 1 in the data]
- "Points in Google's top 3 for "dispensary near me"" [1 word, 1 in the data]
- "Green Leaf Dispensary: 44 of 121" [1 word, 1 in the data]
- "Green Leaf Dispensary" [1 word, 1 in the data]
- "The Flowery Dispensary Richmond A…" [1 word, 1 in the data]
- "Green Leaf Cannabis LLC" [1 word, 1 in the data]
- "The Dispensary of Union" [1 word, 1 in the data]
- "FlynnStoned Cannabis Dispensary -…" [2 words, 2 in the data]
- "The Flowery Dispensary Staten Isl…" [1 word, 1 in the data]
- "Ｗeed And De𝗅ivery Dispensary" [1 word, 1 in the data]
- "Map points are the points in Google's top 3 for "dispensary near me", of 121." [1 word, 1 in the data]
- "Green Leaf Dispensary: 6 ratings" [1 word, 1 in the data]
- "The businesses with the most top-3 points for "dispensary near me"." [1 word, 1 in the data]
- "Green Leaf Dispensary: 1 photos" [1 word, 1 in the data]
- "Green Leaf Dispensary: 4.7 stars" [1 word, 1 in the data]
- "Map points are for "dispensary near me"." [1 word, 1 in the data]
- "Name Green Haven Industries Address 402 Elizabeth Ave, Elizabeth, NJ 07206 Phone (908) 242-5119 Hours Mon to Fri 10 AM to 10 PM, Sat 10 AM to 9 PM, Sun 11 AM to 9 PM Category Cannabis store Rating 5 s..." [1 word, 1 in the data]
- "Number 1 on the map for "cannabis near me"" [1 word, 1 in the data]
- "Number 1 on the map for "weed near me"" [1 word, 1 in the data]
- "Cannabis store" [1 word, 1 in the data]
- "Number 1 on the map for "dispensary near me"" [1 word, 1 in the data]
- "Number 1 for "dispensary near me": in Google's top 3 at 58 of 121 points, 1 point ahead of Zen Leaf (57)." [1 word, 1 in the data]
- "Google listed the store in its first 20 results at 119 of 121 points for "dispensary near me"." [1 word, 1 in the data]
- "For "weed near me" it is in the top 3 at none at 0 of 121 points; Joyleaf is number 1 with at least 117." [1 word, 1 in the data]
- "For "cannabis near me" it is 3rd at 37 of 111 points; Zen Leaf is number 1 with 88." [1 word, 1 in the data]
- "For "dispensary near me" the store is number 1 at 58 of 121 points; Zen Leaf is next with 57." [1 word, 1 in the data]
- "In "dispensary near me" they show up in the first 20 at 27 of 121 points, at most 5 in one list; 2 of the points where the store was not found carry them." [1 word, 1 in the data]
- "In "cannabis near me" they show up in the first 20 at 1 of 111 points, at most 5 in one list." [1 word, 1 in the data]
- "In "weed near me" they show up in the first 20 at 120 of 121 points, at most 3 in one list; 120 of the points where the store was not found carry them; one reached a top 3 at 66 points." [1 word, 1 in the data]
- "Read again with them taken out of each list, the store's count is the same (0), and the others' rise: Joyleaf 117 to 119, Budzooka 103 to 114, ZenZest 67 to 89, The Cannabis Place Dispensary Wee… 10 t..." [2 words, 2 in the data]
- ""dispensary near me": started by an admin (whole feed), 121 points; "cannabis near me": the software holds no record of who started it or when (whole feed), 111 points, 10 of the 121 grid points left ..." [3 words, 3 in the data]
- "Counts for "cannabis near me" are of 111 points, not 121." [1 word, 1 in the data]
- ""dispensary near me" ran 7:14 PM to 7:21 PM on Sunday, Oct 11; the store's hours that day: 11 AM to 9 PM. "cannabis near me" finished 7:26 PM on Sunday, Oct 11; the store's hours that day: 11 AM to 9 ..." [3 words, 3 in the data]
- "weedmaps.com" [1 word, 1 in the data]
- "cannabispromotions.com" [1 word, 1 in the data]
- "freshcannabis.co" [1 word, 1 in the data]
- "Shared means both websites show up in Google's first 100 results for the same search. weedmaps.com is there for 96 of the 122 searches this website shows up for." [1 word, 1 in the data]
- "zenleafdispensaries.com/locations/elizabeth" [1 word, 1 in the data]
- "zenzestweeddispensary.com" [1 word, 1 in the data]
- "Title Green Haven Industries: Cannabis Dispensary in Elizabeth, NJ Main heading Premium Weed in Elizabeth, NJ Words 2,393 as a crawler, 2,404 in a browser Age check On the page; the text still reaches..." [3 words, 3 in the data]
- "The page has a main heading: "Premium Weed in Elizabeth, NJ"." [1 word, 1 in the data]
- "Title: "Green Haven Industries: Cannabis Dispensary in Elizabeth, NJ"." [2 words, 2 in the data]
- "weedmaps.com Cannabis directory" [2 words, 1 in the data]
- "blackherb.org blissco.life bn.toponavi.com bt.toponavi.com cannabispromotions.com cannawayz.com jointcommerce.com manta.com mapquest.com smokeshops.com yelp.com" [1 word, 1 in the data]
- "Weedmaps" [1 word, 0 in the data]
- "californiacannabis.directory" [1 word, 1 in the data]
- "freecannabis.directory" [1 word, 1 in the data]
- "thecannabiswire.com" [1 word, 1 in the data]
- "What the 22 with weight are, by their pages' titles: 9 carry the store's name in the page title, directory pages and articles (blackherb.org, activeplayhub.net, whatnetworksph.com, pressloaded.net, jo..." [4 words, 3 in the data]
- "Open each listing in the tables on the Links and listings tab: Google Business Profile, Apple Maps, Bing Places, Yelp, Facebook, Weedmaps, Leafly, Dutchie." [1 word, 0 in the data]
- "Settle the 120 directories the software could not read either way, starting with the core and cannabis ones." [1 word, 0 in the data]
- "Start with the cannabis sites: weedmaps.com." [2 words, 1 in the data]
- "Evidence: merchantcircle.com/​search?q=Dispensary&qn=Elizabeth%2C%20NJ" [1 word, 1 in the data]
- "Open the evidence: merchantcircle.com/​search?q=Dispensary&qn=Elizabeth%2C%20NJ" [1 word, 1 in the data]
- "Evidence: jointcommerce.com/​dispensaries/​green-haven-industries" [1 word, 1 in the data]
- "Open the evidence: jointcommerce.com/​dispensaries/​green-haven-industries" [1 word, 1 in the data]
- "cannabisforthailand.com" [1 word, 1 in the data]

</details>

## no-store-reviews

Changed: The store's own Google reviews reading (kind reviews) removed from the full-audit answer; scan 320 kept. full-audit-48.json: 1 rows removed.

Outcome: **stopped** at `check-sweeps-market`. run-report.mjs printed:

```
RUN STOPPED at check-sweeps-market (exit 1)
  MISMATCH  velocity of the store against SEOS's own 30-day snapshot
      file: null  raw: 17
  MISMATCH  velocity of the store against SEOS's own 90-day snapshot
      file: null  raw: 42
  MISMATCH  velocity of the store against SEOS's own 365-day snapshot
      file: null  raw: 341
  1685 checks, 3 disagreements
  SWEEPS MARKET CHECK: FAIL
```

## no-rival-pages

Changed: The rivals' readings removed from the website-audit answer (every reading not about the store); scan 320 kept. website-audit-48.json: 9 rows removed.

Outcome: built. Searches in the model: weed near me: 0 of 121; cannabis near me: 37 of 111; dispensary near me: 58 of 121. Expected searches: weed near me; expected and not on file: none.

The Competitor Analysis opens with: "Nowhere for "weed near me". First for "dispensary near me", by 1 point.", then: "For "weed near me" Green Haven is not in Google's top 3 at any of the 121 map points, and not in the first 20 at any of them; Joyleaf, at number 1, holds at least 117. For "cannabis near me" Green Haven is third, in Google's top 3 at 37 of ..."

Against base:

- checks added: none; removed: none; status changed: none
- tasks added: none; removed: none
- holds added: "Whole-site crawl counts and scores: 4 duplicate titles, 4 duplicate descriptions, score 95.05; "; removed: "Whole-site crawl counts and scores: 4 duplicate titles, 4 duplicate descriptions, score 95.05; Zen Leaf 84.8, Budzooka 92.65, ZenZest 92.8"
- plan items added: none; removed: none
- documents identical to base: Competitor Analysis no, Action Plan no

Competitor Analysis: 0 sentences not in base, 1 of base's gone. Sentences matching /front page|home page|website|page|speed|crawl/: 131 (base 132).

New: none matching.

Gone (1, first 1):
- "2nd of 4 store pages on a phone."

Action Plan: 3 sentences not in base, 18 of base's gone. Sentences matching /front page|home page|website|page|speed|crawl/: 226 (base 232).

New:
- "Whole-site crawl counts and scores: 4 duplicate titles, 4 duplicate descriptions, score 95.05;"
- "The website audit also read each website's front page the night before: (the store's page is its front page, the same read)."

Gone (8, first 3):
- "Whole-site crawl counts and scores: 4 duplicate titles, 4 duplicate descriptions, score 95.05; Zen Leaf 84.8, Budzooka 92.65, ZenZest 92.8"
- "2nd of 4 store pages on a phone."
- "The website audit also read each website's front page the night before: Zen Leaf 7 on a phone, 45 on a desktop; Budzooka 37 on a phone, 58 on a desktop; ZenZest 88 on a phone, 66 on a desktop (the store's page is its front page, the same re..."

## Reference code lines that hold these words

23 lines in reference/ (comment lines left out) hold cannabis, dispensar-, weed or marijuana. By file: reference/extract-v2.mjs 14, reference/build-report.mjs 8, reference/sweeps-market.mjs 1.

- reference/extract-v2.mjs:67: `, 'green haven industries'], agency: 'Dispenza', vertical: 'Cannabis', expect: ['weed near me'],`
- reference/extract-v2.mjs:108: `=> { let x = String(nm).split(' - ')[0]; for (const w of [' Weed', ' Cannabis', ' Dispensary', ' Marijuana', ' Recreatio`
- reference/extract-v2.mjs:283: `const plain = '${loc.city} dispensary'.toLowerCase();`
- reference/extract-v2.mjs:338: `['the product', /quality|dry|old|stale|weak|moldy|bad weed|product/i],`
- reference/extract-v2.mjs:492: `const CANNABIS_SITE = /canna|leaf|ganja|weed|420|bud|dispens|marij`
- reference/extract-v2.mjs:564: `({ domain: g.domain, score: g.score, rivals: [...g.rivals], cannabis: CANNABIS_SITE.test(g.domain) }));`
- reference/extract-v2.mjs:595: `['weedmaps', 'Weedmaps', /(^|\.)weedmaps\.com$/, 'weedmaps.com`
- reference/extract-v2.mjs:789: `const CATEGORY = { Cannabis: ['cannabis_store'] };`
- reference/extract-v2.mjs:865: `pied.join(', ')}); ' : ''}${plural(q.articles.length, 'is a cannabis article', 'are cannabis articles')} on general site`
- reference/extract-v2.mjs:909: `const worthCannabis = (links?.gap_worth || []).filter(g => g.cannabis).`
- reference/extract-v2.mjs:918: `?', "Who holds the logins for the store's listings (Google, Weedmaps, Leafly, Yelp, Apple Maps)?"], done: 'All three ans`
- reference/extract-v2.mjs:928: `tware could not read either way, starting with the core and cannabis ones.' : 'Note the name, address, phone, hours and`
- reference/extract-v2.mjs:930: `steps: [worthCannabis.length ? 'Start with the cannabis sites: ${worthCan`
- reference/extract-v2.mjs:1334: `for (const kw of set.expect || []) if (kw === 'weed near me') eq('"weed near me" sweep on file for this rep`
- reference/build-report.mjs:83: `const RANK_NOTE = 'In our own study of cannabis map checks, stores with these in place ranked highe`
- reference/build-report.mjs:194: `"tile-u">of ${n(S.top10)} page 1 searches is a ${e(B.city)} dispensary search</span><span class="tile-s">${S.sister_town`
- reference/build-report.mjs:417: `if (!V2) fact('Page 1 for "${B.city} dispensary" searches', S.town_page1 ? n(S.town_page1) : 'Non`
- reference/build-report.mjs:425: `{B.city} page', S.other_store_page, 'search', 'two-pages', 'dispensary-locations page two pages which page');`
- reference/build-report.mjs:439: `<div class="card" id="town"><p class="card-k">"${e(B.city)} dispensary" searches, without the store's name</p><div class`
- reference/build-report.mjs:440: `'${v} with ${k === 'shop' ? '/shop' : k === 'locations' ? '/dispensary-locations' : 'other'} pages').join(', ')}. Only $`
- reference/build-report.mjs:502: `class="cols" role="img" aria-label="Linking sites for each dispensary website from the map check's list">${L.field.map(`
- reference/build-report.mjs:515: `ad><tbody>${L.gap_worth.map(g => '<tr><td>${e(g.domain)}${g.cannabis ? ' <span class="chip chip-plain">Cannabis director`
- reference/sweeps-market.mjs:207: `const KIND = [' Weed', ' Cannabis', ' Dispensary', ' Marijuana', ' Recreatio`
