# The builders' reports

Four agents built this package's parts on 2026-10-12, in parallel, each from the reference code and the Green Haven data.
These are their reports as they returned them. One edit: in `B-contract.json` the absolute paths into our working tree
were cut to start at the repository folder (`Product/seos-report/...`), so they no longer carry our machine's folder
names; read every path in these reports as relative to our repository, mapped to this package by SPEC.md section 13.

| File | Part | Holds |
|---|---|---|
| `A-build.json` | runner, fixture, conformance, variants | every file, check and result; the scrub record; the runner's stages and failure tests; 21 findings; 8 unverified points |
| `B-contract.json` | inputs, settings, model | how each contract file was generated; 14 checks; counts; 26 findings; 10 unverified points |
| `C1-outline.json` | outline and wording | how to run the checkers; 9 checks; 27 findings; 6 unverified points |
| `C2-rules.json` | rules | what was read; 10 checks; counts; 19 findings; 8 unverified points |

`OPEN-ITEMS.md` merges the 93 findings (many were found by more than one part) into one list.

## What changed after these reports

Two changes were made to the fixture after them, during assembly (`fixtures/green-haven-48/scrub.mjs`,
`input/SCRUBBED.md`):

- the SEOS console users' e-mail addresses (2 addresses, held as whole values in 973 fields across 5 input files) were
  replaced by `person-<n>@example.invalid`. Part A had left them in and flagged them for a decision;
- after the independent check, the Eagle Eyes export's `request.vantage.ip` and `.isp` (the scan machine's network
  address and provider) were set to null. Nothing in the chain reads them: every output came out byte-identical, and
  `expected/` did not change.

Effects, measured:

- The two expected documents did not change (byte-identical to the live Green Haven documents before and after).
- `expected/market.json` and `expected/report-data.json` changed only where they record the input files' size and
  sha256 (5 and 13 paths). Conformance passed on the new fixture; the variants' results and `VARIANTS.md` came out
  byte-identical.
- So the sha256 values that `A-build.json` gives for the fixture's input files (`fixture.input_files`, the Eagle Eyes
  export's included), for `expected/market.json` and `expected/report-data.json` (`conformance.expected`) and in its
  scrub record are those of the fixture before these changes. The current values are in `fixtures/green-haven-48/fixture.json`,
  `fixtures/green-haven-48/expected/SHA256SUMS` and `MANIFEST.json`. The documents' values in `A-build.json` still hold.
- `A-build.json`'s note that the e-mail addresses are "the owner's call" is settled by this change.
