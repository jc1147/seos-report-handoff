// scrub.mjs: builds this fixture's input/ from a folder of SEOS answers, with the privacy scrub applied to the copies.
// One script, run once by the person who builds the fixture. It never prints a value it removes: SCRUBBED.md and
// fixture.json record what was removed as counts and kinds only.
//
// usage: node scrub.mjs <SEOS data folder> --settings=<business-settings file> [--extra=<Eagle Eyes export>]...
//          [--out=<folder>] [--mode=stub|remove]
//   <SEOS data folder>  the answers as fetched: business-<id>.json, full-audit-<id>.json, website-audit-<id>.json,
//                       engine_sweeps-all.json, locations-all.json (and the oracle's two extra files, below)
//   --settings          copied as it is to <fixture>/settings.json
//   --extra             an Eagle Eyes scan export, copied as it is to <out>/extra-ee/; its file time is recorded in
//                       fixture.json (ee-scan-to-seos.mjs stamps read_at with it, see SCRUBBED.md)
//   --out               default: <this folder>/input. fixture.json and settings.json go next to it.
//   --mode              stub (default): another account's analytics readings keep kind, place, site and time and lose
//                       request, result and endpoints. remove: those readings are dropped whole (used only to measure
//                       what the report would print without them; see SCRUBBED.md).
//
// What the scrub does (each rule is checked against the chain's code, which this script reads):
//   business-<id>.json  a table is removed when its name marks tokens, credentials or Google-account links and no
//                       script in the chain names it; a column is removed when its name holds token, secret, key,
//                       password or refresh and no script names it. Everything else is kept byte for byte.
//   full-audit-<id>.json  the Google Analytics and Search Console readings (kinds analytics_*, gsc_*, ga4_*) of any
//                       place that is not the store are emptied (mode stub) or dropped (mode remove).
//   locations-all.json  only the rows the chain uses: our other accounts that sit in a sweep's field (extract-v2.mjs
//                       --locations) and the subjects of SEOS's "weed" sweeps (oracle/gh-facts.mjs, nearest sweep).
//   Eagle Eyes exports  the scan machine's network address and provider (request.vantage.ip and .isp) set to null; the
//                       chain reads only request.vantage.label (ee-scan-to-seos.mjs:73).
//   every JSON file     a value that is wholly an e-mail address (a SEOS console user: who started a run, fetched a
//                       reading, set a keyword, sent a task) becomes person-<n>@example.invalid; see unmail() below.
//   every other file    copied byte for byte, or left out when no script in the chain reads it.
// The edits are made on the answer's own text, so every byte that is not removed stays as SEOS wrote it; each edited
// file is parsed again and must equal the original with exactly the intended changes, or the run stops.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PKG = path.resolve(HERE, '..', '..');
const argv = process.argv.slice(2);
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
const many = k => argv.filter(v => v.startsWith('--' + k + '=')).map(v => v.slice(k.length + 3));
const [SRC] = argv.filter(a => !a.startsWith('--'));
const die = m => { console.error('SCRUB FAILED: ' + m); process.exit(1); };
if (!SRC || !opt('settings')) { console.error('usage: node scrub.mjs <SEOS data folder> --settings=<file> [--extra=<Eagle Eyes export>]... [--out=<folder>] [--mode=stub|remove]'); process.exit(2); }
const MODE = opt('mode') || 'stub';
if (!['stub', 'remove'].includes(MODE)) die('--mode is stub or remove');
const OUT = path.resolve(opt('out') || path.join(HERE, 'input'));
const FIXTURE_DIR = path.dirname(OUT);
const sha = b => crypto.createHash('sha256').update(b).digest('hex');

// ---------- the chain's code: every script that reads these answers ----------
const CHAIN = ['reference/merge-sweep.mjs', 'reference/ee-scan-to-seos.mjs', 'reference/sweeps-market.mjs', 'reference/check-sweeps-market.mjs', 'reference/extract-v2.mjs',
  'reference/check-compare-v2.mjs', 'reference/build-report.mjs', 'reference/verify-classes.mjs', 'reference/client.js', 'reference/mapview.js', 'fixtures/green-haven-48/oracle/gh-facts.mjs', 'run-report.mjs'];
const code = {};
for (const f of CHAIN) { const p = path.join(PKG, f); if (!fs.existsSync(p)) die('missing chain script ' + f + ' (copy the reference code first)'); code[f] = fs.readFileSync(p, 'utf8'); }
const readers = name => Object.entries(code).filter(([, src]) => src.includes(name)).map(([f]) => f);
const grepRow = name => Object.fromEntries(CHAIN.map(f => [f, code[f].split(name).length - 1]));

// ---------- a JSON scanner that keeps byte positions (the answers are compact JSON: no spaces between tokens) ----------
const skipWs = (s, i) => { while (i < s.length && (s[i] === ' ' || s[i] === '\n' || s[i] === '\r' || s[i] === '\t')) i++; return i; };
const endOfString = (s, i) => { for (let j = i + 1; j < s.length; j++) { if (s[j] === '\\') { j++; continue; } if (s[j] === '"') return j + 1; } die('unterminated string at ' + i); };
const endOfValue = (s, i) => {
  i = skipWs(s, i);
  if (s[i] === '"') return endOfString(s, i);
  if (s[i] === '{' || s[i] === '[') {
    let depth = 0;
    for (let j = i; j < s.length; j++) { const c = s[j]; if (c === '"') { j = endOfString(s, j) - 1; continue; } if (c === '{' || c === '[') depth++; else if (c === '}' || c === ']') { depth--; if (depth === 0) return j + 1; } }
    die('unterminated container at ' + i);
  }
  let j = i; while (j < s.length && !',]} \n\r\t'.includes(s[j])) j++; return j;
};
const members = (s, i) => {                       // the members of the object at i, with their positions
  i = skipWs(s, i); if (s[i] !== '{') die('expected an object at ' + i);
  const list = []; let j = skipWs(s, i + 1); if (s[j] === '}') return { start: i, end: j + 1, list };
  for (;;) {
    const kEnd = endOfString(s, j), key = JSON.parse(s.slice(j, kEnd)), colon = skipWs(s, kEnd); if (s[colon] !== ':') die('expected : at ' + colon);
    const vStart = skipWs(s, colon + 1), vEnd = endOfValue(s, vStart); list.push({ key, start: j, vStart, vEnd });
    const m = skipWs(s, vEnd); if (s[m] === ',') { j = skipWs(s, m + 1); continue; } if (s[m] === '}') return { start: i, end: m + 1, list }; die('expected , or } at ' + m);
  }
};
const elements = (s, i) => {                      // the elements of the array at i, with their positions
  i = skipWs(s, i); if (s[i] !== '[') die('expected an array at ' + i);
  const list = []; let j = skipWs(s, i + 1); if (s[j] === ']') return { start: i, end: j + 1, list };
  for (;;) { const end = endOfValue(s, j); list.push({ start: j, end }); const m = skipWs(s, end); if (s[m] === ',') { j = skipWs(s, m + 1); continue; } if (s[m] === ']') return { start: i, end: m + 1, list }; die('expected , or ] at ' + m); }
};
const member = (s, obj, key) => obj.list.find(m => m.key === key) || null;
// cut the items marked in `drop` out of a list (members or elements): consecutive runs go with one comma each
const cutRuns = (list, drop, edits, endOf = x => x.vEnd ?? x.end) => {
  for (let a = 0; a < list.length; a++) {
    if (!drop[a]) continue; let b = a; while (b + 1 < list.length && drop[b + 1]) b++;
    if (b < list.length - 1) edits.push([list[a].start, list[b + 1].start, '']);
    else if (a > 0) edits.push([endOf(list[a - 1]), endOf(list[b]), '']);
    else edits.push([list[a].start, endOf(list[b]), '']);
    a = b;
  }
};
const apply = (s, edits) => {
  const sorted = [...edits].sort((x, y) => y[0] - x[0]);
  for (let k = 1; k < sorted.length; k++) if (sorted[k][1] > sorted[k - 1][0]) die('two edits overlap');
  let out = s; for (const [a, b, r] of sorted) out = out.slice(0, a) + r + out.slice(b); return out;
};
const readText = p => { const buf = fs.readFileSync(p); const s = buf.toString('utf8'); if (!Buffer.from(s, 'utf8').equals(buf)) die(path.basename(p) + ' is not plain UTF-8 text'); return { buf, s }; };
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

// ---------- the source folder ----------
const files = fs.readdirSync(SRC).filter(f => fs.statSync(path.join(SRC, f)).isFile()).sort();
const bizFile = files.find(f => /^business-\d+\.json$/.test(f)) || die('no business-<id>.json in ' + SRC);
const ID = Number(bizFile.match(/\d+/)[0]);
const ANSWERS = [bizFile, `full-audit-${ID}.json`, `website-audit-${ID}.json`];
for (const f of ANSWERS) if (!files.includes(f)) die('missing ' + f + ' in ' + SRC);
const OPTIONAL = ['engine_sweeps-all.json', 'locations-all.json'].filter(f => files.includes(f));
// files only the facts oracle reads (oracle/gh-facts.mjs loads them by these names)
const ORACLE_ONLY = files.filter(f => !ANSWERS.includes(f) && !OPTIONAL.includes(f) && readers(f).length);
const LEFT_OUT = files.filter(f => !ANSWERS.includes(f) && !OPTIONAL.includes(f) && !ORACLE_ONLY.includes(f));
for (const f of LEFT_OUT) if (readers(f).length) die(f + ' is read by ' + readers(f).join(', ') + ' and would be left out');
const settingsPath = opt('settings'), settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
if (settings.business_id !== ID) die(`the settings file is for business ${settings.business_id}, the answers for ${ID}`);

fs.mkdirSync(OUT, { recursive: true });
if (fs.readdirSync(OUT).length) die('the output folder is not empty: ' + OUT);
const record = { made_by: 'fixtures/green-haven-48/scrub.mjs', mode: MODE, source_folder: path.basename(path.resolve(SRC)), business_id: ID, files: [], extra_sweeps: [], left_out: [], removed: {}, kept_on_purpose: [], checks: [] };
// the SEOS console users' e-mail addresses: SEOS records who started a run, fetched a reading, set a keyword or sent a
// task as that person's address. The chain reads only whether such a field is filled (sweeps-market.mjs: !!actor.username),
// so every JSON value that is wholly an e-mail address becomes a stable placeholder, person-<n>@example.invalid, numbered in
// the order first met (files in the order written below). Addresses inside longer text (review text, owner replies, page
// text, business descriptions: what the public web shows, and text the chain reads) are left as fetched.
const WHOLE_EMAIL = /"([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})"(?!\s*:)/g;
const IS_EMAIL = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
const people = new Map(), peopleByFile = {};
const placeholder = a => { if (!people.has(a)) people.set(a, `person-${people.size + 1}@example.invalid`); return people.get(a); };
const unmail = (name, s) => {
  let n = 0;
  const t = s.replace(WHOLE_EMAIL, (m, a) => { n++; return '"' + placeholder(a) + '"'; });
  const swap = v => Array.isArray(v) ? v.map(swap) : v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, swap(x)])) : typeof v === 'string' && IS_EMAIL.test(v) ? placeholder(v) : v;
  // the edited text must parse to the original with exactly those values replaced (an address the text scan missed fails here)
  if (!same(JSON.parse(t), swap(JSON.parse(s)))) die(name + ': replacing the e-mail addresses changed more than those values, or missed one');
  if (n) peopleByFile['input/' + name.replace(/\\/g, '/')] = n;
  return t;
};
const write = (name, buf, srcBuf, scrubbed, from = name) => {
  if (/\.json$/i.test(name)) { const s = buf.toString('utf8'), t = unmail(name, s); if (t !== s) { buf = Buffer.from(t, 'utf8'); scrubbed = true; } }
  const p = path.join(OUT, name); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, buf);
  record.files.push({ file: 'input/' + name.replace(/\\/g, '/'), from, bytes: buf.length, sha256: sha(buf), source_bytes: srcBuf.length, source_sha256: sha(srcBuf), scrubbed });
};

// ---------- 1. the business answer ----------
const B = readText(path.join(SRC, bizFile)), bj = JSON.parse(B.s);
const STORE = bj.tables?.locations?.[0]?.place_id || die('no location row in ' + bizFile);
const top = members(B.s, 0), tablesM = member(B.s, top, 'tables') || die('no tables in ' + bizFile);
const tables = members(B.s, tablesM.vStart);
const TABLE_MARK = /portal|token|secret|passw|session|console|admin|google_account|analytics/i;
const COLUMN_PART = new Set(['token', 'tokens', 'secret', 'secrets', 'key', 'keys', 'password', 'passwd', 'refresh', 'credential', 'credentials']);
const columnMarked = c => c.toLowerCase().split('_').some(p => COLUMN_PART.has(p));
const tableRemove = [], tableKeep = [];
for (const t of tables.list) if (TABLE_MARK.test(t.key)) { const r = readers(t.key); (r.length ? tableKeep : tableRemove).push({ table: t.key, rows: (bj.tables[t.key] || []).length, read_by: r }); }
const colRemove = [], colKeep = [];
for (const t of tables.list) {
  if (tableRemove.some(x => x.table === t.key) || !Array.isArray(bj.tables[t.key])) continue;
  const cols = [...new Set(bj.tables[t.key].flatMap(r => r && typeof r === 'object' ? Object.keys(r) : []))];
  for (const c of cols.filter(columnMarked)) { const r = readers(c); const rows = bj.tables[t.key].filter(x => x && Object.prototype.hasOwnProperty.call(x, c)).length; (r.length ? colKeep : colRemove).push({ table: t.key, column: c, rows, read_by: r }); }
}
const bEdits = [];
cutRuns(tables.list, tables.list.map(t => tableRemove.some(x => x.table === t.key)), bEdits);
for (const table of [...new Set(colRemove.map(x => x.table))]) {
  const cols = new Set(colRemove.filter(x => x.table === table).map(x => x.column));
  const arr = elements(B.s, member(B.s, tables, table).vStart);
  for (const el of arr.list) { const obj = members(B.s, el.start); cutRuns(obj.list, obj.list.map(m => cols.has(m.key)), bEdits); }
}
const bOut = apply(B.s, bEdits);
{ // the edited text must parse to the original minus exactly these tables and columns
  const want = JSON.parse(B.s);
  for (const { table } of tableRemove) delete want.tables[table];
  for (const { table, column } of colRemove) for (const r of want.tables[table]) delete r[column];
  if (!same(JSON.parse(bOut), want)) die(bizFile + ': the edited text is not the original minus the marked tables and columns');
}
write(bizFile, Buffer.from(bOut, 'utf8'), B.buf, bEdits.length > 0);
record.removed[bizFile] = { tables: tableRemove.map(({ table, rows }) => ({ table, rows })), columns: colRemove.map(({ table, column, rows }) => ({ table, column, rows })) };
for (const x of tableKeep) record.kept_on_purpose.push({ file: bizFile, what: `table ${x.table} (${x.rows} rows)`, why: `read by ${x.read_by.join(', ')}` });
for (const x of colKeep) record.kept_on_purpose.push({ file: bizFile, what: `column ${x.table}.${x.column} (${x.rows} rows)`, why: `read by ${x.read_by.join(', ')}` });

// ---------- 2. the full audit: another account's Google Analytics and Search Console readings ----------
const faName = `full-audit-${ID}.json`;
const F = readText(path.join(SRC, faName)), fj = JSON.parse(F.s);
const ANALYTICS = k => /^(analytics_|gsc_|ga4_)|search_console/i.test(String(k));
const fTop = members(F.s, 0), fTables = members(F.s, member(F.s, fTop, 'tables').vStart), vrM = member(F.s, fTables, 'vendor_readings') || die('no vendor_readings in ' + faName);
const vr = elements(F.s, vrM.vStart);
if (vr.list.length !== fj.tables.vendor_readings.length) die('the scanner and the parser count the readings differently');
const hit = fj.tables.vendor_readings.map(r => ANALYTICS(r.kind) && r.place_id !== STORE);
const ownAnalytics = fj.tables.vendor_readings.filter(r => ANALYTICS(r.kind) && r.place_id === STORE).length;
const EMPTY = { request: 'null', result: 'null', endpoints: '[]' };
// the account identifiers inside the removed parts (properties, sites, ids): checked absent from every output file below
const idLeaves = [];
const collect = (v, key, keep) => { if (Array.isArray(v)) v.forEach(x => collect(x, key, keep)); else if (v && typeof v === 'object') for (const [k, x] of Object.entries(v)) collect(x, k, keep); else if (typeof v === 'string' && /property|account|ga4|gsc|site|id$/i.test(String(key)) && v.length >= 6 && !keep.has(v)) idLeaves.push(v); };
const fEdits = [];
if (MODE === 'remove') cutRuns(vr.list, hit, fEdits);
else vr.list.forEach((el, i) => { if (!hit[i]) return; const obj = members(F.s, el.start); for (const m of obj.list) if (EMPTY[m.key] !== undefined) fEdits.push([m.vStart, m.vEnd, EMPTY[m.key]]); });
// (values the stub row keeps in plain sight, such as its own place id and website, are not identifiers to hunt for)
fj.tables.vendor_readings.forEach((r, i) => { if (!hit[i]) return; const keep = new Set(Object.entries(r).filter(([k, v]) => typeof v === 'string' && !(k in EMPTY)).map(([, v]) => v));
  collect(r.request, 'request', keep); collect(r.result, 'result', keep); collect(r.endpoints, 'endpoints', keep); });
const fOut = apply(F.s, fEdits);
{
  const want = JSON.parse(F.s);
  if (MODE === 'remove') want.tables.vendor_readings = want.tables.vendor_readings.filter((r, i) => !hit[i]);
  else want.tables.vendor_readings.forEach((r, i) => { if (hit[i]) { r.request = null; r.result = null; r.endpoints = []; } });
  if (!same(JSON.parse(fOut), want)) die(faName + ': the edited text is not the original with exactly those readings emptied');
}
write(faName, Buffer.from(fOut, 'utf8'), F.buf, fEdits.length > 0);
const hitRows = fj.tables.vendor_readings.filter((r, i) => hit[i]);
record.removed[faName] = { mode: MODE, readings: hitRows.length, by_kind: Object.fromEntries([...new Set(hitRows.map(r => r.kind))].sort().map(k => [k, hitRows.filter(r => r.kind === k).length])),
  places: new Set(hitRows.map(r => r.place_id)).size, fields_emptied: MODE === 'stub' ? Object.keys(EMPTY) : null, store_own_analytics_readings_kept: ownAnalytics,
  bytes_removed: F.buf.length - Buffer.byteLength(fOut, 'utf8') };

// ---------- 3. the website audit and SEOS's list of sweeps: as fetched ----------
for (const f of [`website-audit-${ID}.json`, ...OPTIONAL.filter(f => f !== 'locations-all.json'), ...ORACLE_ONLY]) { const buf = fs.readFileSync(path.join(SRC, f)); write(f, buf, buf, false); }

// ---------- 4. locations-all.json: the rows the chain uses ----------
const extras = many('extra');
if (files.includes('locations-all.json')) {
  const L = readText(path.join(SRC, 'locations-all.json')), lj = JSON.parse(L.s), rows = Array.isArray(lj) ? lj : lj.rows || die('locations-all.json has no rows');
  // (a) extract-v2.mjs --locations: a row names one of our other accounts when its place id is in any sweep's field (every
  //     engine_sweep_businesses row of the business answer, and every place an extra scan lists at a point it kept)
  const field = new Set((bj.tables.engine_sweep_businesses || []).map(b => b.place_id));
  for (const x of extras) { const e = JSON.parse(fs.readFileSync(x, 'utf8')); const ex = new Set((e.request?.excluded_points || []).map(Number)); for (const p of e.results || []) if (!ex.has(p.index)) for (const l of p.listings || []) field.add(l.place_id); }
  const a = new Set(rows.filter(r => r.place_id && r.business_id !== ID && field.has(r.place_id)).map(r => r.place_id));
  // (b) oracle/gh-facts.mjs: the nearest "weed" sweep is measured from its subject's location row
  const sweepsAll = files.includes('engine_sweeps-all.json') ? JSON.parse(fs.readFileSync(path.join(SRC, 'engine_sweeps-all.json'), 'utf8')) : { rows: [] };
  const b = new Set((sweepsAll.rows || sweepsAll).filter(s => /weed/i.test(s.keyword || '')).map(s => s.subject));
  const keep = rows.map(r => !!r.place_id && (a.has(r.place_id) || b.has(r.place_id)));
  const lEdits = []; cutRuns(elements(L.s, Array.isArray(lj) ? 0 : member(L.s, members(L.s, 0), 'rows').vStart).list, keep.map(k => !k), lEdits);
  const lOut = apply(L.s, lEdits);
  { const want = JSON.parse(L.s); if (Array.isArray(want)) die('locations-all.json as a bare list is not handled'); want.rows = want.rows.filter((r, i) => keep[i]); if (!same(JSON.parse(lOut), want)) die('locations-all.json: the edited text is not the original minus the dropped rows'); }
  write('locations-all.json', Buffer.from(lOut, 'utf8'), L.buf, lEdits.length > 0);
  const kept = rows.filter((r, i) => keep[i]);
  record.removed['locations-all.json'] = { rows_before: rows.length, rows_kept: kept.length, rows_removed: rows.length - kept.length,
    kept_for_extract_v2_own_accounts: kept.filter(r => a.has(r.place_id)).length, kept_for_gh_facts_nearest_weed_sweep: kept.filter(r => b.has(r.place_id)).length,
    kept_for_both: kept.filter(r => a.has(r.place_id) && b.has(r.place_id)).length, total_field_left_as_fetched: lj.total ?? null };
}

// ---------- 5. the Eagle Eyes exports (the scan machine's address and provider emptied) and the settings (as given) ----------
const VANTAGE_OUT = ['ip', 'isp'];
for (const x of extras) {
  const src = readText(x), name = path.join('extra-ee', path.basename(x));
  // the scan machine's address and provider: emptied in the text itself, so every other byte stays as Eagle Eyes wrote it
  const eTop = members(src.s, 0), rqM = member(src.s, eTop, 'request'), vEdits = [];
  const vaM = rqM && member(src.s, members(src.s, rqM.vStart), 'vantage');
  if (vaM && src.s[skipWs(src.s, vaM.vStart)] === '{') for (const m of members(src.s, vaM.vStart).list) if (VANTAGE_OUT.includes(m.key)) vEdits.push([m.vStart, m.vEnd, 'null']);
  const eOut = apply(src.s, vEdits);
  { const want = JSON.parse(src.s); for (const k of VANTAGE_OUT) if (want.request?.vantage && k in want.request.vantage) want.request.vantage[k] = null;
    if (!same(JSON.parse(eOut), want)) die(path.basename(x) + ': the edited text is not the original with only the vantage address and provider emptied'); }
  record.removed['extra-ee/' + path.basename(x)] = { vantage_fields_emptied: vEdits.length };
  write(name, Buffer.from(eOut, 'utf8'), src.buf, vEdits.length > 0, path.basename(x));
  const buf = fs.readFileSync(path.join(OUT, name));
  const mtime = fs.statSync(x).mtime;
  fs.utimesSync(path.join(OUT, name), mtime, mtime);              // the copy keeps the export's file time on every system
  record.extra_sweeps.push({ file: 'input/' + name.replace(/\\/g, '/'), sha256: sha(buf), mtime: mtime.toISOString(), why_mtime: 'ee-scan-to-seos.mjs stamps the sweep rows read_at with the export\'s file time; market.json and report-data.json carry it. Pin it with fs.utimesSync before converting.' });
}
{ const buf = fs.readFileSync(settingsPath); fs.writeFileSync(path.join(FIXTURE_DIR, 'settings.json'), buf); record.settings = { file: 'settings.json', bytes: buf.length, sha256: sha(buf), source_sha256: sha(buf) }; }
for (const f of LEFT_OUT) record.left_out.push({ file: f, why: 'no script in the chain reads it', grep: grepRow(f) });

// ---------- 6. checks on what was written ----------
const outFiles = record.files.map(f => path.join(FIXTURE_DIR, f.file));
const outText = outFiles.map(p => fs.readFileSync(p, 'utf8')).join('\n');
const leaked = [...new Set(idLeaves)].filter(v => outText.includes(v)).length;
record.checks.push({ check: 'account identifiers from the emptied readings found in any fixture file', identifiers: new Set(idLeaves).size, found: leaked });
if (leaked) die(`${leaked} account identifiers from the emptied readings are still in the fixture`);
for (const x of [...tableRemove, ...colRemove]) { const name = x.column || x.table; record.checks.push({ check: `scripts in the chain that name ${x.column ? 'column' : 'table'} ${x.column ? x.table + '.' : ''}${name}`, grep: grepRow(name), found: readers(name).length }); }
const leftAnalytics = JSON.parse(fs.readFileSync(path.join(OUT, faName), 'utf8')).tables.vendor_readings.filter(r => ANALYTICS(r.kind) && r.place_id !== STORE && (r.result !== null || r.request !== null));
record.checks.push({ check: "another account's analytics readings that still carry a request or result", found: leftAnalytics.length });
if (leftAnalytics.length) die('an analytics reading of another place still carries data');
record.people = { addresses_replaced: people.size, placeholder: 'person-<n>@example.invalid', values_replaced_by_file: peopleByFile };
const realLeft = outFiles.filter(p => /\.json$/i.test(p)).reduce((n, p) => n + (fs.readFileSync(p, 'utf8').match(WHOLE_EMAIL) || []).filter(m => !/@example\.invalid"$/.test(m)).length, 0);
const origLeft = [...people.keys()].filter(a => outText.includes(a)).length;
record.checks.push({ check: 'values that are wholly an e-mail address, other than the placeholders, in any fixture file', found: realLeft });
record.checks.push({ check: 'replaced console-user addresses found anywhere in the fixture files', identifiers: people.size, found: origLeft });
if (realLeft || origLeft) die('an e-mail address of a console user is still in the fixture');

fs.writeFileSync(path.join(FIXTURE_DIR, 'fixture.json'), JSON.stringify(record, null, 1) + '\n');

// ---------- 7. SCRUBBED.md: counts and kinds, never values ----------
const md = [];
md.push('# What was scrubbed from this fixture', '', `Written by \`scrub.mjs\` (mode \`${MODE}\`) from the SEOS answers in \`${record.source_folder}\` (business ${ID}). Counts and kinds only: no removed value appears here.`, '');
md.push('## Removed', '', `### ${bizFile}`, '');
md.push(...record.removed[bizFile].tables.map(t => `- table \`${t.table}\`: ${t.rows} row${t.rows === 1 ? '' : 's'} (the name marks tokens, credentials or account links; no script in the chain names it)`));
md.push(...record.removed[bizFile].columns.map(c => `- column \`${c.table}.${c.column}\`: removed from ${c.rows} rows (the name holds "key"; no script in the chain names it)`));
md.push('- the answer\'s `counts` header still lists the removed tables with their row counts, and its `not_included` list names some of them, as SEOS sent it: names and counts only', '');
md.push(`### ${faName}`, '', MODE === 'stub'
  ? `- ${hitRows.length} Google Analytics and Search Console readings about ${record.removed[faName].places} places that are not the store (${Object.entries(record.removed[faName].by_kind).map(([k, n]) => `${n} \`${k}\``).join(', ')}): \`request\` and \`result\` set to null and \`endpoints\` emptied, ${record.removed[faName].bytes_removed.toLocaleString('en-US')} bytes in all. Each row keeps every other field (its kind, place id, website address, vendor, cost and fetch time, and its empty errors and notes), because the report's own check that SEOS mixes another account's readings into this answer (check \`answer-scope\`, task \`answer-isolation\`, both team-only and left out of the Action Plan) counts them and names their websites. The store's own analytics readings kept: ${ownAnalytics}.`
  : `- ${hitRows.length} Google Analytics and Search Console readings about ${record.removed[faName].places} places that are not the store dropped whole (${Object.entries(record.removed[faName].by_kind).map(([k, n]) => `${n} \`${k}\``).join(', ')}), ${record.removed[faName].bytes_removed.toLocaleString('en-US')} bytes.`, '');
if (record.removed['locations-all.json']) { const l = record.removed['locations-all.json'];
  md.push('### locations-all.json', '', `- ${l.rows_removed} of ${l.rows_before} rows removed; ${l.rows_kept} kept: ${l.kept_for_extract_v2_own_accounts} are our other accounts in a sweep's field (what \`extract-v2.mjs --locations\` reads), ${l.kept_for_gh_facts_nearest_weed_sweep} are the subjects of SEOS's "weed" sweeps (what \`oracle/gh-facts.mjs\` measures the nearest such sweep from), ${l.kept_for_both} are both. The file's \`total\` field is left as SEOS sent it (${l.total_field_left_as_fetched}).`, ''); }
for (const x of extras) { const k = 'extra-ee/' + path.basename(x), n = record.removed[k]?.vantage_fields_emptied || 0;
  md.push(`### input/${k}`, '', n ? `- the scan machine's network address and provider (\`request.vantage.ip\`, \`request.vantage.isp\`) set to null: ${n} field${n === 1 ? '' : 's'}. The chain reads only \`request.vantage.label\` (\`ee-scan-to-seos.mjs:73\`). Every other byte is as Eagle Eyes wrote it, and the file keeps the export's file time.` : '- no vantage address or provider in this export: copied as given', ''); }
{ const pf = Object.entries(record.people.values_replaced_by_file), total = pf.reduce((s, [, n]) => s + n, 0);
  md.push('### E-mail addresses of SEOS console users (every file)', '', `- ${record.people.addresses_replaced} address${record.people.addresses_replaced === 1 ? '' : 'es'} held as whole values (who started a run, fetched a reading, set a keyword, sent a task): ${total.toLocaleString('en-US')} values in ${pf.length} file${pf.length === 1 ? '' : 's'} (${pf.map(([f, n]) => `${n.toLocaleString('en-US')} in \`${f}\``).join(', ')}), each address replaced by a stable placeholder, \`person-<n>@example.invalid\`, numbered in the order first met. The chain reads only whether such a field is filled (\`sweeps-market.mjs\`: \`!!actor.username\`).`, ''); }
md.push('## Copied as fetched (byte for byte)', '', ...record.files.filter(f => !f.scrubbed).map(f => `- \`${f.file}\` (${f.bytes.toLocaleString('en-US')} bytes)`), '');
md.push('## Left out', '', ...(record.left_out.length ? record.left_out.map(f => `- \`${f.file}\`: no script in the chain names it (${Object.values(f.grep).reduce((s, n) => s + n, 0)} mentions across ${CHAIN.length} scripts)`) : ['- nothing']), '');
md.push('## Kept on purpose', '', ...record.kept_on_purpose.map(k => `- ${k.file}: ${k.what}: ${k.why}`));
md.push('- e-mail addresses inside longer text (owner replies to reviews, the descriptions in Google\'s results for the store\'s phone, street and name, and page text): what the public web shows, and text the chain reads; left as fetched. No document prints one.', '');
md.push('## Checks', '', ...record.checks.map(c => `- ${c.check}: ${c.found}${c.identifiers !== undefined ? ` (of ${c.identifiers} checked)` : ''}`), '');
md.push('## The Eagle Eyes export\'s file time', '', ...record.extra_sweeps.map(x => `- \`${x.file}\`: ${x.mtime}. ${x.why_mtime}`), '');
md.push('## Files', '', '| file | bytes | sha256 | source sha256 |', '|---|---|---|---|', ...record.files.map(f => `| \`${f.file}\` | ${f.bytes} | \`${f.sha256}\` | \`${f.source_sha256}\` |`), '');
fs.writeFileSync(path.join(OUT, 'SCRUBBED.md'), md.join('\n'));
console.log(`scrubbed ${record.files.length} files into ${OUT} (mode ${MODE}): ${record.removed[bizFile].tables.length} tables and ${record.removed[bizFile].columns.length} columns out of ${bizFile}; ${hitRows.length} analytics readings ${MODE === 'stub' ? 'emptied' : 'dropped'} in ${faName}; ${record.removed['locations-all.json'] ? record.removed['locations-all.json'].rows_kept + ' of ' + record.removed['locations-all.json'].rows_before + ' location rows kept' : 'no locations file'}; left out: ${LEFT_OUT.join(', ') || 'nothing'}`);
