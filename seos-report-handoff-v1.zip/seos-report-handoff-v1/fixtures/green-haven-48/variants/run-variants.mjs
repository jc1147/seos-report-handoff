// run-variants.mjs: builds the variable-data inputs (make-variants.mjs), runs run-report.mjs --no-browser on each, and writes
// what each variant did to the report: variants/results.json (everything) and VARIANTS.md at the package root (for reading).
// usage: node run-variants.mjs [--work=<folder>] [--keep]
//   --work  where the variant inputs and runs go (default: a new folder under the system temp folder). --keep leaves it;
//           otherwise the data copies are removed at the end and the runs' outputs stay.
// Every variant is compared with "base", the fixture run the same way (no --facts), so a difference is the variant's alone.
// Nothing here is typed by hand: the quotes are sentences taken from the documents the runs wrote.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PKG = path.resolve(HERE, '..', '..', '..');
const argv = process.argv.slice(2);
const opt = k => { const a = argv.find(v => v.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : null; };
const WORK = path.resolve(opt('work') || fs.mkdtempSync(path.join(os.tmpdir(), 'seos-variants-')));
const die = m => { console.error('RUN VARIANTS FAILED: ' + m); process.exit(1); };

// ---------- 1. the inputs ----------
const mk = spawnSync(process.execPath, [path.join(HERE, 'make-variants.mjs'), WORK], { encoding: 'utf8' });
process.stdout.write(mk.stdout || ''); if (mk.status !== 0) die('make-variants.mjs: ' + (mk.stderr || '').trim());
const plan = JSON.parse(fs.readFileSync(path.join(WORK, 'variants.json'), 'utf8'));

// ---------- 2. the runs ----------
const runs = {};
for (const v of plan.variants) {
  const out = path.join(WORK, v.name, 'out');
  const args = [path.join(PKG, 'run-report.mjs'), ...v.args.map(a => a.replace(/^(--[a-z-]+=)(.*)$/, (m, k, p) => k + path.join(WORK, p))), `--out=${out}`];
  const r = spawnSync(process.execPath, args, { encoding: 'utf8', maxBuffer: 1 << 26 });
  const err = (r.stderr || '').replace(/\s+$/, '').split('\n');
  const at = /^RUN STOPPED at (.+?) \(exit (\d+)\)$/.exec(err[0] || '');
  runs[v.name] = r.status === 0 ? { built: true, out } : { built: false, stage: at ? at[1] : 'before the first stage', message: err };
  console.log(`${v.name.padEnd(20)} ${r.status === 0 ? 'built' : `stopped at ${runs[v.name].stage}`}`);
}
if (!runs.base?.built) die('the control run (base) did not build');

// ---------- 3. what the documents say ----------
// the text a reader meets: visible text plus tooltips and labels, one block per paragraph, cell, item or label
const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", nbsp: ' ' };
const blocks = html => html.replace(/<style>[\s\S]*?<\/style>/g, ' ').replace(/<script[\s\S]*?<\/script>/g, ' ')
  .replace(/<[^>]*>/g, tag => { const tips = [...tag.matchAll(/\s(?:data-tip|aria-label|title|placeholder|alt)="([^"]*)"/g)].map(m => m[1]); const br = /^<\/?(p|li|td|th|tr|h[1-6]|div|summary|button|label|section|header|footer|details|option|br|table|ol|ul|nav|main)\b/i.test(tag); return (br || tips.length ? '\n' : ' ') + tips.join('\n') + (tips.length ? '\n' : ''); })
  .replace(/&(amp|lt|gt|quot|#39|nbsp);/g, (m, k) => ENT[k]).replace(/&#(\d+);/g, (m, c) => String.fromCodePoint(Number(c)))
  .split('\n').map(s => s.replace(/\s+/g, ' ').trim()).filter(s => s.length > 1);
const sentences = html => [...new Set(blocks(html).flatMap(b => b.split(/(?<=[.!?])\s+(?=["'(]?[A-Z0-9])/)).map(s => s.trim()).filter(s => s.length > 2))];
const textOf = frag => blocks(frag).join(' ');
const headline = html => { const h = /<h1\b[^>]*>[\s\S]*?<\/h1>/.exec(html), l = /<p class="lead">[\s\S]*?<\/p>/.exec(html); return { h1: h ? textOf(h[0]) : null, lead: l ? textOf(l[0]) : null }; };
const docs = name => { const o = runs[name].out; return { ca: fs.readFileSync(path.join(o, 'competitor-analysis.html'), 'utf8'), ap: fs.readFileSync(path.join(o, 'action-plan.html'), 'utf8') }; };
const model = name => JSON.parse(fs.readFileSync(path.join(runs[name].out, 'report-data.json'), 'utf8'));
const B = { m: model('base'), d: docs('base') }; B.s = { ca: sentences(B.d.ca), ap: sentences(B.d.ap) };
const expDir = path.join(HERE, '..', 'expected');
const baseVsExpected = ['competitor-analysis.html', 'action-plan.html'].map(f => ({ file: f, identical: fs.readFileSync(path.join(runs.base.out, f)).equals(fs.readFileSync(path.join(expDir, f))) }));

const PROBES = { 'no-weed-scan': /weed near me/i, 'one-search': /near me|map check/i, 'no-expected-search': /weed near me/i, 'other-vertical': null, 'no-store-reviews': /review/i, 'no-rival-pages': /front page|home page|website|page|speed|crawl/i };
const ids = a => (a || []).map(x => x.id);
const diffIds = (a, b) => ({ added: b.filter(x => !a.includes(x)), removed: a.filter(x => !b.includes(x)) });
const VWORD = /cannabis|dispensar(?:y|ies)|\bweed|marijuana/gi;

// for other-vertical: is each vertical word in the documents part of something the data holds (a business or page name, a
// search, a category, a web address), or part of the wording? A heuristic, stated in VARIANTS.md: a word counts as data when
// it sits inside a short string of the model's data blocks (explanations and every sentence left out), inside a web address,
// or inside a name the page shortened with "…".
const EXPLAIN = new Set(['why', 'note', 'notes', 'text', 'detail', 'sales', 'lead', 'steps', 'done', 'done_when', 'benefit', 'rule', 'built_from', 'window_why', 'reason', 'reasons', 'hold_reasons', 'what', 'fix', 'statement', 'title_note', 'say']);
const DATA_BLOCKS = ['business', 'you', 'rivals', 'stores', 'maps', 'market', 'map', 'website', 'links', 'listings', 'search', 'reviews', 'compare'];
const CODE = ['extract-v2.mjs', 'build-report.mjs', 'sweeps-market.mjs', 'client.js', 'mapview.js'].map(f => ({ f, lines: fs.readFileSync(path.join(PKG, 'reference', f), 'utf8').split('\n') }));
const CODE_TEXT = CODE.map(c => c.lines.join('\n')).join('\n');
// a data string counts only when it is more than the bare word ("cannabis" alone would cover every use); in the listings
// block, a label the code defines as a literal (a directory name from a list in the code) is wording, not data
const dataStrings = m => {
  const out = new Set();
  const keep = (v, block) => typeof v === 'string' && v.length <= 100 && !/\.\s*$/.test(v) && /cannabis|dispensar|weed|marijuana/i.test(v)
    && /[a-z]{2}/i.test(v.replace(/cannabis|dispensar(?:y|ies)|weed|marijuana/gi, '')) && !(block === 'listings' && [`'${v}'`, `"${v}"`].some(lit => CODE_TEXT.includes(lit)));
  const walk = (v, key, block) => { if (EXPLAIN.has(key)) return; if (Array.isArray(v)) v.forEach(x => walk(x, key, block)); else if (v && typeof v === 'object') for (const [k, x] of Object.entries(v)) walk(x, k, block);
    else if (keep(v, block)) out.add(v.toLowerCase().replace(/\s+/g, ' ').trim()); };
  for (const k of DATA_BLOCKS) walk(m[k], k, k);
  return [...out].sort((x, y) => y.length - x.length);
};
const codeLine = phrase => { const p = phrase.toLowerCase(); if (p.length < 18) return null; for (const { f, lines } of CODE) { const i = lines.findIndex(l => l.toLowerCase().includes(p)); if (i >= 0) return `reference/${f}:${i + 1}`; } return null; };
const verticalWords = (html, dstr) => {
  const per = {}, list = new Map();
  for (const s of sentences(html)) {
    const hits = [...s.matchAll(VWORD)]; if (!hits.length) continue;
    const low = s.toLowerCase(), covered = new Array(s.length).fill(false), cover = (a, b) => { for (let k = a; k < b; k++) covered[k] = true; };
    for (const ds of dstr) { let i = low.indexOf(ds); while (i >= 0) { cover(i, i + ds.length); i = low.indexOf(ds, i + 1); } }
    for (const m of s.matchAll(/[a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,24}\b(?:\/\S*)?/gi)) if (/[a-z]{2,}$/i.test(m[0].split('/')[0])) cover(m.index, m.index + m[0].length);   // web addresses are data
    for (let j = low.indexOf('…'); j >= 0; j = low.indexOf('…', j + 1)) for (let k = Math.max(0, j - 45); k <= j - 10; k++) { const c = low.slice(k, j); if ((k === 0 || /[\s(:;,"]/.test(low[k - 1])) && dstr.some(ds => ds.startsWith(c))) { cover(k, j + 1); break; } }   // a name the page shortened
    const words = hits.map(h => ({ w: h[0].toLowerCase(), data: covered[h.index] }));
    for (const w of words) per[w.w] = (per[w.w] || 0) + 1;
    const text = words.filter(w => !w.data);
    let where = null;
    if (text.length) { const h = hits.find(x => !covered[x.index]), a = h.index, b = h.index + h[0].length;
      for (const cand of [s.slice(Math.max(0, a - 30), b + 30), s.slice(Math.max(0, a - 20), b + 20), s.slice(Math.max(0, a - 12), b + 12), s.slice(a, b + 14), s.slice(Math.max(0, a - 14), b)]) { where = codeLine(cand.trim()); if (where) break; } }
    list.set(s, { sentence: s, words: words.length, in_data: words.length - text.length, as_wording: text.length, code: where });
  }
  const all = [...list.values()];
  return { occurrences: Object.values(per).reduce((a, b) => a + b, 0), by_word: per, sentences: all.length, in_data_only: all.filter(x => !x.as_wording).length, with_wording: all.filter(x => x.as_wording).length, list: all };
};

const results = { made_by: 'fixtures/green-haven-48/variants/run-variants.mjs', compared_with: 'base', base_documents_equal_expected: baseVsExpected, variants: [] };
for (const v of plan.variants) {
  const R = runs[v.name], row = { name: v.name, title: v.title, files_changed: v.files_changed.map(({ file, rows_removed }) => ({ file, rows_removed })), settings_changed: v.settings_changed, extra_sweeps: v.extra_sweeps.length, outcome: R.built ? 'built' : 'stopped' };
  if (!R.built) { row.stage = R.stage; row.message = R.message; results.variants.push(row); continue; }
  const m = model(v.name), d = docs(v.name), s = { ca: sentences(d.ca), ap: sentences(d.ap) };
  row.verdict = { a: m.verdict.a, b: m.verdict.b };
  row.counts = { checks: m.checks.length, tasks: m.tasks.length, holds: m.holds.length, plan: m.plan.length };
  row.missing_searches = m.meta.missing_searches; row.expected_searches = m.meta.expected_searches;
  row.searches = (m.maps?.searches || []).map(x => `${x.kw}: ${x.you} of ${x.n}`);
  row.competitor_analysis_headline = headline(d.ca);
  if (v.name !== 'base') {
    const bs = Object.fromEntries(B.m.checks.map(c => [c.id, c.status]));
    row.vs_base = { checks: diffIds(ids(B.m.checks), ids(m.checks)), check_status_changed: m.checks.filter(c => bs[c.id] && bs[c.id] !== c.status).map(c => ({ id: c.id, base: bs[c.id], now: c.status, title: c.title })),
      tasks: diffIds(ids(B.m.tasks), ids(m.tasks)), holds: diffIds(B.m.holds.map(h => h.number), m.holds.map(h => h.number)), plan: diffIds(ids(B.m.plan), ids(m.plan)),
      documents_identical_to_base: { 'competitor-analysis.html': d.ca === B.d.ca, 'action-plan.html': d.ap === B.d.ap } };
    const probe = PROBES[v.name];
    for (const k of ['ca', 'ap']) {
      const fresh = s[k].filter(x => !B.s[k].includes(x)), gone = B.s[k].filter(x => !s[k].includes(x));
      row[`sentences_${k}`] = { new: fresh.length, gone: gone.length, probe: probe ? probe.source : null, now_matching: probe ? s[k].filter(x => probe.test(x)).length : null,
        base_matching: probe ? B.s[k].filter(x => probe.test(x)).length : null, new_matching: probe ? fresh.filter(x => probe.test(x)) : [], gone_matching: probe ? gone.filter(x => probe.test(x)) : [] };
    }
  }
  if (v.name === 'other-vertical') { const dstr = dataStrings(m); row.vertical_words = { data_strings: dstr.length, competitor_analysis: verticalWords(d.ca, dstr), action_plan: verticalWords(d.ap, dstr) }; }
  results.variants.push(row);
}
// the reference code lines that print these words whatever the vertical (input for the open items)
results.code_lines_with_vertical_words = CODE.flatMap(({ f, lines }) => lines.map((l, i) => ({ at: `reference/${f}:${i + 1}`, l })).filter(x => !/^\s*\/\//.test(x.l) && /cannabis|dispensar|\bweed|marijuana/i.test(x.l))
  .map(x => { const m = /cannabis|dispensar|\bweed|marijuana/i.exec(x.l); return { at: x.at, text: x.l.slice(Math.max(0, m.index - 60), m.index + 60).trim() }; }));
fs.writeFileSync(path.join(HERE, 'results.json'), JSON.stringify(results, null, 1) + '\n');

// ---------- 4. VARIANTS.md ----------
const q = s => `"${String(s).replace(/\|/g, '/')}"`;
const clipq = (s, n = 240) => q(s.length > n ? s.slice(0, n) + '...' : s);
const list = a => (a.length ? a.join(', ') : 'none');
const md = ['# Variable data: what the report does when the data changes', '',
  'Green Haven fixture (SEOS business 48). Each variant is one scripted change of the scrubbed fixture (`fixtures/green-haven-48/variants/make-variants.mjs`), run through `run-report.mjs --no-browser` and compared with **base**, the fixture run the same way (no `--facts`, like every variant). Rebuild this file with `node fixtures/green-haven-48/variants/run-variants.mjs`. Every number and quote below comes from those runs; `fixtures/green-haven-48/variants/results.json` holds all of it, the full sentence lists included.', '',
  `Control: base's documents are byte-identical to \`fixtures/green-haven-48/expected/\`: ${baseVsExpected.map(x => `${x.file} ${x.identical ? 'yes' : 'NO'}`).join(', ')}.`, '',
  '| variant | what changed | outcome | verdict.a | verdict.b | checks | tasks | holds | plan items |', '|---|---|---|---|---|---|---|---|---|',
  ...results.variants.map(r => `| ${r.name} | ${r.title.replace(/\|/g, '/')} | ${r.outcome === 'built' ? 'built' : `stopped at ${r.stage}`} | ${r.verdict ? q(r.verdict.a) : ''} | ${r.verdict ? (r.verdict.b ? q(r.verdict.b) : '(empty)') : ''} | ${r.counts?.checks ?? ''} | ${r.counts?.tasks ?? ''} | ${r.counts?.holds ?? ''} | ${r.counts?.plan ?? ''} |`), ''];
for (const r of results.variants.filter(x => x.name !== 'base')) {
  md.push(`## ${r.name}`, '', `Changed: ${r.title}.${r.files_changed.length ? ' ' + r.files_changed.map(f => `${f.file}: ${f.rows_removed} rows removed.`).join(' ') : ''}`, '');
  if (r.outcome !== 'built') { md.push(`Outcome: **stopped** at \`${r.stage}\`. run-report.mjs printed:`, '', '```', ...r.message, '```', ''); continue; }
  const vb = r.vs_base;
  md.push(`Outcome: built. Searches in the model: ${r.searches.join('; ') || 'none'}. Expected searches: ${list(r.expected_searches)}; expected and not on file: ${list(r.missing_searches)}.`, '',
    `The Competitor Analysis opens with: ${q(r.competitor_analysis_headline.h1)}, then: ${clipq(r.competitor_analysis_headline.lead || '')}`, '',
    'Against base:', '',
    `- checks added: ${list(vb.checks.added)}; removed: ${list(vb.checks.removed)}; status changed: ${vb.check_status_changed.length ? vb.check_status_changed.map(c => `${c.id} (${c.title}) ${c.base} -> ${c.now}`).join(', ') : 'none'}`,
    `- tasks added: ${list(vb.tasks.added)}; removed: ${list(vb.tasks.removed)}`,
    `- holds added: ${vb.holds.added.length ? vb.holds.added.map(q).join('; ') : 'none'}; removed: ${vb.holds.removed.length ? vb.holds.removed.map(q).join('; ') : 'none'}`,
    `- plan items added: ${list(vb.plan.added)}; removed: ${list(vb.plan.removed)}`,
    `- documents identical to base: Competitor Analysis ${vb.documents_identical_to_base['competitor-analysis.html'] ? 'yes' : 'no'}, Action Plan ${vb.documents_identical_to_base['action-plan.html'] ? 'yes' : 'no'}`, '');
  if (r.name !== 'other-vertical') for (const [k, label] of [['ca', 'Competitor Analysis'], ['ap', 'Action Plan']]) {
    const x = r[`sentences_${k}`];
    md.push(`${label}: ${x.new} sentences not in base, ${x.gone} of base's gone. Sentences matching /${x.probe}/: ${x.now_matching} (base ${x.base_matching}).`, '',
      ...(x.new_matching.length ? ['New:', ...x.new_matching.slice(0, 5).map(y => `- ${clipq(y)}`)] : ['New: none matching.']), '',
      ...(x.gone_matching.length ? [`Gone (${x.gone_matching.length}, first ${Math.min(3, x.gone_matching.length)}):`, ...x.gone_matching.slice(0, 3).map(y => `- ${clipq(y)}`)] : ['Gone: none matching.']), '');
  }
  if (r.vertical_words) {
    md.push(`How the words below are counted (a heuristic): a word is "in the data" when it sits inside a short string of the model's data blocks (names, searches, categories, page titles; explanations and whole sentences left out), inside a web address, or inside a name the page shortened with "…". Everything else is "in the wording", with the reference code line that holds the wording when a phrase of 18 or more characters around the word is found there.`, '');
    for (const [k, label] of [['competitor_analysis', 'Competitor Analysis'], ['action_plan', 'Action Plan']]) {
      const w = r.vertical_words[k];
      md.push(`The ${label} still says cannabis / dispensary / weed / marijuana ${w.occurrences} times (${Object.entries(w.by_word).map(([a, b]) => `${a} ${b}`).join(', ')}) in ${w.sentences} sentences: ${w.in_data_only} have it only in the data, ${w.with_wording} in the wording. The wording ones:`, '',
        ...w.list.filter(x => x.as_wording).map(x => `- ${clipq(x.sentence, 220)}${x.code ? ` (${x.code})` : ' (no code line found)'}`), '',
        `<details><summary>Every sentence of the ${label} that holds one of the words (${w.sentences}; words in it, and how many sit in the data)</summary>`, '',
        ...w.list.map(x => `- ${clipq(x.sentence, 200)} [${x.words} word${x.words === 1 ? '' : 's'}, ${x.in_data} in the data]`), '', '</details>', '');
    }
  }
}
md.push('## Reference code lines that hold these words', '', `${results.code_lines_with_vertical_words.length} lines in reference/ (comment lines left out) hold cannabis, dispensar-, weed or marijuana. By file: ${[...new Set(results.code_lines_with_vertical_words.map(x => x.at.split(':')[0]))].map(f => `${f} ${results.code_lines_with_vertical_words.filter(x => x.at.startsWith(f + ':')).length}`).join(', ')}.`, '',
  ...results.code_lines_with_vertical_words.map(x => `- ${x.at}: \`${x.text.replace(/`/g, "'")}\``), '');
fs.writeFileSync(path.join(PKG, 'VARIANTS.md'), md.join('\n'));
console.log(`wrote ${path.join(HERE, 'results.json')} and ${path.join(PKG, 'VARIANTS.md')}`);

if (!argv.includes('--keep')) for (const v of plan.variants) { fs.rmSync(path.join(WORK, v.name, 'data'), { recursive: true, force: true }); fs.rmSync(path.join(WORK, v.name, 'out', 'data'), { recursive: true, force: true }); }
console.log(`runs in ${WORK}`);
