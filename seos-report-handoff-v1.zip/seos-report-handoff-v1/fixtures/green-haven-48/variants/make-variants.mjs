// make-variants.mjs: the variable-data inputs, each built from the scrubbed fixture by one scripted change (never by hand).
// usage: node make-variants.mjs <work folder>
// Writes, for each variant, <work>/<name>/data/ (a complete data folder for run-report.mjs), <work>/<name>/settings.json and,
// when the variant keeps the owner's "weed near me" scan, <work>/<name>/extra/<export> with its file time pinned from
// fixture.json. <work>/variants.json lists each variant: what changed (counts), the files that differ from the fixture
// (sha256 before and after) and the runner's arguments. The fixture itself is only read.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const FX = path.resolve(HERE, '..');
const [WORK] = process.argv.slice(2);
if (!WORK) { console.error('usage: node make-variants.mjs <work folder>'); process.exit(2); }
const die = m => { console.error('VARIANTS FAILED: ' + m); process.exit(1); };
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const IN = path.join(FX, 'input');
const fixture = JSON.parse(fs.readFileSync(path.join(FX, 'fixture.json'), 'utf8'));
const baseSettings = JSON.parse(fs.readFileSync(path.join(FX, 'settings.json'), 'utf8'));
const ID = baseSettings.business_id;
const F = { biz: `business-${ID}.json`, full: `full-audit-${ID}.json`, web: `website-audit-${ID}.json` };
const read = f => JSON.parse(fs.readFileSync(path.join(IN, f), 'utf8'));
const STORE = read(F.biz).tables.locations[0].place_id;
const EXPORT = (fixture.extra_sweeps || [])[0] || die('fixture.json records no Eagle Eyes export');

// each variant: a title, what it changes, whether it keeps the export, and its edits (each returns a count, which must be > 0)
const VARIANTS = [
  { name: 'base', title: 'Control: the fixture as it is (scan 320 folded in), run without --facts like every variant', extra: true, edits: {} },
  { name: 'no-weed-scan', title: "SEOS's answers alone: no Eagle Eyes export, so no \"weed near me\" sweep", extra: false, edits: {} },
  { name: 'one-search', title: 'Only the "dispensary near me" sweep (352): sweep 353\'s rows removed from every engine_* table of the business answer, no export', extra: false,
    edits: { [F.biz]: j => { let n = 0; for (const t of Object.keys(j.tables).filter(k => k.startsWith('engine_'))) { const before = j.tables[t].length; j.tables[t] = j.tables[t].filter(r => String(r.scan_id ?? (r.kind === 'scan' ? r.ref : '')) !== '353'); n += before - j.tables[t].length; } return n; } } },
  { name: 'no-expected-search', title: 'As no-weed-scan, and expected_searches removed from the settings', extra: false,
    settings: s => { if (!('expected_searches' in s)) return 0; delete s.expected_searches; return 1; } },
  { name: 'other-vertical', title: 'settings.vertical = "Dental" (the record\'s own vertical is empty, so the settings decide); scan 320 kept', extra: true,
    settings: s => { s.vertical = 'Dental'; return 1; } },
  { name: 'no-store-reviews', title: "The store's own Google reviews reading (kind reviews) removed from the full-audit answer; scan 320 kept", extra: true,
    edits: { [F.full]: j => { const before = j.tables.vendor_readings.length; j.tables.vendor_readings = j.tables.vendor_readings.filter(r => !(r.kind === 'reviews' && r.place_id === STORE)); return before - j.tables.vendor_readings.length; } } },
  { name: 'no-rival-pages', title: "The rivals' readings removed from the website-audit answer (every reading not about the store); scan 320 kept", extra: true,
    edits: { [F.web]: j => { const before = j.tables.vendor_readings.length; j.tables.vendor_readings = j.tables.vendor_readings.filter(r => r.place_id === STORE); return before - j.tables.vendor_readings.length; } } },
];

fs.mkdirSync(WORK, { recursive: true });
const list = [];
for (const v of VARIANTS) {
  const dir = path.join(WORK, v.name), data = path.join(dir, 'data');
  if (fs.existsSync(dir)) die('the work folder already holds ' + v.name);
  fs.mkdirSync(data, { recursive: true });
  const changed = [];
  for (const f of fs.readdirSync(IN).filter(f => f.endsWith('.json') && fs.statSync(path.join(IN, f)).isFile())) {
    const src = fs.readFileSync(path.join(IN, f));
    if (!v.edits?.[f]) { fs.writeFileSync(path.join(data, f), src); continue; }
    const j = JSON.parse(src.toString('utf8')), count = v.edits[f](j);
    if (!(count > 0)) die(`${v.name}: the edit of ${f} changed nothing`);
    const out = Buffer.from(JSON.stringify(j)); fs.writeFileSync(path.join(data, f), out);
    changed.push({ file: f, rows_removed: count, sha256_fixture: sha(src), sha256_variant: sha(out) });
  }
  const s = JSON.parse(JSON.stringify(baseSettings));
  if (v.settings && !(v.settings(s) > 0)) die(`${v.name}: the settings edit changed nothing`);
  fs.writeFileSync(path.join(dir, 'settings.json'), JSON.stringify(s, null, 2) + '\n');
  const extra = [];
  if (v.extra) {
    const dst = path.join(dir, 'extra', path.basename(EXPORT.file)); fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(path.join(FX, EXPORT.file), dst); const t = new Date(EXPORT.mtime); fs.utimesSync(dst, t, t);
    if (fs.statSync(dst).mtime.toISOString() !== EXPORT.mtime) die('the export\'s file time could not be pinned');
    extra.push(dst);
  }
  list.push({ name: v.name, title: v.title, files_changed: changed, settings_changed: v.settings ? s : null, extra_sweeps: extra.map(x => path.relative(WORK, x).replace(/\\/g, '/')),
    args: [`--data=${v.name}/data`, `--settings=${v.name}/settings.json`, ...extra.map(x => `--extra-sweep=${path.relative(WORK, x).replace(/\\/g, '/')}`), '--no-browser'] });
  console.log(`${v.name.padEnd(20)} ${changed.map(c => `${c.file} -${c.rows_removed} rows`).join(', ') || 'answers as in the fixture'}${v.settings ? '; settings changed' : ''}${extra.length ? '; with the export' : '; no export'}`);
}
fs.writeFileSync(path.join(WORK, 'variants.json'), JSON.stringify({ made_by: 'fixtures/green-haven-48/variants/make-variants.mjs', fixture_business: ID, store: STORE, variants: list }, null, 1) + '\n');
