# What was scrubbed from this fixture

Written by `scrub.mjs` (mode `stub`) from the SEOS answers in `green-haven-2026-10-12` (business 48). Counts and kinds only: no removed value appears here.

## Removed

### business-48.json

- table `analytics_sync`: 0 rows (the name marks tokens, credentials or account links; no script in the chain names it)
- table `analytics_sync_runs`: 0 rows (the name marks tokens, credentials or account links; no script in the chain names it)
- table `portal_access`: 0 rows (the name marks tokens, credentials or account links; no script in the chain names it)
- table `portal_tokens`: 1 row (the name marks tokens, credentials or account links; no script in the chain names it)
- column `notifications.dedupe_key`: removed from 4 rows (the name holds "key"; no script in the chain names it)
- column `vendor_spend.step_key`: removed from 804 rows (the name holds "key"; no script in the chain names it)
- the answer's `counts` header still lists the removed tables with their row counts, and its `not_included` list names some of them, as SEOS sent it: names and counts only

### full-audit-48.json

- 4 Google Analytics and Search Console readings about 2 places that are not the store (2 `analytics_watch`, 2 `gsc_sitemaps`): `request` and `result` set to null and `endpoints` emptied, 5,755 bytes in all. Each row keeps every other field (its kind, place id, website address, vendor, cost and fetch time, and its empty errors and notes), because the report's own check that SEOS mixes another account's readings into this answer (check `answer-scope`, task `answer-isolation`, both team-only and left out of the Action Plan) counts them and names their websites. The store's own analytics readings kept: 0.

### locations-all.json

- 41 of 54 rows removed; 13 kept: 3 are our other accounts in a sweep's field (what `extract-v2.mjs --locations` reads), 12 are the subjects of SEOS's "weed" sweeps (what `oracle/gh-facts.mjs` measures the nearest such sweep from), 2 are both. The file's `total` field is left as SEOS sent it (54).

### input/extra-ee/eagleeyes-scan-320-weed-near-me.json

- the scan machine's network address and provider (`request.vantage.ip`, `request.vantage.isp`) set to null: 2 fields. The chain reads only `request.vantage.label` (`ee-scan-to-seos.mjs:73`). Every other byte is as Eagle Eyes wrote it, and the file keeps the export's file time.

### E-mail addresses of SEOS console users (every file)

- 2 addresses held as whole values (who started a run, fetched a reading, set a keyword, sent a task): 973 values in 5 files (815 in `input/business-48.json`, 135 in `input/full-audit-48.json`, 14 in `input/website-audit-48.json`, 1 in `input/business_info-history-green-haven.json`, 8 in `input/locations-all.json`), each address replaced by a stable placeholder, `person-<n>@example.invalid`, numbered in the order first met. The chain reads only whether such a field is filled (`sweeps-market.mjs`: `!!actor.username`).

## Copied as fetched (byte for byte)

- `input/engine_sweeps-all.json` (57,669 bytes)
- `input/engine_sweep_businesses-green-haven-anywhere.json` (1,335 bytes)

## Left out

- `openapi.json`: no script in the chain names it (0 mentions across 12 scripts)
- `tables.json`: no script in the chain names it (0 mentions across 12 scripts)

## Kept on purpose

- business-48.json: table google_accounts (0 rows): read by fixtures/green-haven-48/oracle/gh-facts.mjs
- business-48.json: table analytics_bindings (0 rows): read by reference/extract-v2.mjs, fixtures/green-haven-48/oracle/gh-facts.mjs
- business-48.json: column pm_tasks.public_key (1 rows): read by reference/extract-v2.mjs
- e-mail addresses inside longer text (owner replies to reviews, the descriptions in Google's results for the store's phone, street and name, and page text): what the public web shows, and text the chain reads; left as fetched. No document prints one.

## Checks

- account identifiers from the emptied readings found in any fixture file: 0 (of 2 checked)
- scripts in the chain that name table analytics_sync: 0
- scripts in the chain that name table analytics_sync_runs: 0
- scripts in the chain that name table portal_access: 0
- scripts in the chain that name table portal_tokens: 0
- scripts in the chain that name column notifications.dedupe_key: 0
- scripts in the chain that name column vendor_spend.step_key: 0
- another account's analytics readings that still carry a request or result: 0
- values that are wholly an e-mail address, other than the placeholders, in any fixture file: 0
- replaced console-user addresses found anywhere in the fixture files: 0 (of 2 checked)

## The Eagle Eyes export's file time

- `input/extra-ee/eagleeyes-scan-320-weed-near-me.json`: 2026-10-12T16:40:36.494Z. ee-scan-to-seos.mjs stamps the sweep rows read_at with the export's file time; market.json and report-data.json carry it. Pin it with fs.utimesSync before converting.

## Files

| file | bytes | sha256 | source sha256 |
|---|---|---|---|
| `input/business-48.json` | 696246 | `af68535841fdaa5c8b9122d85098593ffb3d8fa4b34171a8a584cd612d190933` | `159664ef594af11b8987938784d44a06c07a3b30708e8a453bfff06755291ae5` |
| `input/full-audit-48.json` | 24791649 | `e748318edc52d85426de04883cc9bc2a948f34e3f94651543e45f837adde6d77` | `c217f37404fb0cd1b03a8bb40e2a13ef0b1609814541a14ad52de32b1506efb3` |
| `input/website-audit-48.json` | 401518 | `08a68e5d4e4262c707c3899c885d8bb0d741df0a8bf98c14ea960a669449e343` | `fa4520e3be4b093b0e0db5913bd0a8c022480147daed9bce680d271e66a4603d` |
| `input/engine_sweeps-all.json` | 57669 | `1d8bf31aadfe25e2eb5e477031797fe0d81a699eac9d2c9fd21f8428470cd9b5` | `1d8bf31aadfe25e2eb5e477031797fe0d81a699eac9d2c9fd21f8428470cd9b5` |
| `input/business_info-history-green-haven.json` | 13769 | `0474ccb8a591bc5c72c60ef0db9a5ec2e6192428730e71c863e3e575b55fbd95` | `f1cafb4421a10b755a179485e0ea1a67c2a8653bc8c7ca0792f8593a987af493` |
| `input/engine_sweep_businesses-green-haven-anywhere.json` | 1335 | `1d8c4c7be7574713c0d42fec0fc9b79c17fd63b966add2728751302541bc0e20` | `1d8c4c7be7574713c0d42fec0fc9b79c17fd63b966add2728751302541bc0e20` |
| `input/locations-all.json` | 10640 | `ef320a1a67a9d6d0532cd3ba1d8c45df1605877c0e2ce2f87eb36b184dfb1e65` | `8a7e00457aef78f1176828c20bfacca2866c23f48ac0d33aadd91e59751134c7` |
| `input/extra-ee/eagleeyes-scan-320-weed-near-me.json` | 652079 | `bf417c889721372ec6f5c55e85a071c82cb57adeb422a33ba176c5b831d13c9e` | `818539cd9208cc2b127b466f2d88b1d768d06d4410a282faa6b9fa9015f85e91` |
