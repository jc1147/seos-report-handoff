// gh-facts.mjs - the independent numbers oracle for the Green Haven Industries report (SEOS business 48).
// Written from the raw SEOS answers alone (it does not read or share code with extract*.mjs or sweeps-market*.mjs),
// so a figure the report prints can be checked against a second, independent computation.
//
// usage: node gh-facts.mjs <DATA folder> <out gh-facts.json> [--md <owner's markdown copy of the same answers>]
//
// Output: { generated_by, sources, facts, md_diff? }
//   facts   - ONE flat object: dotted name -> value (scalars, or a short list). Deterministic: no clock in it.
//   md_diff - only with --md: every table / row / field where the markdown copy and the JSON answers differ.
// Privacy: counts and settings only. No review text, no page text, no account fields, and no URL with a query
// string (a URL is printed as origin + path at most). Fail closed: a missing reading becomes `null` or a `.read`
// fact set to false, never a guess; a broken invariant stops the run with "FACTS FAILED".
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

// ---------------------------------------------------------------- arguments + loading
const argv = process.argv.slice(2);
let mdPath = null;
{ const i = argv.indexOf('--md'); if (i >= 0) { mdPath = argv[i + 1]; argv.splice(i, 2); } }
const [dataDir, outPath] = argv;
if (!dataDir || !outPath) { console.error('usage: node gh-facts.mjs <DATA folder> <out gh-facts.json> [--md <markdown copy>]'); process.exit(2); }
const die = m => { console.error('FACTS FAILED: ' + m); process.exit(1); };
const sources = {};
const rawText = {};
const load = f => {
  const p = path.join(dataDir, f);
  if (!fs.existsSync(p)) die('missing ' + f + ' in ' + dataDir);
  const raw = fs.readFileSync(p);
  sources[f] = { bytes: raw.length, sha256: crypto.createHash('sha256').update(raw).digest('hex') };
  rawText[f] = raw.toString('utf8');
  return JSON.parse(rawText[f]);
};
const biz = load('business-48.json');
const full = load('full-audit-48.json');
const web = load('website-audit-48.json');
const sweepsAll = load('engine_sweeps-all.json');
const locAll = load('locations-all.json');
const anywhere = load('engine_sweep_businesses-green-haven-anywhere.json');
const biHist = load('business_info-history-green-haven.json');

// ---------------------------------------------------------------- helpers
const F = {};
const put = (k, v) => { if (Object.prototype.hasOwnProperty.call(F, k)) die('fact named twice: ' + k); F[k] = v === undefined ? null : v; };
const r1 = x => x == null || Number.isNaN(x) ? null : Math.round(x * 10) / 10;
const r2 = x => x == null || Number.isNaN(x) ? null : Math.round(x * 100) / 100;
const r3 = x => x == null || Number.isNaN(x) ? null : Math.round(x * 1000) / 1000;
const r4 = x => x == null || Number.isNaN(x) ? null : Math.round(x * 10000) / 10000;
const r6 = x => x == null || Number.isNaN(x) ? null : Math.round(x * 1e6) / 1e6;
const sum = (a, f = x => x) => a.reduce((s, x) => s + (f(x) || 0), 0);
const tally = (a, f) => { const o = {}; for (const x of a) { const k = String(f(x)); o[k] = (o[k] || 0) + 1; } return Object.fromEntries(Object.entries(o).sort((p, q) => q[1] - p[1] || p[0].localeCompare(q[0]))); };
const median = xs => { const a = xs.filter(x => x != null && !Number.isNaN(x)).sort((p, q) => p - q); if (!a.length) return null; const m = Math.floor(a.length / 2); return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2; };
// every timestamp in SEOS is UTC: with an offset ("+00:00", " +00:00") or without one
const toMs = s => {
  if (s == null || s === '') return null;
  let x = String(s).trim().replace(' ', 'T').replace(/ ([+-]\d\d:?\d\d)$/, '$1').replace(/(\.\d{3})\d+/, '$1');
  if (!/(Z|[+-]\d\d:?\d\d)$/.test(x)) x += 'Z';
  const t = Date.parse(x);
  return Number.isNaN(t) ? null : t;
};
const isoDay = ms => ms == null ? null : new Date(ms).toISOString().slice(0, 10);
const isoMin = ms => ms == null ? null : new Date(ms).toISOString().slice(0, 16).replace('T', ' ') + ' UTC';
const cleanUrl = u => { try { const x = new URL(u); return x.origin + x.pathname; } catch { return null; } };
// any URL inside a value loses its query string and fragment before it is written out
const scrub = v => typeof v === 'string' ? v.replace(/https?:\/\/[^\s"'<>]+/g, m => cleanUrl(m) ?? '[url]') : Array.isArray(v) ? v.map(scrub) : v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).map(([a, b]) => [a, scrub(b)])) : v;
const km = (a, b) => { const rad = d => d * Math.PI / 180; const dLat = rad(b[0] - a[0]), dLng = rad(b[1] - a[1]); const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dLng / 2) ** 2; return 2 * 6371.0088 * Math.asin(Math.sqrt(h)); };
const MONTH_DAYS = 30.4375; // 365.25 / 12: a "month" in review velocity

// ---------------------------------------------------------------- the store, its runs, its rivals
const T = biz.tables;
const loc = T.locations?.[0];
if (!loc) die('no locations row');
const SUBJ = loc.place_id;
const run = (full.tables.audit_runs || [])[0];
const wrun = (web.tables.audit_runs || [])[0];
if (!run || run.place_id !== SUBJ) die('the full audit run is not this store');
if (!wrun || wrun.place_id !== SUBJ) die('the website audit run is not this store');
const TZ = { NJ: 'America/New_York', NY: 'America/New_York' }[loc.state];
if (!TZ) die(`no timezone mapping for state ${loc.state}`);
const pin = [loc.lat, loc.lng];
const STORE = run.request.slug;
const rivals = (run.request.rivals || []).map(r => ({ pid: r.place_id, slug: r.slug }));
const places = [{ pid: SUBJ, slug: STORE }, ...rivals];
const VR = full.tables.vendor_readings;
const WVR = web.tables.vendor_readings;
const readingIn = (src, kind, pid) => { const rs = src.filter(r => r.kind === kind && r.place_id === pid); if (rs.length > 1) die(`${rs.length} ${kind} readings for ${pid}`); return rs[0] || null; };
const reading = (kind, pid) => readingIn(VR, kind, pid);
const biItem = pid => reading('business_info', pid)?.result?.business_info?.items?.[0] || null;
const storeBi = biItem(SUBJ);
if (!storeBi) die('no Google listing reading for the store');
const created = toMs(T.businesses?.[0]?.created_at);
const local = ms => {
  if (ms == null) return null;
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: TZ, weekday: 'long', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date(ms)).map(x => [x.type, x.value]));
  return { weekday: p.weekday.toLowerCase(), date: `${p.year}-${p.month}-${p.day}`, hm: `${p.hour}:${p.minute}` };
};
const hm = o => `${String(o.hour).padStart(2, '0')}:${String(o.minute).padStart(2, '0')}`;
const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
const daySlots = (it, d) => { const tt = it?.work_time?.work_hours?.timetable; if (!tt) return undefined; const s = tt[d]; return Array.isArray(s) && s.length ? s : null; };

// ---------------------------------------------------------------- sources and shape
put('src.business.tables', Object.keys(T).length);
put('src.business.rows', sum(Object.values(T), v => Array.isArray(v) ? v.length : 0));
put('src.business.vendor_readings_inside', Array.isArray(T.vendor_readings) ? T.vendor_readings.length : null);
put('src.business.analytics_bindings', (T.analytics_bindings || []).length);
put('src.business.google_accounts', (T.google_accounts || []).length);
put('src.business.account_type', T.businesses?.[0]?.account_type ?? null);
put('src.full.vendor_readings', VR.length);
put('src.full.audit_runs', full.tables.audit_runs.length);
put('src.full.keys', (full.keys || []).length);
put('src.full.readings_by_kind', tally(VR, r => r.kind));
put('src.full.readings_for_other_seos_clients', VR.filter(r => ['analytics_watch', 'gsc_sitemaps'].includes(r.kind)).length);
put('src.web.vendor_readings', WVR.length);
put('src.web.kinds_listed', web.kinds || []);
put('src.web.kinds_with_rows', [...new Set(WVR.map(r => r.kind))].sort());
put('src.web.kinds_listed_without_rows', (web.kinds || []).filter(k => !WVR.some(r => r.kind === k)));
{
  // the same (kind, place) held twice would make "the" reading ambiguous
  const seen = tally(VR, r => `${r.kind}|${r.place_id}`);
  put('src.full.duplicate_kind_place_pairs', Object.values(seen).filter(n => n > 1).length);
}
for (const f of ['business-48.json', 'full-audit-48.json', 'website-audit-48.json']) put(`src.phrase_weed_near_me.${f}`, (rawText[f].match(/weed near me/gi) || []).length);

// ---------------------------------------------------------------- the name
put('name.register', T.businesses?.[0]?.name ?? null);
put('name.location_row', loc.name);
put('name.google_title', storeBi.title);
put('name.google_listing_read_at', isoMin(toMs(reading('business_info', SUBJ).fetched_at)));
put('name.google_listing_reads_held', (biHist.rows || []).length);
put('name.register_added_at', isoMin(created));
{
  const sa = reading('site_audit', SUBJ);
  const pg = sa?.result?.page?.items?.[0];
  put('name.site_title', pg?.meta?.title ?? null);
  put('name.site_h1', pg?.meta?.htags?.h1 ?? null);
  put('name.site_og_site_name', pg?.meta?.social_media_tags?.['og:site_name'] ?? null);
  const sightings = (anywhere.rows || []).filter(r => !r.is_subject).map(r => {
    const sw = (sweepsAll.rows || []).find(s => String(s.scan_id) === String(r.scan_id));
    return { scan_id: r.scan_id, name_recorded: r.name, keyword: sw?.keyword ?? null, finished: isoDay(toMs(sw?.finished_at)) };
  });
  put('name.seen_in_other_sweeps', sightings);
  put('name.citation_listing_urls_naming_industries', T.citation_verdicts.filter(v => /green[\W_]*haven[\W_]*industries/i.test(v.listing_url || '')).length);
}

// ---------------------------------------------------------------- the Google listing (store + named rivals)
for (const p of places) {
  const k = `gbp.${p.slug}`;
  const it = biItem(p.pid);
  put(`${k}.read`, !!it);
  if (!it) continue;
  put(`${k}.title`, it.title);
  put(`${k}.category`, it.category);
  put(`${k}.additional_categories`, it.additional_categories || []);
  put(`${k}.rating`, it.rating?.value ?? null);
  put(`${k}.ratings_count`, it.rating?.votes_count ?? null);
  put(`${k}.photos`, it.total_photos ?? null);
  put(`${k}.claimed`, it.is_claimed ?? null);
  for (const d of DAYS) { const s = daySlots(it, d); put(`${k}.hours.${d}`, s === undefined ? null : s === null ? 'closed' : s.map(x => `${hm(x.open)}-${hm(x.close)}`).join(',')); }
  const avail = it.attributes?.available_attributes || {};
  put(`${k}.attributes`, sum(Object.values(avail), v => v.length));
  put(`${k}.service_options`, (avail.service_options || []).length);
  put(`${k}.description_chars`, (it.description || '').length);
  put(`${k}.website`, cleanUrl(it.url));
  // the listing's own link tag (a rival's tag is the rival's own tracking, not the agency's)
  put(`${k}.website_utm_source`, (() => { try { return new URL(it.url).searchParams.get('utm_source'); } catch { return null; } })());
  put(`${k}.read_at`, isoMin(toMs(reading('business_info', p.pid).fetched_at)));
}
put(`gbp.${STORE}.rating_distribution`, storeBi.rating_distribution || null);
put(`gbp.${STORE}.place_topics`, Object.keys(storeBi.place_topics || {}).length);
put(`gbp.${STORE}.people_also_search`, (storeBi.people_also_search || []).map(x => x.title));

// ---------------------------------------------------------------- the field's Google listings (business_info)
const esb = T.engine_sweep_businesses;
const posOf = pid => { const it = biItem(pid); if (it && it.latitude != null) return [it.latitude, it.longitude]; const r = esb.find(x => x.place_id === pid && x.lat != null); return r ? [r.lat, r.lng] : null; };
{
  const named = new Set(places.map(p => p.pid));
  const fieldBi = VR.filter(r => r.kind === 'business_info' && !named.has(r.place_id)).map(r => ({ r, it: r.result?.business_info?.items?.[0] || null }));
  const withKm = fieldBi.map(o => ({ ...o, km: o.it && o.it.latitude != null ? km(pin, [o.it.latitude, o.it.longitude]) : null }));
  const inMkt = withKm.filter(o => o.km != null && o.km <= 40), farOnes = withKm.filter(o => o.km != null && o.km > 40);
  put('field_profiles.read', fieldBi.length);
  put('field_profiles.in_market_40km', inMkt.length);
  put('field_profiles.out_of_market', farOnes.length);
  put('field_profiles.out_of_market_read_before_store_added', farOnes.filter(o => toMs(o.r.fetched_at) < created).length);
  put('field_profiles.out_of_market_bought_for_this_store', farOnes.filter(o => toMs(o.r.fetched_at) >= created).map(o => o.it.title));
  put('field_profiles.out_of_market_cities', tally(farOnes, o => `${o.it.address_info?.city}, ${o.it.address_info?.region}`));
  put('field_profiles.in_market_median_rating', median(inMkt.map(o => o.it.rating?.value)));
  put('field_profiles.in_market_median_ratings_count', median(inMkt.map(o => o.it.rating?.votes_count)));
  const most = [...inMkt].sort((a, b) => (b.it.rating?.votes_count || 0) - (a.it.rating?.votes_count || 0))[0];
  put('field_profiles.in_market_most_ratings', most ? { name: most.it.title, ratings_count: most.it.rating?.votes_count, rating: most.it.rating?.value } : null);
  put('field_profiles.in_market_with_more_ratings_than_store', inMkt.filter(o => (o.it.rating?.votes_count || 0) > storeBi.rating.votes_count).length);
  put('field_profiles.in_market_rated_5', inMkt.filter(o => o.it.rating?.value === 5).length);
  put('field_profiles.in_market_claimed', inMkt.filter(o => o.it.is_claimed === true).length);
  // the sweep rows carry a rating and a count too: do they agree with the listing reads?
  const pairs = esb.filter(x => !x.is_subject && x.rating != null).map(x => ({ x, it: biItem(x.place_id) })).filter(o => o.it);
  put('field_profiles.sweep_row_vs_listing_rating_disagree', pairs.filter(o => o.it.rating?.value !== o.x.rating).length);
  put('field_profiles.sweep_row_vs_listing_count_disagree', pairs.filter(o => o.x.reviews != null && o.it.rating?.votes_count !== o.x.reviews).length);
  // every in-market listing read, most ratings first: [name, rating, ratings count, claimed, km from the store]
  put('field_profiles.in_market_list', [...inMkt].sort((a, b) => (b.it.rating?.votes_count || 0) - (a.it.rating?.votes_count || 0) || a.it.title.localeCompare(b.it.title)).map(o => [o.it.title, o.it.rating?.value ?? null, o.it.rating?.votes_count ?? null, o.it.is_claimed ?? null, r1(o.km)]));
  put('field_profiles.in_market_unclaimed', inMkt.filter(o => o.it.is_claimed === false).map(o => o.it.title).sort());
  put('field_profiles.in_market_without_category', inMkt.filter(o => !o.it.category).map(o => o.it.title).sort());
}
// sweep rows whose columns are shifted or empty (read them before trusting a row)
put('sweeps.rows_category_holds_a_street_address', esb.filter(x => /^\d+[A-Za-z]?\s+\S/.test(x.category || '')).map(x => `${x.scan_id}: ${x.name} (category "${x.category}", address ${x.address == null ? 'null' : JSON.stringify(x.address)})`));
put('sweeps.subject_row_null_columns', [...new Set(esb.filter(x => x.is_subject).flatMap(x => Object.entries(x).filter(([, v]) => v == null).map(([c]) => c)))].sort());

// ---------------------------------------------------------------- the map sweeps (every sweep stored for this store)
const mySweeps = T.engine_sweeps.filter(s => s.subject === SUBJ).sort((a, b) => Number(a.scan_id) - Number(b.scan_id));
put('sweeps.count', mySweeps.length);
put('sweeps.ids', mySweeps.map(s => String(s.scan_id)));
put('sweeps.keywords', mySweeps.map(s => s.keyword));
put('sweeps.weed_near_me_held', mySweeps.some(s => /weed near me/i.test(s.keyword || '')));
// "out of market" is the report's own line: 150 miles (241.4 km), the cut-off sweeps-market.mjs states in the market file
// and the template's check draws. (It was 40 km: harmless while every far business sat ~1,800 km away, wrong once the
// "weed near me" sweep listed Bronx delivery services 35-40 km off as well as the Council Bluffs cluster.)
const OUT_KM = 150 * 1.609344;
const nameOf = pid => pid === SUBJ ? storeBi.title : (esb.find(x => x.place_id === pid)?.name ?? biItem(pid)?.title ?? pid);
for (const s of mySweeps) {
  const k = `sweep.${s.scan_id}`;
  const cr = T.engine_sweep_cells.find(c => String(c.scan_id) === String(s.scan_id));
  put(`${k}.keyword`, s.keyword);
  put(`${k}.grid`, `${s.grid_size}x${s.grid_size}`);
  put(`${k}.radius`, `${s.radius} ${s.unit}`);
  put(`${k}.stored.total_points`, s.total_points);
  put(`${k}.stored.found_points`, s.found_points);
  put(`${k}.stored.share`, s.solv);
  put(`${k}.stored.arp`, s.arp);
  put(`${k}.stored.atrp`, s.atrp);
  put(`${k}.exclusion_note`, s.exclusion_note || null);
  put(`${k}.started_how`, s.started_how || null);
  put(`${k}.cells_read`, !!cr);
  if (!cr) continue; // not measured: no point-by-point record held for this sweep
  const cells = cr.cells;
  const n = cells.length;
  const full2 = s.grid_size * s.grid_size;
  const ranks = cells.map(c => c.rank);
  const found = ranks.filter(r => r != null);
  const b13 = found.filter(r => r <= 3).length, b410 = found.filter(r => r >= 4 && r <= 10).length, b1120 = found.filter(r => r >= 11 && r <= 20).length;
  put(`${k}.points`, n);
  put(`${k}.points_excluded`, full2 - n);
  {
    const have = new Set(cells.map(c => `${c.row},${c.col}`));
    const miss = []; for (let r = 0; r < s.grid_size; r++) for (let c = 0; c < s.grid_size; c++) if (!have.has(`${r},${c}`)) miss.push(`r${r}c${c}`);
    put(`${k}.points_excluded_cells`, miss);
  }
  put(`${k}.store.found`, found.length);
  put(`${k}.store.rank_1`, found.filter(r => r === 1).length);
  put(`${k}.store.in_1_3`, b13);
  put(`${k}.store.in_4_10`, b410);
  put(`${k}.store.in_11_20`, b1120);
  put(`${k}.store.over_20`, found.filter(r => r > 20).length);
  put(`${k}.store.not_found`, ranks.filter(r => r == null).length);
  put(`${k}.store.share`, r2(100 * b13 / n));
  put(`${k}.store.share_matches_stored`, r2(100 * b13 / n) === s.solv);
  put(`${k}.store.arp`, found.length ? r2(sum(found) / found.length) : null);
  put(`${k}.store.atrp_21_for_not_found`, r2((sum(found) + 21 * (n - found.length)) / n));
  put(`${k}.stored_totals_match_cells`, s.total_points === n && s.found_points === found.length);
  put(`${k}.rank_vs_list_disagree`, cells.filter(c => { const i = c.top.indexOf(SUBJ); return c.rank == null ? i >= 0 && i < 20 : i !== c.rank - 1; }).length);
  // every business, from the stored top lists (first 20 at a point; the centre point holds the whole feed)
  const st = new Map();
  for (const c of cells) c.top.forEach((pid, i) => { const o = st.get(pid) || { top3: 0, in20: 0, listed: 0, best: Infinity }; if (i < 3) o.top3++; if (i < 20) o.in20++; o.listed++; o.best = Math.min(o.best, i + 1); st.set(pid, o); });
  put(`${k}.store.top3_from_lists_matches`, (st.get(SUBJ)?.top3 || 0) === b13);
  const rows = esb.filter(x => String(x.scan_id) === String(s.scan_id));
  put(`${k}.field_rows`, rows.length - rows.filter(x => x.is_subject).length);
  put(`${k}.field_ids_in_lists`, [...st.keys()].filter(p => p !== SUBJ).length);
  // the whole-feed point lists far past 20: a business seen only there was never in a first 20 anywhere
  put(`${k}.field_in_a_first_20`, [...st.entries()].filter(([p, o]) => p !== SUBJ && o.in20 > 0).length);
  put(`${k}.field_only_beyond_20`, [...st.entries()].filter(([p, o]) => p !== SUBJ && o.in20 === 0).length);
  const all = rows.map(x => ({ pid: x.place_id, name: nameOf(x.place_id), stored: x.solv, storedTop3: x.top3_appearances, top3: st.get(x.place_id)?.top3 || 0, in20: st.get(x.place_id)?.in20 || 0 }));
  put(`${k}.top3_count_disagree_with_stored`, all.filter(o => o.pid !== SUBJ && o.storedTop3 != null && o.storedTop3 !== o.top3).length);
  put(`${k}.share_disagree_with_stored`, all.filter(o => o.stored != null && r2(100 * o.top3 / n) !== o.stored).length);
  const ranked = [...all].sort((a, b) => b.top3 - a.top3 || b.in20 - a.in20 || a.name.localeCompare(b.name));
  const placeOf = pid => 1 + all.filter(o => o.top3 > (all.find(x => x.pid === pid)?.top3 ?? 0)).length;
  put(`${k}.store.place_by_share`, placeOf(SUBJ));
  put(`${k}.store.place_by_share_stored`, rows.find(x => x.is_subject)?.rank_solv ?? null);
  put(`${k}.top5`, ranked.slice(0, 5).map(o => ({ name: o.name, share: r2(100 * o.top3 / n), top3_points: o.top3, is_store: o.pid === SUBJ })));
  const leader = ranked[0];
  put(`${k}.leader.name`, leader.name);
  put(`${k}.leader.is_store`, leader.pid === SUBJ);
  put(`${k}.leader.share`, r2(100 * leader.top3 / n));
  put(`${k}.leader.top3_points`, leader.top3);
  const best = ranked.find(o => o.pid !== SUBJ);
  put(`${k}.best_rival.name`, best?.name ?? null);
  put(`${k}.best_rival.top3_points`, best?.top3 ?? null);
  put(`${k}.store.top3_points_minus_leader`, b13 - leader.top3);
  put(`${k}.store.top3_points_minus_best_rival`, best ? b13 - best.top3 : null);
  // head to head against each named rival: the store above / below it point by point
  for (const r of rivals) {
    let ahead = 0, behind = 0, neither = 0;
    for (const c of cells) { const a = c.top.indexOf(SUBJ), b = c.top.indexOf(r.pid); const A = a < 0 ? Infinity : a, B = b < 0 ? Infinity : b; if (A === Infinity && B === Infinity) neither++; else if (A < B) ahead++; else behind++; }
    put(`${k}.vs.${r.slug}.store_above`, ahead);
    put(`${k}.vs.${r.slug}.rival_above`, behind);
    put(`${k}.vs.${r.slug}.neither_listed`, neither);
    put(`${k}.vs.${r.slug}.rival_top3_points`, st.get(r.pid)?.top3 || 0);
  }
  // where the field sits: distance from the store's pin (not from the sweep's centre)
  const dist = rows.filter(x => !x.is_subject).map(x => ({ x, d: x.lat != null && x.lng != null ? km(pin, [x.lat, x.lng]) : null }));
  put(`${k}.field_unplaced`, dist.filter(o => o.d == null).length);
  put(`${k}.field_beyond_25km`, dist.filter(o => o.d != null && o.d > 25).length);
  put(`${k}.field_beyond_40km`, dist.filter(o => o.d != null && o.d > 40).length);
  put(`${k}.field_beyond_150km`, dist.filter(o => o.d != null && o.d > 150).length);
  const outM = dist.filter(o => o.d != null && o.d > OUT_KM);
  const outSet = new Set(outM.map(o => o.x.place_id));
  put(`${k}.out_of_market.nearest_km`, outM.length ? Math.round(Math.min(...outM.map(o => o.d))) : null);
  put(`${k}.out_of_market.farthest_km`, outM.length ? Math.round(Math.max(...outM.map(o => o.d))) : null);
  put(`${k}.out_of_market.top3_points`, sum(outM, o => st.get(o.x.place_id)?.top3 || 0));
  put(`${k}.out_of_market.best_rank`, outM.length ? Math.min(...outM.map(o => st.get(o.x.place_id)?.best ?? Infinity)) : null);
  const intr = cells.filter(c => c.top.slice(0, 20).some(p => outSet.has(p)));
  put(`${k}.out_of_market.points_with_one_in_first_20`, intr.length);
  put(`${k}.out_of_market.points_with_one_above_store`, cells.filter(c => { const i = c.top.indexOf(SUBJ); return i >= 0 && c.top.slice(0, i).some(p => outSet.has(p)); }).length);
  put(`${k}.out_of_market.not_found_points_with_one_in_first_20`, cells.filter(c => c.rank == null && c.top.slice(0, 20).some(p => outSet.has(p))).length);
  // the sweep's own centre against the store's pin
  put(`${k}.centre_offset_m`, Math.round(km(pin, [cr.centre_lat, cr.centre_lng]) * 1000));
  put(`${k}.stored_distances_not_from_store_pin`, rows.filter(x => x.lat != null && x.distance_km != null && Math.abs(km(pin, [x.lat, x.lng]) - x.distance_km) > 0.05).length);
  const longLists = cells.filter(c => c.top.length > 20);
  put(`${k}.points_with_whole_feed`, longLists.length);
  put(`${k}.whole_feed_length`, longLists.map(c => c.top.length));
  // when it ran, in the store's own clock, against the posted hours that day
  const actor = (T.engine_actors || []).find(a => a.kind === 'scan' && String(a.ref) === String(s.scan_id));
  const t0 = actor ? toMs(actor.at) : null, t1 = toMs(s.finished_at);
  const L0 = local(t0), L1 = local(t1);
  put(`${k}.started_utc`, isoMin(t0));
  put(`${k}.finished_utc`, isoMin(t1));
  put(`${k}.started_local`, L0 ? `${L0.weekday} ${L0.date} ${L0.hm}` : null);
  put(`${k}.finished_local`, L1 ? `${L1.weekday} ${L1.date} ${L1.hm}` : null);
  put(`${k}.started_by_recorded`, !!actor);
  put(`${k}.started_by_role`, actor?.role ?? null);
  put(`${k}.started_by_how`, actor?.how ?? null);
  const slots = L1 ? daySlots(storeBi, L1.weekday) : undefined;
  put(`${k}.posted_hours_that_day`, slots === undefined ? null : slots === null ? 'closed' : slots.map(x => `${hm(x.open)}-${hm(x.close)}`).join(','));
  const inside = t => { const L = local(t); const sl = daySlots(storeBi, L.weekday); if (!sl) return false; return sl.some(x => L.hm >= hm(x.open) && L.hm < hm(x.close)); };
  put(`${k}.finished_within_posted_hours`, t1 != null && slots !== undefined ? inside(t1) : null);
  put(`${k}.started_within_posted_hours`, t0 != null && slots !== undefined ? inside(t0) : null);
}
// out-of-market rows across both sweeps, and where they are
{
  const outRows = esb.filter(x => !x.is_subject && x.lat != null && km(pin, [x.lat, x.lng]) > OUT_KM);
  put('sweeps.out_of_market_rows', outRows.length);
  put('sweeps.rows', esb.length);
  put('sweeps.out_of_market_distinct_places', new Set(outRows.map(x => x.place_id)).size);
  const med = [median(outRows.map(x => x.lat)), median(outRows.map(x => x.lng))];
  put('sweeps.out_of_market_median_point', outRows.length ? med.map(v => r2(v)) : null);
  put('sweeps.out_of_market_median_km', outRows.length ? Math.round(km(pin, med)) : null);
  put('sweeps.out_of_market_median_miles', outRows.length ? Math.round(km(pin, med) / 1.609344) : null);
}

// ---------------------------------------------------------------- "weed near me" across SEOS
{
  const all = sweepsAll.rows || [];
  put('seos.sweeps_total', all.length);
  put('seos.sweeps_by_keyword', tally(all, s => s.keyword));
  put('seos.weed_near_me_sweeps', all.filter(s => /weed near me/i.test(s.keyword || '')).length);
  put('seos.weed_near_me_sweeps_for_this_store', all.filter(s => s.subject === SUBJ && /weed near me/i.test(s.keyword || '')).length);
  put('seos.sweeps_for_this_store', all.filter(s => s.subject === SUBJ).map(s => `${s.scan_id} ${s.keyword}`));
  const locs = locAll.rows || [];
  const byPid = Object.fromEntries(locs.map(l => [l.place_id, l]));
  const weedish = all.filter(s => /weed/i.test(s.keyword || '')).map(s => { const l = byPid[s.subject]; return { s, l, d: l && l.lat != null ? km(pin, [l.lat, l.lng]) : null }; }).filter(o => o.d != null).sort((a, b) => a.d - b.d);
  const near = weedish[0];
  const seenIn = new Set((anywhere.rows || []).map(r => String(r.scan_id)));
  put('seos.nearest_weed_sweep', near ? { scan_id: String(near.s.scan_id), keyword: near.s.keyword, subject: near.l.name, km_from_store: r1(near.d), radius: `${near.s.radius} ${near.s.unit}`, finished: isoDay(toMs(near.s.finished_at)), store_in_its_field: seenIn.has(String(near.s.scan_id)) } : null);
  const nearWNM = weedish.find(o => /weed near me/i.test(o.s.keyword));
  put('seos.nearest_weed_near_me_sweep', nearWNM ? { scan_id: String(nearWNM.s.scan_id), subject: nearWNM.l.name, km_from_store: r1(nearWNM.d), radius: `${nearWNM.s.radius} ${nearWNM.s.unit}`, finished: isoDay(toMs(nearWNM.s.finished_at)), store_in_its_field: seenIn.has(String(nearWNM.s.scan_id)) } : null);
  put('seos.store_in_sweep_fields', [...seenIn].sort((a, b) => Number(a) - Number(b)));
}

// ---------------------------------------------------------------- reviews (store + named rivals)
const replied = i => String(i.owner_reply || '').trim().length > 0;
for (const p of places) {
  const k = `rv.${p.slug}`;
  const r = reading('reviews', p.pid);
  put(`${k}.read`, !!r);
  if (!r) continue;
  const R = r.result?.reviews || {};
  const items = R.items || [];
  const collectedAt = toMs(R.collected_at);
  if (collectedAt == null) die(`cannot read reviews.collected_at for ${p.slug}`);
  const stamps = items.map(i => toMs(i.timestamp)).filter(x => x != null);
  const oldest = stamps.length ? Math.min(...stamps) : null, newest = stamps.length ? Math.max(...stamps) : null;
  put(`${k}.collected`, items.length);
  put(`${k}.vendor_count`, R.count ?? null);
  put(`${k}.asked_depth`, r.request?.reviews?.depth ?? null);
  put(`${k}.capped`, R.capped === true);
  put(`${k}.google_ratings_count`, biItem(p.pid)?.rating?.votes_count ?? null);
  put(`${k}.undated`, items.length - stamps.length);
  put(`${k}.newest`, isoDay(newest));
  put(`${k}.oldest_collected`, isoDay(oldest));
  put(`${k}.collected_at`, isoMin(collectedAt));
  for (const d of [30, 90, 365]) {
    const cut = collectedAt - d * 864e5;
    const covered = R.capped !== true || (oldest != null && oldest <= cut);
    const w = items.filter(i => { const t = toMs(i.timestamp); return t != null && t >= cut; });
    put(`${k}.in_${d}d`, covered ? w.length : null);
    put(`${k}.per_month_${d}d`, covered ? r2(w.length * MONTH_DAYS / d) : null);
    put(`${k}.replied_${d}d`, covered ? w.filter(replied).length : null);
  }
  put(`${k}.replied`, R.capped === true ? null : items.filter(replied).length);
  put(`${k}.replied_in_collected`, items.filter(replied).length);
  // calendar months (UTC), the 12 before the collection month plus that month itself (partial); null where a capped pull does not reach
  {
    const c = new Date(collectedAt);
    const months = {};
    for (let back = 12; back >= 0; back--) {
      const m0 = Date.UTC(c.getUTCFullYear(), c.getUTCMonth() - back, 1), m1 = Date.UTC(c.getUTCFullYear(), c.getUTCMonth() - back + 1, 1);
      const label = new Date(m0).toISOString().slice(0, 7);
      const covered = R.capped !== true || (oldest != null && oldest <= m0);
      months[label] = covered ? items.filter(i => { const t = toMs(i.timestamp); return t != null && t >= m0 && t < m1; }).length : null;
    }
    put(`${k}.by_month_utc`, months);
    put(`${k}.by_month_last_is_partial_to`, isoDay(collectedAt));
  }
  for (const star of [1, 2, 3, 4, 5]) {
    const g = items.filter(i => i.rating === star);
    put(`${k}.star${star}.collected`, g.length);
    put(`${k}.star${star}.replied`, g.filter(replied).length);
  }
}
{
  const snaps = T.review_velocity_snapshots || [];
  for (const sn of snaps) {
    const d = sn.window_days;
    put(`rv.${STORE}.seos_snapshot_${d}d`, { in_window: sn.reviews_in_window, per_month: sn.per_month, replied: sn.replied_in_window });
    put(`rv.${STORE}.seos_snapshot_${d}d_matches`, F[`rv.${STORE}.in_${d}d`] === sn.reviews_in_window && F[`rv.${STORE}.per_month_${d}d`] === sn.per_month && F[`rv.${STORE}.replied_${d}d`] === sn.replied_in_window);
  }
}

// ---------------------------------------------------------------- websites and page speed
// POSITIVE checks are good when true; NEUTRAL ones are information, never a flag; every other check is a problem when true.
const POSITIVE = new Set(['is_https', 'has_html_doctype', 'canonical', 'seo_friendly_url', 'seo_friendly_url_characters_check', 'seo_friendly_url_dynamic_check', 'seo_friendly_url_keywords_check', 'seo_friendly_url_relative_length_check', 'meta_charset_consistency']);
const NEUTRAL = new Set(['is_www', 'is_http', 'from_sitemap', 'has_meta_title', 'has_micromarkup']);
const flagged = checks => Object.entries(checks || {}).filter(([c, v]) => !NEUTRAL.has(c) && (POSITIVE.has(c) ? v === false : v === true)).map(([c]) => c).sort();
const siteFacts = (k, r) => {
  put(`${k}.read`, !!r);
  if (!r) return;
  const pg = r.result?.page?.items?.[0] || null, pr = r.result?.page_rendered?.items?.[0] || null;
  const rd = r.result?.render || {};
  put(`${k}.url`, cleanUrl(pg?.url ?? r.target));
  put(`${k}.read_at`, isoMin(toMs(r.fetched_at)));
  put(`${k}.status`, pg?.status_code ?? null);
  put(`${k}.onpage_score_crawler`, pg?.onpage_score ?? null);
  put(`${k}.onpage_score_browser`, pr?.onpage_score ?? null);
  put(`${k}.onpage_score`, pg && pr ? (pg.onpage_score === pr.onpage_score ? pg.onpage_score : 'not confirmed') : (pg?.onpage_score ?? null));
  put(`${k}.words_crawler`, rd.crawler_words ?? pg?.meta?.content?.plain_text_word_count ?? null);
  put(`${k}.words_browser`, rd.browser_words ?? pr?.meta?.content?.plain_text_word_count ?? null);
  put(`${k}.chars_crawler`, rd.crawler_chars ?? null);
  put(`${k}.chars_browser`, rd.browser_chars ?? null);
  put(`${k}.text_ratio_browser_to_crawler`, rd.ratio ?? null);
  put(`${k}.thin_to_crawler`, rd.thin_to_crawler ?? null);
  put(`${k}.render_blocked`, rd.blocked ?? null);
  put(`${k}.age_gate`, r.result?.age_gate ? r.result.age_gate.gated : null);
  put(`${k}.crawler_fetch_ms`, pg?.page_timing?.duration_time ?? null);
  put(`${k}.browser_dom_complete_ms`, pr?.page_timing?.dom_complete ?? null);
  put(`${k}.flagged_checks`, flagged(pg?.checks));
  put(`${k}.flagged_checks_count`, flagged(pg?.checks).length);
  put(`${k}.crawler_saw_micromarkup`, pg?.checks?.has_micromarkup ?? null);
  put(`${k}.pages_read`, Object.keys(r.result || {}).filter(x => /^page(_\d+)?$/.test(x) && r.result[x]?.items?.length).length);
};
const psFacts = (k, r) => {
  for (const dev of ['phone', 'desktop']) {
    const x = r?.result?.[dev];
    const ok = !!(x && !x.error && x.score != null);
    put(`${k}.${dev}.read`, ok);
    if (!ok) continue;
    const m = x.metrics || {};
    put(`${k}.${dev}.performance`, Math.round(x.score * 100));
    put(`${k}.${dev}.lcp_ms`, m.lcp ? Math.round(m.lcp.value) : null);
    put(`${k}.${dev}.cls`, m.cls ? r3(m.cls.value) : null);
    put(`${k}.${dev}.tbt_ms`, m.tbt ? Math.round(m.tbt.value) : null);
    put(`${k}.${dev}.fcp_ms`, m.fcp ? Math.round(m.fcp.value) : null);
    put(`${k}.${dev}.accessibility`, x.categories?.accessibility != null ? Math.round(x.categories.accessibility * 100) : null);
    put(`${k}.${dev}.seo`, x.categories?.seo != null ? Math.round(x.categories.seo * 100) : null);
    put(`${k}.${dev}.url`, cleanUrl(x.final_url || x.url));
  }
};
// (a) the page each Google listing points to (full audit) - the store's page, and each rival's own listing page
for (const p of places) { siteFacts(`site.listing_page.${p.slug}`, reading('site_audit', p.pid)); psFacts(`speed.listing_page.${p.slug}`, reading('page_speed', p.pid)); }
// (b) the competitor websites' home pages (website audit, keyed site:<domain>) - for a chain that is the whole brand's site
const domainOf = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return null; } };
const siteKeys = (web.keys || []).filter(x => x.startsWith('site:'));
const slugForSite = key => { const d = key.slice(5); const p = rivals.find(r => domainOf(biItem(r.pid)?.url) === d); return p ? p.slug : d.replace(/\W+/g, '-'); };
for (const key of siteKeys) {
  const slug = slugForSite(key);
  siteFacts(`site.home.${slug}`, readingIn(WVR, 'site_audit', key));
  psFacts(`speed.home.${slug}`, readingIn(WVR, 'page_speed', key));
}
put('site.home.store_is_listing_page', cleanUrl(storeBi.url) === cleanUrl(readingIn(WVR, 'site_audit', SUBJ)?.target));
// site crawls (website audit: the store and the three competitor sites)
for (const key of [SUBJ, ...siteKeys]) {
  const slug = key === SUBJ ? STORE : slugForSite(key);
  const r = readingIn(WVR, 'site_crawl', key);
  const k = `crawl.${slug}`;
  const sm = r?.result?.summary;
  put(`${k}.read`, !!sm);
  if (!sm) continue;
  put(`${k}.pages_crawled`, sm.pages_crawled);
  put(`${k}.max_pages`, sm.max_pages);
  put(`${k}.stopped_at_limit`, sm.pages_crawled >= sm.max_pages);
  put(`${k}.onpage_score`, sm.onpage_score);
  put(`${k}.duplicate_title`, sm.duplicate_title);
  put(`${k}.duplicate_description`, sm.duplicate_description);
  put(`${k}.duplicate_content`, sm.duplicate_content);
  put(`${k}.broken_links`, sm.broken_links);
  put(`${k}.no_h1_tag`, sm.checks?.no_h1_tag ?? 0);
}
// whole-website signals (a chain's figure is its whole brand's site, not one store)
{
  const rs = reading('ranking_signals', SUBJ);
  put('domain.read', !!rs);
  if (rs) {
    for (const it of rs.result?.ranks?.items || []) put(`domain.${it.target}.rank`, it.rank);
    for (const it of rs.result?.traffic?.items || []) { put(`domain.${it.target}.organic_keywords_whole_site`, it.metrics?.organic?.count ?? null); put(`domain.${it.target}.organic_traffic_estimate_whole_site`, it.metrics?.organic?.etv != null ? Math.round(it.metrics.organic.etv) : null); }
  }
  const cd = reading('competitor_domains', SUBJ)?.result?.competitors;
  put('domain.competitor_domains_total', cd?.total_count ?? null);
  const own = (cd?.items || []).find(i => i.domain === storeBi.domain)?.full_domain_metrics?.organic;
  put(`domain.${storeBi.domain}.positions_1_3`, own ? (own.pos_1 || 0) + (own.pos_2_3 || 0) : null);
  put(`domain.${storeBi.domain}.positions_4_10`, own ? own.pos_4_10 ?? null : null);
}

// ---------------------------------------------------------------- backlinks: classify first, then count
const SELLER_TITLE = /\b(backlinks?|link[\s-]*building|seo[\s-]+links?|high[\s-]*authority|domain[\s-]*authority|guest[\s-]*posts?|pbn|black[\s-]*hat|bhs[\s-]*links)\b/i;
const normTitle = t => String(t || '').toLowerCase().replace(/\s*[-|–—]\s*page\s*[\d,]+\s*$/, '').replace(/\s+/g, ' ').trim();
const WAVE_MIN_HOSTS = 20;
const host = h => String(h || '').toLowerCase().replace(/^www\./, '');
for (const p of places) {
  const k = `links.${p.slug}`;
  const ex = reading('bl_exhaustive', p.pid);
  put(`${k}.read`, !!ex);
  if (!ex) continue;
  const parts = re => Object.entries(ex.result || {}).filter(([n, v]) => re.test(n) && v && Array.isArray(v.items)).map(([, v]) => v);
  const rdP = parts(/^rd_\d+$/), blP = parts(/^bl_\d+$/);
  const rdTotal = rdP[0]?.total_count ?? null, blTotal = blP[0]?.total_count ?? null;
  const rdItems = rdP.flatMap(v => v.items), blItems = blP.flatMap(v => v.items);
  put(`${k}.referring_domains`, rdTotal);
  put(`${k}.referring_domains_held`, rdItems.length);
  put(`${k}.referring_domains_complete`, rdTotal != null && rdItems.length >= rdTotal);
  put(`${k}.links`, blTotal);
  put(`${k}.links_held`, blItems.length);
  put(`${k}.links_complete`, blTotal != null && blItems.length >= blTotal);
  // classify every linking host from the link rows held: a link-seller title, or a title shared by a wave of hosts
  const titleHosts = new Map();
  for (const b of blItems) { const t = normTitle(b.page_from_title); if (!t) continue; if (!titleHosts.has(t)) titleHosts.set(t, new Set()); titleHosts.get(t).add(host(b.domain_from)); }
  const waves = [...titleHosts.entries()].filter(([, s]) => s.size >= WAVE_MIN_HOSTS).sort((a, b) => b[1].size - a[1].size);
  const waveTitles = new Set(waves.map(([t]) => t));
  const seller = new Set();
  for (const b of blItems) { const t = normTitle(b.page_from_title); if (SELLER_TITLE.test(b.page_from_title || '') || waveTitles.has(t)) seller.add(host(b.domain_from)); }
  const hosts = new Set(blItems.map(b => host(b.domain_from)));
  // SEOS's own link ledger flags scheme hosts as well (integration, 2026-10-12: Budzooka's smartwebdirectory.com, whose one
  // link sits on a bulk "Domains 7831001 - 7832000" list page, was flagged by the ledger and counted clean here)
  for (const h of reading('bl_ledger', p.pid)?.result?.hosts || []) if (h.scheme_like) seller.add(host(h.host));
  put(`${k}.classified_over`, blTotal != null && blItems.length >= blTotal ? 'every link' : `the ${blItems.length} links held of ${blTotal}`);
  put(`${k}.linking_hosts`, hosts.size);
  put(`${k}.seller_hosts`, [...hosts].filter(h => seller.has(h)).length);
  put(`${k}.other_hosts`, [...hosts].filter(h => !seller.has(h)).length);
  put(`${k}.links_from_sellers`, blItems.filter(b => seller.has(host(b.domain_from))).length);
  put(`${k}.links_from_others`, blItems.filter(b => !seller.has(host(b.domain_from))).length);
  put(`${k}.title_waves`, waves.length);
  put(`${k}.largest_wave_hosts`, waves[0] ? waves[0][1].size : 0);
  if (waves[0]) {
    const w = waves[0][0];
    const fs0 = blItems.filter(b => normTitle(b.page_from_title) === w).map(b => toMs(b.first_seen)).filter(x => x != null);
    put(`${k}.largest_wave_first_seen`, `${isoDay(Math.min(...fs0))} to ${isoDay(Math.max(...fs0))}`);
    put(`${k}.largest_wave_title_is_seller_text`, SELLER_TITLE.test(w));
  } else { put(`${k}.largest_wave_first_seen`, null); put(`${k}.largest_wave_title_is_seller_text`, null); }
  // a referring domain is a seller when a seller host is that domain or sits under it
  const rdSeller = d => { const h = host(d); for (const s of seller) if (s === h || s.endsWith('.' + h)) return true; return false; };
  const fetched = toMs(ex.fetched_at);
  const new30 = rdItems.filter(i => { const t = toMs(i.first_seen); return t != null && t >= fetched - 30 * 864e5; });
  put(`${k}.referring_domains_new_30d`, rdTotal != null && rdItems.length >= rdTotal ? new30.length : null);
  put(`${k}.referring_domains_new_30d_sellers`, rdTotal != null && rdItems.length >= rdTotal && blItems.length >= blTotal ? new30.filter(i => rdSeller(i.domain)).length : null);
  put(`${k}.referring_domains_sellers`, blItems.length >= blTotal ? rdItems.filter(i => rdSeller(i.domain)).length : null);
  put(`${k}.referring_domains_not_sellers`, blItems.length >= blTotal && rdItems.length >= rdTotal ? rdItems.filter(i => !rdSeller(i.domain)).length : null);
  // the agency's own tags: utm_*=dispenza anywhere; a gmb-<store> tag only counts on the store's own links
  // (a rival's gmb- tag, e.g. Zen Leaf's utm_campaign=gmb-website-<city>, is the rival's own tracking)
  const agencyRe = p.pid === SUBJ ? /[?&]utm_[a-z]+=(dispenza|gmb-)/i : /[?&]utm_[a-z]+=dispenza/i;
  put(`${k}.links_with_agency_tag`, blItems.filter(b => agencyRe.test(b.url_to || '')).length);
  // SEOS's own ledger, for comparison with the classification above
  const L = reading('bl_ledger', p.pid)?.result;
  put(`${k}.seos_ledger.hosts`, L ? L.hosts.length : null);
  put(`${k}.seos_ledger.scheme_like_hosts`, L ? L.hosts.filter(h => h.scheme_like).length : null);
  put(`${k}.seos_ledger.agency_tagged_rows`, L ? L.tagged_rows : null);
  const land = reading('bl_landing', p.pid)?.result?.land;
  put(`${k}.listing_page.links`, land?.backlinks ?? null);
  put(`${k}.listing_page.referring_domains`, land?.referring_domains ?? null);
  put(`${k}.listing_page.vendor_spam_score`, land?.backlinks_spam_score ?? null);
  const lo = reading('bl_location', p.pid)?.result?.loc;
  put(`${k}.links_to_city_urls`, lo ? lo.total_count : null);
}
{
  const g = reading('bl_link_gap', SUBJ);
  put('links.gap.read', !!g);
  if (g) {
    const all = new Set();
    for (const [id, req] of Object.entries(g.request || {}).filter(([n]) => /^gap_\d+$/.test(n))) {
      const res = g.result?.[id];
      if (!res) { put(`links.gap.${id}.read`, false); continue; }
      const names = Object.values(req.targets || {}).map(d => d.replace(/\..*$/, '')).join('+');
      put(`links.gap.${id}.rivals`, names);
      put(`links.gap.${id}.sites`, res.total_count);
      put(`links.gap.${id}.held`, res.items?.length ?? 0);
      put(`links.gap.${id}.stopped_at_limit`, (res.items?.length ?? 0) < res.total_count);
      for (const it of res.items || []) all.add(Object.values(it.domain_intersection || {})[0]?.target);
    }
    put('links.gap.sites_held_union', all.size);
  }
  // every place with a backlink pull in the full audit, and which of them sit out of market
  put('links.places_read', VR.filter(r => r.kind === 'bl_exhaustive').map(r => { const p = posOf(r.place_id); return `${nameOf(r.place_id)}${p && km(pin, p) > OUT_KM ? ' (out of market)' : ''}`; }).sort());
}

// ---------------------------------------------------------------- directory listings (citation_verdicts)
{
  const cv = T.citation_verdicts || [];
  put('cit.verdicts', cv.length);
  put('cit.by_verdict', tally(cv, v => v.verdict));
  put('cit.by_nap_status', tally(cv, v => v.nap_status || '(blank)'));
  put('cit.contested', tally(cv, v => v.contested));
  put('cit.control_ok', tally(cv, v => v.control_ok));
  put('cit.by_tier', tally(cv, v => v.tier));
  put('cit.by_next_action', tally(cv, v => v.next_action_code));
  put('cit.by_source_of_truth', tally(cv, v => v.source_of_truth));
  put('cit.listed', cv.filter(v => v.verdict === 'listed').map(v => `${v.domain} (${v.nap_status})`).sort());
  put('cit.not_listed', cv.filter(v => v.verdict === 'not-listed').map(v => v.domain).sort());
  const MI = /michigan|new[-\s]?buffalo|berrien/i;
  const mi = cv.filter(v => MI.test(`${v.source_id} ${v.domain}`));
  put('cit.sources_naming_michigan_places', mi.map(v => v.source_id).sort());
  put('cit.sources_naming_michigan_places_count', mi.length);
  put('cit.sources_naming_michigan_places_listed', mi.filter(v => v.verdict === 'listed').length);
  const probe = reading('cit_probe', SUBJ);
  put('cit.probe_sources', probe?.request?.sources?.length ?? null);
  put('cit.probe_sources_naming_michigan_places', (probe?.request?.sources || []).filter(s => MI.test(s)).length);
  // the directory pages read for the store: how many carry the Google spelling of the name
  const cp = reading('cit_pages', SUBJ);
  const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const titleRe = new RegExp(esc(storeBi.title).replace(/\s+/g, '\\s+'), 'i');
  const pagesWith = Object.entries(cp?.result || {}).filter(([n, v]) => /^page-\d+$/.test(n) && v?.items?.length);
  put('cit.pages_requested', cp?.request?.candidates?.length ?? null);
  put('cit.pages_with_content', pagesWith.length);
  put('cit.pages_naming_google_title', pagesWith.filter(([, v]) => titleRe.test(JSON.stringify(v))).length);
  // SEOS's JointCommerce task says the listing is not the Google spelling; check it against the verdict row and the page itself
  {
    const task = (T.tasks || []).find(x => /jointcommerce/i.test(x.statement || ''));
    const verdict = cv.find(v => v.domain === 'jointcommerce.com');
    const cand = (cp?.request?.candidates || []).findIndex(c => /jointcommerce\.com/i.test(c.url || ''));
    const page = cand >= 0 ? cp.result?.[`page-${cand}`] : null;
    put('cit.jointcommerce.task_says', task ? task.statement : null);
    put('cit.jointcommerce.verdict', verdict ? `${verdict.verdict} / ${verdict.nap_status}` : null);
    put('cit.jointcommerce.page_names_google_title', page?.items?.length ? titleRe.test(JSON.stringify(page)) : null);
    put('cit.jointcommerce.spelling_claim', task && verdict?.nap_status === 'nap-correct' && page?.items?.length && titleRe.test(JSON.stringify(page)) ? 'not confirmed' : (task ? 'unchecked' : null));
  }
  const sw = reading('cit_sweep', SUBJ);
  put('cit.sweep_queries', sw ? Object.keys(sw.request || {}).filter(x => /^nap-/.test(x)).length : null);
  put('cit.sweep_queries_refused', sw ? Object.keys(sw.errors || {}).length : null);
  put('cit.sweep_queries_partial', sw ? Object.values(sw.notes || {}).filter(n => /partial results/i.test(n)).length : null);
}

// ---------------------------------------------------------------- SEOS's own why-it-ranks layer
{
  const apex = [...(T.apex_runs || [])].sort((a, b) => String(a.created_at).localeCompare(String(b.created_at)));
  const last = apex[apex.length - 1];
  put('seos.apex_runs', apex.length);
  put('seos.apex_latest', last ? last.id : null);
  const sw = last ? mySweeps.find(s => s.solv === last.solv && s.arp === last.arp) : null;
  put('seos.apex_latest_matches_sweep', sw ? String(sw.scan_id) : null);
  put('seos.findings', (T.findings || []).length);
  put('seos.findings_by_run', tally(T.findings || [], f => f.run_id));
  put('seos.findings_by_dimension', tally(T.findings || [], f => f.dimension));
  const lf = (T.findings || []).filter(f => f.run_id === last?.id);
  put('seos.findings_latest', lf.length);
  put('seos.findings_latest_by_dimension', tally(lf, f => f.dimension));
  put('seos.findings_latest_codes', lf.map(f => f.code).sort());
  put('seos.findings_scan_ids', tally(T.findings || [], f => f.scan_id));
  put('seos.tasks', (T.tasks || []).length);
  put('seos.tasks_by_class', tally(T.tasks || [], x => x.class));
  put('seos.tasks_by_state', tally(T.tasks || [], x => x.state));
  put('seos.tasks_latest', (T.tasks || []).filter(x => x.run_id === last?.id).length);
  put('seos.run_factors', (T.run_factors || []).length);
  const sv = (T.run_factors || []).filter(f => f.survives_control);
  put('seos.factors_surviving_control', [...new Set(sv.map(f => f.factor))]);
  put('seos.factors_surviving_control_latest', sv.filter(f => f.run_id === last?.id).map(f => ({ factor: f.factor, rho: f.rho, partial_rho: f.partial_rho, n: f.n })));
  put('seos.factors_under_30_rows_latest', (T.run_factors || []).filter(f => f.run_id === last?.id && f.n < 30).map(f => f.factor));
  put('seos.model_versions', (T.model_versions || []).length);
  put('seos.model_population_n', [...new Set((T.model_versions || []).map(m => m.population_n))]);
  // reproduce "Distance from grid centre" (Spearman of the stored distance against share over every sweep row),
  // then again without the out-of-market rows: does the one surviving factor lean on them?
  const rankAvg = xs => { const idx = xs.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]); const r = new Array(xs.length); let i = 0; while (i < idx.length) { let j = i; while (j + 1 < idx.length && idx[j + 1][0] === idx[i][0]) j++; for (let q = i; q <= j; q++) r[idx[q][1]] = (i + j) / 2 + 1; i = j + 1; } return r; };
  const pearson = (x, y) => { const n = x.length, mx = sum(x) / n, my = sum(y) / n; let a = 0, b = 0, c = 0; for (let i = 0; i < n; i++) { a += (x[i] - mx) * (y[i] - my); b += (x[i] - mx) ** 2; c += (y[i] - my) ** 2; } return a / Math.sqrt(b * c); };
  const spear = rows => r4(pearson(rankAvg(rows.map(x => x.distance_km)), rankAvg(rows.map(x => x.solv))));
  // the rows the software's fit could have seen: sweeps finished before its latest model run (a scan folded in later from
  // another tool, such as Eagle Eyes 320, is not part of the fit being reproduced)
  const fitRun = [...(T.apex_runs || [])].sort((x, y) => String(y.created_at).localeCompare(String(x.created_at)))[0] || null, utc = t => Date.parse(/[zZ]|[+-][0-9][0-9]:?[0-9][0-9]$/.test(String(t)) ? t : t + 'Z');
  const fitSweeps = new Set((T.engine_sweeps || []).filter(w => !fitRun || utc(w.finished_at) <= utc(fitRun.created_at)).map(w => String(w.scan_id)));
  const ok = esb.filter(x => fitSweeps.has(String(x.scan_id)) && x.distance_km != null && x.solv != null);
  put('seos.distance_rho_reproduced_all_rows', spear(ok));
  put('seos.distance_rho_rows', ok.length);
  const inm = ok.filter(x => !(x.lat != null && km(pin, [x.lat, x.lng]) > OUT_KM));
  put('seos.distance_rho_without_out_of_market', spear(inm));
  put('seos.distance_rho_without_out_of_market_rows', inm.length);
  put('seos.rows_with_share_0', esb.filter(x => x.solv === 0).length);
  put('seos.evidence_rows', (T.evidence_rows || []).length);
  put('seos.task_briefs', (T.task_briefs || []).length);
  put('seos.pm_tasks', (T.pm_tasks || []).map(x => `${x.code}: ${x.pm_status_label}`));
  const cov = (T.run_coverage || []).filter(c => c.run_id === last?.id);
  for (const c of cov) put(`seos.coverage_latest.${c.surface}`, { attempted: c.attempted, obtained: c.obtained, blocked: c.blocked, absent_reason: c.absent_reason });
}

// ---------------------------------------------------------------- the runs and what they cost
{
  const vs = T.vendor_spend || [];
  for (const ar of T.audit_runs || []) {
    const k = `spend.run.${ar.id}`;
    const rows = vs.filter(s => s.run_id === ar.id);
    put(`${k}.what`, ar.keyword ? `full audit, "${ar.keyword}", scan ${ar.scan_id}` : (ar.request?.origin || 'run'));
    put(`${k}.billed_usd`, r6(sum(rows, s => s.usd)));
    put(`${k}.steps_billed_usd`, r6(sum(ar.steps || [], s => s.usd)));
    put(`${k}.estimate_usd`, ar.estimate_usd);
    put(`${k}.steps`, (ar.steps || []).length);
    put(`${k}.steps_by_state`, tally(ar.steps || [], s => s.state));
    put(`${k}.started_utc`, isoMin(toMs(ar.started_at)));
    put(`${k}.finished_utc`, isoMin(toMs(ar.finished_at)));
  }
  put('spend.rows', vs.length);
  put('spend.usd_all_rows', r6(sum(vs, s => s.usd)));
  const before = vs.filter(s => toMs(s.at) < created);
  put('spend.rows_dated_before_store_added', before.length);
  put('spend.usd_dated_before_store_added', r6(sum(before, s => s.usd)));
  put('spend.places_dated_before_store_added', [...new Set(before.map(s => nameOf(s.place_id)))].sort());
  put('spend.usd_for_this_store', r6(sum(vs.filter(s => toMs(s.at) >= created), s => s.usd)));
  put('spend.outside_runs_after_added', tally(vs.filter(s => !s.run_id && toMs(s.at) >= created), s => `${s.vendor}:${s.kind}`));
  put('spend.ai_usd', r6(sum(vs.filter(s => s.vendor === 'openai'), s => s.usd)));
  put('run.full.parts_on', Object.entries(run.request.parts || {}).filter(([, v]) => v).map(([n]) => n));
  put('run.full.parts_off', Object.entries(run.request.parts || {}).filter(([, v]) => !v).map(([n]) => n));
  put('run.full.reviews_option', run.request.parts?.reviews || null);
  put('run.full.field_measure_option', run.request.parts?.field_measure || null);
  put('run.full.refused_parts', sum(run.steps || [], s => s.refused || 0));
  put('run.full.site_audits_option', run.request.parts?.site_audits || null);
  put('run.full.exhaustive_option', run.request.parts?.exhaustive || null);
  put('run.web.parts_on', Object.entries(wrun.request.parts || {}).filter(([, v]) => v).map(([n]) => n));
  put('run.web.site_crawl_option', wrun.request.parts?.site_crawl || null);
  put('run.web.site_audits_option', wrun.request.parts?.site_audits || null);
}

// ---------------------------------------------------------------- the owner's markdown copy against the JSON
let mdDiff = null;
if (mdPath) {
  const FENCE = '`'.repeat(3);
  const text = fs.readFileSync(mdPath, 'utf8');
  const lines = text.split(/\r?\n/);
  const parts = {};
  let part = null, table = null, row = null, wide = null, pending = null, inFence = false, buf = [];
  const cellsOf = l => { const out = []; let cur = ''; for (let i = 0; i < l.length; i++) { const ch = l[i]; if (ch === '\\' && l[i + 1] === '|') { cur += '|'; i++; continue; } if (ch === '|') { out.push(cur); cur = ''; continue; } cur += ch; } out.push(cur); return out.slice(1, -1).map(x => x.trim()); };
  let fetchedLine = null;
  for (const l of lines) {
    if (inFence) { if (l.startsWith(FENCE)) { inFence = false; let v; try { v = JSON.parse(buf.join('\n')); } catch (e) { v = { __unparsed__: true }; } pending.target[pending.field] = { json: v }; pending = null; buf = []; } else buf.push(l); continue; }
    let m;
    if (!fetchedLine && (m = l.match(/^- \*\*Fetched:\*\* (\d{4}-\d\d-\d\d \d\d:\d\d UTC)/))) fetchedLine = m[1];
    if ((m = l.match(/^## Part (\d+)\./))) { part = (parts[m[1]] = { header: {}, tables: {} }); table = null; row = null; wide = null; continue; }
    if (!part) continue;
    if ((m = l.match(/^### `([^`]+)` \((\d+) rows?\)/))) { table = (part.tables[m[1]] = { declared: Number(m[2]), rows: [] }); row = null; wide = null; continue; }
    if ((m = l.match(/^#### `([^`]+)` row (\d+) - (.*)$/))) { row = {}; table.rows[Number(m[2]) - 1] = row; wide = null; continue; }
    if ((m = l.match(/^\*\*([^*]+)\*\* <!-- json p\d+\/[^/]+\/\d+\/.+? -->/))) { pending = { target: row, field: m[1] }; continue; }
    if (l.startsWith(FENCE + 'json') && pending) { inFence = true; buf = []; continue; }
    if (!table && (m = l.match(/^- \*\*([^*]+):\*\* (.*)$/))) { part.header[m[1]] = m[2]; continue; }
    if (table && l.startsWith('|')) {
      const c = cellsOf(l);
      if (row) { if (c[0] === 'field' || /^-+$/.test(c[0])) continue; row[c[0]] = { s: c.slice(1).join('|') }; continue; }
      if (!wide) { wide = c; continue; }
      if (c.every(x => /^-+$/.test(x))) continue;
      const o = {}; wide.forEach((col, i) => { if (col !== '#') o[col] = { s: c[i] }; }); table.rows[Number(c[0]) - 1] = o;
    }
  }
  const deep = (a, b, p, out) => {
    if (out.length > 200 || a === b) return out;
    if (typeof a === 'number' && typeof b === 'number') { if (a !== b) out.push(p); return out; }
    if (a === null || b === null || typeof a !== 'object' || typeof b !== 'object' || Array.isArray(a) !== Array.isArray(b)) { out.push(p); return out; }
    if (Array.isArray(a)) { if (a.length !== b.length) out.push(p + '.length'); for (let i = 0; i < Math.min(a.length, b.length); i++) deep(a[i], b[i], `${p}[${i}]`, out); return out; }
    for (const x of new Set([...Object.keys(a), ...Object.keys(b)])) { if (!(x in a) || !(x in b)) out.push(`${p}.${x}`); else deep(a[x], b[x], `${p}.${x}`, out); }
    return out;
  };
  const same = (s, v) => {
    if (s === '*null*') return v === null;
    if (s === '*""*') return v === '';
    if (v === null) return false;
    if (typeof v === 'boolean') return s === String(v);
    if (typeof v === 'number') return s !== '' && Number(s) === v;
    if (typeof v === 'string') return s === v || s === v.replace(/\r?\n/g, ' ');
    try { return deep(JSON.parse(s), v, '', []).length === 0; } catch { return false; }
  };
  const keyJ = (t, r) => t === 'vendor_readings' ? `${r.kind}|${r.place_id}` : String(r.id ?? r.scan_id ?? r.ver ?? r.place_id);
  const keyM = (t, r) => { const g = f => r[f] ? ('json' in r[f] ? r[f].json : r[f].s) : undefined; return t === 'vendor_readings' ? `${g('kind')}|${g('place_id')}` : String(g('id') ?? g('scan_id') ?? g('ver') ?? g('place_id')); };
  const answers = { 1: biz, 2: full, 3: web };
  const tables = [];
  for (const pn of ['1', '2', '3']) {
    const mp = parts[pn];
    if (!mp) die(`markdown has no Part ${pn}`);
    for (const [t, rows] of Object.entries(answers[pn].tables)) {
      const mt = mp.tables[t];
      const entry = { part: Number(pn), table: t, json_rows: rows.length, md_rows: mt ? mt.rows.filter(Boolean).length : null, rows_only_in_json: [], rows_only_in_md: [], field_differences: [] };
      if (!mt) { entry.missing_in_md = true; tables.push(entry); continue; }
      const J = new Map(rows.map(r => [keyJ(t, r), r])), M = new Map(mt.rows.filter(Boolean).map(r => [keyM(t, r), r]));
      entry.rows_only_in_json = [...J.keys()].filter(x => !M.has(x));
      entry.rows_only_in_md = [...M.keys()].filter(x => !J.has(x));
      for (const [id, jr] of J) {
        const mr = M.get(id); if (!mr) continue;
        for (const [f, v] of Object.entries(jr)) {
          const mv = mr[f];
          if (!mv) { entry.field_differences.push({ row: id, field: f, what: 'missing in markdown' }); continue; }
          if ('json' in mv) {
            const d = deep(mv.json, v, '', []);
            if (d.length) {
              const small = Buffer.byteLength(JSON.stringify(v)) < 2000 && Buffer.byteLength(JSON.stringify(mv.json)) < 2000;
              entry.field_differences.push({ row: id, field: f, paths: d, ...(small ? { markdown: scrub(mv.json), json: scrub(v) } : {}), json_minus_markdown_bytes: Buffer.byteLength(JSON.stringify(v)) - Buffer.byteLength(JSON.stringify(mv.json)) });
            }
          }
          else if (!same(mv.s, v)) entry.field_differences.push({ row: id, field: f, markdown: scrub(mv.s.slice(0, 300)), json: scrub(typeof v === 'string' ? v.slice(0, 300) : v) });
        }
        for (const f of Object.keys(mr)) if (!(f in jr)) entry.field_differences.push({ row: id, field: f, what: 'only in markdown' });
      }
      tables.push(entry);
    }
    for (const t of Object.keys(mp.tables)) if (!(t in answers[pn].tables)) tables.push({ part: Number(pn), table: t, missing_in_json: true });
  }
  const differing = tables.filter(e => e.missing_in_md || e.missing_in_json || e.rows_only_in_json?.length || e.rows_only_in_md?.length || e.field_differences?.length);
  // reconcile the byte sizes the markdown states for each answer against the JSON files
  const stated = {};
  for (const m of text.matchAll(/^\d+\. \[[^\]]+\]\(#part-(\d+)\) - `GET [^`]+` - (\d+) tables?, (\d+) rows?, ([\d,]+) bytes as JSON/gm)) stated[m[1]] = { tables: Number(m[2]), rows: Number(m[3]), bytes: Number(m[4].replace(/,/g, '')) };
  const fileOf = { 1: 'business-48.json', 2: 'full-audit-48.json', 3: 'website-audit-48.json' };
  const bytes = Object.fromEntries(Object.entries(stated).map(([pn, s]) => [fileOf[pn], { markdown_states: s.bytes, json_file: sources[fileOf[pn]].bytes, difference: sources[fileOf[pn]].bytes - s.bytes, markdown_rows: s.rows, json_rows: sum(Object.values(answers[pn].tables), v => Array.isArray(v) ? v.length : 0) }]));
  // the exact bytes of each JSON-only reading in the raw answer text, to see whether they explain the difference
  const rawRowBytes = (file, kind, pid) => {
    const raw = rawText[file]; const needle = `{"kind":"${kind}","place_id":"${pid}"`; const i = raw.indexOf(needle); if (i < 0) return null;
    let depth = 0, j = i, str = false;
    for (; j < raw.length; j++) { const ch = raw[j]; if (str) { if (ch === '\\') { j++; continue; } if (ch === '"') str = false; continue; } if (ch === '"') str = true; else if (ch === '{') depth++; else if (ch === '}') { depth--; if (depth === 0) break; } }
    return Buffer.byteLength(raw.slice(i, j + 1));
  };
  const onlyJ = differing.flatMap(e => (e.rows_only_in_json || []).map(id => ({ part: e.part, table: e.table, id })));
  const locName = pid => (locAll.rows || []).find(l => l.place_id === pid)?.name ?? null;
  const onlyJBytes = onlyJ.filter(o => o.table === 'vendor_readings').map(o => { const [kind, pid] = o.id.split('|'); return { ...o, about: locName(pid) ? `${locName(pid)} (another SEOS client)` : nameOf(pid), bytes_with_separator: (rawRowBytes(fileOf[o.part], kind, pid) ?? NaN) + 1, fetched_at: VR.concat(WVR).find(r => r.kind === kind && r.place_id === pid)?.fetched_at ?? null }; });
  mdDiff = { markdown_fetched: fetchedLine, markdown_bytes: Buffer.byteLength(text), tables_compared: tables.length, tables_differing: differing.length, differing, json_only_rows: onlyJBytes, bytes };
  put('md.tables_compared', tables.length);
  put('md.tables_differing', differing.map(e => `${e.part}:${e.table}`));
  put('md.rows_only_in_json', onlyJ.map(o => `${o.table}:${o.id}`));
  put('md.rows_only_in_md', differing.flatMap(e => (e.rows_only_in_md || []).map(id => `${e.table}:${id}`)));
  put('md.field_differences', differing.flatMap(e => (e.field_differences || []).map(d => `${e.table}:${d.row}:${d.field}`)));
  put('md.json_only_rows_bytes', sum(onlyJBytes, o => o.bytes_with_separator));
  put('md.json_only_rows_about', [...new Set(onlyJBytes.map(o => o.about))]);
  put('md.field_difference_bytes', sum(differing.flatMap(e => e.field_differences || []), d => d.json_minus_markdown_bytes || 0));
  put('md.markdown_fetched', fetchedLine);
  for (const [f, b] of Object.entries(bytes)) put(`md.bytes.${f}`, b);
}

// ---------------------------------------------------------------- write
const out = { generated_by: 'gh-facts.mjs', data: path.basename(path.resolve(dataDir)), sources, fact_count: Object.keys(F).length, facts: F };
if (mdDiff) out.md_diff = mdDiff;
const text = JSON.stringify(scrub(out), null, 1) + '\n';
if (/[?&](token|key|sig|signature|access_token)=/i.test(text)) die('a URL carrying a token reached the output');
fs.writeFileSync(outPath, text);
console.log(`wrote ${path.basename(outPath)}: ${Object.keys(F).length} facts from ${Object.keys(sources).length} files${mdDiff ? `; markdown diff: ${mdDiff.tables_differing} of ${mdDiff.tables_compared} tables differ` : ''}`);
